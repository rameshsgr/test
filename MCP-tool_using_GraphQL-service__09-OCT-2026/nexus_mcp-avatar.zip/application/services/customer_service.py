"""
application.services.customer_service
-------------------------------------

Orchestrates customer use-cases. Validates caller input at the boundary, then
delegates to the injected domain ports — a :class:`CustomerGateway` (MDM) and an
:class:`EligibilityGateway` (GDH). Holds no I/O of its own.
"""

from __future__ import annotations

from typing import Any

from core.validation import normalize_ssn, require_non_empty
from domain.entities.customer import Customer
from domain.interfaces.coverage_gateway import CoverageGateway
from domain.interfaces.customer_gateway import CustomerGateway
from domain.interfaces.eligibility_gateway import EligibilityGateway


class CustomerService:
    def __init__(
        self,
        customer_gateway: CustomerGateway,
        eligibility_gateway: EligibilityGateway,
        coverage_gateway: CoverageGateway,
    ) -> None:
        self._customers = customer_gateway
        self._eligibility = eligibility_gateway
        self._coverage = coverage_gateway

    async def search_customer_by_ssn(self, ssn: str) -> list[dict[str, Any]]:
        return await self._customers.search_customer_by_ssn(normalize_ssn(ssn))

    async def search_customer_by_umid(self, umid: str) -> list[dict[str, Any]]:
        return await self._customers.search_customer_by_umid(require_non_empty(umid, "UMID"))

    async def get_customer_details_by_ssn(self, ssn: str) -> list[dict[str, Any]]:
        return await self._customers.get_customer_details_by_ssn(normalize_ssn(ssn))

    async def get_customer_details_by_umid(self, umid: str) -> list[dict[str, Any]]:
        return await self._customers.get_customer_details_by_umid(require_non_empty(umid, "UMID"))

    async def get_customer_eligibility_details(self, customer: Customer) -> dict[str, Any]:
        return await self._eligibility.get_eligibility(customer)

    async def get_member_coverage_by_id(self, customer_id: int) -> list[dict[str, Any]]:
        return await self._coverage.get_member_coverage_by_id(customer_id)
