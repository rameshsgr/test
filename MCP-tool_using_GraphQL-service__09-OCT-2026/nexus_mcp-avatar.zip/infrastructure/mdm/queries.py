"""
infrastructure.mdm.queries
---------------------------

GraphQL query documents for the MDM customer API.

The ``idNumber`` is passed as a **GraphQL variable** (``$idNumber``) rather than
interpolated into the query string. This keeps the payload flexible JSON and
prevents GraphQL injection — the search value is never concatenated into the
document.
"""

from __future__ import annotations

# Full customer detail projection, searched by an identifier number + type.
# Used for both SSN and UMID detail lookups by varying `idType` at call time.
CUSTOMER_DETAILS_QUERY = """
query CustomerSearch($idNumber: String!, $idType: String!) {
  searchCustomer(
    searchCustomerRequest: {
      validationStatus: "all"
      customerSource: "ELGBTY"
      idNumber: $idNumber
      idSearchType: "Exact"
      idType: $idType
    }
  ) {
    pageInfo {
      startCursor
      endCursor
      hasNextPage
      hasPreviousPage
    }
    edges {
      cursor
      node {
        umid
        status
        requestedUmidMergeStatus

        customerDetails {
          idType
          idNumber
          dateOfBirth
          gender
          prefix
          firstName
          middleName
          lastName
          suffix
          maritalStatus
          sourceSystem
          sourceSystemId
          lastUpdated

          addresses {
            addressType
            addressLine1
            addressLine2
            addressLine3
            addressLine4
            city
            state
            postalCode
            county
            country
            effectiveDate
            expiryDate
            lastUpdated
          }

          contacts {
            contactType
            effectiveDate
            expiryDate
            phoneNumber
            emailAddress
            preferred
            lastUpdated
          }

          customerModificationDetails {
            lastUpdated
          }

          customerOccupation {
            client
            clientName
            empId
            dateOfHire
            employmentStatus
            employmentStatusEffectiveDate
            terminationDate
            sourceSystem
            employmentLastUpdatedTimestamp
          }
        }

        externalSystemKeys {
          sourceSystem
          sourceSystemId
          sourceSystemIdStatus
          sourceSystemIdStatusTimestamp
        }
      }
    }
  }
}
""".strip()


def build_details_payload(id_number: str, id_type: str) -> dict:
    """Build the flexible-JSON GraphQL request body for a customer detail search."""
    return {
        "operationName": "CustomerSearch",
        "query": CUSTOMER_DETAILS_QUERY,
        "variables": {"idNumber": id_number, "idType": id_type},
    }


def build_member_coverage_payload(customer_id: int) -> dict:
    """Build the GraphQL request body for a member-coverage lookup by customer id.

    ``customer_id`` is coerced to ``int`` before interpolation, so the identifier
    cannot carry a GraphQL-injection payload even though it is inlined into the
    query document.
    """
    query = (
        "query { memberCoverage(customerId: %d) "
        "{ memberName employer benefitType benefitName } }" % int(customer_id)
    )
    return {"query": query}
