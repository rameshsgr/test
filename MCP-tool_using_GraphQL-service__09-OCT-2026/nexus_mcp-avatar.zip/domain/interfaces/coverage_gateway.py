"""
domain.interfaces.coverage_gateway
-----------------------------------

Port for member-coverage lookups (benefits a customer is covered for).
Implemented by ``infrastructure/mdm/gateway.py`` against the member-coverage
GraphQL endpoint.

Methods return raw decoded JSON (``list[dict]``); typed mapping can be layered
in once the full attribute set is confirmed.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class CoverageGateway(ABC):
    @abstractmethod
    async def get_member_coverage_by_id(self, customer_id: int) -> list[dict[str, Any]]:
        """Return the coverage records for a customer id."""
