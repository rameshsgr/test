# Usage:  $env:TESTKEY = "<your-api-key>";  .\probe_apikey.ps1
# The key is read from the TESTKEY env var so it never gets hard-coded in the file.
$key = $env:TESTKEY
if ([string]::IsNullOrWhiteSpace($key)) { Write-Host "Set `$env:TESTKEY first."; exit 1 }

$uri  = "http://127.0.0.1:8241/graphql"
$body = '{"query":"query { memberCoverage(customerId: 48) { memberName employer benefitType benefitName } }"}'

$variants = @(
  @{ name = "X-API-Key";            h = @{ "X-API-Key" = $key } },
  @{ name = "x-api-key";            h = @{ "x-api-key" = $key } },
  @{ name = "apikey";               h = @{ "apikey" = $key } },
  @{ name = "api-key";              h = @{ "api-key" = $key } },
  @{ name = "X-Api-Key";            h = @{ "X-Api-Key" = $key } },
  @{ name = "Authorization Bearer"; h = @{ "Authorization" = "Bearer $key" } },
  @{ name = "Authorization ApiKey"; h = @{ "Authorization" = "ApiKey $key" } }
)

foreach ($v in $variants) {
  try {
    $r = Invoke-RestMethod -Uri $uri -Method Post -ContentType "application/json" -Headers $v.h -Body $body
    "{0,-22} -> OK  {1}" -f $v.name, (($r | ConvertTo-Json -Depth 6 -Compress))
  } catch {
    "{0,-22} -> 401/err: {1}" -f $v.name, $_.Exception.Message
  }
}
