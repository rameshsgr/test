-- =====================================================================
-- Group Insurance — schema DDL (H2, PostgreSQL compatibility mode)
-- Translated from database/schema.sql.
-- Start the H2 server / connection with MODE=PostgreSQL, e.g.
--   jdbc:h2:mem:group_insurance;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE
-- Differences from the Postgres DDL:
--   JSONB -> JSON, TEXT -> VARCHAR, now() -> CURRENT_TIMESTAMP,
--   no BEGIN/COMMIT wrapper (H2 auto-commits DDL).
-- =====================================================================

DROP TABLE IF EXISTS tool_registry, external_lookup, payment, claim_document,
  claim_event, claim, beneficiary, dependent, enrollment, benefit, policy,
  customer, client, address, region_ref CASCADE;

-- ---------- Reference ----------
CREATE TABLE region_ref (
  region_code   VARCHAR(20) PRIMARY KEY,
  region_name   VARCHAR(60) NOT NULL,
  default_currency CHAR(3) NOT NULL,
  privacy_regime   VARCHAR(40)
);

CREATE TABLE address (
  address_id    BIGINT PRIMARY KEY,
  line1         VARCHAR(120),
  line2         VARCHAR(120),
  city          VARCHAR(80),
  state_province VARCHAR(80),
  postal_code   VARCHAR(20),
  country_code  CHAR(2),
  region        VARCHAR(20) REFERENCES region_ref(region_code),
  geo_lat       DECIMAL(9,6),
  geo_lng       DECIMAL(9,6)
);

-- ---------- Parties ----------
CREATE TABLE client (
  client_id            BIGINT PRIMARY KEY,
  client_legal_name    VARCHAR(200) NOT NULL,
  dba_name             VARCHAR(200),
  tax_id               VARCHAR(40),
  industry_code        VARCHAR(10),
  employee_count_band  VARCHAR(20),
  region               VARCHAR(20) NOT NULL REFERENCES region_ref(region_code),
  country_code         CHAR(2),
  hq_address_id        BIGINT REFERENCES address(address_id),
  billing_address_id   BIGINT REFERENCES address(address_id),
  account_manager_id   BIGINT,
  status               VARCHAR(20) DEFAULT 'Prospect',
  effective_date       DATE,
  termination_date     DATE,
  mdm_client_ref       VARCHAR(64),
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customer (
  customer_id            BIGINT PRIMARY KEY,
  client_id              BIGINT NOT NULL REFERENCES client(client_id),
  first_name             VARCHAR(80),
  middle_name            VARCHAR(80),
  last_name              VARCHAR(80),
  date_of_birth          DATE,
  gender                 VARCHAR(20),
  national_id            VARCHAR(64),
  email                  VARCHAR(160),
  phone                  VARCHAR(40),
  hire_date              DATE,
  employment_status      VARCHAR(20),
  job_title              VARCHAR(100),
  department             VARCHAR(80),
  annual_salary          DECIMAL(14,2),
  salary_currency        CHAR(3),
  region                 VARCHAR(20) NOT NULL REFERENCES region_ref(region_code),
  country_code           CHAR(2),
  residential_address_id BIGINT REFERENCES address(address_id),
  mdm_customer_ref       VARCHAR(64),
  created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dependent (
  dependent_id  BIGINT PRIMARY KEY,
  customer_id   BIGINT NOT NULL REFERENCES customer(customer_id),
  relationship  VARCHAR(20),
  first_name    VARCHAR(80),
  last_name     VARCHAR(80),
  date_of_birth DATE,
  national_id   VARCHAR(64)
);

-- ---------- Product ----------
CREATE TABLE policy (
  policy_id           BIGINT PRIMARY KEY,
  policy_number       VARCHAR(40) UNIQUE,
  client_id           BIGINT NOT NULL REFERENCES client(client_id),
  product_line        VARCHAR(20),
  carrier_underwriter VARCHAR(120),
  funding_type        VARCHAR(20),
  coverage_start_date DATE,
  coverage_end_date   DATE,
  renewal_date        DATE,
  premium_amount      DECIMAL(14,2),
  premium_frequency   VARCHAR(20),
  currency            CHAR(3),
  status              VARCHAR(20),
  mdm_policy_ref      VARCHAR(64)
);

CREATE TABLE benefit (
  benefit_id             BIGINT PRIMARY KEY,
  policy_id              BIGINT NOT NULL REFERENCES policy(policy_id),
  benefit_type           VARCHAR(20),
  benefit_name           VARCHAR(120),
  coverage_amount        DECIMAL(14,2),
  income_replacement_pct DECIMAL(5,2),
  elimination_period_days INT,
  max_benefit_period     VARCHAR(40),
  waiting_period_days    INT,
  deductible             DECIMAL(14,2),
  coinsurance            DECIMAL(5,2),
  oop_max                DECIMAL(14,2),
  benefit_currency       CHAR(3),
  is_active              BOOLEAN DEFAULT TRUE
);

-- ---------- Election ----------
CREATE TABLE enrollment (
  enrollment_id        BIGINT PRIMARY KEY,
  customer_id          BIGINT NOT NULL REFERENCES customer(customer_id),
  benefit_id           BIGINT NOT NULL REFERENCES benefit(benefit_id),
  policy_id            BIGINT REFERENCES policy(policy_id),
  coverage_tier        VARCHAR(20),
  elected_amount       DECIMAL(14,2),
  enrollment_channel   VARCHAR(20),
  enrollment_date      DATE,
  effective_date       DATE NOT NULL,
  end_date             DATE,
  status               VARCHAR(20) DEFAULT 'Pending',
  evidence_of_insurability VARCHAR(20),
  CONSTRAINT uq_enrollment UNIQUE (customer_id, benefit_id, effective_date)
);

CREATE TABLE beneficiary (
  beneficiary_id BIGINT PRIMARY KEY,
  enrollment_id  BIGINT NOT NULL REFERENCES enrollment(enrollment_id),
  customer_id    BIGINT REFERENCES customer(customer_id),
  full_name      VARCHAR(160),
  relationship   VARCHAR(30),
  percentage     DECIMAL(5,2)
);

-- ---------- Service ----------
CREATE TABLE claim (
  claim_id             BIGINT PRIMARY KEY,
  claim_number         VARCHAR(40) UNIQUE,
  enrollment_id        BIGINT NOT NULL REFERENCES enrollment(enrollment_id),
  claimant_customer_id BIGINT REFERENCES customer(customer_id),
  claim_type           VARCHAR(20),
  date_of_loss         DATE,
  date_reported        DATE,
  diagnosis_code       VARCHAR(20),
  cause_of_loss        VARCHAR(120),
  disability_start     DATE,
  disability_end       DATE,
  return_to_work_date  DATE,
  status               VARCHAR(20) DEFAULT 'FNOL',
  adjudicator_id       BIGINT,
  approved_amount      DECIMAL(14,2),
  paid_amount          DECIMAL(14,2),
  fineos_case_ref      VARCHAR(64),
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE claim_event (
  event_id     BIGINT PRIMARY KEY,
  claim_id     BIGINT NOT NULL REFERENCES claim(claim_id),
  event_type   VARCHAR(40),
  status_from  VARCHAR(20),
  status_to    VARCHAR(20),
  actor        VARCHAR(80),
  event_ts     TIMESTAMP,
  note         VARCHAR
);

CREATE TABLE claim_document (
  doc_id        BIGINT PRIMARY KEY,
  claim_id      BIGINT NOT NULL REFERENCES claim(claim_id),
  doc_type      VARCHAR(40),
  storage_uri   VARCHAR(200),
  received_date DATE
);

CREATE TABLE payment (
  payment_id   BIGINT PRIMARY KEY,
  claim_id     BIGINT NOT NULL REFERENCES claim(claim_id),
  gross_amount DECIMAL(14,2),
  net_amount   DECIMAL(14,2),
  method       VARCHAR(20),
  payee_name   VARCHAR(160),
  currency     CHAR(3),
  payment_date DATE
);

-- ---------- Integration & Capability ----------
CREATE TABLE external_lookup (
  lookup_id        BIGINT PRIMARY KEY,
  source_system    VARCHAR(30),
  entity_type      VARCHAR(30),
  entity_id        BIGINT,
  endpoint         VARCHAR(200),
  request_payload  JSON,
  response_payload JSON,
  status           VARCHAR(20),
  latency_ms       INT,
  created_at       TIMESTAMP
);

CREATE TABLE tool_registry (
  tool_id       BIGINT PRIMARY KEY,
  tool_name     VARCHAR(60) UNIQUE,
  operation     VARCHAR(20),
  input_schema  JSON,
  output_schema JSON,
  backing_view  VARCHAR(80),
  scope         VARCHAR(40),
  is_enabled    BOOLEAN DEFAULT TRUE
);

-- ---------- Helpful indexes ----------
CREATE INDEX idx_customer_client   ON customer(client_id);
CREATE INDEX idx_customer_region   ON customer(region);
CREATE INDEX idx_policy_client     ON policy(client_id);
CREATE INDEX idx_benefit_policy    ON benefit(policy_id);
CREATE INDEX idx_enrollment_cust   ON enrollment(customer_id);
CREATE INDEX idx_enrollment_benef  ON enrollment(benefit_id);
CREATE INDEX idx_claim_enrollment  ON claim(enrollment_id);
CREATE INDEX idx_claim_status      ON claim(status);
CREATE INDEX idx_claim_event_claim ON claim_event(claim_id);
