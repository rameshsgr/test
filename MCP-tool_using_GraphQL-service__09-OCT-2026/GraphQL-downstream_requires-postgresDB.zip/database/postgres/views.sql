-- =====================================================================
-- Backing views for the MCP tool_registry (curated, join-ready read models)
-- =====================================================================
BEGIN;

DROP VIEW IF EXISTS v_member_coverage, v_eligibility, v_claim_status,
  v_client_summary, v_regional_stats CASCADE;

-- get_member_coverage : a member's active elected coverage
CREATE VIEW v_member_coverage AS
SELECT cu.customer_id,
       cu.first_name || ' ' || cu.last_name AS member_name,
       cu.region, cu.country_code,
       cl.client_id, cl.dba_name AS employer,
       e.enrollment_id, e.coverage_tier, e.elected_amount, e.effective_date, e.end_date,
       b.benefit_id, b.benefit_type, b.benefit_name, b.benefit_currency,
       p.policy_number, p.product_line
FROM customer cu
JOIN client   cl ON cu.client_id = cl.client_id
JOIN enrollment e ON e.customer_id = cu.customer_id AND e.status = 'Enrolled'
JOIN benefit  b  ON e.benefit_id = b.benefit_id
JOIN policy   p  ON b.policy_id = p.policy_id;

-- find_eligible_benefits : benefits offered by a member's employer, with eligibility
CREATE VIEW v_eligibility AS
SELECT cu.customer_id,
       cu.first_name || ' ' || cu.last_name AS member_name,
       cu.region, cu.hire_date,
       b.benefit_id, b.benefit_type, b.benefit_name, b.waiting_period_days,
       (cu.hire_date + (COALESCE(b.waiting_period_days,0) || ' days')::interval)::date AS eligible_on,
       (CURRENT_DATE >= cu.hire_date + (COALESCE(b.waiting_period_days,0) || ' days')::interval) AS is_eligible,
       EXISTS (SELECT 1 FROM enrollment e
               WHERE e.customer_id = cu.customer_id
                 AND e.benefit_id = b.benefit_id
                 AND e.status = 'Enrolled') AS already_enrolled
FROM customer cu
JOIN policy  p ON p.client_id = cu.client_id
JOIN benefit b ON b.policy_id = p.policy_id
WHERE b.is_active;

-- get_claim_status : claim header + its latest event
CREATE VIEW v_claim_status AS
SELECT c.claim_id, c.claim_number, c.claim_type, c.status,
       c.date_of_loss, c.date_reported, c.disability_start, c.disability_end,
       c.return_to_work_date, c.approved_amount, c.paid_amount, c.fineos_case_ref,
       cu.customer_id, cu.first_name || ' ' || cu.last_name AS claimant_name, cu.region,
       le.event_ts  AS last_event_ts,
       le.status_to AS last_status,
       le.actor     AS last_actor,
       le.note      AS last_note
FROM claim c
JOIN customer cu ON c.claimant_customer_id = cu.customer_id
LEFT JOIN LATERAL (
    SELECT ce.event_ts, ce.status_to, ce.actor, ce.note
    FROM claim_event ce
    WHERE ce.claim_id = c.claim_id
    ORDER BY ce.event_ts DESC
    LIMIT 1
) le ON TRUE;

-- lookup_client_summary : per-employer rollup
CREATE VIEW v_client_summary AS
SELECT cl.client_id, cl.dba_name AS employer, cl.client_legal_name,
       cl.region, cl.country_code, cl.status, cl.employee_count_band,
       COUNT(DISTINCT p.policy_id)  AS policies,
       COUNT(DISTINCT b.benefit_id) AS benefits,
       COUNT(DISTINCT e.customer_id) FILTER (WHERE e.status = 'Enrolled') AS enrolled_members,
       ARRAY_AGG(DISTINCT p.product_line) AS product_lines
FROM client cl
LEFT JOIN policy     p ON p.client_id = cl.client_id
LEFT JOIN benefit    b ON b.policy_id = p.policy_id
LEFT JOIN enrollment e ON e.benefit_id = b.benefit_id
GROUP BY cl.client_id, cl.dba_name, cl.client_legal_name, cl.region,
         cl.country_code, cl.status, cl.employee_count_band;

-- regional_benefit_stats : book-of-business aggregates by region & benefit type
CREATE VIEW v_regional_stats AS
SELECT cu.region, b.benefit_type,
       COUNT(DISTINCT e.enrollment_id)                       AS enrolled_members,
       COUNT(DISTINCT cl.claim_id)                           AS claims,
       COUNT(DISTINCT cl.claim_id) FILTER (WHERE cl.status IN ('Paid','Closed')) AS paid_claims,
       COALESCE(SUM(cl.paid_amount), 0)                      AS total_paid
FROM enrollment e
JOIN customer cu ON e.customer_id = cu.customer_id
JOIN benefit  b  ON e.benefit_id = b.benefit_id
LEFT JOIN claim cl ON cl.enrollment_id = e.enrollment_id
WHERE e.status = 'Enrolled'
GROUP BY cu.region, b.benefit_type;

COMMIT;
