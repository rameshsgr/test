# Group Insurance — GraphQL Downstream Service

A Python **GraphQL** surface over the same local Postgres `group_insurance`
database that the MCP server (`server.py`) and REST API (`rest_api.py`) use.

- **Queries** read from the curated `v_*` views defined in `views.sql`.
- **Mutations** perform guarded writes against the base tables in `schema.sql`.

**Stack:** FastAPI · [Strawberry GraphQL](https://strawberry.rocks) · asyncpg
**Default port:** `8241` (MCP = 8239, REST = 8240)

```
graphql-downstream/
├── app/
│   ├── config.py      # env-driven settings (PG*, API_KEY, port)
│   ├── db.py          # asyncpg pool + helpers
│   ├── types.py       # GraphQL types (views + tables)
│   ├── queries.py     # Query resolvers  (reads via v_* views)
│   ├── mutations.py   # Mutation resolvers (guarded writes)
│   ├── schema.py      # Strawberry schema assembly
│   └── main.py        # FastAPI app + auth + GraphiQL
├── requirements.txt
└── .env.example
```

---

## 1. Prerequisites

- PostgreSQL running locally with the `group_insurance` database loaded
  (`schema.sql`, `views.sql`, and `data.sql` from the parent folder applied).
- Python 3.10+.

## 2. Install & run

From the `graphql-downstream/` folder:

```bash
# Using uv (this repo already uses uv)
uv pip install -r requirements.txt
uv run uvicorn app.main:app --port 8241

# …or plain pip / venv
python -m venv .venv && source .venv/Scripts/activate   # Windows Git Bash
pip install -r requirements.txt
uvicorn app.main:app --port 8241
```

Override DB / port / key with env vars (see `.env.example`):

```bash
PGPASSWORD=secret GRAPHQL_PORT=8241 API_KEY=mykey uv run uvicorn app.main:app --port 8241
```

- **GraphiQL playground (browser):** http://127.0.0.1:8241/graphql
- **Health check:** http://127.0.0.1:8241/health

## 3. Auth

The playground (GET) loads without a key. Actual GraphQL operations (POST) require
the static key — same default as the REST API — in **either** header:

```
X-API-Key: 1234567890
Authorization: Bearer 1234567890
```

In GraphiQL, add it under **Headers**:
```json
{ "X-API-Key": "1234567890" }
```

---

## 4. Sample requests & responses

All examples POST to `http://127.0.0.1:8241/graphql`.

### 4.1 Query — a member's active coverage

```graphql
query {
  memberCoverage(customerId: 16) {
    memberName
    employer
    benefitType
    benefitName
    coverageTier
    electedAmount
    effectiveDate
  }
}
```

curl:
```bash
curl -s http://127.0.0.1:8241/graphql \
  -H "Content-Type: application/json" \
  -H "X-API-Key: 1234567890" \
  -d '{"query":"{ memberCoverage(customerId: 16) { memberName employer benefitType benefitName coverageTier electedAmount effectiveDate } }"}'
```

Response:
```json
{
  "data": {
    "memberCoverage": [
      {
        "memberName": "Grace Hopper",
        "employer": "Wonka Industries",
        "benefitType": "LTD",
        "benefitName": "Long Term Disability",
        "coverageTier": "Employee",
        "electedAmount": 6000.0,
        "effectiveDate": "2025-01-01"
      }
    ]
  }
}
```

### 4.2 Query — eligible (not-yet-enrolled) benefits

```graphql
query {
  eligibleBenefits(customerId: 75, onlyEligible: true) {
    benefitType
    benefitName
    waitingPeriodDays
    eligibleOn
    isEligible
    alreadyEnrolled
  }
}
```

Response:
```json
{
  "data": {
    "eligibleBenefits": [
      {
        "benefitType": "MEDICAL",
        "benefitName": "PPO Health Plan",
        "waitingPeriodDays": 30,
        "eligibleOn": "2025-02-15",
        "isEligible": true,
        "alreadyEnrolled": false
      }
    ]
  }
}
```

### 4.3 Query — claim status by claim number

```graphql
query {
  claimStatus(claimNumber: "CLM-2025-00002") {
    claimNumber
    claimType
    status
    claimantName
    approvedAmount
    paidAmount
    lastStatus
    lastActor
    lastEventTs
  }
}
```

Response:
```json
{
  "data": {
    "claimStatus": [
      {
        "claimNumber": "CLM-2025-00002",
        "claimType": "STD",
        "status": "In Review",
        "claimantName": "Alan Turing",
        "approvedAmount": null,
        "paidAmount": null,
        "lastStatus": "In Review",
        "lastActor": "adjudicator-7",
        "lastEventTs": "2025-08-20T14:05:00"
      }
    ]
  }
}
```

### 4.4 Query — regional book-of-business stats

```graphql
query {
  regionalStats(region: "EUROPE") {
    region
    benefitType
    enrolledMembers
    claims
    paidClaims
    totalPaid
  }
}
```

### 4.5 Mutation — open a new claim (FNOL, guarded)

The resolver checks that the enrollment exists **and** is `Enrolled`, derives
`claimType` from the benefit, allocates a `CLM-YYYY-#####` number, and seeds an
opening event.

```graphql
mutation {
  createClaim(input: {
    enrollmentId: 2
    dateOfLoss: "2025-08-15"
    causeOfLoss: "Back injury"
    claimType: "STD"
  }) {
    claimId
    claimNumber
    status
    claimType
    dateOfLoss
  }
}
```

curl:
```bash
curl -s http://127.0.0.1:8241/graphql \
  -H "Content-Type: application/json" \
  -H "X-API-Key: 1234567890" \
  -d '{"query":"mutation { createClaim(input: { enrollmentId: 2, dateOfLoss: \"2025-08-15\", causeOfLoss: \"Back injury\", claimType: \"STD\" }) { claimId claimNumber status claimType dateOfLoss } }"}'
```

Response:
```json
{
  "data": {
    "createClaim": {
      "claimId": 1001,
      "claimNumber": "CLM-2025-01001",
      "status": "FNOL",
      "claimType": "STD",
      "dateOfLoss": "2025-08-15"
    }
  }
}
```

Guard failure (enrollment not `Enrolled`) returns a GraphQL error:
```json
{
  "data": null,
  "errors": [
    { "message": "enrollment 2 is 'Pending', must be 'Enrolled' to open a claim" }
  ]
}
```

### 4.6 Mutation — advance a claim via an event

```graphql
mutation {
  addClaimEvent(input: {
    claimId: 1001
    eventType: "STATUS_CHANGE"
    statusTo: "In Review"
    actor: "adjudicator-7"
    note: "Medical records requested"
  }) {
    eventId
    statusFrom
    statusTo
    eventTs
  }
}
```

### 4.7 Mutation — record a payment

Also increments `claim.paid_amount`.

```graphql
mutation {
  recordPayment(input: {
    claimId: 1001
    grossAmount: 3000.00
    netAmount: 2550.00
    method: "ACH"
    payeeName: "Alan Turing"
    currency: "USD"
  }) {
    paymentId
    netAmount
    method
    paymentDate
  }
}
```

### 4.8 Other mutations

- `createClient(input: { clientLegalName, region, ... })`
- `createCustomer(input: { clientId, firstName, lastName, region, ... })`
- `createEnrollment(input: { customerId, benefitId, effectiveDate, ... })`
- `updateEnrollmentStatus(enrollmentId: 5, status: "Enrolled")`

---

## 5. Full operation list

| Type     | Operation                | Backed by |
|----------|--------------------------|-----------|
| Query    | `memberCoverage`         | `v_member_coverage` |
| Query    | `eligibleBenefits`       | `v_eligibility` |
| Query    | `claimStatus`            | `v_claim_status` |
| Query    | `clientSummary`          | `v_client_summary` |
| Query    | `regionalStats`          | `v_regional_stats` |
| Query    | `clients`                | `client` |
| Query    | `customers`              | `customer` |
| Query    | `enrollments`            | `enrollment` |
| Query    | `claims`                 | `claim` |
| Query    | `claimEvents`            | `claim_event` |
| Query    | `payments`               | `payment` |
| Mutation | `createClient`           | `client` |
| Mutation | `createCustomer`         | `customer` |
| Mutation | `createEnrollment`       | `enrollment` |
| Mutation | `updateEnrollmentStatus` | `enrollment` |
| Mutation | `createClaim`            | `claim` (+ `claim_event`) |
| Mutation | `addClaimEvent`          | `claim_event` (+ `claim`) |
| Mutation | `recordPayment`          | `payment` (+ `claim`) |

> Sample IDs/values above are illustrative; actual values depend on `data.sql`.
