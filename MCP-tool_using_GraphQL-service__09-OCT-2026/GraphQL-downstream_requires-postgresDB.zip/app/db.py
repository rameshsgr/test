"""DB access layer.

Two interchangeable backends behind one async API, chosen by DATASOURCE:
  * postgres -> asyncpg          (native async, $1 placeholders)
  * java     -> psycopg + H2     (H2's PG wire server)

H2's PG server rejects asyncpg's binary/extended protocol, so the java path
uses psycopg with ClientCursor (client-side binding, simple query protocol).
psycopg is synchronous here and runs in a thread; each acquired connection is
pinned to a single worker thread so transactions stay on one thread.
"""
from __future__ import annotations
import asyncio
import concurrent.futures
import re
from decimal import Decimal
from typing import Any, Optional

from .config import settings

_IS_JAVA = settings.datasource == "java"

_asyncpg_pool: Any = None   # asyncpg.Pool
_psycopg_pool: Any = None   # psycopg_pool.ConnectionPool

# $1, $2 (asyncpg) -> %(p1)s, %(p2)s (psycopg named params)
_PARAM_RE = re.compile(r"\$(\d+)")


def _to_named(query: str) -> str:
    return _PARAM_RE.sub(lambda m: f"%(p{m.group(1)})s", query)


def _named_params(args: tuple) -> Optional[dict]:
    return {f"p{i}": a for i, a in enumerate(args, 1)} if args else None


def _coerce(value: Any) -> Any:
    """Make driver scalars JSON/GraphQL friendly (Decimal -> float)."""
    if isinstance(value, Decimal):
        return float(value)
    return value


def row_to_dict(row: Any) -> dict[str, Any]:
    return {k: _coerce(v) for k, v in dict(row).items()}


# ------------------------------------------------------------------ lifecycle
async def connect() -> None:
    global _asyncpg_pool, _psycopg_pool
    if _IS_JAVA:
        if _psycopg_pool is None:
            from psycopg import ClientCursor
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool

            _psycopg_pool = ConnectionPool(
                conninfo=settings.dsn,
                min_size=1,
                max_size=10,
                open=False,
                kwargs={
                    "autocommit": True,
                    "cursor_factory": ClientCursor,
                    "row_factory": dict_row,
                },
            )
            await asyncio.to_thread(_psycopg_pool.open, wait=True)
    else:
        if _asyncpg_pool is None:
            import asyncpg

            _asyncpg_pool = await asyncpg.create_pool(dsn=settings.dsn, min_size=1, max_size=10)


async def disconnect() -> None:
    global _asyncpg_pool, _psycopg_pool
    if _asyncpg_pool is not None:
        await _asyncpg_pool.close()
        _asyncpg_pool = None
    if _psycopg_pool is not None:
        await asyncio.to_thread(_psycopg_pool.close)
        _psycopg_pool = None


def pool() -> Any:
    """Connection pool / acquirer. Mirrors asyncpg's Pool.acquire() surface."""
    if _IS_JAVA:
        if _psycopg_pool is None:
            raise RuntimeError("DB pool not initialised — did the app start up?")
        return _JavaPool()
    if _asyncpg_pool is None:
        raise RuntimeError("DB pool not initialised — did the app start up?")
    return _asyncpg_pool


# --------------------------------------------------------- module read helpers
async def fetch(query: str, *args: Any) -> list[dict[str, Any]]:
    if _IS_JAVA:
        rows = await asyncio.to_thread(_sync_query, query, args, "all")
        return [{k: _coerce(v) for k, v in r.items()} for r in rows]
    async with _asyncpg_pool.acquire() as conn:
        rows = await conn.fetch(query, *args)
    return [row_to_dict(r) for r in rows]


async def fetchrow(query: str, *args: Any) -> Optional[dict[str, Any]]:
    if _IS_JAVA:
        row = await asyncio.to_thread(_sync_query, query, args, "one")
        return {k: _coerce(v) for k, v in row.items()} if row is not None else None
    async with _asyncpg_pool.acquire() as conn:
        row = await conn.fetchrow(query, *args)
    return row_to_dict(row) if row is not None else None


async def fetchval(query: str, *args: Any) -> Any:
    if _IS_JAVA:
        return _coerce(await asyncio.to_thread(_sync_query, query, args, "val"))
    async with _asyncpg_pool.acquire() as conn:
        return _coerce(await conn.fetchval(query, *args))


async def execute(query: str, *args: Any) -> None:
    if _IS_JAVA:
        await asyncio.to_thread(_sync_exec, query, args)
        return
    async with _asyncpg_pool.acquire() as conn:
        await conn.execute(query, *args)


def _sync_query(query: str, args: tuple, mode: str) -> Any:
    """Checkout + execute + return, all on one thread (psycopg is sync)."""
    with _psycopg_pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(_to_named(query), _named_params(args))
            if mode == "all":
                return cur.fetchall()
            if mode == "one":
                return cur.fetchone()
            row = cur.fetchone()
            return None if row is None else next(iter(row.values()))


def _sync_exec(query: str, args: tuple) -> None:
    with _psycopg_pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(_to_named(query), _named_params(args))


# ------------------------------------- psycopg adapter for the mutation path
class _JavaPool:
    def acquire(self) -> "_JavaAcquire":
        return _JavaAcquire()


class _JavaAcquire:
    """Async context manager yielding a psycopg connection pinned to one thread."""

    async def __aenter__(self) -> "_JavaConn":
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        self._loop = asyncio.get_running_loop()
        self._cm = _psycopg_pool.connection()
        conn = await self._loop.run_in_executor(self._executor, self._cm.__enter__)
        return _JavaConn(conn, self._loop, self._executor)

    async def __aexit__(self, exc_type, exc, tb) -> Any:
        try:
            return await self._loop.run_in_executor(
                self._executor, self._cm.__exit__, exc_type, exc, tb
            )
        finally:
            self._executor.shutdown(wait=False)


class _JavaConn:
    """asyncpg-shaped wrapper over a sync psycopg connection on a pinned thread."""

    def __init__(self, conn, loop, executor) -> None:
        self._conn = conn
        self._loop = loop
        self._executor = executor

    def _call(self, fn, *a):
        return self._loop.run_in_executor(self._executor, fn, *a)

    async def fetch(self, query: str, *args: Any) -> list[dict[str, Any]]:
        rows = await self._call(self._fetch, query, args)
        return [{k: _coerce(v) for k, v in r.items()} for r in rows]

    async def fetchrow(self, query: str, *args: Any) -> Optional[dict[str, Any]]:
        row = await self._call(self._fetchrow, query, args)
        return {k: _coerce(v) for k, v in row.items()} if row is not None else None

    async def fetchval(self, query: str, *args: Any) -> Any:
        return _coerce(await self._call(self._fetchval, query, args))

    async def execute(self, query: str, *args: Any) -> None:
        await self._call(self._execute, query, args)

    def transaction(self) -> "_JavaTx":
        return _JavaTx(self._conn, self._loop, self._executor)

    # --- sync bodies (run on the pinned thread) ---
    def _fetch(self, query, args):
        with self._conn.cursor() as cur:
            cur.execute(_to_named(query), _named_params(args))
            return cur.fetchall()

    def _fetchrow(self, query, args):
        with self._conn.cursor() as cur:
            cur.execute(_to_named(query), _named_params(args))
            return cur.fetchone()

    def _fetchval(self, query, args):
        with self._conn.cursor() as cur:
            cur.execute(_to_named(query), _named_params(args))
            row = cur.fetchone()
            return None if row is None else next(iter(row.values()))

    def _execute(self, query, args):
        with self._conn.cursor() as cur:
            cur.execute(_to_named(query), _named_params(args))


class _JavaTx:
    """Async wrapper over psycopg's sync Transaction, kept on the pinned thread."""

    def __init__(self, conn, loop, executor) -> None:
        self._conn = conn
        self._loop = loop
        self._executor = executor
        self._tx: Any = None

    async def __aenter__(self) -> "_JavaTx":
        self._tx = self._conn.transaction()
        await self._loop.run_in_executor(self._executor, self._tx.__enter__)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> Any:
        return await self._loop.run_in_executor(
            self._executor, self._tx.__exit__, exc_type, exc, tb
        )
