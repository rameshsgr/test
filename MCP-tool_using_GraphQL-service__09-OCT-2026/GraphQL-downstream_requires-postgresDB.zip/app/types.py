"""GraphQL object types — mirror the v_* read views and the core write tables."""
from __future__ import annotations
import datetime
from typing import Any, List, Optional

import strawberry


def _d(row: dict[str, Any], key: str) -> Any:
    return row.get(key)


# ----------------------------------------------------------------- read views
@strawberry.type(description="A member's active elected coverage (view v_member_coverage).")
class MemberCoverage:
    customer_id: int
    member_name: Optional[str]
    region: Optional[str]
    country_code: Optional[str]
    client_id: Optional[int]
    employer: Optional[str]
    enrollment_id: Optional[int]
    coverage_tier: Optional[str]
    elected_amount: Optional[float]
    effective_date: Optional[datetime.date]
    end_date: Optional[datetime.date]
    benefit_id: Optional[int]
    benefit_type: Optional[str]
    benefit_name: Optional[str]
    benefit_currency: Optional[str]
    policy_number: Optional[str]
    product_line: Optional[str]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "MemberCoverage":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="Benefits a member is eligible for (view v_eligibility).")
class Eligibility:
    customer_id: int
    member_name: Optional[str]
    region: Optional[str]
    hire_date: Optional[datetime.date]
    benefit_id: Optional[int]
    benefit_type: Optional[str]
    benefit_name: Optional[str]
    waiting_period_days: Optional[int]
    eligible_on: Optional[datetime.date]
    is_eligible: Optional[bool]
    already_enrolled: Optional[bool]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "Eligibility":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="Claim header + its latest event (view v_claim_status).")
class ClaimStatus:
    claim_id: int
    claim_number: Optional[str]
    claim_type: Optional[str]
    status: Optional[str]
    date_of_loss: Optional[datetime.date]
    date_reported: Optional[datetime.date]
    disability_start: Optional[datetime.date]
    disability_end: Optional[datetime.date]
    return_to_work_date: Optional[datetime.date]
    approved_amount: Optional[float]
    paid_amount: Optional[float]
    fineos_case_ref: Optional[str]
    customer_id: Optional[int]
    claimant_name: Optional[str]
    region: Optional[str]
    last_event_ts: Optional[datetime.datetime]
    last_status: Optional[str]
    last_actor: Optional[str]
    last_note: Optional[str]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "ClaimStatus":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="Per-employer rollup (view v_client_summary).")
class ClientSummary:
    client_id: int
    employer: Optional[str]
    client_legal_name: Optional[str]
    region: Optional[str]
    country_code: Optional[str]
    status: Optional[str]
    employee_count_band: Optional[str]
    policies: Optional[int]
    benefits: Optional[int]
    enrolled_members: Optional[int]
    product_lines: Optional[List[str]]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "ClientSummary":
        pl = r.get("product_lines") or []
        pl = [x for x in pl if x is not None]
        return cls(
            client_id=r.get("client_id"),
            employer=r.get("employer"),
            client_legal_name=r.get("client_legal_name"),
            region=r.get("region"),
            country_code=r.get("country_code"),
            status=r.get("status"),
            employee_count_band=r.get("employee_count_band"),
            policies=r.get("policies"),
            benefits=r.get("benefits"),
            enrolled_members=r.get("enrolled_members"),
            product_lines=pl,
        )


@strawberry.type(description="Book-of-business aggregates (view v_regional_stats).")
class RegionalStat:
    region: Optional[str]
    benefit_type: Optional[str]
    enrolled_members: Optional[int]
    claims: Optional[int]
    paid_claims: Optional[int]
    total_paid: Optional[float]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "RegionalStat":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


# ----------------------------------------------------------------- write tables
@strawberry.type(description="An employer client (table client).")
class Client:
    client_id: int
    client_legal_name: Optional[str]
    dba_name: Optional[str]
    industry_code: Optional[str]
    employee_count_band: Optional[str]
    region: Optional[str]
    country_code: Optional[str]
    status: Optional[str]
    effective_date: Optional[datetime.date]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "Client":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="A member / employee (table customer).")
class Customer:
    customer_id: int
    client_id: Optional[int]
    first_name: Optional[str]
    last_name: Optional[str]
    email: Optional[str]
    date_of_birth: Optional[datetime.date]
    hire_date: Optional[datetime.date]
    employment_status: Optional[str]
    job_title: Optional[str]
    region: Optional[str]
    country_code: Optional[str]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "Customer":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="A benefit election (table enrollment).")
class Enrollment:
    enrollment_id: int
    customer_id: Optional[int]
    benefit_id: Optional[int]
    policy_id: Optional[int]
    coverage_tier: Optional[str]
    elected_amount: Optional[float]
    enrollment_channel: Optional[str]
    enrollment_date: Optional[datetime.date]
    effective_date: Optional[datetime.date]
    end_date: Optional[datetime.date]
    status: Optional[str]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "Enrollment":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="A claim header (table claim).")
class Claim:
    claim_id: int
    claim_number: Optional[str]
    enrollment_id: Optional[int]
    claimant_customer_id: Optional[int]
    claim_type: Optional[str]
    date_of_loss: Optional[datetime.date]
    date_reported: Optional[datetime.date]
    cause_of_loss: Optional[str]
    status: Optional[str]
    approved_amount: Optional[float]
    paid_amount: Optional[float]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "Claim":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="A claim lifecycle event (table claim_event).")
class ClaimEvent:
    event_id: int
    claim_id: Optional[int]
    event_type: Optional[str]
    status_from: Optional[str]
    status_to: Optional[str]
    actor: Optional[str]
    event_ts: Optional[datetime.datetime]
    note: Optional[str]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "ClaimEvent":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})


@strawberry.type(description="A claim payment (table payment).")
class Payment:
    payment_id: int
    claim_id: Optional[int]
    gross_amount: Optional[float]
    net_amount: Optional[float]
    method: Optional[str]
    payee_name: Optional[str]
    currency: Optional[str]
    payment_date: Optional[datetime.date]

    @classmethod
    def from_row(cls, r: dict[str, Any]) -> "Payment":
        return cls(**{f: _d(r, f) for f in cls.__annotations__})
