"""
Group Insurance — GraphQL downstream service
============================================
A Python GraphQL surface over the local Postgres `group_insurance` database.
Reads are served by the curated `v_*` views (Queries); writes go to the base
tables through guarded resolvers (Mutations).

Stack: FastAPI + Strawberry GraphQL + asyncpg.

Run:
    uv run uvicorn app.main:app --port 8241
Playground (GraphiQL):
    http://127.0.0.1:8241/graphql
"""
from __future__ import annotations
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from strawberry.fastapi import GraphQLRouter

_STATIC_DIR = Path(__file__).parent / "static"

from . import db
from .config import settings
from .schema import schema


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.connect()
    yield
    await db.disconnect()


app = FastAPI(
    title="Group Insurance GraphQL",
    version="1.0.0",
    description="GraphQL surface over the group-insurance database.",
    lifespan=lifespan,
)

# Serve the vendored GraphiQL assets locally (no external CDN — works behind a proxy).
app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")


@app.get("/graphql", include_in_schema=False)
async def graphiql_playground() -> FileResponse:
    """Self-contained GraphiQL UI (loads React/GraphiQL from /static, not a CDN)."""
    return FileResponse(_STATIC_DIR / "graphiql.html")


# Built-in IDE disabled (it pulls from unpkg, which is blocked here); the custom
# GET /graphql above handles the UI. The router still serves the POST API.
graphql_app = GraphQLRouter(schema, graphql_ide=None)
app.include_router(graphql_app, prefix="/graphql")


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok", "service": "group-insurance-graphql", "endpoint": "/graphql"}


def main() -> None:
    import uvicorn

    uvicorn.run(app, host=settings.host, port=settings.port)


if __name__ == "__main__":
    main()
