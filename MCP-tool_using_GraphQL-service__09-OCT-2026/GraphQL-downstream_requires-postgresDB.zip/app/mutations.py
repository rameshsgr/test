"""Mutation resolvers — guarded writes against the base tables.

IDs are explicit BIGINT in this schema (no sequences), so new rows take
MAX(id)+1 allocated inside the same transaction as the INSERT.
"""
from __future__ import annotations
import datetime
from typing import Optional

import strawberry

from . import db
from .types import Claim, ClaimEvent, Client, Customer, Enrollment, Payment

# benefit_type -> claim_type (mirrors server.py's BENEFIT_TO_CLAIM)
BENEFIT_TO_CLAIM = {
    "ADD": "ACCIDENT",
    "STD": "STD",
    "LTD": "LTD",
    "ABSENCE": "ABSENCE",
    "MEDICAL": "HEALTH",
}


async def _next_id(conn, table: str, pk: str) -> int:
    return int(await conn.fetchval(f"SELECT COALESCE(MAX({pk}), 0) + 1 FROM {table}"))


# ----------------------------------------------------------------- inputs
@strawberry.input
class CreateClientInput:
    client_legal_name: str
    region: str
    dba_name: Optional[str] = None
    industry_code: Optional[str] = None
    employee_count_band: Optional[str] = None
    country_code: Optional[str] = None
    status: Optional[str] = "Prospect"
    effective_date: Optional[datetime.date] = None


@strawberry.input
class CreateCustomerInput:
    client_id: int
    first_name: str
    last_name: str
    region: str
    email: Optional[str] = None
    date_of_birth: Optional[datetime.date] = None
    hire_date: Optional[datetime.date] = None
    employment_status: Optional[str] = "Active"
    job_title: Optional[str] = None
    country_code: Optional[str] = None


@strawberry.input
class CreateEnrollmentInput:
    customer_id: int
    benefit_id: int
    effective_date: datetime.date
    policy_id: Optional[int] = None
    coverage_tier: Optional[str] = None
    elected_amount: Optional[float] = None
    enrollment_channel: Optional[str] = "Portal"
    enrollment_date: Optional[datetime.date] = None
    status: Optional[str] = "Pending"


@strawberry.input
class CreateClaimInput:
    enrollment_id: int
    date_of_loss: datetime.date
    cause_of_loss: str
    claim_type: Optional[str] = None


@strawberry.input
class AddClaimEventInput:
    claim_id: int
    event_type: str
    status_to: str
    actor: str
    note: Optional[str] = None


@strawberry.input
class RecordPaymentInput:
    claim_id: int
    gross_amount: float
    net_amount: float
    method: str
    payee_name: str
    currency: Optional[str] = "USD"
    payment_date: Optional[datetime.date] = None


# ----------------------------------------------------------------- mutations
@strawberry.type
class Mutation:
    @strawberry.mutation(description="Create a new employer client.")
    async def create_client(self, input: CreateClientInput) -> Client:
        async with db.pool().acquire() as conn:
            async with conn.transaction():
                cid = await _next_id(conn, "client", "client_id")
                await conn.execute(
                    "INSERT INTO client (client_id, client_legal_name, dba_name, "
                    "industry_code, employee_count_band, region, country_code, status, "
                    "effective_date) "
                    "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)",
                    cid,
                    input.client_legal_name,
                    input.dba_name,
                    input.industry_code,
                    input.employee_count_band,
                    input.region,
                    input.country_code,
                    input.status,
                    input.effective_date,
                )
                row = await conn.fetchrow(
                    "SELECT * FROM client WHERE client_id = $1", cid
                )
        return Client.from_row(db.row_to_dict(row))

    @strawberry.mutation(description="Create a new member under a client.")
    async def create_customer(self, input: CreateCustomerInput) -> Customer:
        async with db.pool().acquire() as conn:
            async with conn.transaction():
                exists = await conn.fetchval(
                    "SELECT 1 FROM client WHERE client_id = $1", input.client_id
                )
                if not exists:
                    raise ValueError(f"client_id {input.client_id} does not exist")
                cid = await _next_id(conn, "customer", "customer_id")
                await conn.execute(
                    "INSERT INTO customer (customer_id, client_id, first_name, last_name, "
                    "email, date_of_birth, hire_date, employment_status, job_title, region, "
                    "country_code) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)",
                    cid,
                    input.client_id,
                    input.first_name,
                    input.last_name,
                    input.email,
                    input.date_of_birth,
                    input.hire_date,
                    input.employment_status,
                    input.job_title,
                    input.region,
                    input.country_code,
                )
                row = await conn.fetchrow(
                    "SELECT * FROM customer WHERE customer_id = $1", cid
                )
        return Customer.from_row(db.row_to_dict(row))

    @strawberry.mutation(description="Enroll a member into a benefit.")
    async def create_enrollment(self, input: CreateEnrollmentInput) -> Enrollment:
        async with db.pool().acquire() as conn:
            async with conn.transaction():
                benefit = await conn.fetchrow(
                    "SELECT policy_id FROM benefit WHERE benefit_id = $1", input.benefit_id
                )
                if benefit is None:
                    raise ValueError(f"benefit_id {input.benefit_id} does not exist")
                policy_id = input.policy_id or benefit["policy_id"]
                eid = await _next_id(conn, "enrollment", "enrollment_id")
                await conn.execute(
                    "INSERT INTO enrollment (enrollment_id, customer_id, benefit_id, "
                    "policy_id, coverage_tier, elected_amount, enrollment_channel, "
                    "enrollment_date, effective_date, status) "
                    "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)",
                    eid,
                    input.customer_id,
                    input.benefit_id,
                    policy_id,
                    input.coverage_tier,
                    input.elected_amount,
                    input.enrollment_channel,
                    input.enrollment_date or datetime.date.today(),
                    input.effective_date,
                    input.status,
                )
                row = await conn.fetchrow(
                    "SELECT * FROM enrollment WHERE enrollment_id = $1", eid
                )
        return Enrollment.from_row(db.row_to_dict(row))

    @strawberry.mutation(description="Change an enrollment's status (e.g. Pending -> Enrolled).")
    async def update_enrollment_status(
        self, enrollment_id: int, status: str
    ) -> Enrollment:
        await db.execute(
            "UPDATE enrollment SET status = $2 WHERE enrollment_id = $1",
            enrollment_id,
            status,
        )
        row = await db.fetchrow(
            "SELECT * FROM enrollment WHERE enrollment_id = $1", enrollment_id
        )
        if row is None:
            raise ValueError(f"enrollment_id {enrollment_id} not found")
        return Enrollment.from_row(row)

    @strawberry.mutation(
        description="Open a new claim (FNOL) against an ACTIVE enrollment. Guarded."
    )
    async def create_claim(self, input: CreateClaimInput) -> Claim:
        async with db.pool().acquire() as conn:
            async with conn.transaction():
                enr = await conn.fetchrow(
                    "SELECT e.customer_id, e.status, b.benefit_type "
                    "FROM enrollment e JOIN benefit b ON e.benefit_id = b.benefit_id "
                    "WHERE e.enrollment_id = $1",
                    input.enrollment_id,
                )
                if enr is None:
                    raise ValueError(f"enrollment_id {input.enrollment_id} does not exist")
                if enr["status"] != "Enrolled":
                    raise ValueError(
                        f"enrollment {input.enrollment_id} is '{enr['status']}', "
                        "must be 'Enrolled' to open a claim"
                    )
                claim_type = input.claim_type or BENEFIT_TO_CLAIM.get(
                    enr["benefit_type"], "OTHER"
                )
                claim_id = await _next_id(conn, "claim", "claim_id")
                year = input.date_of_loss.year
                claim_number = f"CLM-{year}-{claim_id:05d}"
                await conn.execute(
                    "INSERT INTO claim (claim_id, claim_number, enrollment_id, "
                    "claimant_customer_id, claim_type, date_of_loss, date_reported, "
                    "cause_of_loss, status) "
                    "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'FNOL')",
                    claim_id,
                    claim_number,
                    input.enrollment_id,
                    enr["customer_id"],
                    claim_type,
                    input.date_of_loss,
                    datetime.date.today(),
                    input.cause_of_loss,
                )
                # seed the opening event so v_claim_status has something to show
                ev_id = await _next_id(conn, "claim_event", "event_id")
                await conn.execute(
                    "INSERT INTO claim_event (event_id, claim_id, event_type, "
                    "status_from, status_to, actor, event_ts, note) "
                    "VALUES ($1,$2,'FNOL',NULL,'FNOL','system',now(),'Claim opened via GraphQL')",
                    ev_id,
                    claim_id,
                )
                row = await conn.fetchrow(
                    "SELECT * FROM claim WHERE claim_id = $1", claim_id
                )
        return Claim.from_row(db.row_to_dict(row))

    @strawberry.mutation(
        description="Append a lifecycle event to a claim and advance the claim's status."
    )
    async def add_claim_event(self, input: AddClaimEventInput) -> ClaimEvent:
        async with db.pool().acquire() as conn:
            async with conn.transaction():
                claim = await conn.fetchrow(
                    "SELECT status FROM claim WHERE claim_id = $1", input.claim_id
                )
                if claim is None:
                    raise ValueError(f"claim_id {input.claim_id} does not exist")
                status_from = claim["status"]
                ev_id = await _next_id(conn, "claim_event", "event_id")
                await conn.execute(
                    "INSERT INTO claim_event (event_id, claim_id, event_type, "
                    "status_from, status_to, actor, event_ts, note) "
                    "VALUES ($1,$2,$3,$4,$5,$6,now(),$7)",
                    ev_id,
                    input.claim_id,
                    input.event_type,
                    status_from,
                    input.status_to,
                    input.actor,
                    input.note,
                )
                await conn.execute(
                    "UPDATE claim SET status = $2, updated_at = now() WHERE claim_id = $1",
                    input.claim_id,
                    input.status_to,
                )
                row = await conn.fetchrow(
                    "SELECT * FROM claim_event WHERE event_id = $1", ev_id
                )
        return ClaimEvent.from_row(db.row_to_dict(row))

    @strawberry.mutation(description="Record a payment against a claim.")
    async def record_payment(self, input: RecordPaymentInput) -> Payment:
        async with db.pool().acquire() as conn:
            async with conn.transaction():
                claim = await conn.fetchrow(
                    "SELECT 1 FROM claim WHERE claim_id = $1", input.claim_id
                )
                if claim is None:
                    raise ValueError(f"claim_id {input.claim_id} does not exist")
                pid = await _next_id(conn, "payment", "payment_id")
                await conn.execute(
                    "INSERT INTO payment (payment_id, claim_id, gross_amount, net_amount, "
                    "method, payee_name, currency, payment_date) "
                    "VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
                    pid,
                    input.claim_id,
                    input.gross_amount,
                    input.net_amount,
                    input.method,
                    input.payee_name,
                    input.currency,
                    input.payment_date or datetime.date.today(),
                )
                # keep claim.paid_amount in step with recorded payments
                await conn.execute(
                    "UPDATE claim SET paid_amount = COALESCE(paid_amount,0) + $2, "
                    "updated_at = now() WHERE claim_id = $1",
                    input.claim_id,
                    input.net_amount,
                )
                row = await conn.fetchrow(
                    "SELECT * FROM payment WHERE payment_id = $1", pid
                )
        return Payment.from_row(db.row_to_dict(row))
