"""Query resolvers — reads are served by the curated v_* views and base tables."""
from __future__ import annotations
from typing import List, Optional

import strawberry

from . import db
from .types import (
    Claim,
    ClaimEvent,
    ClaimStatus,
    Client,
    ClientSummary,
    Customer,
    Eligibility,
    Enrollment,
    MemberCoverage,
    Payment,
    RegionalStat,
)


@strawberry.type
class Query:
    # ---------------------------------------------------- view-backed reads
    @strawberry.field(description="Active elected coverage for one member.")
    async def member_coverage(self, customer_id: int) -> List[MemberCoverage]:
        rows = await db.fetch(
            "SELECT * FROM v_member_coverage WHERE customer_id = $1 ORDER BY benefit_type",
            customer_id,
        )
        return [MemberCoverage.from_row(r) for r in rows]

    @strawberry.field(description="Benefits a member's employer offers, with eligibility.")
    async def eligible_benefits(
        self, customer_id: int, only_eligible: bool = False
    ) -> List[Eligibility]:
        sql = "SELECT * FROM v_eligibility WHERE customer_id = $1"
        if only_eligible:
            sql += " AND is_eligible AND NOT already_enrolled"
        sql += " ORDER BY benefit_type"
        rows = await db.fetch(sql, customer_id)
        return [Eligibility.from_row(r) for r in rows]

    @strawberry.field(description="Claim status + latest event, by claim number or id.")
    async def claim_status(
        self, claim_number: Optional[str] = None, claim_id: Optional[int] = None
    ) -> List[ClaimStatus]:
        if claim_number is not None:
            rows = await db.fetch(
                "SELECT * FROM v_claim_status WHERE claim_number = $1", claim_number
            )
        elif claim_id is not None:
            rows = await db.fetch(
                "SELECT * FROM v_claim_status WHERE claim_id = $1", claim_id
            )
        else:
            rows = await db.fetch(
                "SELECT * FROM v_claim_status ORDER BY last_event_ts DESC NULLS LAST LIMIT 25"
            )
        return [ClaimStatus.from_row(r) for r in rows]

    @strawberry.field(description="Employer rollup by id, by (partial) name, or top-25.")
    async def client_summary(
        self, client_id: Optional[int] = None, name: Optional[str] = None
    ) -> List[ClientSummary]:
        if client_id is not None:
            rows = await db.fetch(
                "SELECT * FROM v_client_summary WHERE client_id = $1", client_id
            )
        elif name is not None:
            rows = await db.fetch(
                "SELECT * FROM v_client_summary "
                "WHERE employer ILIKE '%' || $1 || '%' "
                "   OR client_legal_name ILIKE '%' || $1 || '%' "
                "ORDER BY enrolled_members DESC LIMIT 25",
                name,
            )
        else:
            rows = await db.fetch(
                "SELECT * FROM v_client_summary ORDER BY enrolled_members DESC LIMIT 25"
            )
        return [ClientSummary.from_row(r) for r in rows]

    @strawberry.field(description="Book-of-business aggregates by region and benefit type.")
    async def regional_stats(
        self, region: Optional[str] = None, benefit_type: Optional[str] = None
    ) -> List[RegionalStat]:
        rows = await db.fetch(
            "SELECT * FROM v_regional_stats "
            "WHERE ($1::text IS NULL OR region = $1) "
            "  AND ($2::text IS NULL OR benefit_type = $2) "
            "ORDER BY region, benefit_type",
            region,
            benefit_type,
        )
        return [RegionalStat.from_row(r) for r in rows]

    # ---------------------------------------------------- base-table reads
    @strawberry.field(description="List employer clients.")
    async def clients(
        self, region: Optional[str] = None, limit: int = 25
    ) -> List[Client]:
        rows = await db.fetch(
            "SELECT * FROM client "
            "WHERE ($1::text IS NULL OR region = $1) "
            "ORDER BY client_id LIMIT $2",
            region,
            limit,
        )
        return [Client.from_row(r) for r in rows]

    @strawberry.field(description="List members, optionally filtered by employer.")
    async def customers(
        self, client_id: Optional[int] = None, limit: int = 25
    ) -> List[Customer]:
        rows = await db.fetch(
            "SELECT * FROM customer "
            "WHERE ($1::bigint IS NULL OR client_id = $1) "
            "ORDER BY customer_id LIMIT $2",
            client_id,
            limit,
        )
        return [Customer.from_row(r) for r in rows]

    @strawberry.field(description="List a member's enrollments.")
    async def enrollments(self, customer_id: int) -> List[Enrollment]:
        rows = await db.fetch(
            "SELECT * FROM enrollment WHERE customer_id = $1 ORDER BY effective_date DESC",
            customer_id,
        )
        return [Enrollment.from_row(r) for r in rows]

    @strawberry.field(description="List claims, optionally filtered by status.")
    async def claims(
        self, status: Optional[str] = None, limit: int = 25
    ) -> List[Claim]:
        rows = await db.fetch(
            "SELECT * FROM claim "
            "WHERE ($1::text IS NULL OR status = $1) "
            "ORDER BY claim_id DESC LIMIT $2",
            status,
            limit,
        )
        return [Claim.from_row(r) for r in rows]

    @strawberry.field(description="Full event timeline for a claim.")
    async def claim_events(self, claim_id: int) -> List[ClaimEvent]:
        rows = await db.fetch(
            "SELECT * FROM claim_event WHERE claim_id = $1 ORDER BY event_ts",
            claim_id,
        )
        return [ClaimEvent.from_row(r) for r in rows]

    @strawberry.field(description="Payments recorded against a claim.")
    async def payments(self, claim_id: int) -> List[Payment]:
        rows = await db.fetch(
            "SELECT * FROM payment WHERE claim_id = $1 ORDER BY payment_date",
            claim_id,
        )
        return [Payment.from_row(r) for r in rows]
