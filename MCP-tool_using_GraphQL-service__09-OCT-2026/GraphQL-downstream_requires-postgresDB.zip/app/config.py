"""Runtime configuration, read from environment (matches server.py / rest_api.py)."""
from __future__ import annotations
import os

from dotenv import load_dotenv

# Load .env so DATASOURCE / PG* / JAVADB* can be set in the file. Real shell
# environment variables still win (override=False).
load_dotenv(override=False)


class Settings:
    # --- Datasource toggle: "postgres" (default) or "java" ---
    datasource: str = os.environ.get("DATASOURCE", "postgres").strip().lower()

    # --- PostgreSQL (same env vars the MCP / REST surfaces already use) ---
    pg_host: str = os.environ.get("PGHOST", "localhost")
    pg_port: int = int(os.environ.get("PGPORT", "5432"))
    pg_user: str = os.environ.get("PGUSER", "postgres")
    pg_password: str = os.environ.get("PGPASSWORD", "postgres")
    pg_database: str = os.environ.get("PGDATABASE", "group_insurance")

    # --- Java in-memory datasource (speaks the PostgreSQL wire protocol) ---
    javadb_host: str = os.environ.get("JAVADBHOST", "localhost")
    javadb_port: int = int(os.environ.get("JAVADBPORT", "5435"))
    javadb_user: str = os.environ.get("JAVADBUSER", "sa")
    javadb_password: str = os.environ.get("JAVADBPASSWORD", "sa")
    javadb_database: str = os.environ.get("JAVADBDATABASE", "group_insurance")

    # --- HTTP ---
    host: str = os.environ.get("GRAPHQL_HOST", "127.0.0.1")
    port: int = int(os.environ.get("GRAPHQL_PORT", "8241"))

    @property
    def dsn(self) -> str:
        if self.datasource == "java":
            user, password = self.javadb_user, self.javadb_password
            host, port, database = self.javadb_host, self.javadb_port, self.javadb_database
        else:
            user, password = self.pg_user, self.pg_password
            host, port, database = self.pg_host, self.pg_port, self.pg_database
        return f"postgresql://{user}:{password}@{host}:{port}/{database}"


settings = Settings()
