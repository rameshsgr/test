"""Group Insurance — GraphQL downstream service."""
