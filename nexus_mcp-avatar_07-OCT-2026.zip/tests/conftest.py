"""
tests.conftest
--------------

Makes the repo root importable and provides a baseline set of required env vars
so ``core.config`` can build its singleton during collection.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# Ensure required secrets exist for config import even without a local .env.
os.environ.setdefault("MDM_URI", "https://mdm.example.test/graphql")
os.environ.setdefault("MDM_CLIENT_ID", "test-mdm-id")
os.environ.setdefault("MDM_CLIENT_SECRET", "test-mdm-secret")
os.environ.setdefault("GDH_CLIENT_ID", "test-gdh-id")
os.environ.setdefault("GDH_CLIENT_SECRET", "test-gdh-secret")
os.environ.setdefault("FINEOS_CLIENT_ID", "test-fineos-id")
os.environ.setdefault("FINEOS_CLIENT_SECRET", "test-fineos-secret")
