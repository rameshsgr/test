"""Contract: MDM GraphQL payload is flexible JSON with the SSN passed as a variable."""

from __future__ import annotations

from infrastructure.mdm.queries import CUSTOMER_DETAILS_QUERY, build_details_payload


def test_payload_passes_id_as_graphql_variable_not_interpolated():
    payload = build_details_payload(id_number="256464427", id_type="SSN")

    assert payload["operationName"] == "CustomerSearch"
    assert payload["variables"] == {"idNumber": "256464427", "idType": "SSN"}
    # The raw SSN must NOT be concatenated into the query document (injection-safe).
    assert "256464427" not in payload["query"]
    assert "$idNumber" in payload["query"]


def test_query_requests_expected_projection_fields():
    for field in ("searchCustomer", "umid", "customerDetails", "addresses", "contacts",
                  "customerOccupation", "externalSystemKeys"):
        assert field in CUSTOMER_DETAILS_QUERY
