"""Contract: MDMGateway extracts customer nodes from a GraphQL edges response."""

from __future__ import annotations

from infrastructure.mdm.gateway import MDMGateway


def test_extract_nodes_returns_node_dicts_from_edges():
    data = {
        "data": {
            "searchCustomer": {
                "edges": [
                    {"cursor": "a", "node": {"umid": "U1", "status": "ACTIVE"}},
                    {"cursor": "b", "node": {"umid": "U2", "status": "ACTIVE"}},
                ]
            }
        }
    }
    assert MDMGateway._extract_nodes(data) == [
        {"umid": "U1", "status": "ACTIVE"},
        {"umid": "U2", "status": "ACTIVE"},
    ]


def test_extract_nodes_handles_empty_and_missing():
    assert MDMGateway._extract_nodes({}) == []
    assert MDMGateway._extract_nodes({"data": {"searchCustomer": {"edges": []}}}) == []
