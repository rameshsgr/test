"""Contract: SSN normalisation and required-field validation at the boundary."""

from __future__ import annotations

import pytest

from core.exceptions import ValidationError
from core.validation import normalize_ssn, require_non_empty


# ---------------------------------------------------------------------------
# normalize_ssn
# ---------------------------------------------------------------------------
def test_normalize_ssn_strips_separators_returns_digits():
    assert normalize_ssn("256-46-4427") == "256464427"


def test_normalize_ssn_accepts_plain_digits():
    assert normalize_ssn("256464427") == "256464427"


@pytest.mark.parametrize("bad", ["", "   ", "123", "12345678", "1234567890"])
def test_normalize_ssn_invalid_length_raises(bad):
    with pytest.raises(ValidationError):
        normalize_ssn(bad)


# ---------------------------------------------------------------------------
# require_non_empty
# ---------------------------------------------------------------------------
def test_require_non_empty_trims_and_returns():
    assert require_non_empty("  U123  ", "UMID") == "U123"


def test_require_non_empty_blank_raises():
    with pytest.raises(ValidationError):
        require_non_empty("   ", "UMID")
