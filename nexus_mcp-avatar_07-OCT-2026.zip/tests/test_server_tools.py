"""Contract: the server factory registers all nine expected MCP tools."""

from __future__ import annotations

import pytest

from api.server import build_server

_EXPECTED_TOOLS = {
    "search_customer_bySSN",
    "search_customer_byUMID",
    "get_customer_details_bySSN",
    "get_customer_details_byUMID",
    "get_customer_eligibility_details",
    "list_all_claims_byCustomer",
    "get_claim_details_byCID",
    "list_customer_absences",
    "get_absence_details_byAID",
}


async def test_build_server_registers_all_tools():
    mcp = build_server()
    tools = await mcp.list_tools()
    names = {tool.name for tool in tools}
    assert _EXPECTED_TOOLS.issubset(names)
