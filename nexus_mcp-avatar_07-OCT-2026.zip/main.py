"""
main
----

Entry point for the nexus-mcp FastMCP service.

Usage
-----
    python main.py                 # stdio transport (default)
    python main.py --http          # streamable-http transport on 0.0.0.0:8000
    python main.py --http --port 9000 --host 127.0.0.1
"""

from __future__ import annotations

import argparse

from api.server import build_server

# Module-level server so `fastmcp run main.py` / ASGI hosts can import `mcp`.
mcp = build_server()


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="nexus-mcp FastMCP service")
    parser.add_argument("--http", action="store_true", help="serve over HTTP instead of stdio")
    parser.add_argument("--host", default="0.0.0.0", help="HTTP bind host (default 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="HTTP bind port (default 8000)")
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    if args.http:
        mcp.run(transport="http", host=args.host, port=args.port)
    else:
        mcp.run()


if __name__ == "__main__":
    main()
