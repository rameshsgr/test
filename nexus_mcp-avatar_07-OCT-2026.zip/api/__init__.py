"""nexus-mcp api package — FastMCP adapter (server factory + tool registration)."""
