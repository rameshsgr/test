"""
api.server
----------

FastMCP adapter. :func:`build_server` is the composition root: it wires the
infrastructure adapters into application services and registers every MCP tool,
then returns a ready-to-run :class:`FastMCP` instance.

Dependency flow (inward):   tools -> services -> domain ports -> adapters.
"""

from __future__ import annotations

from fastmcp import FastMCP

from application.services.absence_service import AbsenceService
from application.services.claims_service import ClaimsService
from application.services.customer_service import CustomerService
from core.config import AppConfig, settings
from core.logging_config import configure_logging
from domain.entities.customer import Customer
from infrastructure.fineos.gateway import FineosGateway
from infrastructure.gdh.gateway import GDHGateway
from infrastructure.mdm.gateway import MDMGateway


def build_server(config: AppConfig = settings) -> FastMCP:
    """Compose adapters, services, and tools into a FastMCP server."""
    configure_logging(config.log_level)

    # Infrastructure adapters (outbound).
    mdm_gateway = MDMGateway(config.mdm)
    gdh_gateway = GDHGateway(config.gdh)
    fineos_gateway = FineosGateway(config.fineos)

    # Application services (depend on domain ports only).
    customer_service = CustomerService(mdm_gateway, gdh_gateway)
    claims_service = ClaimsService(fineos_gateway)
    absence_service = AbsenceService(fineos_gateway)

    mcp = FastMCP(config.server_name)

    # -- Customer tools -----------------------------------------------------
    @mcp.tool
    async def search_customer_bySSN(ssn: str) -> list[dict]:
        """Search for customers by SSN (MDM)."""
        return await customer_service.search_customer_by_ssn(ssn)

    @mcp.tool
    async def search_customer_byUMID(umid: str) -> list[dict]:
        """Search for customers by UMID (MDM)."""
        return await customer_service.search_customer_by_umid(umid)

    @mcp.tool
    async def get_customer_details_bySSN(ssn: str) -> list[dict]:
        """Retrieve full customer detail records by SSN (MDM)."""
        return await customer_service.get_customer_details_by_ssn(ssn)

    @mcp.tool
    async def get_customer_details_byUMID(umid: str) -> list[dict]:
        """Retrieve full customer detail records by UMID (MDM)."""
        return await customer_service.get_customer_details_by_umid(umid)

    @mcp.tool
    async def get_customer_eligibility_details(customer: Customer) -> dict:
        """Retrieve eligibility details for a customer (GDH)."""
        return await customer_service.get_customer_eligibility_details(customer)

    # -- Claim tools --------------------------------------------------------
    @mcp.tool
    async def list_all_claims_byCustomer(customer: Customer) -> list[dict]:
        """List all claims for a customer (FINEOS)."""
        return await claims_service.list_all_claims_by_customer(customer)

    @mcp.tool
    async def get_claim_details_byCID(claim_id: str) -> dict:
        """Retrieve full detail for a single claim by Claim ID (FINEOS)."""
        return await claims_service.get_claim_details_by_cid(claim_id)

    # -- Absence tools ------------------------------------------------------
    @mcp.tool
    async def list_customer_absences(customer: Customer) -> list[dict]:
        """List all absences for a customer (FINEOS)."""
        return await absence_service.list_customer_absences(customer)

    @mcp.tool
    async def get_absence_details_byAID(absence_id: str) -> dict:
        """Retrieve full detail for a single absence by Absence ID (FINEOS)."""
        return await absence_service.get_absence_details_by_aid(absence_id)

    return mcp
