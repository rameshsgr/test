# CLAUDE.md

Coding style and technology conventions for this codebase. This file is intended to be
**portable**: drop it into a sibling repository to enforce the same architecture, style, and
technology choices. Where it names a specific module (e.g. `core/config.py`), treat that as the
*pattern to replicate*, not a hard dependency.

---

## 1. What this project is

A Python **MCP (Model Context Protocol) server** that answers natural-language questions over
Redshift, deployed as an **AWS Lambda** (behind a Bedrock AgentCore Gateway) *and* runnable as a
**FastAPI** service on EKS. It performs semantic retrieval (pgvector), graph enrichment (Neptune),
and LLM-based SQL/Gremlin generation (AWS Bedrock via LangChain).

The same `main.py` serves both runtimes — Lambda via a raw MCP JSON-RPC handler, EKS via
`gunicorn` + `uvicorn` workers.

---

## 2. Technology stack

| Concern              | Choice                                                        |
|----------------------|---------------------------------------------------------------|
| Language             | **Python 3.12**                                               |
| Web framework        | **FastAPI** (+ `uvicorn` / `gunicorn`), ASGI                  |
| Lambda bridge        | Raw MCP JSON-RPC handler in `main.py` (not Mangum/API-GW)     |
| Data validation      | **Pydantic v2** (request/response models only)                |
| LLM                  | **AWS Bedrock** (Claude Sonnet) via **`langchain-aws`**        |
| Embeddings           | Bedrock **Titan** (`amazon.titan-embed-text-v2:0`, dim 1024)  |
| Relational DB        | **Redshift / PostgreSQL** via **`psycopg2-binary`**           |
| Vector store         | **pgvector** on Aurora PostgreSQL                             |
| Graph DB             | **AWS Neptune** — `gremlinpython` + `boto3 neptunedata` REST   |
| AWS SDK              | **boto3** (execution-role creds; adaptive retry config)       |
| Secrets              | **CyberArk Conjur** (IAM auth) — injected into `os.environ`   |
| Config               | **PyYAML** + env vars (see §4)                                |
| Tests                | **pytest** + **pytest-asyncio** (`asyncio_mode = auto`)       |
| CI/CD                | **Jenkins** → SonarQube → Artifactory → uDeploy               |

Pin exact versions in `requirements.txt` (this repo pins everything except `numpy`). Do not add a
dependency without a concrete need — the Lambda package size is budget-constrained.

---

## 3. Architecture — Clean / Hexagonal (Ports & Adapters)

Dependencies point **inward**. Outer layers depend on inner ones, never the reverse.

```
api/              HTTP/MCP adapter — FastAPI routes, Pydantic models, app factory
application/      Use-cases / orchestration — services, routers (business logic)
domain/           Pure core — entities (dataclasses) + interfaces (ABC "ports")
infrastructure/   Outbound adapters — redshift, vector_store, graph_ontology, business_catalog
core/             Cross-cutting — config, logging, exceptions, shared tool defs
creds/ components/ Secret injection (Conjur) and auth helpers
gateway/ prompts/ scripts/   Exported tool schema, LLM prompt templates, offline utilities
```

Rules:

- **`domain/` imports nothing from outer layers.** It holds `@dataclass` entities and `ABC`
  interfaces (ports) only — e.g. `domain/interfaces/redshift_gateway.py` defines the abstract
  `RedshiftGateway`; `infrastructure/redshift/gateway.py` implements it.
- **`application/` services depend on domain interfaces, never concrete adapters.** Keep them
  I/O-free where possible — e.g. `datasource_router.py` is a documented *pure function* that
  accepts plain data and structurally cannot call out to a DB.
- **`infrastructure/` is the only place that touches the network, DBs, or AWS.**
- **`api/` wires everything via a factory** (`api/app.py::create_app()`) and caches heavy
  dependencies in a module-level singleton so Lambda warm invocations skip re-init.
- One sub-package per external system under `infrastructure/`, each with its own `__init__.py`.

---

## 4. Configuration & secrets

- **Single source of truth:** `core/config.py` builds a frozen `AppConfig` singleton once at import
  time (`settings = AppConfig.from_raw(_RAW)`). Import `settings` everywhere; never read env vars
  ad hoc elsewhere.
- **Resolution order:** environment variable **wins over** `config.yaml` value. `config.yaml` holds
  only non-sensitive structure/routing defaults bundled in the image.
- **Secrets never live in `config.yaml` or source.** DB users/passwords are injected at runtime
  into `os.environ` by `creds/conjur_secrets.py`, then config is re-read. Mark secret fields
  `required=False` at import time (Conjur hasn't run yet); validate post-injection.
- Use the typed helpers `_env`, `_env_int`, `_env_bool`, `_env_float` — each takes
  `(key, yaml_fallback, default/required)`. Missing-but-required config logs a **WARNING and the
  service still boots**, failing gracefully at request time rather than refusing to start.
- Each config section is its own `@dataclass(frozen=True)` with a `from_dict` classmethod.

---

## 5. Python coding style

**Idioms**
- `from __future__ import annotations` at the top of **every** module.
- Type hints on all public functions, parameters, and dataclass fields. `Optional[X]`, `X | None`,
  `Dict[str, Any]`, `Tuple`, etc. from `typing`.
- **`@dataclass`** for data structures: `frozen=True` for config/value objects and domain
  entities; `field(default_factory=list)` for mutable defaults; `@property` for derived values.
- **`ABC` + `@abstractmethod`** for ports/interfaces in `domain/interfaces/`.
- Classmethod constructors (`from_dict`, `from_raw`, `create`) for non-trivial construction;
  factory functions for wiring.
- 4-space indent, ~100-char lines. Module/class/function docstrings are **mandatory** — triple
  double-quoted, often with `---` underlined sections explaining *why*, trade-offs, and runtime
  caveats (Lambda vs EKS). This repo documents heavily; match that density.
- Private helpers and module globals are prefixed with `_` (`_env`, `_log`, `_RAW`, `_build_*`).
- Section headers as banner comments:
  ```python
  # ---------------------------------------------------------------------------
  # Helpers
  # ---------------------------------------------------------------------------
  ```
- Allow deliberate broad excepts where boot resilience matters, annotated `# noqa: BLE001`, and
  **log** (`_log.warning`/`.exception`) rather than crash.

**Logging**
- `logging` stdlib only. Module logger via `logging.getLogger(__name__)` (named `_log` or
  `logger`); some operational modules use an explicit UPPER_SNAKE name
  (`logging.getLogger("DATASOURCE_ROUTER")`).
- Configure once at startup via `core/logging_config.py::configure_logging()`. Use `%`-style
  lazy args (`_log.warning("bad %s", x)`), never f-strings in log calls.
- Silence noisy third-party loggers (`urllib3`, `boto3`, `botocore`, `httpx`, …) to WARNING.

**Errors**
- Custom exceptions in `core/exceptions.py`, all subclassing a single `AppError` base. HTTP-facing
  ones carry a `status_code` class attribute.

**Async**
- Route handlers are always `async def` (FastAPI best practice).
- Natively-async work (Bedrock calls) is awaited directly; **sync-blocking** work (psycopg2,
  pgvector) is offloaded with `asyncio.to_thread` so the event loop is never blocked.

**Naming**
- `snake_case` functions/vars, `PascalCase` classes, `UPPER_SNAKE` constants, `snake_case.py`
  modules. Test files `test_<unit>.py`.

---

## 6. Testing

- `pytest` with `testpaths = tests`, `asyncio_mode = auto`, `DeprecationWarning` filtered.
- `tests/conftest.py` makes the repo root importable and **strips `AWS_LAMBDA_FUNCTION_NAME`** so
  the eager Lambda INIT path never fires under test.
- Prefer **pure, dependency-free unit tests**: construct units from plain
  `types.SimpleNamespace` / dicts / lists and `@pytest.fixture` factories rather than real DB,
  Neptune, or vector clients. If a unit needs mocking to test, that's a smell the layering is wrong.
- One test module per unit; module docstring states the contract under test. Group cases with
  banner comments. Name tests `test_<behavior>_<expected>`.

---

## 7. Build & deployment

- PowerShell build scripts (`build_lambda*.ps1`, `build_layer*.ps1`) package the Lambda and its
  dependency layers.
- Jenkins pipeline: Git checkout → SonarQube static analysis → non-blocking quality gate → zip
  (excluding `tests/`, `__pycache__`, `dist/`, `.git`, `Jenkinsfile`) → Artifactory → uDeploy.
- Runtime targets: Lambda handler `main.handler`; EKS
  `gunicorn main:app -k uvicorn.workers.UvicornWorker`.
- Do heavy init (secrets, connections) during the Lambda **INIT phase** (module import), not in the
  handler — INIT time is outside the timeout budget. Catch and log init failures; retry on first
  request instead of crashing the container.
- `.gitignore` must exclude secrets (`.env`, `.env.*`), build artifacts (`dist/`, `gdh_mcp/`),
  `__pycache__/`, and `.pytest_cache/`. Commit `.env.example`, never `.env`.

---

## 8. Quick checklist before committing

- [ ] New external system → new `infrastructure/<system>/` adapter implementing a `domain`
      interface; business logic stays in `application/`.
- [ ] No secrets in `config.yaml` or source; new secrets flow through Conjur injection.
- [ ] New config → a `@dataclass(frozen=True)` section in `core/config.py` with `from_dict` + env
      override and a safe default.
- [ ] `from __future__ import annotations`, full type hints, and a real docstring on new modules.
- [ ] Blocking I/O in an async path is wrapped in `asyncio.to_thread`.
- [ ] Pure unit test added under `tests/`, no live dependencies.
- [ ] Dependencies pinned in `requirements.txt`.
