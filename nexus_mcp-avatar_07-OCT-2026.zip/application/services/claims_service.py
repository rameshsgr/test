"""
application.services.claims_service
-----------------------------------

Orchestrates claim use-cases over a :class:`ClaimsGateway` (FINEOS).
"""

from __future__ import annotations

from typing import Any

from core.validation import require_non_empty
from domain.entities.customer import Customer
from domain.interfaces.claims_gateway import ClaimsGateway


class ClaimsService:
    def __init__(self, claims_gateway: ClaimsGateway) -> None:
        self._claims = claims_gateway

    async def list_all_claims_by_customer(self, customer: Customer) -> list[dict[str, Any]]:
        return await self._claims.list_claims(customer)

    async def get_claim_details_by_cid(self, claim_id: str) -> dict[str, Any]:
        return await self._claims.get_claim_details(require_non_empty(claim_id, "ClaimID"))
