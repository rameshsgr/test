"""
application.services.absence_service
------------------------------------

Orchestrates absence use-cases over an :class:`AbsenceGateway` (FINEOS).
"""

from __future__ import annotations

from typing import Any

from core.validation import require_non_empty
from domain.entities.customer import Customer
from domain.interfaces.absence_gateway import AbsenceGateway


class AbsenceService:
    def __init__(self, absence_gateway: AbsenceGateway) -> None:
        self._absences = absence_gateway

    async def list_customer_absences(self, customer: Customer) -> list[dict[str, Any]]:
        return await self._absences.list_absences(customer)

    async def get_absence_details_by_aid(self, absence_id: str) -> dict[str, Any]:
        return await self._absences.get_absence_details(require_non_empty(absence_id, "AbsenceID"))
