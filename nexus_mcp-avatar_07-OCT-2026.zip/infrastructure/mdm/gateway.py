"""
infrastructure.mdm.gateway
--------------------------

MDM adapter — implements :class:`CustomerGateway` against the MDM customer
GraphQL API.

Currently ``get_customer_details_by_ssn`` is fully wired; the remaining methods
raise :class:`ToolNotImplementedError` until their MDM contracts are confirmed.

Networking notes
----------------
* ``httpx.AsyncClient`` is natively async, so calls are awaited directly (no
  ``asyncio.to_thread`` needed). One client is reused for the process lifetime.
* Every request carries the ``X-AUTH-TYPE`` header (``Oauth`` by default). OAuth
  bearer-token acquisition from the client id/secret is not yet specified — see
  the TODO in ``_auth_headers``.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from core.config import MDMConfig
from core.exceptions import ExternalSystemError, ToolNotImplementedError
from domain.interfaces.customer_gateway import CustomerGateway
from infrastructure.mdm.queries import build_details_payload

_log = logging.getLogger(__name__)


class MDMGateway(CustomerGateway):
    """Concrete customer gateway backed by the MDM GraphQL endpoint."""

    def __init__(self, config: MDMConfig) -> None:
        self._config = config
        self._client = httpx.AsyncClient(timeout=config.timeout)

    # -- public port methods ------------------------------------------------
    async def get_customer_details_by_ssn(self, ssn: str) -> list[dict[str, Any]]:
        """Full customer detail lookup by SSN (idType=SSN)."""
        payload = build_details_payload(id_number=ssn, id_type="SSN")
        data = await self._post_graphql(payload)
        return self._extract_nodes(data)

    async def get_customer_details_by_umid(self, umid: str) -> list[dict[str, Any]]:
        raise ToolNotImplementedError("MDM get_customer_details_by_umid not yet implemented")

    async def search_customer_by_ssn(self, ssn: str) -> list[dict[str, Any]]:
        raise ToolNotImplementedError("MDM search_customer_by_ssn not yet implemented")

    async def search_customer_by_umid(self, umid: str) -> list[dict[str, Any]]:
        raise ToolNotImplementedError("MDM search_customer_by_umid not yet implemented")

    # -- internals ----------------------------------------------------------
    def _auth_headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-AUTH-TYPE": self._config.auth_type,
        }
        # TODO: obtain an OAuth bearer token from client_id/client_secret and add
        #       `Authorization: Bearer <token>` here once the token flow is known.
        return headers

    async def _post_graphql(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self._config.uri:
            raise ExternalSystemError("MDM_URI is not configured")
        try:
            response = await self._client.post(
                self._config.uri,
                json=payload,
                headers=self._auth_headers(),
            )
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPError as exc:
            _log.exception("MDM request failed")
            raise ExternalSystemError(f"MDM request failed: {exc}") from exc

        if data.get("errors"):
            _log.warning("MDM returned GraphQL errors: %s", data["errors"])
            raise ExternalSystemError(f"MDM GraphQL errors: {data['errors']}")
        return data

    @staticmethod
    def _extract_nodes(data: dict[str, Any]) -> list[dict[str, Any]]:
        edges = (
            data.get("data", {})
            .get("searchCustomer", {})
            .get("edges", [])
        ) or []
        return [edge.get("node", {}) for edge in edges]

    async def aclose(self) -> None:
        """Close the underlying HTTP client (call on shutdown)."""
        await self._client.aclose()
