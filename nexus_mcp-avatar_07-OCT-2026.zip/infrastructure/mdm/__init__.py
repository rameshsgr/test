"""MDM adapter package (customer master data — GraphQL)."""
