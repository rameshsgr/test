"""FINEOS adapter package (claims + absences)."""
