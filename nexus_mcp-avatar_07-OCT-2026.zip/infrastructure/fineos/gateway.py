"""
infrastructure.fineos.gateway
-----------------------------

FINEOS adapter — implements both :class:`ClaimsGateway` and
:class:`AbsenceGateway`. Stubbed until the FINEOS contracts are confirmed.
"""

from __future__ import annotations

from typing import Any

from core.config import FineosConfig
from core.exceptions import ToolNotImplementedError
from domain.entities.customer import Customer
from domain.interfaces.absence_gateway import AbsenceGateway
from domain.interfaces.claims_gateway import ClaimsGateway


class FineosGateway(ClaimsGateway, AbsenceGateway):
    """Concrete claims + absence gateway backed by FINEOS."""

    def __init__(self, config: FineosConfig) -> None:
        self._config = config

    # -- claims -------------------------------------------------------------
    async def list_claims(self, customer: Customer) -> list[dict[str, Any]]:
        raise ToolNotImplementedError("FINEOS list_claims not yet implemented")

    async def get_claim_details(self, claim_id: str) -> dict[str, Any]:
        raise ToolNotImplementedError("FINEOS get_claim_details not yet implemented")

    # -- absences -----------------------------------------------------------
    async def list_absences(self, customer: Customer) -> list[dict[str, Any]]:
        raise ToolNotImplementedError("FINEOS list_absences not yet implemented")

    async def get_absence_details(self, absence_id: str) -> dict[str, Any]:
        raise ToolNotImplementedError("FINEOS get_absence_details not yet implemented")
