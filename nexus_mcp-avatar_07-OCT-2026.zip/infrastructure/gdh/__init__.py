"""GDH adapter package (eligibility)."""
