"""
infrastructure.gdh.gateway
--------------------------

GDH adapter — implements :class:`EligibilityGateway`. Stubbed until the GDH
eligibility contract is confirmed.
"""

from __future__ import annotations

from typing import Any

from core.config import GDHConfig
from core.exceptions import ToolNotImplementedError
from domain.entities.customer import Customer
from domain.interfaces.eligibility_gateway import EligibilityGateway


class GDHGateway(EligibilityGateway):
    """Concrete eligibility gateway backed by GDH."""

    def __init__(self, config: GDHConfig) -> None:
        self._config = config

    async def get_eligibility(self, customer: Customer) -> dict[str, Any]:
        raise ToolNotImplementedError("GDH get_eligibility not yet implemented")
