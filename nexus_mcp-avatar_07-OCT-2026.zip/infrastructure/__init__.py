"""nexus-mcp infrastructure package — outbound adapters (the only layer with I/O)."""
