# nexus-mcp

A **FastMCP** service that exposes customer, claim, and absence tools backed by several
external systems (MDM, GDH, FINEOS). Built with a Clean / Hexagonal architecture — see
[CLAUDE.md](CLAUDE.md) for the conventions this project follows.

## Layout

```
api/              FastMCP adapter — server factory + tool registration
application/      Use-cases / orchestration (services)
domain/           Pure core — Pydantic entities + ABC interfaces (ports)
infrastructure/   Outbound adapters — mdm/ (GraphQL), gdh/, fineos/
core/             Cross-cutting — config, logging, exceptions, validation
main.py           Entry point (runs the FastMCP server)
```

## Tools

| Tool                             | System    | Status        |
|----------------------------------|-----------|---------------|
| `search_customer_bySSN`          | MDM       | stub          |
| `search_customer_byUMID`         | MDM       | stub          |
| `get_customer_details_bySSN`     | MDM       | implemented   |
| `get_customer_details_byUMID`    | MDM       | stub          |
| `get_customer_eligibility_details` | GDH     | stub          |
| `list_all_claims_byCustomer`     | FINEOS    | stub          |
| `get_claim_details_byCID`        | FINEOS    | stub          |
| `list_customer_absences`         | FINEOS    | stub          |
| `get_absence_details_byAID`      | FINEOS    | stub          |

## Setup

Dependencies are pulled through the index configured in `uv.toml`.

```powershell
uv sync
Copy-Item .env.example .env   # then fill in real secrets
```

## Run

```powershell
# stdio transport (default — for MCP clients such as Claude Desktop / VS Code)
uv run python main.py

# HTTP transport
uv run python main.py --http --port 8000
```

## Test

```powershell
uv run pytest
```
