"""
core.config
-----------

Single source of truth for configuration. An immutable :class:`AppConfig`
singleton (``settings``) is built once at import time from environment variables
(a local ``.env`` is loaded first, for development).

Resolution rules
----------------
* Environment variable **wins** over everything else.
* Secrets (``*_CLIENT_ID`` / ``*_CLIENT_SECRET``) never live in source — they are
  supplied via ``.env`` locally or injected into the environment in deployment.
* Missing-but-required config logs a WARNING; the service still boots and fails
  gracefully at request time rather than refusing to start.

Each external system is its own frozen ``@dataclass`` section.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass

from dotenv import load_dotenv

_log = logging.getLogger(__name__)

# Load a local .env (no-op if the file is absent or vars already set).
load_dotenv()


# ---------------------------------------------------------------------------
# Typed env helpers — env var wins; `required` only logs, never crashes boot.
# ---------------------------------------------------------------------------
def _env(key: str, default: str | None = None, *, required: bool = False) -> str | None:
    value = os.environ.get(key)
    if value is not None and value.strip():
        return value.strip()
    if required:
        _log.warning("Required config %s is missing; service will boot but may fail at request time", key)
    return default


def _env_int(key: str, default: int) -> int:
    raw = os.environ.get(key)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw)
    except ValueError:
        _log.warning("Config %s=%r is not an int; using default %d", key, raw, default)
        return default


# ---------------------------------------------------------------------------
# Config sections
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class MDMConfig:
    """MDM customer master-data API (GraphQL)."""

    uri: str | None
    client_id: str | None
    client_secret: str | None
    auth_type: str = "Oauth"
    timeout: int = 30

    @classmethod
    def from_env(cls) -> "MDMConfig":
        return cls(
            uri=_env("MDM_URI", required=True),
            client_id=_env("MDM_CLIENT_ID", required=True),
            client_secret=_env("MDM_CLIENT_SECRET", required=True),
            auth_type=_env("MDM_AUTH_TYPE", "Oauth") or "Oauth",
            timeout=_env_int("MDM_TIMEOUT", 30),
        )


@dataclass(frozen=True)
class GDHConfig:
    """GDH eligibility API."""

    uri: str | None
    client_id: str | None
    client_secret: str | None
    timeout: int = 30

    @classmethod
    def from_env(cls) -> "GDHConfig":
        return cls(
            uri=_env("GDH_URI"),
            client_id=_env("GDH_CLIENT_ID", required=True),
            client_secret=_env("GDH_CLIENT_SECRET", required=True),
            timeout=_env_int("GDH_TIMEOUT", 30),
        )


@dataclass(frozen=True)
class FineosConfig:
    """FINEOS claims + absence API."""

    uri: str | None
    client_id: str | None
    client_secret: str | None
    timeout: int = 30

    @classmethod
    def from_env(cls) -> "FineosConfig":
        return cls(
            uri=_env("FINEOS_URI"),
            client_id=_env("FINEOS_CLIENT_ID", required=True),
            client_secret=_env("FINEOS_CLIENT_SECRET", required=True),
            timeout=_env_int("FINEOS_TIMEOUT", 30),
        )


@dataclass(frozen=True)
class AppConfig:
    """Root configuration aggregate."""

    mdm: MDMConfig
    gdh: GDHConfig
    fineos: FineosConfig
    server_name: str = "nexus-mcp"
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "AppConfig":
        return cls(
            mdm=MDMConfig.from_env(),
            gdh=GDHConfig.from_env(),
            fineos=FineosConfig.from_env(),
            server_name=_env("MCP_SERVER_NAME", "nexus-mcp") or "nexus-mcp",
            log_level=_env("LOG_LEVEL", "INFO") or "INFO",
        )


# Frozen singleton — import this everywhere; never read env vars ad hoc elsewhere.
settings = AppConfig.from_env()
