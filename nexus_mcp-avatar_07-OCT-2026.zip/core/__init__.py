"""nexus-mcp core package — cross-cutting concerns (config, logging, exceptions)."""
