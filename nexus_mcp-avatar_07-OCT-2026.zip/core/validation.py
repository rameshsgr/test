"""
core.validation
---------------

Small, pure boundary validators. Tools accept free-form caller input, so values
are normalised and checked here before they reach an external system.
"""

from __future__ import annotations

import re

from core.exceptions import ValidationError

_SSN_DIGITS = re.compile(r"\D")


def normalize_ssn(ssn: str) -> str:
    """Strip separators from an SSN and verify it is exactly 9 digits.

    Returns the 9-digit string. Raises :class:`ValidationError` otherwise.
    """
    if not ssn or not ssn.strip():
        raise ValidationError("SSN is required")
    digits = _SSN_DIGITS.sub("", ssn)
    if len(digits) != 9:
        raise ValidationError("SSN must contain exactly 9 digits")
    return digits


def require_non_empty(value: str, field: str) -> str:
    """Return a trimmed non-empty string or raise :class:`ValidationError`."""
    if not value or not value.strip():
        raise ValidationError(f"{field} is required")
    return value.strip()
