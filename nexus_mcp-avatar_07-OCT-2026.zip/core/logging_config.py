"""
core.logging_config
-------------------

Configure logging exactly once at startup. Noisy third-party loggers are pinned
to WARNING so service logs stay readable.
"""

from __future__ import annotations

import logging

_NOISY_LOGGERS = ("urllib3", "boto3", "botocore", "httpx", "httpcore", "asyncio")

_configured = False


def configure_logging(level: str = "INFO") -> None:
    """Idempotently configure the root logger and silence noisy libraries."""
    global _configured
    if _configured:
        return

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-8s %(name)s | %(message)s",
    )
    for name in _NOISY_LOGGERS:
        logging.getLogger(name).setLevel(logging.WARNING)

    _configured = True
