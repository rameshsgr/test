"""
core.exceptions
---------------

Single exception hierarchy for the service. Every error raised deliberately by
application/infrastructure code subclasses :class:`AppError`, which carries an
HTTP-ish ``status_code`` so an adapter (FastMCP/HTTP) can translate it uniformly.
"""

from __future__ import annotations


class AppError(Exception):
    """Base class for all application errors."""

    status_code: int = 500


class ConfigError(AppError):
    """Raised when required configuration is missing or malformed."""

    status_code = 500


class ValidationError(AppError):
    """Raised when a caller-supplied argument fails boundary validation."""

    status_code = 400


class ExternalSystemError(AppError):
    """Raised when an upstream system (MDM/GDH/FINEOS) errors or is unreachable."""

    status_code = 502


class ToolNotImplementedError(AppError):
    """Raised by a tool/adapter whose behaviour has not been wired up yet."""

    status_code = 501
