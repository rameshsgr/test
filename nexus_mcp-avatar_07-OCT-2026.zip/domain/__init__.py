"""nexus-mcp domain package — pure entities and interface ports (no I/O)."""
