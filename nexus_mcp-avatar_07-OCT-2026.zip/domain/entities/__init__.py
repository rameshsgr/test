"""Domain entities (Pydantic v2 models)."""

from __future__ import annotations

from domain.entities.absence import Absence
from domain.entities.claim import Claim
from domain.entities.customer import Customer

__all__ = ["Customer", "Claim", "Absence"]
