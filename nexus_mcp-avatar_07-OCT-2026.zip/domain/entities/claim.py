"""
domain.entities.claim
---------------------

The ``Claim`` entity. Minimal for now; attributes will be expanded as confirmed.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Claim(BaseModel):
    """A claim associated with a customer."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    claim_id: Optional[str] = Field(default=None, description="Claim identifier (CID)")
    customer_umid: Optional[str] = None
    status: Optional[str] = None
