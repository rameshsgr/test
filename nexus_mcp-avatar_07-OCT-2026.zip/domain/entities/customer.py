"""
domain.entities.customer
------------------------

The ``Customer`` entity. Only identity fields are modelled for now; the full set
of attributes (addresses, contacts, occupation, …) will be added as they are
confirmed. ``extra="allow"`` keeps the model forward-compatible in the meantime.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Customer(BaseModel):
    """A customer / client. Used both as structured tool input and as output."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    umid: Optional[str] = Field(default=None, description="Unified Member ID")
    ssn: Optional[str] = Field(default=None, description="9-digit SSN (no separators)")
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    date_of_birth: Optional[str] = None
