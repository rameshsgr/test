"""
domain.entities.absence
-----------------------

The ``Absence`` entity. Minimal for now; attributes will be expanded as confirmed.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Absence(BaseModel):
    """An absence associated with a customer."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    absence_id: Optional[str] = Field(default=None, description="Absence identifier (AID)")
    customer_umid: Optional[str] = None
    status: Optional[str] = None
