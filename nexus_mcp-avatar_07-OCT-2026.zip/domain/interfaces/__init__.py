"""Domain interface ports (abstract gateways). Implemented in `infrastructure/`."""

from __future__ import annotations

from domain.interfaces.absence_gateway import AbsenceGateway
from domain.interfaces.claims_gateway import ClaimsGateway
from domain.interfaces.customer_gateway import CustomerGateway
from domain.interfaces.eligibility_gateway import EligibilityGateway

__all__ = [
    "CustomerGateway",
    "EligibilityGateway",
    "ClaimsGateway",
    "AbsenceGateway",
]
