"""
domain.interfaces.absence_gateway
---------------------------------

Port for the absence system (FINEOS). Implemented by
``infrastructure/fineos/gateway.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from domain.entities.customer import Customer


class AbsenceGateway(ABC):
    @abstractmethod
    async def list_absences(self, customer: Customer) -> list[dict[str, Any]]:
        """Return all absences for a customer."""

    @abstractmethod
    async def get_absence_details(self, absence_id: str) -> dict[str, Any]:
        """Return full detail for a single absence."""
