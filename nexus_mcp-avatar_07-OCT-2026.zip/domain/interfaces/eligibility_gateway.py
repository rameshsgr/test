"""
domain.interfaces.eligibility_gateway
-------------------------------------

Port for the eligibility system (GDH). Implemented by
``infrastructure/gdh/gateway.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from domain.entities.customer import Customer


class EligibilityGateway(ABC):
    @abstractmethod
    async def get_eligibility(self, customer: Customer) -> dict[str, Any]:
        """Return eligibility details for a customer."""
