"""
domain.interfaces.claims_gateway
--------------------------------

Port for the claims system (FINEOS). Implemented by
``infrastructure/fineos/gateway.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from domain.entities.customer import Customer


class ClaimsGateway(ABC):
    @abstractmethod
    async def list_claims(self, customer: Customer) -> list[dict[str, Any]]:
        """Return all claims for a customer."""

    @abstractmethod
    async def get_claim_details(self, claim_id: str) -> dict[str, Any]:
        """Return full detail for a single claim."""
