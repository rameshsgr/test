"""
domain.interfaces.customer_gateway
----------------------------------

Port for the customer master-data system (MDM). Implemented by
``infrastructure/mdm/gateway.py``.

Methods return raw decoded JSON (``list[dict]``) for now; typed mapping into
``Customer`` can be layered in once the full attribute set is confirmed.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class CustomerGateway(ABC):
    @abstractmethod
    async def search_customer_by_ssn(self, ssn: str) -> list[dict[str, Any]]:
        """Return matching customer summaries for an SSN."""

    @abstractmethod
    async def search_customer_by_umid(self, umid: str) -> list[dict[str, Any]]:
        """Return matching customer summaries for a UMID."""

    @abstractmethod
    async def get_customer_details_by_ssn(self, ssn: str) -> list[dict[str, Any]]:
        """Return full customer detail records for an SSN."""

    @abstractmethod
    async def get_customer_details_by_umid(self, umid: str) -> list[dict[str, Any]]:
        """Return full customer detail records for a UMID."""
