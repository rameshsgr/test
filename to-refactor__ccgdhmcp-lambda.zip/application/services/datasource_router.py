"""DatasourceRouter — picks which Redshift datasource should serve a query.

Pure function, no I/O
----------------------
This module has NO dependency on VectorStoreGateway, RedshiftGateway, or
Neptune. It consumes data the orchestration layer already produced from a
single vector search call — it never performs a search of its own. This is
enforced structurally: the router's signature only accepts plain data
(schema names / vector result dicts / an intent string), so it has no handle
through which it could call out to pgvector, Redshift, or Neptune.

Priority (highest to lowest, per architecture review)
-------------------------------------------------------
1. Retrieved schemas   — if the schemas present in the vector results
   resolve to exactly one datasource, that datasource wins outright.
   If they resolve to more than one, routing STOPS with a structured
   ambiguity warning — intent is never consulted to break this tie.
2. Vector evidence      — used only when schema names alone were absent/
   unresolvable (e.g. no schema_name populated on any result row).
3. Query intent          — a tie-breaker ONLY among datasource candidates
   that vector evidence has already narrowed down. Intent can never
   introduce a datasource that isn't already supported by (1) or (2), and
   it is never consulted at all while schema evidence is decisive.

Schema -> datasource routing map is derived automatically from
``AppConfig.datasources[*].schemas`` — there is no separate config table to
keep in sync.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

_log = logging.getLogger("DATASOURCE_ROUTER")


@dataclass(frozen=True)
class DatasourceDecision:
    """A single resolved datasource to route the query to."""

    datasource: str
    reason: str
    candidate_datasources: tuple = ()


@dataclass(frozen=True)
class AmbiguousDatasourceWarning:
    """Routing could not (and must not) pick a single datasource.

    Execution must stop here — the caller must surface this structured
    warning to the requester rather than silently defaulting to any one
    datasource.
    """

    candidate_datasources: tuple
    retrieved_schemas: tuple
    reason: str


class DatasourceRouter:
    """Resolves a query to exactly one datasource, or flags ambiguity.

    Built once from the datasource registry (``AppConfig.datasources``);
    ``resolve()`` is then a pure function of its three inputs — safe to call
    per-request with no side effects and no external calls.
    """

    def __init__(self, datasources: dict) -> None:
        # schema name (upper-cased) -> datasource name
        self._schema_to_datasource: dict = {}
        for ds_name, ds_cfg in datasources.items():
            for schema in getattr(ds_cfg, "schemas", ()) or ():
                self._schema_to_datasource[str(schema).upper()] = ds_name

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve(
        self,
        retrieved_schemas: Optional[list] = None,
        vector_results: Optional[dict] = None,
        intent: Optional[str] = None,
    ):
        """Resolve a datasource for one query.

        Parameters are plain data only — see module docstring. All three are
        derived by the orchestration layer from the SAME single vector
        search call for a given request.
        """
        retrieved_schemas = retrieved_schemas or []
        vector_results = vector_results or {}

        # --- Priority 1: retrieved schemas -------------------------------
        schema_candidates = self._datasources_for_schemas(retrieved_schemas)
        if len(schema_candidates) == 1:
            decision = DatasourceDecision(
                datasource=next(iter(schema_candidates)),
                reason="retrieved_schemas",
                candidate_datasources=tuple(schema_candidates),
            )
            self._log_decision(retrieved_schemas, schema_candidates, decision)
            return decision
        if len(schema_candidates) > 1:
            # Conflicting schema evidence — intent must NEVER override this.
            warning = AmbiguousDatasourceWarning(
                candidate_datasources=tuple(sorted(schema_candidates)),
                retrieved_schemas=tuple(retrieved_schemas),
                reason="retrieved_schemas_conflict",
            )
            self._log_warning(retrieved_schemas, schema_candidates, warning)
            return warning

        # --- Priority 2: vector evidence ---------------------------------
        vector_schemas = self._schemas_from_vector_results(vector_results)
        vector_candidates = self._datasources_for_schemas(vector_schemas)
        if len(vector_candidates) == 1:
            decision = DatasourceDecision(
                datasource=next(iter(vector_candidates)),
                reason="vector_evidence",
                candidate_datasources=tuple(vector_candidates),
            )
            self._log_decision(vector_schemas, vector_candidates, decision)
            return decision
        if len(vector_candidates) > 1:
            # --- Priority 3: query intent, tie-break ONLY ----------------
            if intent and intent in vector_candidates:
                decision = DatasourceDecision(
                    datasource=intent,
                    reason="intent_tiebreak",
                    candidate_datasources=tuple(vector_candidates),
                )
                self._log_decision(vector_schemas, vector_candidates, decision)
                return decision
            warning = AmbiguousDatasourceWarning(
                candidate_datasources=tuple(sorted(vector_candidates)),
                retrieved_schemas=tuple(vector_schemas),
                reason="vector_evidence_conflict",
            )
            self._log_warning(vector_schemas, vector_candidates, warning)
            return warning

        # --- No schema or vector evidence at all -------------------------
        # Intent alone is too weak to route a Redshift query.
        warning = AmbiguousDatasourceWarning(
            candidate_datasources=(),
            retrieved_schemas=(),
            reason="no_evidence",
        )
        self._log_warning([], set(), warning)
        return warning

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _datasources_for_schemas(self, schemas) -> set:
        candidates = set()
        for schema in schemas:
            if not schema:
                continue
            ds = self._schema_to_datasource.get(str(schema).upper())
            if ds:
                candidates.add(ds)
        return candidates

    @staticmethod
    def _schemas_from_vector_results(vector_results: dict) -> list:
        schemas = []
        for row in (vector_results.get("tables") or []):
            s = row.get("schema_name")
            if s:
                schemas.append(s)
        for row in (vector_results.get("columns") or []):
            s = row.get("schema_name")
            if s:
                schemas.append(s)
        return schemas

    @staticmethod
    def _log_decision(retrieved_schemas, candidates, decision: DatasourceDecision) -> None:
        _log.info(
            "retrieved_schemas=%s candidate_datasources=%s selected_datasource=%s reason=%s",
            list(dict.fromkeys(retrieved_schemas)),
            sorted(candidates),
            decision.datasource,
            decision.reason,
        )

    @staticmethod
    def _log_warning(retrieved_schemas, candidates, warning: AmbiguousDatasourceWarning) -> None:
        _log.warning(
            "retrieved_schemas=%s candidate_datasources=%s selected_datasource=None reason=%s",
            list(dict.fromkeys(retrieved_schemas)),
            sorted(candidates),
            warning.reason,
        )
