"""RedshiftToolService — MCP tool-provider service.

This service is the core of the MCP server.  It owns all infrastructure
gateways (Redshift, pgvector, GraphOntologyEnricher) and exposes them as
discrete, callable tool methods:

  list_tables          → schema discovery
  describe_table       → column / key introspection
  generate_sql         → Bedrock LLM SQL generation
  query_redshift       → SQL execution
  vector_search        → semantic metadata search
  get_metadata_context → combined vector + graph enrichment

An external agent calls whichever tools it needs via the ``/tools/*``
HTTP endpoints.  The ``process_query`` method provides a convenience
3-stage pipeline (vector_search → generate_sql → query_redshift) for
simple end-to-end queries via ``POST /query``.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, Dict, List, Optional

from core.config import settings
from domain.entities.query_result import QueryResult
from domain.interfaces.redshift_gateway import RedshiftGateway
from domain.interfaces.vector_store_gateway import VectorStoreGateway
from infrastructure.redshift.redshift_client import RedshiftClient

logger = logging.getLogger(__name__)


class RedshiftToolService:
    """Stateless service: one instance per application lifetime."""

    # Column-name keywords that indicate a pre-aggregated numeric metric
    # (count, total, sum, amount, etc.).  Used to identify candidate metric
    # columns so the LLM can be guided to use them instead of inventing
    # new column/table names.
    _METRIC_KEYWORDS: tuple = (
        "count", "total", "sum", "amount", "lives", "enrolled",
        "eligible", "premium", "balance", "rate", "percent", "pct",
        "revenue", "headcount", "volume", "qty", "quantity",
    )

    # Numeric Redshift data types — only columns of these types are surfaced
    # as candidate metric columns (VARCHAR/DATE columns are excluded even if
    # their name contains a metric keyword).
    _NUMERIC_TYPES: tuple = (
        "integer", "int", "bigint", "smallint", "numeric", "decimal",
        "float", "double", "real", "number",
    )

    # Column-name suffixes that indicate a numeric identifier rather than a
    # pre-aggregated metric.  Columns ending in these suffixes pass the
    # metric-keyword test only because the keyword appears as a substring
    # inside the suffix (e.g. "count" inside "account_number", "key" inside
    # "hash_key").  They must be excluded from MATCHED_METRIC_COLUMNS and
    # logged as REJECTED_IDENTIFIER_COLUMNS instead.
    _IDENTIFIER_SUFFIXES: tuple = (
        "_id", "_key", "_number",
    )

    @classmethod
    def _detect_metric_columns(
        cls, metadata_context: Dict[str, Any]
    ) -> tuple:
        """Return (metric_columns, rejected_identifier_columns).

        Scans ``relevant_tables`` in the metadata context for columns whose
        name contains a metric keyword AND whose data type is numeric.

        Columns that also end with an identifier suffix (_id, _key, _number)
        are excluded from metric_columns and returned separately as
        rejected_identifier_columns — numeric identifiers must not be treated
        as pre-aggregated metrics even when a metric keyword appears as a
        substring of their name (e.g. "count" inside "client_account_number").
        """
        found: List[Dict[str, Any]] = []
        rejected: List[Dict[str, Any]] = []
        for tbl in metadata_context.get("relevant_tables", []):
            full_name = tbl.get("full_name", "")
            col_types = tbl.get("column_types", {}) or {}
            for col in tbl.get("column_names", []):
                col_lower = col.lower()
                if not any(kw in col_lower for kw in cls._METRIC_KEYWORDS):
                    continue
                dtype = (col_types.get(col) or "").lower()
                if not any(nt in dtype for nt in cls._NUMERIC_TYPES):
                    continue
                # Exclude numeric identifiers — they match metric keywords only
                # as substrings but are not pre-aggregated metrics.
                if any(col_lower.endswith(suf) for suf in cls._IDENTIFIER_SUFFIXES):
                    rejected.append({"table": full_name, "column": col, "type": dtype})
                    continue
                found.append({"table": full_name, "column": col, "type": dtype})
        return found, rejected

    # Keywords that mark a query as relationship/ownership-based, i.e. one
    # that benefits from graph enrichment (joins, lineage, extra tables)
    # rather than a plain vector-only lookup.
    _GRAPH_ASSISTED_KEYWORDS = (
        "book of business", "account executive", " ae ", "producer",
        "advisor", "territory", "hierarchy", "parent account", "child account",
        "parent-child", "ownership", "owner", "owns", "rollup", "roll up",
        "roll-up", "organization", "organizational", "relationship analysis",
        "revenue attribution", "attribution",
    )

    def _needs_graph_enrichment(self, user_message: str) -> bool:
        """Keyword-based intent detection (unchanged) — one of two signals
        feeding the combined graph_assisted trigger in get_metadata_context().

        Simple lookups (account/policy/product lookup, straightforward
        aggregations/reporting) stay vector-only. Relationship-shaped
        questions (book of business, ownership, hierarchy, rollups) are
        routed through GraphOntologyEnricher for joins/lineage context.
        """
        msg = f" {user_message.lower()} "
        return any(kw in msg for kw in self._GRAPH_ASSISTED_KEYWORDS)

    # Second graph_assisted signal: a query retrieving this many-or-more
    # tables from PGVector is treated as complex enough to benefit from
    # Neptune enrichment even without matching a keyword — see CloudWatch
    # evidence of keyword-only routing bypassing Neptune on 4-table queries.
    _MULTI_TABLE_THRESHOLD = 3

    def __init__(
        self,
        redshift: RedshiftGateway,
        vector_store: VectorStoreGateway,
        graph_enricher: Optional[Any] = None,
        schemas: Optional[tuple] = None,
    ) -> None:
        self._redshift = redshift
        self._vector_store = vector_store
        # GraphOntologyEnricher — optional, degrades gracefully when None
        self._graph_enricher = graph_enricher
        # None -> fall back to the legacy global (settings.redshift.schemas),
        # preserving exact current behavior for the Discovery-only
        # get_tool_service() path. Datasource-aware callers (QueryOrchestrator
        # via api/app.py::_build_datasource_services()) pass their own
        # DatasourceConfig.schemas so list_tables()/describe_table() never
        # read another datasource's schema list.
        self._schemas = schemas

    # ------------------------------------------------------------------
    # MCP Tool: list_tables
    # ------------------------------------------------------------------

    def list_tables(self, schema: str | None = None) -> Any:
        """List all tables in the given schema, or across ALL configured schemas.

        When *schema* is provided the caller gets exactly that schema.
        When omitted, the result is the combined table list from every schema
        this instance owns (``self._schemas``, i.e. the datasource this
        service was built for — falls back to the legacy
        ``settings.redshift.schemas`` singleton when this instance wasn't
        given an explicit schema list, preserving Discovery's original
        behavior).
        """
        if schema:
            return self._redshift.list_tables(schema)

        all_schemas = self._schemas or settings.redshift.schemas or (settings.redshift.schema,)
        if len(all_schemas) == 1:
            return self._redshift.list_tables(all_schemas[0])

        # Multiple schemas — merge results into a single list
        combined_rows: list = []
        combined_cols: list = []
        for s in all_schemas:
            result = self._redshift.list_tables(s)
            if isinstance(result, dict):
                combined_rows.extend(result.get("rows", []))
                if not combined_cols:
                    combined_cols = result.get("columns", [])
            elif isinstance(result, list):
                combined_rows.extend(result)
        if combined_cols:
            return {"rows": combined_rows, "columns": combined_cols, "total_rows": len(combined_rows)}
        return combined_rows

    # ------------------------------------------------------------------
    # MCP Tool: describe_table
    # ------------------------------------------------------------------

    def describe_table(self, table_name: str, schema: str | None = None) -> Any:
        """Describe columns, types and keys for a table.

        When *schema* is provided it is used directly.
        When omitted, each schema this instance owns (``self._schemas``,
        falling back to the legacy ``settings.redshift.schemas`` singleton)
        is tried in order until a non-empty result is found (handles
        cross-schema table lookups).
        """
        if schema:
            return self._redshift.describe_table(table_name, schema)

        all_schemas = self._schemas or settings.redshift.schemas or (settings.redshift.schema,)
        for s in all_schemas:
            result = self._redshift.describe_table(table_name, s)
            has_rows = (
                (isinstance(result, dict) and result.get("rows"))
                or (isinstance(result, list) and result)
            )
            if has_rows:
                return result
        # Return last (empty) result if nothing found in any schema
        return result

    # ------------------------------------------------------------------
    # MCP Tool: generate_sql
    # ------------------------------------------------------------------

    async def generate_sql(self, prompt: str, schema_context: str | None = None) -> str:
        """Use Bedrock to generate Redshift SQL; does not retrieve or execute data."""
        return await self._redshift.generate_sql(prompt, schema_context)

    # ------------------------------------------------------------------
    # MCP Tool: generate_gremlin
    # ------------------------------------------------------------------

    async def generate_gremlin(self, prompt: str, graph_context: str | None = None) -> str:
        """Use Bedrock to generate Gremlin; does not connect to or query Neptune."""
        return await self._redshift.generate_gremlin(prompt, graph_context)

    # ------------------------------------------------------------------
    # MCP Tool: get_neptune_schema
    # ------------------------------------------------------------------

    def get_neptune_schema(
        self,
        vertex_labels: Optional[List[str]] = None,
        include_properties: bool = True,
        include_edge_properties: bool = True,
        max_labels: int = 25,
        max_properties_per_label: int = 50,
        sample_size: int = 100,
        max_connections: int = 100,
    ) -> Dict[str, Any]:
        """Inspect the Neptune graph-ontology schema; never accesses PGVector or Redshift."""
        if self._graph_enricher is None or not self._graph_enricher.is_loaded:
            raise RuntimeError("Neptune graph ontology is not configured or connected")
        return self._graph_enricher.get_schema(
            vertex_labels=vertex_labels,
            include_properties=include_properties,
            include_edge_properties=include_edge_properties,
            max_labels=max_labels,
            max_properties_per_label=max_properties_per_label,
            sample_size=sample_size,
            max_connections=max_connections,
        )

    # ------------------------------------------------------------------
    # MCP Tool: query_neptune
    # ------------------------------------------------------------------

    def query_neptune(self, gremlin: str, max_results: int = 100) -> Dict[str, Any]:
        """Execute one bounded, read-only traversal on the graph ontology."""
        RedshiftClient._guard_readonly_gremlin(gremlin)
        if self._graph_enricher is None or not self._graph_enricher.is_loaded:
            raise RuntimeError("Neptune graph ontology is not configured or connected")
        return self._graph_enricher.query_readonly(gremlin, max_results=max_results)

    # ------------------------------------------------------------------
    # MCP Tool: query_redshift
    # ------------------------------------------------------------------

    def query_redshift(self, sql: str) -> Any:
        """Execute read-only SQL against Redshift; never accesses PGVector or Neptune.

        Enforces read-only policy before forwarding to the gateway.
        Raises ``PermissionError`` for any write or DDL statement.
        """
        # Guard here as well as inside RedshiftClient._execute_query so that
        # direct calls to the MCP tool endpoint are blocked at the service
        # layer regardless of which gateway implementation is in use.
        RedshiftClient._guard_readonly_sql(sql)
        return self._redshift.execute_query(sql)

    # ------------------------------------------------------------------
    # MCP Tool: vector_search
    # ------------------------------------------------------------------

    def vector_search(self, query: str, top_k: int = 5) -> Any:
        """Search PGVector table/column metadata; never accesses Neptune or Redshift data."""
        return self._vector_store.search(query, top_k=top_k)

    # ------------------------------------------------------------------
    # MCP Tool: get_metadata_context
    # ------------------------------------------------------------------

    def get_metadata_context(
        self,
        user_message: str,
        top_k: int | None = None,
        precomputed_vector_results: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        """PGVector DAR metadata search + optional Neptune ontology enrichment.

        Parameters
        ----------
        top_k : override the default ``settings.search.top_k``.
                Used by the empty-result retry loop to broaden the search.
        precomputed_vector_results : when provided (same shape as
                ``VectorStoreGateway.search_tables_and_columns()`` returns),
                skips the internal vector search entirely and builds the
                metadata context from these results instead. Used by the new
                datasource-aware orchestration path to guarantee exactly one
                vector search per request — the orchestrator runs the search
                once, feeds it to ``DatasourceRouter``, then passes the same
                results in here. Default ``None`` preserves prior behavior
                for every existing caller.
        """
        _top_k    = top_k if top_k is not None else settings.search.top_k
        col_multi = settings.search.column_multiplier

        context: Dict[str, Any] = {"relevant_tables": [], "relevant_columns": []}

        if precomputed_vector_results is not None:
            results = precomputed_vector_results
        else:
            results = self._vector_store.search_tables_and_columns(
                user_message,
                table_count=_top_k,
                column_count=_top_k * col_multi,
            )

        for tbl in results.get("tables", []):
            context["relevant_tables"].append(
                {
                    "full_name": tbl["full_table_name"],
                    "schema": tbl.get("schema_name", ""),
                    "table": tbl.get("table_name", ""),
                    "column_names": tbl.get("column_names", []),
                    "column_types": tbl.get("column_types", {}),
                    "column_count": len(tbl.get("column_names", [])),
                    "primary_keys": tbl.get("primary_key_columns", []),
                    "foreign_keys": tbl.get("foreign_key_columns", []),
                    "description": tbl.get("table_description", ""),
                    "relevance_score": tbl.get("_score", 0.0),
                }
            )

        for col in results.get("columns", []):
            context["relevant_columns"].append(
                {
                    "full_name": col["full_column_name"],
                    "table": col["table_name"],
                    "schema": col.get("schema_name", ""),
                    "column": col.get("column_name", ""),
                    "data_type": col.get("data_type", "unknown"),
                    "is_pk": col.get("is_primary_key", False),
                    "is_fk": col.get("is_foreign_key", False),
                    "references": col.get("parent_table_physical_name"),
                    "description": col.get("column_description", ""),
                    "relevance_score": col.get("_score", 0.0),
                }
            )

        # ── Graph ontology enrichment (optional, hybrid-gated) ─────────────
        graph_enabled = self._graph_enricher is not None

        # Two independent signals, evaluated AFTER PGVector retrieval above
        # (context["relevant_tables"] is already fully populated at this
        # point): a keyword-matched query (unchanged behavior) OR a query
        # complex enough to have pulled 3+ tables from the vector store.
        keyword_trigger = self._needs_graph_enrichment(user_message)
        multi_table_trigger = len(context.get("relevant_tables", [])) >= self._MULTI_TABLE_THRESHOLD
        graph_assisted = keyword_trigger or multi_table_trigger

        if keyword_trigger and multi_table_trigger:
            graph_trigger_reason = "KEYWORD_AND_MULTI_TABLE"
        elif keyword_trigger:
            graph_trigger_reason = "KEYWORD"
        elif multi_table_trigger:
            graph_trigger_reason = "MULTI_TABLE"
        else:
            graph_trigger_reason = "NONE"

        if graph_enabled and graph_assisted:
            context = self._graph_enricher.enrich(context, user_query=user_message)
            context["_enricher"] = self._graph_enricher

        gctx = context.get("graph_context", {}) or {}
        graph_relationships_count = len(gctx.get("table_relationships", []))
        graph_joins_count = len(gctx.get("suggested_joins", []))

        # ── PK/FK fallback relationship builder ─────────────────────────────
        # Neptune's DarColumn pkFlag/fkFlag properties are a separate,
        # independently-ingested data source from the pgvector metadata
        # dictionary's pk_flg/fk_flg — Neptune can (and sometimes does) carry
        # no usable PK/FK flags for a table even when the pgvector dictionary
        # has them. Rather than leave the LLM with no join guidance whenever
        # that happens, fall back to deriving joins directly from
        # relevant_tables.primary_keys / .foreign_keys / shared column names
        # — the same PK/FK metadata already visible in the "PK: [...] | FK:
        # [...]" schema-context lines.
        #
        # Like the graph-derived joins above, these are inferred from
        # column-name matching, not a verified relationship — see the
        # "graph-assisted inferred JOIN paths" labeling in
        # _build_schema_context().
        fallback_joins_count = 0
        if graph_joins_count == 0:
            fb_relationships, fb_joins = self._build_pkfk_fallback_relationships(
                context.get("relevant_tables", [])
            )
            fallback_joins_count = len(fb_joins)
            if fb_joins:
                gctx = dict(gctx)  # never mutate a shared/default {} in place
                gctx["table_relationships"] = gctx.get("table_relationships", []) + fb_relationships
                gctx["suggested_joins"] = gctx.get("suggested_joins", []) + fb_joins
                gctx["fallback_pkfk_relationships"] = fb_joins
                context["graph_context"] = gctx

        logger.info(
            "Graph enrichment enabled: %s | Graph-assisted query: %s (reason=%s) | "
            "Graph-inferred relationships injected (column-name match, NOT verified): %d | "
            "Graph-assisted inferred joins injected: %d | "
            "Extra tables injected: %d | Fallback PK/FK-inferred joins injected: %d",
            graph_enabled, graph_assisted, graph_trigger_reason,
            graph_relationships_count, graph_joins_count,
            len(gctx.get("extra_tables", [])),
            fallback_joins_count,
        )

        # CloudWatch instrumentation only — pure logging, no behavior change.
        # Makes it possible to prove, per request, whether a join in
        # graph_context came from NeptuneGraphOntologyEnricher.enrich() or
        # from the PK/FK fallback (_build_pkfk_fallback_relationships),
        # without having to cross-reference the log line above against
        # NeptuneClient's own GRAPH_SOURCE=NEPTUNE/NEPTUNE_THREAD lines.
        logger.info(
            "GRAPH_TRIGGER=%s\nGRAPH_TRIGGER_REASON=%s\nRETRIEVED_TABLES=%d\n"
            "NEPTUNE_ENRICH_CALLED=%s\nGRAPH_RELATIONSHIPS=%d\nFALLBACK_RELATIONSHIPS=%d",
            graph_assisted,
            graph_trigger_reason,
            len(context.get("relevant_tables", [])),
            graph_enabled and graph_assisted,
            graph_relationships_count,
            fallback_joins_count,
        )

        return context

    @staticmethod
    def _build_pkfk_fallback_relationships(
        relevant_tables: List[Dict[str, Any]],
    ) -> tuple[List[str], List[str]]:
        """Derive JOIN guidance from PK/FK + shared-column analysis of the
        vector-retrieved tables, for use when graph-derived relationships are
        empty (see ``get_metadata_context``).

        Emits the SAME structure ``GraphOntologyEnricher.enrich()`` produces
        (``table_relationships`` human-readable strings, ``suggested_joins``
        ready-to-use ``JOIN`` clauses) so callers/prompt-building code do not
        need to special-case the fallback path.

        These are inferred from column-name matching (PK/FK flags + shared
        names), not a verified relationship from any graph edge — same
        caveat as the Neptune-derived joins (see ``_build_schema_context``).
        """
        table_relationships: List[str] = []
        suggested_joins: List[str] = []
        seen: set = set()

        tables = [t for t in relevant_tables if t.get("full_name")]
        for i, t1 in enumerate(tables):
            t1_name = t1["full_name"]
            t1_cols = set(t1.get("column_names", []))
            t1_pk = set(t1.get("primary_keys", []))
            t1_fk = set(t1.get("foreign_keys", []))

            for t2 in tables[i + 1:]:
                t2_name = t2["full_name"]
                t2_cols = set(t2.get("column_names", []))
                t2_pk = set(t2.get("primary_keys", []))
                t2_fk = set(t2.get("foreign_keys", []))

                shared_cols = t1_cols & t2_cols
                for col in sorted(shared_cols):
                    key = frozenset({t1_name, t2_name, col})
                    if key in seen:
                        continue
                    seen.add(key)

                    if col in t1_fk and col in t2_pk:
                        kind = "FK→PK"
                    elif col in t2_fk and col in t1_pk:
                        kind = "FK→PK"
                    elif col in t1_pk and col in t2_pk:
                        kind = "PK↔PK"
                    else:
                        kind = "shared column"

                    table_relationships.append(f"{t1_name}.{col} ↔ {t2_name}.{col} ({kind})")
                    suggested_joins.append(
                        f"JOIN {t2_name} ON {t1_name}.{col} = {t2_name}.{col}"
                    )

        return table_relationships, suggested_joins

    # ------------------------------------------------------------------
    # Use-case entry point  (simple pipeline — no agent loop)
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_confidence(relevant_tables: List[Dict[str, Any]]) -> float:
        """Derive a 0–1 confidence score from the best vector-search similarity.

        ``relevance_score`` stored in each table entry is the raw L2 distance
        returned by pgvector (lower = closer match).  Convert to similarity via
        ``1 / (1 + distance)`` so that:
          distance = 0   → similarity = 1.0  (perfect match)
          distance = 1   → similarity = 0.5
          distance = inf → similarity = 0.0
        """
        if not relevant_tables:
            return 0.0
        best_distance = min(
            t.get("relevance_score", 1.0) for t in relevant_tables
        )
        return round(1.0 / (1.0 + best_distance), 4)

    @staticmethod
    def _build_schema_context(metadata_context: Dict[str, Any]) -> str | None:
        """Build the compact schema-context string passed to the LLM.

        Includes BOTH the vector-retrieved tables/columns AND the graph
        enrichment (``graph_context``).  Previously the graph output —
        graph-assisted inferred JOIN paths, business-term→physical mappings,
        and keyword-discovered ``extra_tables`` — was computed and then
        discarded before SQL generation.  Wiring it in here means the LLM
        actually sees the relationship context the SQL prompt requires it
        to use.

        IMPORTANT — these JOIN paths are inferred, not verified: Neptune's
        DarColumn vertices carry no relationship/reference edge between a
        foreign key and the primary key it points to (confirmed against a
        real graph sample — see ``neptune_enricher.py``). Both the
        graph-derived joins and the PK/FK-fallback joins below are built by
        matching column names (``fkFlag``/``pkFlag`` and, in the fallback
        path, shared column names) — never treat them as confirmed
        relationships from the graph itself.
        """
        gctx = metadata_context.get("graph_context", {}) or {}

        # Merge graph-discovered extra tables into the candidate table list.
        tables: List[Dict[str, Any]] = list(metadata_context.get("relevant_tables", []))
        seen = {t.get("full_name") for t in tables}
        for extra in gctx.get("extra_tables", []):
            if extra.get("full_name") and extra["full_name"] not in seen:
                seen.add(extra["full_name"])
                tables.append({
                    "full_name":    extra["full_name"],
                    "column_names": extra.get("column_names", []),
                    "primary_keys": extra.get("primary_keys", []),
                    "foreign_keys": extra.get("foreign_keys", []),
                    "logical_name": extra.get("logical_name", ""),
                })

        lines: List[str] = []
        for tbl in tables:
            # Render "col_name (DATA_TYPE)" whenever the type is known, so the
            # LLM can avoid type-coercion mistakes (e.g. COALESCE(integer_col,
            # '') failing with "invalid input syntax for integer") instead of
            # guessing blindly from bare column names.
            col_types = tbl.get("column_types", {}) or {}
            columns_rendered = ", ".join(
                f"{c} ({col_types[c]})" if col_types.get(c) and col_types[c] != "unknown" else c
                for c in tbl.get("column_names", [])
            )
            line = (
                f"Table: {tbl['full_name']} | "
                f"Columns: {columns_rendered} | "
                f"PK: {tbl.get('primary_keys', [])} | FK: {tbl.get('foreign_keys', [])}"
            )
            if tbl.get("logical_name"):
                line += f" | Business name: {tbl['logical_name']}"
            if tbl.get("view_sources"):
                line += f" | View sources: {', '.join(tbl['view_sources'])}"
            lines.append(line)

        # Graph-assisted inferred JOIN paths — derived by matching FK/PK
        # column names (Neptune has no relationship edge confirming these),
        # NOT verified graph relationships. Still preferred over the LLM
        # inventing its own joins, but labeled honestly for both the LLM
        # and anyone reading logs/schema context.
        suggested_joins = gctx.get("suggested_joins", [])
        if suggested_joins:
            lines.append("")
            lines.append(
                "-- Graph-assisted inferred JOIN paths (column-name matches, "
                "NOT verified graph relationships — prefer these over inventing "
                "your own joins, but treat them as inference, not ground truth):"
            )
            lines.extend(f"  {j}" for j in suggested_joins)

        # Business-term → physical name mapping (e.g. "Premium Amount" → prem_amt).
        logical_map = gctx.get("logical_name_map", {})
        if logical_map:
            lines.append("")
            lines.append("-- Business-term → physical mapping:")
            lines.extend(f"  {phys} = {logic}" for phys, logic in logical_map.items())

        # Shared-column join hints — cross-reference column names across the
        # retrieved tables so the LLM can identify candidate join keys even
        # when GraphOntologyEnricher is not configured (no suggested_joins).
        # Without this, a query spanning multiple domain tables (e.g. a
        # Book-of-Business question touching client/policy/product tables)
        # gives the LLM no visible shared key to join on, so it silently
        # drops every table but the one it can answer from alone.
        if not suggested_joins and len(tables) > 1:
            col_to_tables: Dict[str, set] = {}
            for tbl in tables:
                for col in tbl.get("column_names", []):
                    col_to_tables.setdefault(col.lower(), set()).add(tbl["full_name"])
            shared = {c: names for c, names in col_to_tables.items() if len(names) > 1}
            if shared:
                lines.append("")
                lines.append("-- Shared columns across retrieved tables (candidate join keys):")
                for col, names in shared.items():
                    lines.append(f"  {col}: {', '.join(sorted(names))}")

        return "\n".join(lines) or None

    # Loose "Firstname [Middle[.]] Lastname" pattern — good enough to detect
    # that the user named a specific PERSON (Account Executive / Advisor /
    # Owner / Producer / Relationship Manager) in their question.  Each name
    # token requires a capital letter followed by LOWERCASE letters, so
    # all-caps role abbreviations like "AE", "VP", "CEO" never match (an
    # earlier looser pattern matched "AE Andrew" instead of "Andrew Landon").
    # This is a best-effort heuristic for building a retry hint, not a full
    # NER — it is not relied on for correctness of the core pipeline.
    _PERSON_NAME_RE = re.compile(
        r"\b([A-Z][a-z]+(?:\s+[A-Z]\.)?\s+[A-Z][a-z]+)\b"
    )

    @classmethod
    def _extract_person_name(cls, user_message: str) -> str | None:
        """Best-effort extraction of a capitalized person name from the query.

        Used only to build a name-matching relaxation hint on empty-result
        retries — never to alter or drop the user's actual request.
        """
        m = cls._PERSON_NAME_RE.search(user_message)
        return m.group(1).strip() if m else None

    @staticmethod
    def _name_matching_relaxation_hint(name: str) -> str:
        """Build guidance for matching a person's name stored in an unknown format.

        A full "First Last" ILIKE match against a name column commonly
        returns 0 rows even when the person IS present, because operational /
        golden-record data frequently stores person names as "Last, First",
        as separate first/last columns, or even as an employee/producer CODE
        rather than free text.  This hint tells the LLM to try every plausible
        representation — CRITICALLY without ever dropping the named-entity
        scope itself (dropping it would violate the standing rule to preserve
        every user-named entity exactly, and would silently return an
        over-broad, wrong-owner result set instead of an honest 0 rows).
        """
        parts = name.split()
        first, last = parts[0], parts[-1]
        return (
            f"\nThe name '{name}' may not be stored as a single 'First Last' string. "
            f"Person names in this data may be stored as 'Last, First' or "
            f"'LAST,FIRST' (no space), as separate first-name/last-name columns, "
            f"or as an employee/producer CODE rather than a free-text name. "
            f"Do NOT drop the '{name}' filter or widen the result to all "
            f"executives/owners — instead try ALL of the following, combined "
            f"with OR, against every candidate owner/executive/advisor/producer/"
            f"manager column shown in SCHEMA CONTEXT:\n"
            f"  - column ILIKE '%{first}%{last}%'            (First ... Last, current order)\n"
            f"  - column ILIKE '%{last}%{first}%'             (Last ... First — e.g. 'Last, First')\n"
            f"  - column ILIKE '%{last}%' AND column ILIKE '%{first}%'   (both tokens present, any order/columns)\n"
            f"If SCHEMA CONTEXT shows separate first-name and last-name columns for "
            f"this entity, filter each column independently instead of one combined string.\n"
        )

    @classmethod
    def _build_generation_prompt(cls, user_message: str, attempt: int) -> str:
        """Build the SQL-generation prompt, adding relaxation hints on retries.

        When the user's question names a specific person, retries must NEVER
        simply drop that name filter (the generic "remove optional equality
        filters" relaxation used for non-person queries would do exactly
        that here). Instead, person-scoped retries broaden HOW the name is
        matched while keeping the person-scope intact.
        """
        if attempt == 0:
            return user_message

        person_name = cls._extract_person_name(user_message)

        if attempt == 1:
            hint = f"{user_message}\n\nIMPORTANT: A previous SQL attempt returned 0 rows."
            if person_name:
                hint += cls._name_matching_relaxation_hint(person_name)
            else:
                hint += (
                    " The WHERE filters or JOIN conditions are likely too restrictive. "
                    "Please generate a more relaxed query — consider using broader date "
                    "ranges, removing optional equality filters, or using LIKE/ILIKE "
                    "instead of exact matches where appropriate."
                )
            return hint

        hint = f"{user_message}\n\nIMPORTANT: Two previous SQL attempts returned 0 rows."
        if person_name:
            hint += cls._name_matching_relaxation_hint(person_name)
            hint += (
                f"\nAlso check EVERY candidate owner/executive/advisor/producer/manager "
                f"column visible in SCHEMA CONTEXT for '{person_name}' (not just the one "
                f"tried before) and combine them with OR. Still do NOT drop the "
                f"'{person_name}' scope entirely — an honest 0-row result is better than "
                f"silently returning every executive's book."
            )
        else:
            hint += (
                " Generate the simplest possible version of this query. "
                "Remove all non-essential WHERE filters. Use COUNT(*) or SELECT TOP 100 "
                "to confirm the table is not empty before adding filters. "
                "Focus only on the most directly relevant table from the schema context."
            )
        return hint

    # ------------------------------------------------------------------
    # Data-driven owner-entity resolution
    # ------------------------------------------------------------------
    # Instead of guessing how a person's name is stored (First Last vs
    # Last, First vs initials vs a producer/employee code) and hoping the
    # LLM's retry prompt happens to land on the right format, this phase
    # runs small, cheap, read-only discovery queries directly against the
    # candidate owner/AE columns BEFORE SQL generation, and resolves the
    # exact stored representation from the actual data.

    # Column-NAME keyword matching — not a fixed table/column allow-list — so
    # owner-entity resolution generalises to any schema/table without a code
    # change.  See _find_owner_candidate_columns for the precision filters
    # (non-name-shaped suffix exclusion) that keep this from probing an
    # unrelated ID/flag/count column just because it contains "manager".
    _OWNER_ROLE_KEYWORDS: tuple = (
        "owner", "advisor", "producer", "executive", "manager", "agent",
    )

    # Column-name suffixes that indicate the column almost certainly holds an
    # ID / code / flag / date / amount rather than a free-text person name,
    # even when the name also contains an owner-role keyword — e.g.
    # "case_owner_id", "territory_manager_flag", "producer_count".  Such
    # columns are deprioritised (tried last, not excluded outright, in case
    # nothing better is retrieved).
    _NON_NAME_SUFFIXES: tuple = (
        "_id", "_cd", "_code", "_flag", "_ind", "_num", "_dt", "_date",
        "_amt", "_amount", "_pct", "_percent", "_cnt", "_count", "_key",
    )

    # Previously-confirmed owner/AE column names for this data dictionary.
    # NOT an exclusive gate — used only to rank a keyword match higher when
    # it is ALSO one of these known-good names, so verified institutional
    # knowledge still wins over an equally keyword-matched but unverified
    # column, while new schemas/tables are still discovered automatically.
    #
    # Order is a DATA-CONFIRMED preference, not aspirational — live query
    # against ard_client_policy.policy_golden_record_mvw found
    # COUNT(DISTINCT policy_account_executive_name) = 0 (column present in
    # the schema but entirely unpopulated), while
    # client_golden_record_mvw.client_account_executive_name is populated
    # and already drives working book-of-business results. client_* columns
    # are therefore ranked ahead of policy_* columns. policy_account_executive_name
    # and policy_account_manager_name are kept (not removed) as lower-priority
    # fallbacks only — e.g. for a future data reload, or a different
    # environment/table where they are populated — never as the first choice.
    _KNOWN_OWNER_COLUMNS: tuple = (
        "client_account_executive_name",
        "client_account_owner_name",
        "client_account_manager_name",
        "policy_account_executive_name",
        "policy_account_manager_name",
    )

    @staticmethod
    def _escape_ilike_literal(value: str) -> str:
        """Escape a single-quote for safe embedding in an ILIKE string literal.

        Owner-resolution SQL is built from our own regex-extracted name
        tokens ([A-Z][a-z]+ only) and column names discovered from the
        retrieved schema metadata — not raw user SQL — but literal values are
        still escaped defensively.
        """
        return value.replace("'", "''")

    @classmethod
    def _is_owner_role_column(cls, column: str) -> bool:
        lname = column.lower()
        return any(kw in lname for kw in cls._OWNER_ROLE_KEYWORDS)

    @classmethod
    def _looks_like_non_name_column(cls, column: str) -> bool:
        lname = column.lower()
        return any(lname.endswith(suf) for suf in cls._NON_NAME_SUFFIXES)

    @classmethod
    def _owner_column_rank(cls, column: str) -> tuple:
        """Sort key for candidate ranking — lower sorts first (higher priority).

        Priority order: (1) previously-confirmed known-good columns first —
        and, among those, in their data-confirmed preference order (e.g.
        client-level AE before policy-level AE, since
        policy_account_executive_name was confirmed empty via
        COUNT(DISTINCT ...) = 0 while client_account_executive_name is
        populated), (2) name-shaped columns before ID/code/flag-shaped ones,
        (3) columns whose name also hints "name" explicitly, (4) more
        specific keyword (earlier in _OWNER_ROLE_KEYWORDS) before a more
        generic one, (5) alphabetical as a final, deterministic tiebreaker
        for otherwise-equal new columns.
        """
        lname = column.lower()
        is_unknown = column not in cls._KNOWN_OWNER_COLUMNS
        known_rank = (
            cls._KNOWN_OWNER_COLUMNS.index(column)
            if not is_unknown else len(cls._KNOWN_OWNER_COLUMNS)
        )
        is_non_name_shaped = cls._looks_like_non_name_column(column)
        lacks_name_hint = 0 if ("name" in lname or lname.endswith("_nm")) else 1
        keyword_rank = next(
            (i for i, kw in enumerate(cls._OWNER_ROLE_KEYWORDS) if kw in lname),
            len(cls._OWNER_ROLE_KEYWORDS),
        )
        return (is_unknown, is_non_name_shaped, lacks_name_hint, known_rank, keyword_rank, lname)

    def _find_owner_candidate_columns(
        self, metadata_context: Dict[str, Any], max_candidates: int = 8,
    ) -> List[tuple]:
        """Discover owner/AE-shaped candidate columns from the RETRIEVED
        schema by column-name keyword matching (owner/advisor/producer/
        executive/manager/agent) — never a fixed allow-list — so resolution
        generalises to any table without a code change.  Ranked so that
        previously-confirmed columns and name-shaped columns are tried
        before ID/code/flag-shaped ones, and capped at *max_candidates* to
        bound the number of live discovery queries.
        """
        found: List[tuple] = []
        seen: set = set()
        for tbl in metadata_context.get("relevant_tables", []):
            full_name = tbl.get("full_name", "")
            if not full_name:
                continue
            for col in tbl.get("column_names", []):
                if not self._is_owner_role_column(col):
                    continue
                key = (full_name, col)
                if key in seen:
                    continue
                seen.add(key)
                found.append(key)
        found.sort(key=lambda tc: self._owner_column_rank(tc[1]))
        return found[:max_candidates]

    async def _count_where(self, table: str, where_sql: str) -> int:
        """Run a read-only ``COUNT(*) ... WHERE <where_sql>`` against *table*."""

        sql = f"SELECT COUNT(*) AS match_count FROM {table} WHERE {where_sql}"
        result = await asyncio.to_thread(self.query_redshift, sql)
        rows = result.get("rows", []) if isinstance(result, dict) else []
        return int(rows[0]["match_count"]) if rows else 0

    async def _sample_distinct(self, table: str, column: str, where_sql: str, limit: int = 5) -> List[str]:
        """Return up to *limit* distinct stored values matching *where_sql*."""

        sql = f"SELECT DISTINCT {column} AS val FROM {table} WHERE {where_sql} LIMIT {limit}"
        result = await asyncio.to_thread(self.query_redshift, sql)
        rows = result.get("rows", []) if isinstance(result, dict) else []
        return [r["val"] for r in rows if r.get("val") is not None]

    async def resolve_owner_entity(
        self, person_name: str, metadata_context: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """Discover how *person_name* is actually stored in the data.

        Tests, in order, against each candidate owner/AE column present in the
        retrieved schema:
          1. exact "First Last" (contiguous, current assumed order)
          2. reversed "Last ... First" (covers "Last, First" / "LAST,FIRST")
          3. both tokens present in any order — ``col ILIKE '%Last%' AND
             col ILIKE '%First%'`` — robust to punctuation/whitespace
             differences and is what actually resolves names stored as
             "LANDON, ANDREW" against a query for "Andrew Landon".

        The first candidate column where any strategy returns a non-zero
        count wins (documented preference order).  Returns ``None`` if no
        candidate column is present in the retrieved schema, or none of them
        match — callers must fall back to the existing retry mechanism
        rather than fail hard.
        """
        parts = person_name.split()
        if len(parts) < 2:
            return None
        first = self._escape_ilike_literal(parts[0])
        last = self._escape_ilike_literal(parts[-1])

        candidates = self._find_owner_candidate_columns(metadata_context)
        logger.info("Owner-resolution query: person=%r", person_name)
        logger.info("Candidate columns tested: %s", candidates)

        if not candidates:
            logger.warning(
                "Owner resolution: no column matching keywords %s was present "
                "in the retrieved schema for '%s'.",
                self._OWNER_ROLE_KEYWORDS, person_name,
            )
            return None

        for table, column in candidates:
            try:
                count_first = await self._count_where(table, f"{column} ILIKE '%{first}%'")
                count_last = await self._count_where(table, f"{column} ILIKE '%{last}%'")
                logger.info(
                    "Candidate matches: table=%s column=%s first_only=%d last_only=%d",
                    table, column, count_first, count_last,
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Owner resolution: probe failed for %s.%s — %s", table, column, exc)
                continue

            # Strategies tried in order of precision — first non-zero count wins.
            strategies = (
                ("exact_first_last", f"{column} ILIKE '%{first}%{last}%'"),
                ("reversed_last_first", f"{column} ILIKE '%{last}%{first}%'"),
                ("tokens_any_order", f"{column} ILIKE '%{first}%' AND {column} ILIKE '%{last}%'"),
            )

            resolved_strategy = None
            resolved_where = None
            match_count = 0
            for strategy, where_sql in strategies:
                try:
                    count = await self._count_where(table, where_sql)
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "Owner resolution: strategy %s failed for %s.%s — %s",
                        strategy, table, column, exc,
                    )
                    continue
                logger.info(
                    "Candidate matches: table=%s column=%s strategy=%s count=%d",
                    table, column, strategy, count,
                )
                if count > 0:
                    resolved_strategy, resolved_where, match_count = strategy, where_sql, count
                    break  # most-precise-first order — first hit wins

            if resolved_strategy is None:
                continue  # this column matched nothing; try the next candidate

            sample_values = await self._sample_distinct(table, column, resolved_where)
            logger.info("Resolved owner value: %s", sample_values)
            logger.info("Resolved owner column: %s.%s", table, column)
            logger.info("Match count: %d", match_count)
            return {
                "table": table,
                "column": column,
                "strategy": resolved_strategy,
                "where_sql": resolved_where,
                "match_count": match_count,
                "sample_values": sample_values,
            }

        logger.warning(
            "Owner resolution: no candidate column matched '%s' via any strategy.",
            person_name,
        )
        return None

    @staticmethod
    def _owner_resolution_directive(resolved: Dict[str, Any], person_name: str) -> str:
        """Build the schema-context directive telling the LLM the EXACT filter to use."""
        table, column = resolved["table"], resolved["column"]
        where_sql = resolved["where_sql"]
        samples = resolved["sample_values"]
        return (
            f"\n-- RESOLVED OWNER ENTITY (discovered directly from the data — "
            f"use this EXACT filter, do not guess a different format) --\n"
            f"  Person requested: {person_name}\n"
            f"  Confirmed stored value(s) in {table}.{column}: {samples}\n"
            f"  Required filter (qualify with the correct table alias in the final SQL):\n"
            f"    {where_sql}\n"
            f"  Do NOT use a single \"%{person_name}%\" substring match — it does not "
            f"match the stored format above.\n"
        )

    async def _execute_pipeline_attempt(
        self,
        user_message: str,
        attempt: int,
        search_top_k: int,
        generation_prompt: str,
        extra_context: str | None = None,
        precomputed_vector_results: Dict[str, Any] | None = None,
    ) -> tuple:
        """Run one pipeline attempt: vector search → SQL generation → execution.

        ``precomputed_vector_results`` is only honored on ``attempt == 0`` —
        empty-result retries (attempt 1+) intentionally broaden ``search_top_k``
        and must re-search; that retry behavior is unchanged.

        Returns
        -------
        tuple of (rows, columns, error, sql_query, best_confidence,
                  vs_elapsed, sql_elapsed, exec_elapsed)
        """
        # ── Stage 1: vector search ───────────────────────────────────────────
        t1 = time.time()
        reuse = precomputed_vector_results if attempt == 0 else None
        metadata_context = self.get_metadata_context(
            user_message, top_k=search_top_k, precomputed_vector_results=reuse,
        )
        vs_elapsed = time.time() - t1

        logger.info(
            "   [Stage 1: VectorSearch] attempt=%d  top_k=%d  %.2fs — %d tables, %d columns",
            attempt + 1, search_top_k, vs_elapsed,
            len(metadata_context["relevant_tables"]),
            len(metadata_context["relevant_columns"]),
        )
        logger.info(
            "Retrieved tables: %s",
            [t.get("full_name") for t in metadata_context["relevant_tables"]],
        )
        logger.info(
            "Retrieved schemas: %s",
            sorted({t.get("schema") for t in metadata_context["relevant_tables"] if t.get("schema")}),
        )

        best_confidence = self._compute_confidence(metadata_context["relevant_tables"])
        schema_context  = self._build_schema_context(metadata_context)

        # ── Retrieval score logging ──────────────────────────────────────────
        # Log per-table distance scores so retrieval ranking is visible in
        # CloudWatch (lower distance = closer match = better retrieval).
        for _tbl in metadata_context["relevant_tables"]:
            logger.info(
                "RETRIEVAL_SCORE table=%s distance=%.4f",
                _tbl["full_name"], _tbl.get("relevance_score", 0.0),
            )
        # Log top retrieved column hits with scores (sorted best-first) so
        # we can see which columns ranked highest before any filtering and
        # diagnose why a metric column may have dropped out of the results.
        _col_scores = sorted(
            metadata_context.get("relevant_columns", []),
            key=lambda c: c.get("relevance_score", 999.0),
        )
        logger.info(
            "TOP_RETRIEVED_COLUMNS_WITH_SCORES=%s",
            [
                (
                    f"{c.get('schema','')}.{c.get('table','')}.{c.get('column','')}",
                    round(c.get("relevance_score", 0.0), 4),
                )
                for c in _col_scores[:20]
            ],
        )

        # ── Metric column detection ──────────────────────────────────────────
        # Log all pre-aggregated numeric metric columns retrieved from the
        # vector store so they are visible in CloudWatch even when the LLM
        # ignores them.  Also inject a curated hint into schema_context so the
        # first generation attempt already knows which existing columns to use
        # instead of inventing new metric names (e.g. total_eligible_employees_count
        # instead of the hallucinated enrolled_lives_count).
        # Numeric identifier columns (_id, _key, _number) are excluded from
        # MATCHED_METRIC_COLUMNS and logged separately as REJECTED_IDENTIFIER_COLUMNS.
        metric_cols, rejected_id_cols = self._detect_metric_columns(metadata_context)
        if rejected_id_cols:
            logger.info(
                "REJECTED_IDENTIFIER_COLUMNS=%s",
                [f"{m['table']}.{m['column']} ({m['type']})" for m in rejected_id_cols],
            )
        if metric_cols:
            logger.info(
                "MATCHED_METRIC_COLUMNS=%s",
                [f"{m['table']}.{m['column']} ({m['type']})" for m in metric_cols],
            )
            metric_hint_lines = [
                "",
                "-- AVAILABLE METRIC COLUMNS (pre-aggregated numerics in retrieved schema):",
                "-- Use these existing columns for any metric/count/total/sum request.",
                "-- Do NOT invent a new column or table name for a metric.",
            ]
            for m in metric_cols:
                metric_hint_lines.append(f"--   {m['table']}.{m['column']} ({m['type']})")
            metric_hint = "\n".join(metric_hint_lines)
            schema_context = (
                f"{schema_context}{metric_hint}" if schema_context else metric_hint
            )

        logger.info(
            "TABLES INCLUDED: %s",
            [t.get("full_name") for t in metadata_context["relevant_tables"]],
        )
        logger.info(
            "COLUMNS INCLUDED: %s",
            {
                t.get("full_name"): t.get("column_names", [])
                for t in metadata_context["relevant_tables"]
            },
        )

        # Append optional domain-reasoning guidance (e.g. Book of Business) AFTER
        # the schema so the LLM grounds it in the retrieved tables/columns.  This
        # augments the *system/schema* context only — the user's question itself
        # is never modified.
        if extra_context:
            logger.info(
                "BOOK_OF_BUSINESS_INSTRUCTIONS injected (%d chars): %s",
                len(extra_context), extra_context[:200],
            )
            schema_context = (
                f"{schema_context}\n\n{extra_context}" if schema_context else extra_context
            )

        logger.info("SCHEMA CONTEXT SENT TO LLM:\n%s", schema_context)

        # ── Stage 2: generate SQL ────────────────────────────────────────────
        t2 = time.time()
        sql_query = await self.generate_sql(generation_prompt, schema_context)
        sql_elapsed = time.time() - t2
        logger.info("   [Stage 2: GenerateSQL] attempt=%d  %.2fs", attempt + 1, sql_elapsed)

        # ── Stage 3: execute ─────────────────────────────────────────────────
        # If SQL generation could not produce a schema-valid statement (hard
        # validation in RedshiftClient exhausted all repair attempts), do not
        # send the failure sentinel to Redshift — short-circuit with a clear
        # error instead of an opaque syntax-error round-trip.
        if sql_query.strip().startswith("-- ERROR"):
            logger.error("SQL generation failed — not executing: %s", sql_query)
            return (
                [], [], sql_query.lstrip("- ").strip(), sql_query,
                best_confidence, vs_elapsed, sql_elapsed, 0.0,
            )

        t3 = time.time()
        raw_result = self.query_redshift(sql_query)
        exec_elapsed = time.time() - t3

        # Normalise result shape
        if isinstance(raw_result, dict):
            rows    = raw_result.get("rows", [])
            columns = raw_result.get("columns", [])
            error   = raw_result.get("error")
        elif isinstance(raw_result, list):
            rows    = raw_result
            columns = list(rows[0].keys()) if raw_result else []
            error   = None
        else:
            rows, columns, error = [], [], str(raw_result)

        logger.info(
            "   [Stage 3: QueryRedshift] attempt=%d  %.2fs — %d rows",
            attempt + 1, exec_elapsed, len(rows),
        )
        return rows, columns, error, sql_query, best_confidence, vs_elapsed, sql_elapsed, exec_elapsed

    @staticmethod
    def _build_final_answer(
        rows: List[Any],
        sql: str,
        error: Optional[str],
        confidence: float,
        max_retries: int,
    ) -> str:
        """Build the human-readable answer string for a QueryResult."""
        if error:
            return f"Query execution error: {error}\n\nSQL:\n{sql}"
        if rows:
            return (
                f"Query returned {len(rows)} row(s).  "
                f"(confidence={confidence:.2f})\n\nSQL:\n{sql}"
            )
        return (
            f"Query returned no rows after {1 + max_retries} attempt(s). "
            f"The data may not exist or the query may need manual review.  "
            f"(confidence={confidence:.2f})\n\nSQL:\n{sql}"
        )

    async def process_book_of_business_query(self, user_message: str) -> QueryResult:
        """Book-of-Business entry point.

        Treats Book of Business as a first-class business concept.  The user's
        question is passed through verbatim; a domain-reasoning instruction pack
        is injected into the *schema context* (not the query) so the LLM resolves
        ownership / territory / hierarchy via the retrieved metadata and graph
        relationships rather than assuming column names.
        """
        from core.mcp_tools import BOOK_OF_BUSINESS_INSTRUCTIONS
        logger.info("📘 Book-of-Business query")
        return await self.process_query(
            user_message, extra_context=BOOK_OF_BUSINESS_INSTRUCTIONS
        )

    # ------------------------------------------------------------------
    # Client-scoped domain tools (pipeline-style, retrieval + graph driven)
    # ------------------------------------------------------------------

    @staticmethod
    def _client_scope_hint(client_name: str | None, client_id: str | None) -> str:
        """Build an optional CLIENT SCOPE hint appended to the schema context.

        The user's question is never modified; identifiers passed by the caller
        are surfaced to the LLM as an explicit, additional scope constraint.
        """
        parts = []
        if client_name:
            parts.append(f"name='{client_name}'")
        if client_id:
            parts.append(f"id='{client_id}'")
        if not parts:
            return ""
        return (
            "\n-- CLIENT SCOPE (filter to exactly this client) --\n  "
            + ", ".join(parts)
        )

    async def get_client_products(
        self, query: str, client_name: str | None = None,
        client_id: str | None = None, **_: Any,
    ) -> QueryResult:
        """Products owned by / associated with a client (holdings, mix, penetration)."""
        from core.mcp_tools import CLIENT_PRODUCTS_INSTRUCTIONS
        logger.info("👤 getClientProducts")
        ctx = CLIENT_PRODUCTS_INSTRUCTIONS + self._client_scope_hint(client_name, client_id)
        return await self.process_query(query, extra_context=ctx)

    async def get_client_policies(
        self, query: str, client_name: str | None = None,
        client_id: str | None = None, **_: Any,
    ) -> QueryResult:
        """Policies associated with a client (coverage, status, portfolio)."""
        from core.mcp_tools import CLIENT_POLICIES_INSTRUCTIONS
        logger.info("👤 getClientPolicies")
        ctx = CLIENT_POLICIES_INSTRUCTIONS + self._client_scope_hint(client_name, client_id)
        return await self.process_query(query, extra_context=ctx)

    async def get_client_by_demographics(self, query: str, **_: Any) -> QueryResult:
        """Find/analyse clients by demographic attributes (age, income, geography …)."""
        from core.mcp_tools import CLIENT_DEMOGRAPHICS_INSTRUCTIONS
        logger.info("👤 getClientByDemographics")
        return await self.process_query(query, extra_context=CLIENT_DEMOGRAPHICS_INSTRUCTIONS)

    async def get_client_by_segment(self, query: str, **_: Any) -> QueryResult:
        """Retrieve/analyse clients by customer segment (affluent, wealth, business …)."""
        from core.mcp_tools import CLIENT_SEGMENT_INSTRUCTIONS
        logger.info("👤 getClientBySegment")
        return await self.process_query(query, extra_context=CLIENT_SEGMENT_INSTRUCTIONS)

    async def process_query(
        self,
        user_message: str,
        extra_context: str | None = None,
        precomputed_vector_results: Dict[str, Any] | None = None,
    ) -> QueryResult:
        """Process a natural-language query via a 3-stage pipeline with empty-result retry.

        Pipeline
        --------
        Stage 1 — vector_search  : retrieve relevant table/column metadata from pgvector
        Stage 2 — generate_sql   : ask Bedrock to produce SQL from the prompt
        Stage 3 — query_redshift : execute SQL and collect rows

        Empty-result retry
        ------------------
        When SQL executes successfully but returns 0 rows, the pipeline retries
        up to ``MAX_EMPTY_RETRIES`` (2) additional times with two escalating
        adjustments:

          Retry 1 — broaden the vector search (top_k × 2) so more candidate
                     tables reach the LLM, then regenerate SQL with an explicit
                     hint that the previous attempt returned 0 rows and the
                     WHERE filters should be relaxed.

          Retry 2 — broaden further (top_k × 3) and strengthen the relaxation
                     hint, instructing the LLM to remove the most restrictive
                     filters and try a simpler version of the query.

        SQL errors are NOT retried here (they are handled inside the LLM
        validation loop in ``RedshiftClient._generate_sql_from_prompt``).

        Confidence scoring
        ------------------
        ``confidence`` reflects how well the vector search matched the query:
          • High confidence (≥ 0.7) — strong table matches found.
          • Medium confidence (0.4–0.7) — plausible but uncertain matches.
          • Low confidence (< 0.4) — weak matches; results may be unreliable.

        The final score is penalised when the pipeline exhausts all retries
        and still returns 0 rows (multiplied by 0.3 to signal low certainty).
        """
        MAX_EMPTY_RETRIES = 2

        logger.info("📥 Processing query: %s", user_message[:120])
        t0 = time.time()

        # ── Data-driven owner-entity resolution ─────────────────────────────
        # When the question names a specific person (Account Executive,
        # advisor, owner, manager …), discover how that name is ACTUALLY
        # stored in the data via direct read-only discovery queries — rather
        # than letting SQL generation guess a format and retry blindly.  The
        # resolved directive is merged into extra_context so even the FIRST
        # generation attempt already uses the correct filter.
        person_name = self._extract_person_name(user_message)
        if person_name:
            probe_context = self.get_metadata_context(
                user_message,
                top_k=settings.search.top_k,
                precomputed_vector_results=precomputed_vector_results,
            )
            resolved = await self.resolve_owner_entity(person_name, probe_context)
            if resolved:
                directive = self._owner_resolution_directive(resolved, person_name)
                extra_context = f"{extra_context}\n\n{directive}" if extra_context else directive

        rows: List[Any]    = []
        columns: List[str] = []
        error:   Optional[str] = None
        sql_query = ""
        best_confidence = 0.0
        vs_elapsed = sql_elapsed = exec_elapsed = 0.0

        for attempt in range(1 + MAX_EMPTY_RETRIES):
            search_top_k      = settings.search.top_k * (1 + attempt)
            generation_prompt = self._build_generation_prompt(user_message, attempt)

            (rows, columns, error, sql_query, best_confidence,
             vs_elapsed, sql_elapsed, exec_elapsed) = await self._execute_pipeline_attempt(
                user_message, attempt, search_top_k, generation_prompt, extra_context,
                precomputed_vector_results=precomputed_vector_results,
            )

            if error:
                # SQL error — stop immediately, no further broadening will help
                logger.warning("Query error on attempt %d: %s", attempt + 1, error)
                break

            if rows:
                break  # got results — done

            # 0 rows — retry unless exhausted
            if attempt < MAX_EMPTY_RETRIES:
                logger.warning(
                    "⚠️  Query returned 0 rows on attempt %d/%d "
                    "(confidence=%.2f) — retrying with relaxed SQL and broader search …",
                    attempt + 1, 1 + MAX_EMPTY_RETRIES, best_confidence,
                )

        # ── Final confidence ────────────────────────────────────────────────
        if error:
            final_confidence = 0.0
        elif not rows:
            final_confidence = best_confidence * 0.3
            logger.warning(
                "All %d attempt(s) returned 0 rows. "
                "Penalised confidence: %.4f → %.4f",
                1 + MAX_EMPTY_RETRIES, best_confidence, final_confidence,
            )
        else:
            final_confidence = best_confidence

        total_elapsed = time.time() - t0
        answer = self._build_final_answer(rows, sql_query, error, final_confidence, MAX_EMPTY_RETRIES)

        logger.info(
            "✅ Total: %.2fs  (vector=%.2fs, sql_gen=%.2fs, exec=%.2fs)  "
            "rows=%d  confidence=%.4f",
            total_elapsed, vs_elapsed, sql_elapsed, exec_elapsed,
            len(rows), final_confidence,
        )

        return QueryResult(
            answer=answer,
            sql_query=sql_query,
            execution_time=total_elapsed,
            confidence=final_confidence,
            intent="query",
            rows=rows,
            columns=columns,
        )
