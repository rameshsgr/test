"""QueryOrchestrator — the new datasource-aware multi-datasource entry point.

This is purely additive: it does not replace or modify ``RedshiftToolService``
or ``get_tool_service()``. Existing Discovery-only callers keep using
``get_tool_service()`` exactly as before. This orchestrator is the only place
that wires ``DatasourceRouter`` into a live request path.

Vector-search contract
-----------------------
Exactly ONE vector search occurs before datasource selection. This
orchestrator performs that single search, and ``DatasourceRouter.resolve()``
makes its decision from that one result set — this is the guarantee the
"one vector search per request" requirement refers to.

Once a datasource is selected, ``RedshiftToolService.process_query()``'s
pre-existing empty-result retry loop (attempts 1-2, broadened top_k) is a
SEPARATE, independent concern scoped entirely within the already-selected
datasource. It may perform additional vector searches on retry — that has
no bearing on datasource routing, which is already finalized by that point,
and is unrelated to (does not violate) the contract above.

Flow
----
    user_message
        -> vector_store.search_tables_and_columns()      (ONCE — the only search before routing)
        -> DatasourceRouter.resolve(schemas, results, intent)
        -> DatasourceDecision -> services[name].process_query(msg, precomputed_vector_results=results)
           | AmbiguousDatasourceWarning -> returned as-is, RedshiftToolService never called
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

from application.services.datasource_router import (
    AmbiguousDatasourceWarning,
    DatasourceRouter,
)
from application.services.redshift_tool_service import RedshiftToolService
from domain.entities.query_result import QueryResult

logger = logging.getLogger(__name__)


def _extract_schemas(vector_results: Dict[str, Any]) -> list:
    schemas = []
    for row in (vector_results.get("tables") or []):
        s = row.get("schema_name")
        if s:
            schemas.append(s)
    for row in (vector_results.get("columns") or []):
        s = row.get("schema_name")
        if s:
            schemas.append(s)
    return schemas


@dataclass
class QueryOrchestrator:
    """Routes one query to the correct per-datasource RedshiftToolService.

    ``services`` and ``vector_store`` are shared, already-built dependencies —
    this class performs no wiring of its own beyond holding references to
    them and calling ``DatasourceRouter`` (a pure function).
    """

    services: Dict[str, RedshiftToolService]
    router: DatasourceRouter
    vector_store: Any  # VectorStoreGateway — shared across all datasources today

    async def handle_query(
        self,
        user_message: str,
        top_k: Optional[int] = None,
        intent: Optional[str] = None,
    ):
        """Resolve a datasource and run the query, or return a structured warning.

        Returns
        -------
        QueryResult on success, or AmbiguousDatasourceWarning when routing
        cannot safely pick a single datasource — callers MUST check the
        return type and must NOT call any service when a warning is returned.
        """
        from core.config import settings

        _top_k = top_k if top_k is not None else settings.search.top_k
        col_multi = settings.search.column_multiplier

        # ── Exactly one vector search for this request ──────────────────────
        vector_results = self.vector_store.search_tables_and_columns(
            user_message,
            table_count=_top_k,
            column_count=_top_k * col_multi,
        )
        retrieved_schemas = _extract_schemas(vector_results)

        decision = self.router.resolve(
            retrieved_schemas=retrieved_schemas,
            vector_results=vector_results,
            intent=intent,
        )

        if isinstance(decision, AmbiguousDatasourceWarning):
            logger.warning(
                "Query routing ambiguous — stopping without selecting a datasource. "
                "candidate_datasources=%s reason=%s",
                decision.candidate_datasources, decision.reason,
            )
            return decision

        service = self.services.get(decision.datasource)
        if service is None:
            # Router resolved a datasource that has no live service (e.g. its
            # Conjur credentials failed to load) — fail safely, do not guess.
            logger.error(
                "DatasourceRouter selected '%s' but no RedshiftToolService is "
                "registered for it (credentials/config unavailable).",
                decision.datasource,
            )
            return AmbiguousDatasourceWarning(
                candidate_datasources=(decision.datasource,),
                retrieved_schemas=tuple(retrieved_schemas),
                reason="datasource_unavailable",
            )

        logger.info("Routed query to datasource='%s' (reason=%s)", decision.datasource, decision.reason)
        result: QueryResult = await service.process_query(
            user_message, precomputed_vector_results=vector_results,
        )
        return result
