# =============================================================================
# build_layer.ps1 - Build a SINGLE combined x86_64 Lambda Layer
#
# Usage:
#   $env:ARTIFACTORY_TOKEN = 'your_token'
#   .\build_layer.ps1                        # defaults ArtifactoryUser = t03vb2h
#   .\build_layer.ps1 -ArtifactoryUser 't03vhtu'
#
# The Artifactory token MUST be set in the environment variable
#   ARTIFACTORY_TOKEN before running this script.
#   It is never accepted as a script parameter and must never be hardcoded.
#
# Output:
#   dist\graph_broker_layer.zip   - all runtime dependencies in ONE layer
#
# Requirements (on the build machine):
#   - Python 3.11  (x86_64)
#   - pip  >= 23
#   - PowerShell 5.1+
#
# NOTE: AWS Lambda layers have a 250 MB unzipped size limit.
# The combined dependency set may exceed this limit; a warning will be
# emitted so you can decide whether to prune further or split back into
# two layers via build_layers.ps1.
# =============================================================================
param(
    [string]$ArtifactoryUser = "t03vb2h"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Validate token - read exclusively from the environment; never hardcode
# ---------------------------------------------------------------------------
$ArtifactoryToken = $env:ARTIFACTORY_TOKEN

if ([string]::IsNullOrWhiteSpace($ArtifactoryToken)) {
    Write-Error @"
Artifactory token not found.
Set the environment variable before running this script:
  `$env:ARTIFACTORY_TOKEN = 'your_token'
  .\build_layer.ps1
"@
    exit 1
}

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
$PYTHON        = "python"
$DIST_DIR      = ".\dist"
$LAYER_ROOT    = "$DIST_DIR\layer"
$LAYER_DIR     = "$LAYER_ROOT\python"
$LAYER_ZIP     = "$DIST_DIR\gbs-nexusstudio-redshiftmcplib-package.zip"
$REQS_FILE     = ".\requirements.txt"

if (-not (Test-Path $REQS_FILE)) {
    Write-Error "requirements.txt not found in the current directory: $REQS_FILE"
    exit 1
}

# Build pip index URL from injected credentials (never stored in source)
$ARTIFACTORY_HOST = "nylartifactory.jfrog.io"
$PIP_INDEX        = "https://${ArtifactoryUser}:${ArtifactoryToken}@${ARTIFACTORY_HOST}/artifactory/api/pypi/pypi-python-org/simple"

# Common pip flags for Lambda-compatible x86_64 Linux wheels
$PIP_FLAGS = @(
    "--platform",         "manylinux2014_x86_64",
    "--python-version",   "3.11",
    "--implementation",   "cp",
    "--abi",              "cp311",
    "--only-binary",      ":all:",
    "--upgrade",
    "--no-cache-dir",
    "--index-url",        $PIP_INDEX,
    "--trusted-host",     $ARTIFACTORY_HOST
)

# ---------------------------------------------------------------------------
# Helper: prune a layer directory
# ---------------------------------------------------------------------------
function Invoke-Prune {
    param([string]$Dir)

    # Compiled bytecode caches
    Get-ChildItem -Path $Dir -Recurse -Include "__pycache__" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    Get-ChildItem -Path $Dir -Recurse -Include "*.pyc","*.pyo" -File -ErrorAction SilentlyContinue |
        Remove-Item -Force

    # Test directories
    Get-ChildItem -Path $Dir -Recurse -Include "tests","test" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    # Package metadata (not needed at runtime)
    Get-ChildItem -Path $Dir -Recurse -Include "*.dist-info","*.egg-info" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    # Type stub files (IDE / type-checker use only - never loaded at runtime)
    Get-ChildItem -Path $Dir -Recurse -Include "*.pyi" -File -ErrorAction SilentlyContinue |
        Remove-Item -Force

    # CLI entry-point scripts (never invoked inside Lambda)
    Get-ChildItem -Path $Dir -Recurse -Include "bin","Scripts" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force
}

# ---------------------------------------------------------------------------
# Helper: report sizes and warn on Lambda limits
# ---------------------------------------------------------------------------
function Show-LayerSize {
    param(
        [string]$Label,
        [string]$UnzippedDir,
        [string]$ZipPath
    )

    $unzipped_mb = [math]::Round(
        (Get-ChildItem -Path $UnzippedDir -Recurse |
         Measure-Object -Property Length -Sum).Sum / 1MB, 1)

    $zipped_mb = [math]::Round((Get-Item $ZipPath).Length / 1MB, 1)

    Write-Host "`n==> $Label sizes:" -ForegroundColor Yellow
    Write-Host "    Unzipped : $unzipped_mb MB"
    Write-Host "    Zipped   : $zipped_mb MB"

    if ($unzipped_mb -gt 250) {
        Write-Warning "$Label unzipped size ($unzipped_mb MB) exceeds Lambda's 250 MB layer limit!"
    }
    if ($zipped_mb -gt 50) {
        Write-Warning "$Label zipped size ($zipped_mb MB) exceeds Lambda's 50 MB direct-upload limit - use S3!"
    }
}

# ---------------------------------------------------------------------------
# Helper: print top-N packages by installed size (call after Invoke-Prune)
# ---------------------------------------------------------------------------
function Show-TopPackageSizes {
    param(
        [string]$LayerDir,
        [string]$Label,
        [int]$Top = 20
    )
    Write-Host "`n==> $Label - Top $Top packages by installed size:" -ForegroundColor Yellow

    $results = Get-ChildItem -Path $LayerDir -Directory -ErrorAction SilentlyContinue |
        ForEach-Object {
            $bytes = (Get-ChildItem -Path $_.FullName -Recurse -File -ErrorAction SilentlyContinue |
                      Measure-Object -Property Length -Sum).Sum
            [PSCustomObject]@{
                Package = $_.Name
                SizeMB  = [math]::Round($bytes / 1MB, 2)
            }
        } |
        Sort-Object SizeMB -Descending |
        Select-Object -First $Top

    $results | Format-Table -AutoSize

    $total = ($results | Measure-Object -Property SizeMB -Sum).Sum
    Write-Host "    Shown total : $([math]::Round($total, 1)) MB" -ForegroundColor DarkGray
}

# ===========================================================================
# CLEAN PREVIOUS BUILD
# ===========================================================================
Write-Host "`n==> Cleaning previous build artifacts..." -ForegroundColor Cyan

foreach ($path in @($LAYER_ROOT, $LAYER_ZIP)) {
    if (Test-Path $path) { Remove-Item -Recurse -Force $path }
}

New-Item -ItemType Directory -Path $LAYER_DIR -Force | Out-Null

# ===========================================================================
# INSTALL ALL DEPENDENCIES FROM requirements.txt
# ===========================================================================
Write-Host "`n==> Installing all packages from $REQS_FILE into $LAYER_DIR ..." -ForegroundColor Cyan

& $PYTHON -m pip install `
    --requirement $REQS_FILE `
    --target $LAYER_DIR `
    @PIP_FLAGS

if ($LASTEXITCODE -ne 0) {
    Write-Error "pip install failed. See output above."
    exit 1
}

# ===========================================================================
# PRUNE
# ===========================================================================
Write-Host "`n==> Pruning build artifacts..." -ForegroundColor Cyan
Invoke-Prune -Dir $LAYER_DIR

# Prune unused botocore service data - keep only services used by this application
$BOTOCORE_DATA = "$LAYER_DIR\botocore\data"
if (Test-Path $BOTOCORE_DATA) {
    $KEEP_SERVICES = @(
        'bedrock', 'bedrock-runtime', 'bedrock-agent', 'bedrock-agent-runtime',
        's3', 'iam', 'sts', 'secretsmanager', 'ec2',
        'redshift', 'redshift-data', 'neptune', 'neptunedata', 'rds'
    )
    Get-ChildItem -Path $BOTOCORE_DATA -Directory |
        Where-Object { $_.Name -notin $KEEP_SERVICES } |
        Remove-Item -Recurse -Force
    $kept = (Get-ChildItem -Path $BOTOCORE_DATA -Directory).Count
    Write-Host "  botocore/data pruned to $kept service directories"
}
Write-Host "  Pruning complete"
Show-TopPackageSizes -LayerDir $LAYER_DIR -Label "Combined layer"

# ===========================================================================
# ZIP
# ===========================================================================
Write-Host "`n==> Creating $LAYER_ZIP ..." -ForegroundColor Cyan
Compress-Archive -Path "$LAYER_ROOT\*" -DestinationPath $LAYER_ZIP -Force

Show-LayerSize -Label "Combined layer (graph-broker-layer)" `
               -UnzippedDir $LAYER_DIR `
               -ZipPath $LAYER_ZIP

# ===========================================================================
# SUMMARY
# ===========================================================================
Write-Host "`n==> Build complete!" -ForegroundColor Green
Write-Host "    Combined layer: $(Resolve-Path $LAYER_ZIP)" -ForegroundColor Green

Write-Host @"

Lambda Layer deployment limits:
  Zipped  : 50 MB  (direct upload) - use S3 for larger layers
  Unzipped: 250 MB per layer (max 5 layers per function, 250 MB total unzipped)

Publish the layer:
  aws lambda publish-layer-version ``
      --layer-name graph-broker-layer ``
      --zip-file fileb://dist/graph_broker_layer.zip ``
      --compatible-runtimes python3.11 ``
      --compatible-architectures x86_64 ``
      --region us-east-1

Attach it to your Lambda function:
  aws lambda update-function-configuration ``
      --function-name <your-function-name> ``
      --layers <layer-arn> ``
      --region us-east-1
"@ -ForegroundColor DarkGray
