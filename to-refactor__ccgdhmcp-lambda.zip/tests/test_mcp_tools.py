"""Single-source-of-truth tool manifest + prompts."""

from core import mcp_tools as mt


def test_expected_tools_present():
    names = {t["name"] for t in mt.MCP_TOOLS}
    assert {"get_metadata_context", "process_query", "book_of_business",
            "generate_sql", "generate_gremlin", "get_neptune_schema",
            "query_neptune", "query_redshift", "vector_search",
            "list_tables", "describe_table"} <= names


def test_generate_gremlin_is_read_only_generation_only():
    tool = next(t for t in mt.MCP_TOOLS if t["name"] == "generate_gremlin")
    description = tool["description"].lower()
    assert "does not execute" in description
    assert "read-only" in description
    assert tool["inputSchema"]["required"] == ["prompt"]
    assert "graph_context" in tool["inputSchema"]["properties"]


def test_neptune_schema_tool_is_sampled_and_value_free():
    tool = next(t for t in mt.MCP_TOOLS if t["name"] == "get_neptune_schema")
    description = tool["description"].lower()
    assert "sampled" in description
    assert "property values" in description
    assert tool["inputSchema"]["required"] == []
    assert tool["inputSchema"]["properties"]["vertex_labels"]["type"] == "array"


def test_query_neptune_is_read_only_and_bounded():
    tool = next(t for t in mt.MCP_TOOLS if t["name"] == "query_neptune")
    description = tool["description"].lower()
    assert "read-only" in description
    assert "bounded" in description
    assert tool["inputSchema"]["required"] == ["gremlin"]
    assert "max_results" in tool["inputSchema"]["properties"]


def test_every_tool_description_declares_its_data_source_or_capability():
    expected_prefixes = {
        "get_metadata_context": "[HYBRID METADATA:",
        "process_query": "[END-TO-END:",
        "book_of_business": "[DOMAIN PIPELINE:",
        "getClientProducts": "[DOMAIN PIPELINE:",
        "getClientPolicies": "[DOMAIN PIPELINE:",
        "getClientByDemographics": "[DOMAIN PIPELINE:",
        "getClientBySegment": "[DOMAIN PIPELINE:",
        "generate_sql": "[BEDROCK GENERATOR: REDSHIFT SQL;",
        "generate_gremlin": "[BEDROCK GENERATOR: NEPTUNE GREMLIN;",
        "get_neptune_schema": "[NEPTUNE GRAPH ONTOLOGY ONLY:",
        "query_neptune": "[NEPTUNE GRAPH ONTOLOGY ONLY:",
        "query_redshift": "[REDSHIFT DATA ONLY:",
        "vector_search": "[PGVECTOR ONLY:",
        "list_tables": "[REDSHIFT ONLY:",
        "describe_table": "[REDSHIFT ONLY:",
        "get_business_catalog_context": "[NEPTUNE BUSINESS CATALOG ONLY:",
    }
    descriptions = {tool["name"]: tool["description"] for tool in mt.MCP_TOOLS}
    assert descriptions.keys() == expected_prefixes.keys()
    for name, prefix in expected_prefixes.items():
        assert descriptions[name].startswith(prefix), name


def test_every_tool_has_valid_mcp_schema():
    for t in mt.MCP_TOOLS:
        assert t["name"] and t["description"]
        schema = t["inputSchema"]
        assert schema["type"] == "object"
        assert "properties" in schema
        # required entries must be declared as properties
        for req in schema.get("required", []):
            assert req in schema["properties"]


def test_rest_manifest_is_derived_and_consistent():
    rest = mt.rest_manifest()
    assert {r["name"] for r in rest} == {t["name"] for t in mt.MCP_TOOLS}
    for r in rest:
        assert r["endpoint"] == f"POST /tools/{r['name']}"
        assert isinstance(r["input_schema"], dict)


def test_query_param_marked_required_in_rest_view():
    gmc = next(r for r in mt.rest_manifest() if r["name"] == "get_metadata_context")
    assert "required" in gmc["input_schema"]["query"]


def test_system_prompt_covers_key_directives():
    p = mt.SYSTEM_PROMPT.lower()
    for token in ("exactly", "retriev", "graph", "book of business", "read-only"):
        assert token in p


def test_book_of_business_instructions_nonempty():
    assert "BOOK OF BUSINESS" in mt.BOOK_OF_BUSINESS_INSTRUCTIONS
    assert "account concentration" in mt.BOOK_OF_BUSINESS_INSTRUCTIONS
