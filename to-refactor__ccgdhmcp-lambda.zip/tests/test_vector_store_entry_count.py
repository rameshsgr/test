"""Regression tests for the "Vector store ready — -1 entries" diagnostic bug.

Root cause: PgVectorGateway.entry_count caught ANY exception from
PgVectorMetadataVectorStore._db_count() and silently returned the sentinel
-1, with zero logging of what actually failed. -1 is not a possible real
COUNT(*) result — it only ever meant "an exception was swallowed here."

Fix: entry_count now returns None (never a fake int) on failure, logs the
exception with type/message/timing at WARNING level, and logs a DEBUG success
line with timing on the happy path. The caller (api.app._build_tool_service)
branches on None to log "count unavailable" instead of feeding None into a
"%d" format spec (which would itself raise TypeError).
"""

import logging
import sys
import types

import pytest


def _stub(name):
    if name not in sys.modules:
        sys.modules[name] = types.ModuleType(name)


_stub("psycopg2")
_stub("psycopg2.extras")
_stub("psycopg2.extensions")
_stub("pgvector")
_stub("pgvector.psycopg2")
_stub("boto3")
sys.modules["psycopg2"].extensions = types.SimpleNamespace(connection=object)
sys.modules["pgvector.psycopg2"].register_vector = lambda conn: None

from infrastructure.vector_store.gateway import PgVectorGateway


class _FakeStoreOK:
    def _db_count(self):
        return 12345


class _FakeStoreFails:
    def __init__(self, exc=None):
        self._exc = exc or RuntimeError("permission denied for schema gbs_clientreporting")

    def _db_count(self):
        raise self._exc


def test_entry_count_returns_real_int_on_success():
    result = PgVectorGateway(_FakeStoreOK()).entry_count
    assert result == 12345
    assert isinstance(result, int)


def test_entry_count_returns_none_never_minus_one_on_failure():
    result = PgVectorGateway(_FakeStoreFails()).entry_count
    assert result is None
    assert result != -1


def test_entry_count_logs_exception_detail_on_failure(caplog):
    with caplog.at_level(logging.WARNING, logger="infrastructure.vector_store.gateway"):
        PgVectorGateway(_FakeStoreFails(RuntimeError("permission denied for schema x"))).entry_count
    assert any("permission denied for schema x" in r.message for r in caplog.records)
    assert any("RuntimeError" in r.message for r in caplog.records)


def test_entry_count_does_not_raise_typeerror_downstream():
    """The old '-1' sentinel was at least a safe int for '%d' formatting;
    None is not.  Guard that no caller can naively %-format entry_count."""
    result = PgVectorGateway(_FakeStoreFails()).entry_count
    with pytest.raises(TypeError):
        "count=%d" % result  # exactly why api.app must branch on None first


def test_api_app_style_branch_avoids_the_typeerror():
    """Mirrors the fixed logging branch in api.app._build_tool_service."""
    result = PgVectorGateway(_FakeStoreFails()).entry_count
    if result is None:
        message = "Vector store ready — count unavailable (see prior WARNING for cause)"
    else:
        message = "Vector store ready — %d entries" % result
    assert message == "Vector store ready — count unavailable (see prior WARNING for cause)"

    result_ok = PgVectorGateway(_FakeStoreOK()).entry_count
    if result_ok is None:
        message_ok = "Vector store ready — count unavailable (see prior WARNING for cause)"
    else:
        message_ok = "Vector store ready — %d entries" % result_ok
    assert message_ok == "Vector store ready — 12345 entries"
