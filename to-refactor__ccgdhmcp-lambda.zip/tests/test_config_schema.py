"""Fix 1 — RedshiftConfig must never expose a comma-joined string as the
single ``schema``, and must expand the full list into ``schemas``."""

import pytest

from core.config import RedshiftConfig

_SCHEMA_ENV_VARS = ("REDSHIFT_SCHEMA", "REDSHIFT_SCHEMAS")


@pytest.fixture(autouse=True)
def _clear_schema_env(monkeypatch):
    for var in _SCHEMA_ENV_VARS:
        monkeypatch.delenv(var, raising=False)


def test_comma_joined_yaml_schema_yields_single_primary():
    # Historic misconfiguration: SCHEMA set to a comma-joined list.
    cfg = RedshiftConfig.from_dict({
        "HOST": "h", "DATABASE": "d",
        "SCHEMA": "ARD_CLIENT_POLICY,ARD_SALES_OPPORTUNITY",
    })
    # Primary schema is a SINGLE value (first entry) — never the comma string.
    assert cfg.schema == "ARD_CLIENT_POLICY"
    assert "," not in cfg.schema
    # But every accessible schema is still expanded into `schemas`.
    assert cfg.schemas == ("ARD_CLIENT_POLICY", "ARD_SALES_OPPORTUNITY")


def test_explicit_schemas_env_wins(monkeypatch):
    monkeypatch.setenv("REDSHIFT_SCHEMA", "ONLY_ONE")
    monkeypatch.setenv("REDSHIFT_SCHEMAS", "A,B,C")
    cfg = RedshiftConfig.from_dict({"HOST": "h", "DATABASE": "d"})
    assert cfg.schema == "ONLY_ONE"
    assert cfg.schemas == ("A", "B", "C")


def test_default_schema_is_public_when_unset():
    cfg = RedshiftConfig.from_dict({"HOST": "h", "DATABASE": "d"})
    assert cfg.schema == "public"
    assert cfg.schemas == ("public",)


def test_whitespace_in_schema_list_is_trimmed():
    cfg = RedshiftConfig.from_dict({
        "HOST": "h", "DATABASE": "d",
        "SCHEMA": " ARD_CLIENT_POLICY , ARD_SALES_OPPORTUNITY ",
    })
    assert cfg.schema == "ARD_CLIENT_POLICY"
    assert cfg.schemas == ("ARD_CLIENT_POLICY", "ARD_SALES_OPPORTUNITY")
