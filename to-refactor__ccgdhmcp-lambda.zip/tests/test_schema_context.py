"""Fix 3 — `_build_schema_context` must surface the graph enrichment
(joins, business-term map, view lineage) and merge graph-discovered tables,
instead of discarding `graph_context` before SQL generation."""

from application.services.redshift_tool_service import RedshiftToolService

_build = RedshiftToolService._build_schema_context


def _base_context():
    return {
        "relevant_tables": [
            {
                "full_name": "ARD_SALES_OPPORTUNITY.opportunity",
                "column_names": ["opp_id", "acct_id", "amount"],
                "primary_keys": ["opp_id"],
                "foreign_keys": ["acct_id"],
            }
        ],
        "relevant_columns": [],
        "graph_context": {
            "suggested_joins": [
                "JOIN ARD_CLIENT_POLICY.account ON "
                "ARD_SALES_OPPORTUNITY.opportunity.acct_id = ARD_CLIENT_POLICY.account.acct_id"
            ],
            "logical_name_map": {"amount": "Opportunity Amount"},
            "view_lineage": {},
            "extra_tables": [
                {
                    "full_name": "ARD_CLIENT_POLICY.account",
                    "column_names": ["acct_id", "acct_nm"],
                    "logical_name": "Account",
                }
            ],
        },
    }


def test_includes_vector_table():
    out = _build(_base_context())
    assert "ARD_SALES_OPPORTUNITY.opportunity" in out
    assert "opp_id" in out


def test_includes_suggested_joins():
    out = _build(_base_context())
    assert "Graph-assisted inferred JOIN paths" in out
    assert "JOIN ARD_CLIENT_POLICY.account" in out


def test_includes_logical_name_map():
    out = _build(_base_context())
    assert "Business-term" in out
    assert "amount = Opportunity Amount" in out


def test_merges_graph_extra_tables():
    out = _build(_base_context())
    # The keyword-discovered table (not in vector results) must appear.
    assert "ARD_CLIENT_POLICY.account" in out
    assert "acct_nm" in out


def test_no_graph_context_still_works():
    ctx = {"relevant_tables": [
        {"full_name": "s.t", "column_names": ["c"], "primary_keys": [], "foreign_keys": []}
    ]}
    out = _build(ctx)
    assert "s.t" in out
    assert "Graph-assisted inferred JOIN paths" not in out


def test_empty_context_returns_none():
    assert _build({"relevant_tables": []}) is None


def test_extra_table_not_duplicated_when_already_present():
    ctx = _base_context()
    ctx["graph_context"]["extra_tables"].append({
        "full_name": "ARD_SALES_OPPORTUNITY.opportunity",  # already in vector results
        "column_names": [],
    })
    out = _build(ctx)
    assert out.count("Table: ARD_SALES_OPPORTUNITY.opportunity") == 1
