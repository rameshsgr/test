"""Data-driven owner-entity resolution.

"Show the book of business for AE Andrew Landon ..." returned 0 rows across
two ILIKE attempts that both assumed a "First Last" contiguous string. This
suite covers the pre-flight resolution phase that discovers, via direct
read-only discovery queries against the actual candidate owner/AE columns,
how the person is really stored — BEFORE SQL generation — instead of hoping
the LLM's retry prompt happens to land on the right format.

Flow under test:
  User Query -> Owner Resolution -> Resolved Person -> SQL Generation -> Execution
"""

import pytest

from application.services.redshift_tool_service import RedshiftToolService
from domain.entities.query_result import QueryResult


class ScriptedRedshift:
    """Fake RedshiftGateway returning scripted COUNT/DISTINCT results.

    ``count_by_where`` maps an exact WHERE-clause fragment (as built by
    ``resolve_owner_entity``) to the count that fragment should report.
    Any WHERE clause not present in the map reports 0 (not matched).
    """

    def __init__(self, count_by_where: dict, samples=None):
        self._count_by_where = count_by_where
        self._samples = samples or []
        self.executed_sql = []

    def execute_query(self, sql):
        self.executed_sql.append(sql)
        upper = sql.strip().upper()
        if upper.startswith("SELECT COUNT"):
            for where_fragment, count in self._count_by_where.items():
                if where_fragment in sql:
                    return {"rows": [{"match_count": count}], "columns": ["match_count"], "total_rows": 1}
            return {"rows": [{"match_count": 0}], "columns": ["match_count"], "total_rows": 1}
        if upper.startswith("SELECT DISTINCT"):
            return {
                "rows": [{"val": v} for v in self._samples],
                "columns": ["val"], "total_rows": len(self._samples),
            }
        return {"rows": [], "columns": [], "total_rows": 0}


def _metadata_context(*column_pairs):
    """Build a metadata_context with relevant_tables carrying the given
    (full_table_name, [column_names]) pairs."""
    return {
        "relevant_tables": [
            {"full_name": full_name, "column_names": cols}
            for full_name, cols in column_pairs
        ],
    }


def _service(redshift):
    return RedshiftToolService(redshift=redshift, vector_store=None, graph_enricher=None)


# --------------------------------------------------------------------------- #
# Column discovery (never assumes existence — reads from retrieved schema)   #
# --------------------------------------------------------------------------- #

def test_no_candidate_columns_present_returns_none_without_any_query():
    rs = ScriptedRedshift({})
    svc = _service(rs)
    ctx = _metadata_context(("s.t", ["unrelated_col"]))
    import asyncio
    result = asyncio.run(svc.resolve_owner_entity("Andrew Landon", ctx))
    assert result is None
    assert rs.executed_sql == []  # no DB round-trip when no candidate column exists


def test_single_token_name_is_not_resolved():
    rs = ScriptedRedshift({})
    svc = _service(rs)
    ctx = _metadata_context(("s.t", ["policy_account_executive_name"]))
    import asyncio
    result = asyncio.run(svc.resolve_owner_entity("Andrew", ctx))
    assert result is None
    assert rs.executed_sql == []


# --------------------------------------------------------------------------- #
# Dynamic keyword-based column discovery (never a hardcoded allow-list)       #
# --------------------------------------------------------------------------- #

def test_discovers_new_columns_not_in_the_original_known_list():
    """Columns never seen before (e.g. a brand-new table) are still found
    purely by keyword match -- proving discovery isn't a fixed allow-list."""
    svc = _service(ScriptedRedshift({}))
    ctx = _metadata_context((
        "ard_sales_opportunity.new_dim_table",
        ["territory_advisor_nm", "relationship_manager_full_name", "producer_count"],
    ))
    candidates = svc._find_owner_candidate_columns(ctx)
    names = {c[1] for c in candidates}
    assert "territory_advisor_nm" in names
    assert "relationship_manager_full_name" in names
    assert "producer_count" in names  # discovered, but see ranking test below


def test_non_name_shaped_columns_are_ranked_last_not_excluded():
    """An owner-keyword column that looks like an ID/flag/count is still a
    candidate (in case nothing better exists) but must rank behind
    name-shaped columns."""
    svc = _service(ScriptedRedshift({}))
    ctx = _metadata_context((
        "ard_client_policy.policy_golden_record_mvw",
        ["policy_account_executive_name", "policy_owner_id", "policy_manager_flag"],
    ))
    candidates = svc._find_owner_candidate_columns(ctx)
    names = [c[1] for c in candidates]
    assert names[0] == "policy_account_executive_name"
    assert names.index("policy_owner_id") > 0
    assert names.index("policy_manager_flag") > 0


def test_known_good_columns_keep_their_data_confirmed_order():
    """Among two equally keyword-matched, equally 'known' columns, the
    data-confirmed client-before-policy preference order must be preserved.

    COUNT(DISTINCT policy_account_executive_name) against
    ard_client_policy.policy_golden_record_mvw returned 0 (present in the
    schema but entirely unpopulated), while
    client_golden_record_mvw.client_account_executive_name is populated and
    already drives working book-of-business results — so client_* must rank
    ahead of policy_* for account-executive resolution.
    """
    svc = _service(ScriptedRedshift({}))
    ctx = _metadata_context(
        ("ard_client_policy.policy_golden_record_mvw", ["policy_account_executive_name"]),
        ("ard_client_policy.client_golden_record_mvw", ["client_account_executive_name"]),
    )
    candidates = svc._find_owner_candidate_columns(ctx)
    names = [c[1] for c in candidates]
    assert names == ["client_account_executive_name", "policy_account_executive_name"]


def test_unrelated_columns_are_never_candidates():
    svc = _service(ScriptedRedshift({}))
    ctx = _metadata_context((
        "s.t", ["client_id", "policy_premium_amt", "product_category"],
    ))
    assert svc._find_owner_candidate_columns(ctx) == []


def test_candidate_count_is_capped():
    svc = _service(ScriptedRedshift({}))
    many_cols = [f"owner_name_{i}" for i in range(20)]
    ctx = _metadata_context(("s.t", many_cols))
    candidates = svc._find_owner_candidate_columns(ctx, max_candidates=5)
    assert len(candidates) == 5


# --------------------------------------------------------------------------- #
# Strategy cascade: exact -> reversed -> tokens-any-order                     #
# --------------------------------------------------------------------------- #

@pytest.mark.asyncio
async def test_resolves_via_exact_first_last_when_it_matches():
    col = "policy_account_executive_name"
    rs = ScriptedRedshift(
        count_by_where={f"{col} ILIKE '%Andrew%Landon%'": 3},
        samples=["ANDREW LANDON"],
    )
    svc = _service(rs)
    ctx = _metadata_context(("ard_client_policy.policy_golden_record_mvw", [col]))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result["strategy"] == "exact_first_last"
    assert result["match_count"] == 3
    assert result["column"] == col


@pytest.mark.asyncio
async def test_falls_back_to_reversed_last_first_when_exact_fails():
    col = "policy_account_executive_name"
    rs = ScriptedRedshift(
        count_by_where={f"{col} ILIKE '%Landon%Andrew%'": 5},
        samples=["LANDON, ANDREW"],
    )
    svc = _service(rs)
    ctx = _metadata_context(("ard_client_policy.policy_golden_record_mvw", [col]))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result["strategy"] == "reversed_last_first"
    assert result["match_count"] == 5
    assert result["sample_values"] == ["LANDON, ANDREW"]


@pytest.mark.asyncio
async def test_falls_back_to_tokens_any_order_when_order_specific_strategies_fail():
    col = "policy_account_executive_name"
    rs = ScriptedRedshift(
        count_by_where={
            f"{col} ILIKE '%Andrew%' AND {col} ILIKE '%Landon%'": 2,
        },
    )
    svc = _service(rs)
    ctx = _metadata_context(("ard_client_policy.policy_golden_record_mvw", [col]))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result["strategy"] == "tokens_any_order"
    assert result["match_count"] == 2


@pytest.mark.asyncio
async def test_generated_where_sql_matches_required_example_format():
    """Matches the exact expected output from the task:
    ILIKE '%LANDON%' AND ILIKE '%ANDREW%' style token-AND filter."""
    col = "policy_account_executive_name"
    rs = ScriptedRedshift(
        count_by_where={f"{col} ILIKE '%Andrew%' AND {col} ILIKE '%Landon%'": 1},
    )
    svc = _service(rs)
    ctx = _metadata_context(("ard_client_policy.policy_golden_record_mvw", [col]))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result["where_sql"] == f"{col} ILIKE '%Andrew%' AND {col} ILIKE '%Landon%'"


# --------------------------------------------------------------------------- #
# Candidate-column preference order + short-circuit                          #
# --------------------------------------------------------------------------- #

@pytest.mark.asyncio
async def test_first_preference_column_wins_and_short_circuits():
    policy_col = "policy_account_executive_name"
    client_col = "client_account_executive_name"
    rs = ScriptedRedshift(
        count_by_where={
            f"{policy_col} ILIKE '%Andrew%Landon%'": 4,
            f"{client_col} ILIKE '%Andrew%Landon%'": 9,  # would also match, but must not be reached
        },
        samples=["ANDREW LANDON"],
    )
    svc = _service(rs)
    ctx = _metadata_context((
        "ard_client_policy.policy_golden_record_mvw",
        [policy_col],
    ), (
        "ard_client_policy.client_golden_record_mvw",
        [client_col],
    ))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result["column"] == policy_col  # first in _OWNER_CANDIDATE_COLUMNS order
    assert not any(client_col in sql for sql in rs.executed_sql)  # short-circuited


@pytest.mark.asyncio
async def test_second_candidate_tried_when_first_does_not_match():
    policy_col = "policy_account_executive_name"
    client_col = "client_account_executive_name"
    rs = ScriptedRedshift(
        count_by_where={f"{client_col} ILIKE '%Andrew%Landon%'": 1},
        samples=["ANDREW LANDON"],
    )
    svc = _service(rs)
    ctx = _metadata_context((
        "ard_client_policy.policy_golden_record_mvw", [policy_col],
    ), (
        "ard_client_policy.client_golden_record_mvw", [client_col],
    ))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result["column"] == client_col


@pytest.mark.asyncio
async def test_no_strategy_matches_any_candidate_returns_none():
    rs = ScriptedRedshift(count_by_where={})
    svc = _service(rs)
    ctx = _metadata_context((
        "ard_client_policy.policy_golden_record_mvw", ["policy_account_executive_name"],
    ))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result is None


@pytest.mark.asyncio
async def test_query_failure_on_one_candidate_does_not_abort_the_others():
    class FlakyThenGood(ScriptedRedshift):
        def execute_query(self, sql):
            if "policy_account_executive_name" in sql:
                raise RuntimeError("connection reset")
            return super().execute_query(sql)

    client_col = "client_account_executive_name"
    rs = FlakyThenGood(
        count_by_where={f"{client_col} ILIKE '%Andrew%Landon%'": 1},
        samples=["ANDREW LANDON"],
    )
    svc = _service(rs)
    ctx = _metadata_context((
        "ard_client_policy.policy_golden_record_mvw", ["policy_account_executive_name"],
    ), (
        "ard_client_policy.client_golden_record_mvw", [client_col],
    ))
    result = await svc.resolve_owner_entity("Andrew Landon", ctx)
    assert result is not None
    assert result["column"] == client_col


# --------------------------------------------------------------------------- #
# End-to-end: process_query wires resolution into the schema context         #
# --------------------------------------------------------------------------- #

class _FakeVectorStore:
    def search_tables_and_columns(self, query, table_count, column_count):
        return {"tables": [{
            "full_table_name": "ard_client_policy.policy_golden_record_mvw",
            "schema_name": "ard_client_policy", "table_name": "policy_golden_record_mvw",
            "column_names": ["policy_account_executive_name", "policy_id"],
            "primary_key_columns": [], "foreign_key_columns": [],
            "table_description": "", "_score": 0.1,
        }], "columns": []}


class _RedshiftWithResolutionAndGen(ScriptedRedshift):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.schema_contexts = []

    async def generate_sql(self, prompt, schema_context=None):
        self.schema_contexts.append(schema_context)
        return "SELECT policy_id FROM ard_client_policy.policy_golden_record_mvw LIMIT 5"


@pytest.mark.asyncio
async def test_process_query_injects_resolved_owner_directive_before_generation():
    col = "policy_account_executive_name"
    rs = _RedshiftWithResolutionAndGen(
        count_by_where={f"{col} ILIKE '%Landon%Andrew%'": 7},
        samples=["LANDON, ANDREW"],
    )
    svc = RedshiftToolService(redshift=rs, vector_store=_FakeVectorStore(), graph_enricher=None)
    result = await svc.process_query(
        "Show the book of business for AE Andrew Landon including account "
        "number, account name, policy count, and product count"
    )
    assert rs.schema_contexts, "generate_sql should have been called"
    sc = rs.schema_contexts[0]
    assert "RESOLVED OWNER ENTITY" in sc
    assert "LANDON, ANDREW" in sc
    assert f"{col} ILIKE '%Landon%Andrew%'" in sc
    assert 'Do NOT use a single "%Andrew Landon%" substring match' in sc


@pytest.mark.asyncio
async def test_process_query_skips_resolution_when_no_person_named():
    col = "policy_account_executive_name"
    rs = _RedshiftWithResolutionAndGen(count_by_where={f"{col} ILIKE '%x%y%'": 1})
    svc = RedshiftToolService(redshift=rs, vector_store=_FakeVectorStore(), graph_enricher=None)
    await svc.process_query("how many policies are there")
    assert rs.schema_contexts
    assert "RESOLVED OWNER ENTITY" not in rs.schema_contexts[0]
