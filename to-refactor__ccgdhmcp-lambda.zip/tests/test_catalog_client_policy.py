"""Unit tests for infrastructure/business_catalog/catalog_client.py

Covers:
- insight-agent-v0 is no longer restricted to 3 intents
- unknown/missing intent with insight policy → full active set (capped)
- max_templates truncation still applies
- fallback runs at most once
- response includes execution.policy_version and execution.activation_reasons
- old response keys (results, execution.executed_query_ids) still present
- _dedupe_rows removes duplicates
- _active_query_ids returns only active queries
- default policy still uses _DEFAULT_QUERY_IDS when no intent matches
"""
from __future__ import annotations

import json
import types
import unittest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Import helpers — catalog_client has a lazy boto3 init; we stub it out so
# tests can import the module without any AWS credentials.
# ---------------------------------------------------------------------------
def _stub_boto3_client(*args, **kwargs):  # noqa: ANN001
    return MagicMock()


import boto3  # noqa: E402  (must come before catalog_client import)

_real_boto3_client = boto3.client


def _make_module():
    """Import catalog_client with boto3.client stubbed so no AWS calls happen."""
    import importlib
    import infrastructure.business_catalog.catalog_client as mod  # already imported? fine
    return mod


# Patch at module level for entire test session
import boto3 as _boto3_mod  # noqa: E402
_boto3_mod.client = _stub_boto3_client

import infrastructure.business_catalog.catalog_client as cc  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_INSIGHT_POLICY = cc._AGENT_POLICY_REGISTRY["insight-agent-v0"]
_DEFAULT_POLICY = cc._AGENT_POLICY_REGISTRY["default"]
_SITUATION_POLICY = cc._AGENT_POLICY_REGISTRY["situation-analyzer-v0"]


def _fake_neptune_response(rows: list) -> dict:
    """Build a minimal Neptune REST response for a given row list."""
    return {
        "result": {
            "data": {
                "@type": "g:List",
                "@value": [
                    {
                        "@type": "g:Map",
                        "@value": list(sum([[k, v] for k, v in row.items()], [])),
                    }
                    for row in rows
                ],
            }
        }
    }


# ---------------------------------------------------------------------------
# Tests for _active_query_ids
# ---------------------------------------------------------------------------
class TestActiveQueryIds(unittest.TestCase):
    def test_returns_all_active(self):
        ids = cc._active_query_ids()
        self.assertGreater(len(ids), 0)
        for qid in ids:
            self.assertEqual(cc._QUERY_METADATA[qid]["status"], "active")

    def test_excludes_disabled(self):
        # Temporarily disable one query
        original = cc._QUERY_METADATA["SHEET_01_DOMAINS_CONTEXT"]["status"]
        cc._QUERY_METADATA["SHEET_01_DOMAINS_CONTEXT"]["status"] = "disabled"
        try:
            ids = cc._active_query_ids()
            self.assertNotIn("SHEET_01_DOMAINS_CONTEXT", ids)
        finally:
            cc._QUERY_METADATA["SHEET_01_DOMAINS_CONTEXT"]["status"] = original

    def test_order_is_stable(self):
        self.assertEqual(cc._active_query_ids(), cc._active_query_ids())


# ---------------------------------------------------------------------------
# Tests for _dedupe_rows
# ---------------------------------------------------------------------------
class TestDedupeRows(unittest.TestCase):
    def test_removes_dict_duplicates(self):
        rows = [{"a": 1, "b": 2}, {"a": 1, "b": 2}, {"a": 3}]
        result = cc._dedupe_rows(rows)
        self.assertEqual(len(result), 2)

    def test_preserves_order(self):
        rows = [{"x": 1}, {"x": 2}, {"x": 1}]
        result = cc._dedupe_rows(rows)
        self.assertEqual(result, [{"x": 1}, {"x": 2}])

    def test_empty_list(self):
        self.assertEqual(cc._dedupe_rows([]), [])

    def test_non_dict_rows(self):
        rows = ["a", "b", "a", "c"]
        result = cc._dedupe_rows(rows)
        self.assertEqual(result, ["a", "b", "c"])


# ---------------------------------------------------------------------------
# Tests for insight-agent-v0 policy scope
# ---------------------------------------------------------------------------
class TestInsightPolicyScope(unittest.TestCase):
    def test_not_restricted_to_three_intents(self):
        """Intent map must cover more than the original 3 intents."""
        bundle_map = _INSIGHT_POLICY["intent_bundle_map"]
        self.assertGreater(len(bundle_map), 3, "insight-agent-v0 must support more than 3 intents")

    def test_covers_all_intent_query_map_intents(self):
        """Every intent in _INTENT_QUERY_MAP must appear in the insight policy bundle map."""
        bundle_map = _INSIGHT_POLICY["intent_bundle_map"]
        for intent in cc._INTENT_QUERY_MAP:
            self.assertIn(
                intent, bundle_map,
                f"Intent '{intent}' from _INTENT_QUERY_MAP missing from insight-agent-v0 policy",
            )

    def test_full_coverage_flag_set(self):
        self.assertTrue(_INSIGHT_POLICY.get("full_coverage"), "full_coverage must be True")

    def test_limits_raised_to_server_caps(self):
        lim = _INSIGHT_POLICY["limits"]
        self.assertEqual(lim["max_templates"], cc._SERVER_MAX_TEMPLATES)
        self.assertEqual(lim["max_rows"], cc._SERVER_MAX_ROWS)

    def test_fallback_bundle_is_broad(self):
        """Fallback must include more than a single query (broad active set)."""
        self.assertGreater(len(_INSIGHT_POLICY["fallback_bundle"]), 1)

    def test_only_active_queries_in_bundles(self):
        """No disabled queries should appear in any intent bundle."""
        for intent, qids in _INSIGHT_POLICY["intent_bundle_map"].items():
            for qid in qids:
                status = cc._QUERY_METADATA.get(qid, {}).get("status", "active")
                self.assertEqual(
                    status, "active",
                    f"Disabled query '{qid}' found in insight policy bundle for intent '{intent}'",
                )


# ---------------------------------------------------------------------------
# Tests for _resolve_query_ids
# ---------------------------------------------------------------------------
class TestResolveQueryIds(unittest.TestCase):
    def test_known_intent_resolves_for_insight(self):
        ids = cc._resolve_query_ids("domains", "", None, 10, _INSIGHT_POLICY)
        self.assertIn("SHEET_01_DOMAINS_CONTEXT", ids)

    def test_unknown_intent_insight_falls_back_to_full_active(self):
        """Unknown intent with full_coverage policy → returns full active set (up to cap)."""
        ids = cc._resolve_query_ids("nonexistent_intent_xyz", "", None, cc._SERVER_MAX_TEMPLATES, _INSIGHT_POLICY)
        active = cc._active_query_ids()
        # Should be the first max_templates active queries
        self.assertEqual(ids, active[:cc._SERVER_MAX_TEMPLATES])

    def test_no_intent_no_text_insight_falls_back_to_full_active(self):
        """No intent and no query text → full active set for insight policy."""
        ids = cc._resolve_query_ids(None, "", None, cc._SERVER_MAX_TEMPLATES, _INSIGHT_POLICY)
        active = cc._active_query_ids()
        self.assertEqual(ids, active[:cc._SERVER_MAX_TEMPLATES])

    def test_no_intent_default_policy_uses_defaults(self):
        """No intent with default policy → _DEFAULT_QUERY_IDS."""
        ids = cc._resolve_query_ids(None, "", None, cc._SERVER_MAX_TEMPLATES, _DEFAULT_POLICY)
        expected = [q for q in cc._DEFAULT_QUERY_IDS if cc._QUERY_METADATA.get(q, {}).get("status", "active") == "active"]
        self.assertEqual(ids, expected)

    def test_max_templates_truncation(self):
        """Result must never exceed max_templates."""
        for cap in [1, 2, 5]:
            ids = cc._resolve_query_ids(None, "", None, cap, _INSIGHT_POLICY)
            self.assertLessEqual(len(ids), cap, f"Truncation failed for cap={cap}")

    def test_disabled_query_excluded(self):
        cc._QUERY_METADATA["SHEET_01_DOMAINS_CONTEXT"]["status"] = "disabled"
        try:
            ids = cc._resolve_query_ids("domains", "", None, 10, _INSIGHT_POLICY)
            self.assertNotIn("SHEET_01_DOMAINS_CONTEXT", ids)
        finally:
            cc._QUERY_METADATA["SHEET_01_DOMAINS_CONTEXT"]["status"] = "active"

    def test_deduplication_in_resolved_ids(self):
        """Each query ID must appear at most once."""
        ids = cc._resolve_query_ids("renewal_risk", "renewal risk rules", None, 10, _INSIGHT_POLICY)
        self.assertEqual(len(ids), len(set(ids)))


# ---------------------------------------------------------------------------
# Tests for deterministic situation-analyzer policy
# ---------------------------------------------------------------------------
class TestSituationAnalyzerPolicy(unittest.TestCase):
    def test_policy_exists_and_active(self):
        self.assertEqual(_SITUATION_POLICY["policy_key"], "situation-analyzer-v0")
        self.assertEqual(_SITUATION_POLICY["status"], "active")

    def test_fixed_bundle_configured(self):
        self.assertEqual(
            _SITUATION_POLICY.get("fixed_bundle"),
            ["SITUATION_ANALYZER_DEFAULT_CONTEXT"],
        )
        self.assertEqual(
            _SITUATION_POLICY.get("fallback_bundle"),
            ["SITUATION_ANALYZER_DEFAULT_CONTEXT"],
        )

    def test_resolve_query_ids_ignores_intent_when_fixed_bundle_present(self):
        expected = ["SITUATION_ANALYZER_DEFAULT_CONTEXT"]
        for intent in (None, "signals", "insights", "nonexistent_intent_xyz"):
            ids = cc._resolve_query_ids(intent, "", None, 10, _SITUATION_POLICY)
            self.assertEqual(ids, expected)

    def test_policy_resolves_from_policy_key_label(self):
        resolved = cc._resolve_context_hints_from_query(
            "policy key: situation-analyzer-v0. run situation analysis.",
            intent=None,
            agent=None,
            policy_key=None,
        )
        self.assertEqual(resolved.get("policy_key"), "situation-analyzer-v0")

    def test_policy_resolves_from_caller_agent_label(self):
        resolved = cc._resolve_context_hints_from_query(
            "caller agent: situation-analyzer. run situation analysis.",
            intent=None,
            agent=None,
            policy_key=None,
        )
        self.assertEqual(resolved.get("policy_key"), "situation-analyzer-v0")

    def test_policy_resolves_from_agent_name_with_agent_suffix(self):
        resolved = cc._resolve_context_hints_from_query(
            "caller agent: situation-analyzer-agent. run situation analysis.",
            intent=None,
            agent=None,
            policy_key=None,
        )
        self.assertEqual(resolved.get("policy_key"), "situation-analyzer-v0")

    def test_situation_explicit_intent_stays_narrow(self):
        ids = cc._resolve_query_ids(
            "material_changes",
            "Create a situation for client id 385765 with rules, signals, and outcomes.",
            None,
            10,
            _SITUATION_POLICY,
        )
        self.assertEqual(ids, ["SITUATION_MATERIAL_CHANGES"])

    def test_fetch_uses_situation_policy_and_fixed_bundle(self):
        mock = MagicMock()
        mock.execute_gremlin_query.return_value = _fake_neptune_response([{"Definition": "ok"}])
        task = "caller agent: situation-analyzer. policy key: situation-analyzer-v0. semantic intent: signals."
        with patch.object(cc, "_get_neptune_client", return_value=mock):
            result = cc.fetch_catalog_context(task)
        self.assertTrue(result.get("available"))
        self.assertEqual(result["execution"].get("policy_version"), "situation-analyzer-v0")
        self.assertEqual(
            result["execution"].get("executed_query_ids"),
            ["SITUATION_ANALYZER_DEFAULT_CONTEXT"],
        )

    def test_situation_policy_limits_are_applied(self):
        mock = MagicMock()
        mock.execute_gremlin_query.return_value = _fake_neptune_response([{"Definition": "ok"}])
        with patch.object(cc, "_get_neptune_client", return_value=mock):
            result = cc.fetch_catalog_context(
                "policy key: situation-analyzer-v0. caller agent: situation-analyzer.",
                limits={"max_templates": 99},
            )
        self.assertEqual(
            result["execution"].get("executed_query_ids"),
            ["SITUATION_ANALYZER_DEFAULT_CONTEXT"],
        )


# ---------------------------------------------------------------------------
# Tests for fetch_catalog_context response shape
# ---------------------------------------------------------------------------
class TestFetchCatalogContextResponse(unittest.TestCase):
    """Mock the Neptune client to avoid real AWS calls."""

    def _mock_client(self, row_data: list | None = None):
        row_data = row_data or [{"Definition": "test def", "Rule ID": "R001"}]
        mock = MagicMock()
        mock.execute_gremlin_query.return_value = _fake_neptune_response(row_data)
        return mock

    def test_old_response_keys_present(self):
        with patch.object(cc, "_get_neptune_client", return_value=self._mock_client()):
            result = cc.fetch_catalog_context("renewal risk", intent="renewal_risk", policy_key="insight-agent-v0")
        self.assertIn("available", result)
        self.assertIn("results", result)
        self.assertIn("execution", result)
        self.assertIn("coverage", result)
        self.assertIn("executed_query_ids", result["execution"])

    def test_policy_version_in_execution(self):
        with patch.object(cc, "_get_neptune_client", return_value=self._mock_client()):
            result = cc.fetch_catalog_context("any query", policy_key="insight-agent-v0")
        self.assertEqual(result["execution"].get("policy_version"), "insight-agent-v0")

    def test_activation_reasons_in_execution(self):
        with patch.object(cc, "_get_neptune_client", return_value=self._mock_client()):
            result = cc.fetch_catalog_context("renewal risk", intent="renewal_risk", policy_key="insight-agent-v0")
        reasons = result["execution"].get("activation_reasons", [])
        self.assertIsInstance(reasons, list)
        self.assertTrue(len(reasons) > 0)
        self.assertTrue(any("explicit_intent" in r for r in reasons))

    def test_context_key_present_and_has_rows(self):
        """Additive 'context' key must be present with rows and truncated."""
        with patch.object(cc, "_get_neptune_client", return_value=self._mock_client()):
            result = cc.fetch_catalog_context("any query", policy_key="default")
        self.assertIn("context", result)
        self.assertIn("rows", result["context"])
        self.assertIn("truncated", result["context"])

    def test_fallback_runs_at_most_once(self):
        """The fallback path must be entered at most once per call."""
        call_log = []

        def _tracked_execute(gremlinQuery, serializer):
            call_log.append(gremlinQuery[:50])
            # Return no Definition row so coverage fails every time
            return _fake_neptune_response([{"Signal ID": "S001"}])

        mock_client = MagicMock()
        mock_client.execute_gremlin_query.side_effect = _tracked_execute

        with patch.object(cc, "_get_neptune_client", return_value=mock_client):
            result = cc.fetch_catalog_context(
                "renewal risk",
                intent="renewal_risk",
                policy_key="insight-agent-v0",
                limits={"max_templates": 2},  # tight budget to keep call count manageable
            )

        # At most 2 primary + 1 fallback = 3 calls (never more than 1 fallback)
        total_calls = mock_client.execute_gremlin_query.call_count
        # Fallback_used is a boolean in the execution dict
        fallback_used = result["execution"]["fallback_used"]
        # If fallback was triggered, it happened at most once (enforced by [:1] slice)
        if fallback_used:
            self.assertLessEqual(total_calls, 3, "More than one fallback call detected")

    def test_default_policy_activation_reason_default_bundle(self):
        """Empty query + no intent → activation_reason should contain 'default_bundle'."""
        with patch.object(cc, "_get_neptune_client", return_value=self._mock_client()):
            result = cc.fetch_catalog_context("", policy_key="default")
        reasons = result["execution"].get("activation_reasons", [])
        self.assertIn("default_bundle", reasons)

    def test_available_false_when_neptune_unreachable(self):
        def _raise(*a, **kw):
            raise RuntimeError("endpoint not configured")

        with patch.object(cc, "_get_neptune_client", side_effect=_raise):
            result = cc.fetch_catalog_context("any", policy_key="default")
        self.assertFalse(result.get("available"))


if __name__ == "__main__":
    unittest.main()
