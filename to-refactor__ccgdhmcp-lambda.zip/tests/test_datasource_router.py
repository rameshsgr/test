"""DatasourceRouter — priority order, ambiguity, tie-break, no-evidence cases.

DatasourceRouter must be a pure function: these tests construct it directly
from plain DatasourceConfig-like objects and plain dicts/lists — no
VectorStoreGateway, RedshiftGateway, or Neptune dependency anywhere.
"""

from types import SimpleNamespace

import pytest

from application.services.datasource_router import (
    AmbiguousDatasourceWarning,
    DatasourceDecision,
    DatasourceRouter,
)


def _ds(schemas):
    return SimpleNamespace(schemas=tuple(schemas))


@pytest.fixture
def router():
    return DatasourceRouter(
        {
            "discovery": _ds(["ARD_CLIENT_POLICY", "ARD_SALES_OPPORTUNITY"]),
            "gdh": _ds(
                [
                    "GDH_DL_SALESFORCE",
                    "GDH_DL_BENEFITFLOW",
                    "GDH_BD_CLIENT_POLICY",
                    "GDH_BD_REFERENCE_DATA",
                ]
            ),
            "actuarial": _ds(["BOB"]),
        }
    )


def _vector_results(*schema_names):
    return {"tables": [{"schema_name": s} for s in schema_names], "columns": []}


# ---------------------------------------------------------------------------
# Priority 1: retrieved schemas decide outright
# ---------------------------------------------------------------------------

def test_single_schema_resolves_to_discovery(router):
    decision = router.resolve(retrieved_schemas=["ARD_CLIENT_POLICY"])
    assert isinstance(decision, DatasourceDecision)
    assert decision.datasource == "discovery"
    assert decision.reason == "retrieved_schemas"


def test_schema_case_insensitive(router):
    decision = router.resolve(retrieved_schemas=["ard_client_policy"])
    assert isinstance(decision, DatasourceDecision)
    assert decision.datasource == "discovery"


def test_intent_does_not_override_schema_evidence(router):
    # Broker360-style intent, but schema clearly resolves to Discovery.
    decision = router.resolve(
        retrieved_schemas=["ARD_CLIENT_POLICY"],
        vector_results=_vector_results("ARD_CLIENT_POLICY"),
        intent="gdh",
    )
    assert isinstance(decision, DatasourceDecision)
    assert decision.datasource == "discovery"
    assert decision.reason == "retrieved_schemas"


def test_benefitflow_schema_routes_to_gdh(router):
    decision = router.resolve(retrieved_schemas=["GDH_DL_BENEFITFLOW"])
    assert decision.datasource == "gdh"


def test_actuarial_schema_routes_to_actuarial(router):
    decision = router.resolve(retrieved_schemas=["BOB"])
    assert decision.datasource == "actuarial"


# ---------------------------------------------------------------------------
# Ambiguity: multiple datasource groups in retrieved schemas -> stop
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "schemas",
    [
        ["ARD_CLIENT_POLICY", "GDH_DL_BENEFITFLOW"],       # Discovery + GDH
        ["ARD_SALES_OPPORTUNITY", "BOB"],                   # Discovery + Actuarial
        ["GDH_BD_CLIENT_POLICY", "BOB"],                    # GDH + Actuarial
    ],
)
def test_conflicting_schemas_produce_ambiguity_warning_not_a_guess(router, schemas):
    result = router.resolve(retrieved_schemas=schemas, intent="gdh")
    assert isinstance(result, AmbiguousDatasourceWarning)
    assert result.reason == "retrieved_schemas_conflict"
    assert set(result.candidate_datasources) == {
        DatasourceRouterTestHelper.datasource_for(s) for s in schemas
    }


class DatasourceRouterTestHelper:
    _MAP = {
        "ARD_CLIENT_POLICY": "discovery",
        "ARD_SALES_OPPORTUNITY": "discovery",
        "GDH_DL_BENEFITFLOW": "gdh",
        "GDH_BD_CLIENT_POLICY": "gdh",
        "BOB": "actuarial",
    }

    @classmethod
    def datasource_for(cls, schema):
        return cls._MAP[schema]


# ---------------------------------------------------------------------------
# Priority 2: vector evidence used only when no schema evidence at all
# ---------------------------------------------------------------------------

def test_vector_evidence_used_when_no_retrieved_schemas(router):
    decision = router.resolve(
        retrieved_schemas=[],
        vector_results=_vector_results("GDH_DL_SALESFORCE", "GDH_DL_SALESFORCE"),
    )
    assert isinstance(decision, DatasourceDecision)
    assert decision.datasource == "gdh"
    assert decision.reason == "vector_evidence"


# ---------------------------------------------------------------------------
# Priority 3: intent as tie-break ONLY among vector-evidenced candidates
# ---------------------------------------------------------------------------

def test_intent_breaks_tie_among_vector_candidates(router):
    decision = router.resolve(
        retrieved_schemas=[],
        vector_results=_vector_results("GDH_DL_SALESFORCE", "BOB"),
        intent="gdh",
    )
    assert isinstance(decision, DatasourceDecision)
    assert decision.datasource == "gdh"
    assert decision.reason == "intent_tiebreak"


def test_intent_not_in_candidates_still_ambiguous(router):
    result = router.resolve(
        retrieved_schemas=[],
        vector_results=_vector_results("GDH_DL_SALESFORCE", "BOB"),
        intent="discovery",  # not one of the tied vector candidates
    )
    assert isinstance(result, AmbiguousDatasourceWarning)
    assert result.reason == "vector_evidence_conflict"


def test_intent_cannot_introduce_unsupported_datasource(router):
    # No schema, no vector evidence at all -> intent alone must not route.
    result = router.resolve(retrieved_schemas=[], vector_results={}, intent="gdh")
    assert isinstance(result, AmbiguousDatasourceWarning)
    assert result.reason == "no_evidence"
    assert result.candidate_datasources == ()


# ---------------------------------------------------------------------------
# Purity: router has no attribute that could reach a live gateway
# ---------------------------------------------------------------------------

def test_router_has_no_external_dependencies(router):
    forbidden = ("vector_store", "redshift", "gateway", "neptune", "graph_enricher")
    for attr in vars(router):
        assert not any(f in attr.lower() for f in forbidden)
