"""Safety checks for generated Gremlin traversals."""

import pytest

import main as lh
from infrastructure.redshift.redshift_client import RedshiftClient


@pytest.mark.parametrize(
    "query",
    [
        "g.V().hasLabel('Client').limit(10)",
        "g.E().hasLabel('OWNS').limit(5);",
        "g.V().has('status', 'drop').limit(1)",
    ],
)
def test_readonly_gremlin_is_allowed(query):
    RedshiftClient._guard_readonly_gremlin(query)


@pytest.mark.parametrize(
    "query",
    [
        "g.addV('Client')",
        "g.V().drop()",
        "g.V().property('status', 'active')",
        "g.V(); g.V()",
        "g.V().map{ it.get() }",
        "println('not a traversal')",
    ],
)
def test_mutating_or_invalid_gremlin_is_rejected(query):
    with pytest.raises((PermissionError, ValueError)):
        RedshiftClient._guard_readonly_gremlin(query)


def test_markdown_fence_is_removed():
    assert RedshiftClient._clean_gremlin(
        "```gremlin\ng.V().limit(1)\n```"
    ) == "g.V().limit(1)"


class FakeGraphService:
    def __init__(self):
        self.calls = []

    async def generate_gremlin(self, prompt, graph_context=None):
        self.calls.append(("generate_gremlin", prompt, graph_context))
        return "g.V().limit(1)"

    def get_neptune_schema(self, **kwargs):
        self.calls.append(("get_neptune_schema", kwargs))
        return {"vertex_labels": [], "edge_labels": []}

    def query_neptune(self, gremlin, max_results=100):
        self.calls.append(("query_neptune", gremlin, max_results))
        return {"rows": [{"name": "Client"}], "row_count": 1}


@pytest.mark.asyncio
async def test_direct_payload_with_graph_context_routes_to_gremlin():
    service = FakeGraphService()
    result = await lh._dispatch_direct(
        service,
        None,
        {"prompt": "show clients", "graph_context": "{}"},
    )
    assert result == "g.V().limit(1)"
    assert service.calls == [("generate_gremlin", "show clients", "{}")]


@pytest.mark.asyncio
async def test_direct_schema_payload_routes_to_neptune_schema():
    service = FakeGraphService()
    result = await lh._dispatch_direct(
        service,
        None,
        {"max_labels": 10, "include_properties": False},
    )
    assert result == {"vertex_labels": [], "edge_labels": []}
    assert service.calls == [
        ("get_neptune_schema", {"max_labels": 10, "include_properties": False})
    ]


@pytest.mark.asyncio
async def test_named_gremlin_payload_routes_to_neptune_query():
    service = FakeGraphService()
    result = await lh._dispatch_named(
        service,
        None,
        "query_neptune",
        {"gremlin": "g.V().limit(5)", "max_results": 5},
    )
    assert result["row_count"] == 1
    assert service.calls == [("query_neptune", "g.V().limit(5)", 5)]
