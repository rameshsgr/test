"""Regression tests for the "gdh_spectrum" catalog-hallucination bug.

Root cause: PgVectorMetadataVectorStore concatenated the Glue/Spectrum
*catalog* name (tbl_catlg_nm, e.g. "gdh_spectrum") into the queryable
identifier ("full_table_name" / "full_column_name"), producing a 3-part
catalog.schema.table reference that this direct psycopg2 connection to the
"discovery" database cannot resolve — Redshift only supports schema.table
addressing here. The LLM faithfully copied that invalid identifier into
generated SQL, EXPLAIN validation correctly detected it, but the generation
loop returned the last known-invalid SQL anyway after exhausting retries.

These tests cover:
  1. The vector-store fix (catalog no longer concatenated into the name).
  2. The hard static-schema validator that rejects catalog-qualified refs.
  3. The generation loop never returning known-invalid SQL after retries
     are exhausted — it returns the failure sentinel instead.
  4. The pipeline short-circuiting instead of executing the sentinel.
"""

import sys
import types

import pytest


# --------------------------------------------------------------------------- #
# Stub optional native deps so pgvector_store.py is importable in this env    #
# --------------------------------------------------------------------------- #

def _stub(name):
    if name not in sys.modules:
        sys.modules[name] = types.ModuleType(name)


_stub("psycopg2")
_stub("psycopg2.extras")
_stub("psycopg2.extensions")
_stub("pgvector")
_stub("pgvector.psycopg2")
_stub("boto3")
sys.modules["psycopg2"].extensions = types.SimpleNamespace(connection=object)
sys.modules["pgvector.psycopg2"].register_vector = lambda conn: None

from infrastructure.vector_store.pgvector_store import PgVectorMetadataVectorStore
from infrastructure.redshift.redshift_client import (
    RedshiftClient,
    _SQL_GENERATION_FAILED,
)
from application.services.redshift_tool_service import RedshiftToolService

BAD_SQL = (
    "SELECT client_account_name\n"
    "FROM gdh_spectrum.ard_client_policy.client_golden_record_mvw\n"
    "LIMIT 5"
)
GOOD_SQL = "SELECT client_account_name FROM ard_client_policy.client_golden_record_mvw LIMIT 5"


# --------------------------------------------------------------------------- #
# 1. Source fix: pgvector must never concatenate the catalog name            #
# --------------------------------------------------------------------------- #

_GROUPED_ROW = [{
    "catalog_name": "gdh_spectrum",
    "schema_name": "ard_client_policy",
    "table_name": "client_golden_record_mvw",
    "table_logical_name": "", "table_comment": "", "view_type": "",
    "best_score": 0.1,
    "columns": [{"colmn_nm": "client_account_name", "pk_flg": "", "fk_flg": ""}],
}]


class _FakeStore(PgVectorMetadataVectorStore):
    def __init__(self):  # bypass real __init__ (no DB connection needed)
        pass

    def _group_rows_by_table(self, rows):
        return _GROUPED_ROW

    def search(self, query, top_k=50, filter_dict=None):
        return [{
            "tbl_catlg_nm": "gdh_spectrum", "tbl_schema_nm": "ard_client_policy",
            "tbl_nm": "client_golden_record_mvw", "colmn_nm": "client_account_name",
            "_score": 0.1,
        }]


def test_full_table_name_excludes_catalog():
    out = _FakeStore().search_tables_and_columns("x", table_count=5, column_count=5)
    table = out["tables"][0]
    assert table["full_table_name"] == "ard_client_policy.client_golden_record_mvw"
    assert "gdh_spectrum" not in table["full_table_name"]
    # catalog_name is still exposed as metadata — just not concatenated in.
    assert table["catalog_name"] == "gdh_spectrum"


def test_full_column_name_excludes_catalog():
    out = _FakeStore().search_tables_and_columns("x", table_count=5, column_count=5)
    col = out["columns"][0]
    assert col["full_column_name"] == "ard_client_policy.client_golden_record_mvw.client_account_name"
    assert "gdh_spectrum" not in col["full_column_name"]


# --------------------------------------------------------------------------- #
# 2. Hard static-schema validator                                             #
# --------------------------------------------------------------------------- #

def _client():
    return RedshiftClient(host="h", database="d", user="u", password="p")


def test_static_schema_rejects_catalog_qualified_reference():
    ok, err = _client()._check_static_schema(BAD_SQL)
    assert ok is False
    assert "gdh_spectrum" in err
    assert "ard_client_policy.client_golden_record_mvw" in err  # suggested correction


def test_static_schema_accepts_schema_table():
    ok, err = _client()._check_static_schema(GOOD_SQL)
    assert ok is True
    assert err == ""


def test_static_schema_accepts_no_from_clause():
    ok, _ = _client()._check_static_schema("SELECT 1")
    assert ok is True


# --------------------------------------------------------------------------- #
# 3. Generation loop never returns known-invalid SQL                          #
# --------------------------------------------------------------------------- #

class _AlwaysBadClient(RedshiftClient):
    async def _call_sql_model(self, system_prompt, user_prompt):
        return BAD_SQL

    async def _revise_sql(self, prompt, schema_context, sql, error):
        return BAD_SQL  # LLM stubbornly repeats the same mistake

    async def _enforce_schema_adherence(self, sql, prompt, schema_context, system_prompt):
        return sql


class _SelfCorrectingClient(RedshiftClient):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self._n = 0

    async def _call_sql_model(self, system_prompt, user_prompt):
        self._n += 1
        return BAD_SQL if self._n == 1 else GOOD_SQL

    async def _revise_sql(self, prompt, schema_context, sql, error):
        return GOOD_SQL

    async def _enforce_schema_adherence(self, sql, prompt, schema_context, system_prompt):
        return sql


@pytest.mark.asyncio
async def test_exhausted_retries_returns_sentinel_not_bad_sql():
    client = _AlwaysBadClient(host="h", database="d", user="u", password="p")
    result = await client._generate_sql_from_prompt(
        "give me 5 records", schema_context="Table: ard_client_policy.client_golden_record_mvw",
        validate=False, max_attempts=2,
    )
    assert result == _SQL_GENERATION_FAILED
    assert "gdh_spectrum" not in result


@pytest.mark.asyncio
async def test_exhausted_retries_result_is_not_cached_as_bad_sql():
    client = _AlwaysBadClient(host="h", database="d", user="u", password="p")
    prompt, ctx = "give me 5 records", "Table: ard_client_policy.client_golden_record_mvw"
    r1 = await client._generate_sql_from_prompt(prompt, schema_context=ctx, validate=False, max_attempts=2)
    assert r1 == _SQL_GENERATION_FAILED
    # A subsequent identical request must NOT hit a poisoned cache entry —
    # it should re-run generation (still fails here since the fake always
    # returns bad SQL, but critically it is not short-circuited by a cached
    # invalid result).
    r2 = await client._generate_sql_from_prompt(prompt, schema_context=ctx, validate=False, max_attempts=2)
    assert r2 == _SQL_GENERATION_FAILED


@pytest.mark.asyncio
async def test_self_correcting_retry_returns_valid_sql():
    client = _SelfCorrectingClient(host="h", database="d", user="u", password="p")
    result = await client._generate_sql_from_prompt(
        "give me 5 records", schema_context="Table: ard_client_policy.client_golden_record_mvw",
        validate=False, max_attempts=2,
    )
    assert result == GOOD_SQL


# --------------------------------------------------------------------------- #
# 4. Pipeline short-circuits instead of executing the failure sentinel        #
# --------------------------------------------------------------------------- #

class _FakeVectorStore:
    def search_tables_and_columns(self, query, table_count, column_count):
        return {"tables": [{
            "full_table_name": "ard_client_policy.client_golden_record_mvw",
            "schema_name": "ard_client_policy", "table_name": "client_golden_record_mvw",
            "column_names": ["client_account_name"], "primary_key_columns": [],
            "foreign_key_columns": [], "table_description": "", "_score": 0.1,
        }], "columns": []}


class _FakeRedshiftAlwaysFails:
    def __init__(self):
        self.exec_calls = []

    async def generate_sql(self, prompt, schema_context=None):
        return _SQL_GENERATION_FAILED

    def execute_query(self, sql):
        self.exec_calls.append(sql)
        return {"rows": [{"x": 1}], "columns": ["x"], "total_rows": 1}


@pytest.mark.asyncio
async def test_pipeline_never_executes_failure_sentinel_against_redshift():
    rs = _FakeRedshiftAlwaysFails()
    svc = RedshiftToolService(redshift=rs, vector_store=_FakeVectorStore(), graph_enricher=None)
    result = await svc.process_query("give me 5 records of AE book of business")
    assert rs.exec_calls == []  # Redshift must never see the sentinel
    assert result.confidence == 0.0
    assert "Unable to generate valid SQL" in result.answer
