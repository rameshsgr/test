"""Bounded, read-only Neptune query execution."""

import pytest

from application.services.redshift_tool_service import RedshiftToolService
from infrastructure.graph_ontology.neptune_enricher import NeptuneGraphOntologyEnricher


class _FakeNeptuneClient:
    def __init__(self, rows):
        self.rows = rows
        self.queries = []

    def submit(self, query):
        self.queries.append(query)
        return self.rows


def _service(rows):
    client = _FakeNeptuneClient(rows)
    enricher = NeptuneGraphOntologyEnricher(client)
    return RedshiftToolService(None, None, graph_enricher=enricher), client


def test_query_neptune_executes_with_server_side_cap_and_truncates():
    service, client = _service([{"id": 1}, {"id": 2}, {"id": 3}])

    result = service.query_neptune("g.V()", max_results=2)

    assert client.queries == ["g.V().limit(3)"]
    assert result == {
        "source": "neptune",
        "rows": [{"id": 1}, {"id": 2}],
        "row_count": 2,
        "truncated": True,
        "max_results": 2,
    }


def test_query_neptune_normalizes_non_json_graphson_values():
    marker = object()
    service, _ = _service([{"marker": marker, "items": {1, 2}}])

    result = service.query_neptune("g.V().limit(1)")

    assert result["rows"][0]["marker"] == str(marker)
    assert sorted(result["rows"][0]["items"]) == [1, 2]


@pytest.mark.parametrize(
    "query",
    [
        "g.V().drop()",
        "g.addV('Client')",
        "g.V(); g.E()",
        "g.V().map{ it.get() }",
        "g.V().repeat(out())",
    ],
)
def test_query_neptune_rejects_unsafe_traversals_before_execution(query):
    service, client = _service([])

    with pytest.raises((PermissionError, ValueError)):
        service.query_neptune(query)

    assert client.queries == []


def test_query_neptune_caps_max_results():
    service, client = _service([])

    result = service.query_neptune("g.E();", max_results=50_000)

    assert client.queries == ["g.E().limit(501)"]
    assert result["max_results"] == 500
