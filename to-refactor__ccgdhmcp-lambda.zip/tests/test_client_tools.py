"""Client-scoped MCP tools: manifest registration, verbatim query preservation,
domain-pack injection, client-scope hints, and handler routing."""

import pytest

import main as lh
from core import mcp_tools as mt
from domain.entities.query_result import QueryResult
from application.services.redshift_tool_service import RedshiftToolService

_CLIENT_TOOLS = ["getClientProducts", "getClientPolicies",
                 "getClientByDemographics", "getClientBySegment"]


# --------------------------------------------------------------------------- #
# Manifest / registry                                                         #
# --------------------------------------------------------------------------- #

def test_client_tools_registered_in_manifest():
    names = {t["name"] for t in mt.MCP_TOOLS}
    assert set(_CLIENT_TOOLS) <= names


def test_registry_maps_to_existing_service_methods():
    for tool, method in mt.CLIENT_TOOL_METHODS.items():
        assert tool in _CLIENT_TOOLS
        assert hasattr(RedshiftToolService, method)


def test_client_tool_schemas_require_query():
    for t in mt.MCP_TOOLS:
        if t["name"] in _CLIENT_TOOLS:
            assert t["inputSchema"]["required"] == ["query"]


# --------------------------------------------------------------------------- #
# Service behaviour                                                           #
# --------------------------------------------------------------------------- #

class FakeVectorStore:
    def search_tables_and_columns(self, query, table_count, column_count):
        return {"tables": [{
            "full_table_name": "c.client", "schema_name": "c", "table_name": "client",
            "column_names": ["client_id", "name"], "primary_key_columns": ["client_id"],
            "foreign_key_columns": [], "table_description": "", "_score": 0.1,
        }], "columns": []}


class FakeRedshift:
    def __init__(self):
        self.calls = []

    async def generate_sql(self, prompt, schema_context=None):
        self.calls.append((prompt, schema_context))
        return "SELECT client_id FROM c.client"

    def execute_query(self, sql):
        return {"rows": [{"client_id": 1}], "columns": ["client_id"], "total_rows": 1}


def _svc():
    rs = FakeRedshift()
    return rs, RedshiftToolService(redshift=rs, vector_store=FakeVectorStore(), graph_enricher=None)


@pytest.mark.asyncio
async def test_products_preserves_query_and_injects_pack_and_scope():
    rs, svc = _svc()
    q = "Show products owned by client John Smith"
    r = await svc.get_client_products(q, client_name="John Smith")
    prompt, sc = rs.calls[0]
    assert prompt == q                       # verbatim
    assert "CLIENT PRODUCTS" in sc           # domain pack
    assert "John Smith" in sc                # client-scope hint (not in query)
    assert "c.client" in sc                  # retrieval reached SQL
    assert r.row_count == 1


@pytest.mark.asyncio
async def test_policies_accepts_client_id():
    rs, svc = _svc()
    await svc.get_client_policies("Show policies for client John Smith", client_id="C123")
    _, sc = rs.calls[0]
    assert "CLIENT POLICIES" in sc
    assert "C123" in sc


@pytest.mark.asyncio
async def test_demographics_preserves_numeric_bounds_in_query():
    rs, svc = _svc()
    q = "Show clients between 45 and 60 with income above 250K"
    await svc.get_client_by_demographics(q)
    prompt, sc = rs.calls[0]
    assert prompt == q                       # bounds preserved verbatim
    assert "CLIENT DEMOGRAPHICS" in sc


@pytest.mark.asyncio
async def test_segment_injects_segment_pack():
    rs, svc = _svc()
    await svc.get_client_by_segment("Show affluent clients in California")
    _, sc = rs.calls[0]
    assert "CLIENT SEGMENT" in sc


@pytest.mark.asyncio
async def test_extra_unknown_kwargs_are_ignored():
    _, svc = _svc()
    # tolerance: unexpected keys from the gateway must not crash the tool
    r = await svc.get_client_by_segment("x", unexpected="ignored")
    assert r.row_count == 1


# --------------------------------------------------------------------------- #
# Handler routing (by explicit tool name)                                     #
# --------------------------------------------------------------------------- #

class RoutingService:
    def __init__(self):
        self.called = None

    async def _qr(self, tag):
        self.called = tag
        return QueryResult(answer=tag, sql_query="SELECT 1", rows=[{"a": 1}], columns=["a"])

    async def get_client_products(self, query, client_name=None, client_id=None, **_):
        return await self._qr(("products", query, client_name, client_id))

    async def get_client_by_segment(self, query, **_):
        return await self._qr(("segment", query))


@pytest.mark.asyncio
async def test_handler_routes_client_products_with_hints():
    svc = RoutingService()
    out = await lh._dispatch_named(svc, None, "getClientProducts",
                                   {"query": "products for John", "client_name": "John"})
    assert svc.called == ("products", "products for John", "John", None)
    assert out["row_count"] == 1


@pytest.mark.asyncio
async def test_handler_routes_segment():
    svc = RoutingService()
    out = await lh._dispatch_named(
        svc, None, "getClientBySegment", {"query": "affluent in CA"}
    )
    assert svc.called == ("segment", "affluent in CA")
    assert out["answer"] == ("segment", "affluent in CA")
