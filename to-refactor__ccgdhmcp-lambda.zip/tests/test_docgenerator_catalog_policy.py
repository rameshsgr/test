"""Document Generator catalog policy — scoping, fail-closed routing, content type.

The Document Generator asks the catalog one question: which document does this
Guided Action produce? Tab 42 "Guided Action Workspaces" holds the answer, and
these tests pin the three properties that make the answer trustworthy:

  * the traversal is scoped to an exact GA- id, never a whole-register scan,
  * the policy cannot fall through to another agent's query bundles,
  * the governed Content Type (VOC-071) comes back with the row.
"""
from __future__ import annotations

import pytest

from infrastructure.business_catalog import catalog_client as cc

_POLICY_KEY = "docgenerator-agent-v0"
_QUERY_ID = "DOCGENERATOR_GUIDED_ACTION_TEMPLATE_MAPPING"
_INTENT = "get_document_template"


@pytest.fixture
def policy():
    return cc._AGENT_POLICY_REGISTRY[_POLICY_KEY]


# ── Registration ─────────────────────────────────────────────────────────────

class TestRegistration:

    def test_policy_is_active(self, policy):
        assert policy["status"] == "active"

    def test_policy_resolves_from_the_agent_name(self):
        """A caller that sends only `agent` still lands on this policy."""
        assert cc._derive_policy_key_from_agent("docgenerator-agent") == _POLICY_KEY
        assert cc._derive_policy_key_from_agent("docgenerator") == _POLICY_KEY

    def test_query_is_registered_and_active(self):
        assert _QUERY_ID in cc._QUERY_LIBRARY
        assert cc._QUERY_METADATA[_QUERY_ID]["status"] == "active"

    def test_intent_is_in_the_global_map(self):
        """Needed so an intent named in task text survives _normalize_intent_token."""
        assert cc._INTENT_QUERY_MAP[_INTENT] == [_QUERY_ID]

    def test_query_is_real_gremlin_not_a_placeholder(self):
        query = cc._QUERY_LIBRARY[_QUERY_ID]
        assert query.startswith("g.V()"), "query is not a traversal"
        assert ".project(" in query


# ── Routing ──────────────────────────────────────────────────────────────────

class TestRouting:

    def test_intent_resolves_to_the_one_query(self, policy):
        assert cc._resolve_query_ids(_INTENT, "which template", None, 3, policy) == [_QUERY_ID]

    @pytest.mark.parametrize("intent", ["signals", "outcomes", "full_catalog", "unknown_op"])
    def test_another_agents_intent_is_denied(self, intent, policy):
        """Fail closed: a foreign intent must not borrow this policy."""
        assert cc._resolve_query_ids(intent, "all signals and insights", None, 3, policy) == []

    def test_unmapped_task_cannot_fall_back_to_insight_queries(self, policy):
        """No intent at all must not yield the global default bundle.

        _DEFAULT_QUERY_IDS is the two broad cross-chain traversals. Returning
        those here would hand the Document Generator insight-chain rows that look
        like a template answer.
        """
        resolved = cc._resolve_query_ids(
            None, "generate all the relevant documents and full catalog detail", None, 3, policy,
        )
        assert resolved == []

    def test_budget_is_one_template(self, policy):
        """One guided action resolves to one template; a wider budget only makes
        an unscoped result look plausible."""
        assert policy["limits"]["max_templates"] == 1

    def test_policy_is_restricted(self, policy):
        assert policy["restrict_to_policy_intents"] is True


# ── Scoping ──────────────────────────────────────────────────────────────────

class TestScoping:

    def test_policy_is_scope_enforced(self):
        """Unscoped, the traversal returns every action's template."""
        assert _POLICY_KEY in cc._SCOPE_ENFORCED_POLICY_KEYS

    def test_intent_declares_the_action_filter(self):
        assert cc._PLANNER_INTENT_FILTER_ALIASES[_INTENT] == ("action",)

    def test_action_filter_matches_the_property_the_graph_uses(self):
        """GuidedAction nodes carry the GA- id on `assetId`, not `guidedActionId`.

        Confirmed against the cluster in NEPTUNE_LOAD_SPEC_BUSINESS_PLANNER.md §1
        and mirrored by BIZPLANNER_PERSONA_ACTIONS, which reads it the same way.
        Without `assetId` here the predicate binds nothing and the scope gate
        silently passes on an unfiltered traversal.
        """
        _, properties = cc._PLANNER_FILTERS["action"]
        assert "assetId" in properties

    def test_query_carries_the_scope_marker(self):
        """_scope_planner_query injects the predicate at `.as('action')`."""
        assert ".as('action')" in cc._QUERY_LIBRARY[_QUERY_ID]

    def test_guided_action_id_is_pushed_into_the_traversal(self):
        scoped, applied, unapplied = cc._scope_planner_query(
            cc._QUERY_LIBRARY[_QUERY_ID], _INTENT,
            "Which document template applies to Guided Action GA-001?", None,
        )
        assert applied == ["action"]
        assert unapplied == []
        assert "GA-001" in scoped
        assert "assetId" in scoped

    def test_id_from_hints_is_accepted(self):
        scoped, applied, _ = cc._scope_planner_query(
            cc._QUERY_LIBRARY[_QUERY_ID], _INTENT,
            "which template applies", {"guided_action_id": "GA-007"},
        )
        assert applied == ["action"]
        assert "GA-007" in scoped

    def test_no_identifier_binds_no_filter(self):
        """This is what the scope gate turns into a denial."""
        _, applied, unapplied = cc._scope_planner_query(
            cc._QUERY_LIBRARY[_QUERY_ID], _INTENT, "which template applies", None,
        )
        assert applied == []
        assert unapplied == ["action"]

    def test_prose_is_never_treated_as_an_identifier(self):
        """Tab 42's descriptive column says "and other governed outreach Guided
        Actions". That must never behave as a wildcard."""
        _, applied, _ = cc._scope_planner_query(
            cc._QUERY_LIBRARY[_QUERY_ID], _INTENT,
            "the outreach guided actions and other governed outreach Guided Actions", None,
        )
        assert applied == []


# ── Content type (VOC-071) ───────────────────────────────────────────────────

class TestContentType:

    def test_every_catalogued_template_maps_to_a_content_type(self):
        """Tab 42 is complete at four rows; all four must resolve."""
        assert set(cc._CANONICAL_ID_TO_CONTENT_TYPE.values()) == {
            "STRATEGY_RECOMMENDATION",
            "STRATEGIC_REVIEW",
            "TALKING_POINTS",
            "MEETING_PREPARATION",
        }

    def test_content_type_is_filled_from_canonical_id(self):
        rows = cc._apply_content_type([
            {"canonicalId": "urn:gbs:workspace-template:engagement:outreach-talking-points"},
        ])
        assert rows[0]["contentType"] == "TALKING_POINTS"

    def test_canonical_id_match_is_case_insensitive(self):
        rows = cc._apply_content_type([
            {"canonicalId": "URN:GBS:Workspace-Template:Planning:Situation-Strategy"},
        ])
        assert rows[0]["contentType"] == "STRATEGY_RECOMMENDATION"

    def test_a_loaded_content_type_is_never_overwritten(self):
        """Post-load, the graph property is authoritative and the map must not shadow it."""
        rows = cc._apply_content_type([{
            "canonicalId": "urn:gbs:workspace-template:engagement:outreach-talking-points",
            "contentType": "SOMETHING_ELSE",
        }])
        assert rows[0]["contentType"] == "SOMETHING_ELSE"

    def test_unknown_canonical_id_stays_blank(self):
        """An unmapped template is a catalog gap the caller must see, not a guess."""
        rows = cc._apply_content_type([{"canonicalId": "urn:gbs:workspace-template:new:thing"}])
        assert rows[0].get("contentType", "") == ""

    def test_missing_canonical_id_is_survivable(self):
        assert cc._apply_content_type([{}])[0].get("contentType", "") == ""

    def test_non_dict_rows_are_ignored(self):
        assert cc._apply_content_type(["junk", None]) == ["junk", None]

    def test_query_projects_content_type(self):
        """So the map becomes redundant the moment the property is loaded."""
        assert "contentType" in cc._QUERY_LIBRARY[_QUERY_ID]
