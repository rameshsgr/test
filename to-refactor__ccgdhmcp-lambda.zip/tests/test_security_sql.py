"""Security: schema-introspection SQL must be parameterized (no string
interpolation of untrusted schema/table names)."""

from infrastructure.redshift.redshift_client import RedshiftClient


def _client(monkeypatch):
    c = RedshiftClient(host="h", database="d", user="u", password="p")
    captured = {}

    def fake_run_query(sql, params=None):
        captured["sql"] = sql
        captured["params"] = params
        return [], []

    monkeypatch.setattr(c, "_run_query", fake_run_query)
    return c, captured


def test_list_tables_is_parameterized(monkeypatch):
    c, captured = _client(monkeypatch)
    c._list_tables("ARD_CLIENT_POLICY")
    assert captured["params"] == ("ARD_CLIENT_POLICY",)
    assert "%s" in captured["sql"]
    assert "ARD_CLIENT_POLICY" not in captured["sql"]  # value not interpolated


def test_describe_table_is_parameterized(monkeypatch):
    c, captured = _client(monkeypatch)
    c._describe_table("opportunity", "ARD_SALES_OPPORTUNITY")
    assert captured["params"] == ("ARD_SALES_OPPORTUNITY", "opportunity")
    assert captured["sql"].count("%s") == 2
    assert "opportunity" not in captured["sql"]


def test_injection_payload_is_not_interpolated(monkeypatch):
    c, captured = _client(monkeypatch)
    evil = "x'; DROP TABLE users; --"
    c._describe_table("t", evil)
    # The payload travels as a bind param, never spliced into the SQL text.
    assert evil in captured["params"]
    assert "DROP TABLE" not in captured["sql"]
