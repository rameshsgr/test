"""Root-cause regression tests: AgentCore direct-call payloads using a
non-canonical argument key (observed in production as ``{"key1": "..."}``)
must be normalized to ``query`` and routed deterministically via
``infer_tool()`` — never silently defaulted to ``list_tables``.

See CloudWatch evidence: both
    "give me 5 records of AE book of business"
    "give me 5 records of client account name"
were mis-routed to list_tables (0 rows) because _dispatch_direct only
recognised the literal key "query", and the payload key was "key1".
"""

import pytest

import main as lh
from domain.entities.query_result import QueryResult


# --------------------------------------------------------------------------- #
# infer_tool() — deterministic intent classification                          #
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("query,expected", [
    ("give me 5 records of AE book of business", "book_of_business"),
    ("show my book of business revenue", "book_of_business"),
    ("show me my book", "book_of_business"),
    ("give me 5 records of client account name", "process_query"),
    ("what is the total premium for policy 123", "process_query"),
    ("show all tables", "list_tables"),
    ("list tables in ARD_CLIENT_POLICY", "list_tables"),
    ("what tables are available", "list_tables"),
    ("describe table customer", "describe_table"),
    ("what is the schema of orders", "describe_table"),
    ("", "process_query"),
    ("   ", "process_query"),
])
def test_infer_tool_routing(query, expected):
    assert lh.infer_tool(query) == expected


def test_process_query_is_the_default_not_list_tables():
    # Any text with no recognised intent must default to process_query.
    assert lh.infer_tool("some completely unrelated business question") == "process_query"
    assert lh.infer_tool("random gibberish xyz") == "process_query"


def test_list_tables_requires_explicit_match_never_a_fallback():
    # Mentioning "table" in passing (not a "show/list ... tables" request)
    # must NOT be routed to list_tables — it should fall through to the
    # process_query default.
    assert lh.infer_tool("what is in the account table for John Smith") == "process_query"


# --------------------------------------------------------------------------- #
# _extract_table_name()                                                       #
# --------------------------------------------------------------------------- #

def test_extract_table_name_variants():
    assert lh._extract_table_name("describe table customer") == "customer"
    assert lh._extract_table_name("columns of orders") == "orders"
    assert lh._extract_table_name("schema of ARD_CLIENT_POLICY.account") == "ARD_CLIENT_POLICY.account"
    assert lh._extract_table_name("give me 5 records of AE book of business") is None


# --------------------------------------------------------------------------- #
# _normalize_direct_event()                                                    #
# --------------------------------------------------------------------------- #

def test_normalize_key1_payload_to_query():
    assert lh._normalize_direct_event(
        {"key1": "give me 5 records of AE book of business"}
    ) == {"query": "give me 5 records of AE book of business"}


def test_normalize_leaves_canonical_keys_untouched():
    assert lh._normalize_direct_event({"query": "x"}) == {"query": "x"}
    assert lh._normalize_direct_event({"task": "define renewal risk"}) == {
        "task": "define renewal risk"
    }
    assert lh._normalize_direct_event({"sql": "SELECT 1"}) == {"sql": "SELECT 1"}
    assert lh._normalize_direct_event({"table_name": "t"}) == {"table_name": "t"}


def test_normalize_ambiguous_multi_string_payload_untouched():
    # More than one string value — cannot safely infer which is the query.
    event = {"key1": "a", "key2": "b"}
    assert lh._normalize_direct_event(event) == event


def test_normalize_empty_event_untouched():
    assert lh._normalize_direct_event({}) == {}


# --------------------------------------------------------------------------- #
# End-to-end: exact production payloads from the CloudWatch logs              #
# --------------------------------------------------------------------------- #

class FakeService:
    def __init__(self):
        self.calls = []

    async def process_query(self, query):
        self.calls.append(("process_query", query))
        return QueryResult(answer="pq", sql_query="SELECT 1", rows=[{"a": 1}], columns=["a"])

    async def process_book_of_business_query(self, query):
        self.calls.append(("book_of_business", query))
        return QueryResult(answer="bob", sql_query="SELECT 2", rows=[{"b": 2}], columns=["b"])

    def list_tables(self, schema_name=None):
        self.calls.append(("list_tables", schema_name))
        return {"rows": [], "columns": []}

    def describe_table(self, table_name, schema_name=None):
        self.calls.append(("describe_table", table_name, schema_name))
        return {"rows": [], "columns": []}


class FakeOrchestrator:
    def __init__(self, service):
        self._service = service

    async def handle_query(self, query):
        return await self._service.process_query(query)


@pytest.mark.asyncio
async def test_production_payload_ae_book_of_business_routes_to_bob():
    svc = FakeService()
    result = await lh._dispatch_direct(
        svc, FakeOrchestrator(svc), {"key1": "give me 5 records of AE book of business"}
    )
    assert svc.calls == [("book_of_business", "give me 5 records of AE book of business")]
    assert result["answer"] == "bob"


@pytest.mark.asyncio
async def test_production_payload_client_account_name_routes_to_process_query():
    # This is the exact second production example — previously mis-routed to
    # list_tables (0 rows returned). Must now go to process_query.
    svc = FakeService()
    result = await lh._dispatch_direct(
        svc, FakeOrchestrator(svc), {"key1": "give me 5 records of client account name"}
    )
    assert svc.calls == [("process_query", "give me 5 records of client account name")]
    assert result["answer"] == "pq"


@pytest.mark.asyncio
async def test_show_all_tables_still_routes_to_list_tables():
    svc = FakeService()
    await lh._dispatch_direct(svc, FakeOrchestrator(svc), {"key1": "show all tables"})
    assert svc.calls == [("list_tables", None)]


@pytest.mark.asyncio
async def test_describe_table_customer_routes_correctly():
    svc = FakeService()
    await lh._dispatch_direct(
        svc, FakeOrchestrator(svc), {"key1": "describe table customer"}
    )
    assert svc.calls == [("describe_table", "customer", None)]


@pytest.mark.asyncio
async def test_describe_intent_without_extractable_name_falls_back_to_pipeline():
    svc = FakeService()
    # "describe" present but no table name pattern matches -> process_query.
    await lh._dispatch_direct(
        svc,
        FakeOrchestrator(svc),
        {"key1": "please describe our book of business tables"},
    )
    # Book-of-business intent takes priority in this phrasing.
    assert svc.calls[0][0] == "book_of_business"


@pytest.mark.asyncio
async def test_canonical_query_key_path_still_works_unchanged():
    svc = FakeService()
    result = await lh._dispatch_direct(
        svc, FakeOrchestrator(svc), {"query": "plain question"}
    )
    assert svc.calls == [("process_query", "plain question")]
    assert result["sql_query"] == "SELECT 1"


@pytest.mark.asyncio
async def test_truly_empty_event_is_schema_probe_not_unrecognised_text():
    svc = FakeService()
    await lh._dispatch_direct(svc, FakeOrchestrator(svc), {})
    assert svc.calls == [("list_tables", None)]
