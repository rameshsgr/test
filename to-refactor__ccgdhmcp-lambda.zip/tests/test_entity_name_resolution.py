"""Entity-resolution / person-name matching fallback.

Root symptom: "Show the book of business for AE Andrew Landon ..." returns 0
rows even across two ILIKE attempts against plausible AE/owner columns. The
generic empty-result retry hint used for every other query type instructs the
LLM to "remove optional equality filters" -- for a query naming a SPECIFIC
PERSON, that would silently drop the named-entity filter and return an
over-broad, wrong-owner result set instead of an honest 0 rows, violating the
standing rule to preserve every user-named entity exactly.

These tests cover the person-name detection heuristic and the dedicated
name-matching relaxation hint that replaces the generic one whenever the
query names a person.
"""

from application.services.redshift_tool_service import RedshiftToolService as S

QUERY = (
    "Show the book of business for AE Andrew Landon including account number, "
    "account name, policy count, and product count"
)


def test_extracts_person_name_and_ignores_role_abbreviation():
    # "AE" must not be captured as part of the name (all-caps, no lowercase).
    assert S._extract_person_name(QUERY) == "Andrew Landon"


def test_no_person_name_in_non_person_query():
    assert S._extract_person_name("how many opportunities are open") is None
    assert S._extract_person_name("show all tables") is None


def test_attempt_zero_is_verbatim():
    assert S._build_generation_prompt(QUERY, 0) == QUERY


def test_attempt_one_never_instructs_dropping_the_named_filter():
    prompt = S._build_generation_prompt(QUERY, 1)
    assert "Andrew Landon" in prompt
    assert "Do NOT drop the 'Andrew Landon' filter" in prompt
    # The generic (filter-dropping) relaxation wording must NOT appear.
    assert "removing optional equality filters" not in prompt


def test_attempt_one_suggests_reversed_and_token_matching():
    prompt = S._build_generation_prompt(QUERY, 1)
    assert "ILIKE '%Andrew%Landon%'" in prompt
    assert "ILIKE '%Landon%Andrew%'" in prompt  # "Last, First" stored order
    assert "ILIKE '%Landon%' AND" in prompt      # both tokens, any order/columns


def test_attempt_two_reinforces_no_drop_and_checks_all_owner_columns():
    prompt = S._build_generation_prompt(QUERY, 2)
    assert "Andrew Landon" in prompt
    assert "EVERY candidate owner/executive/advisor/producer/manager" in prompt
    assert "silently returning every executive's book" in prompt


def test_non_person_query_still_gets_generic_relaxation():
    q = "how many opportunities are open"
    p1 = S._build_generation_prompt(q, 1)
    p2 = S._build_generation_prompt(q, 2)
    assert "removing optional equality filters" in p1
    assert "Remove all non-essential WHERE filters" in p2
    assert "Andrew Landon" not in p1 and "Andrew Landon" not in p2


def test_name_hint_handles_middle_names_by_using_first_and_last_token():
    hint = S._name_matching_relaxation_hint("Andrew James Landon")
    assert "ILIKE '%Andrew%Landon%'" in hint
    assert "ILIKE '%Landon%Andrew%'" in hint
