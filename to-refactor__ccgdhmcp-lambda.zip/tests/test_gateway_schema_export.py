"""The Gateway inline-schema exporter must stay in lock-step with MCP_TOOLS."""

from core.mcp_tools import MCP_TOOLS
from scripts.export_gateway_schema import build_inline_schema


def test_export_covers_every_tool():
    exported = build_inline_schema()
    assert [t["name"] for t in exported] == [t["name"] for t in MCP_TOOLS]


def test_every_exported_entry_is_well_formed():
    for t in build_inline_schema():
        assert set(t) == {"name", "description", "inputSchema"}
        schema = t["inputSchema"]
        assert schema["type"] == "object"
        assert isinstance(schema["properties"], dict)
        assert isinstance(schema["required"], list)
        for req in schema["required"]:
            assert req in schema["properties"]


def test_descriptions_preserved():
    exported = {t["name"]: t for t in build_inline_schema()}
    for src in MCP_TOOLS:
        assert exported[src["name"]]["description"] == src["description"]
