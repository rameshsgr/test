"""Bounded, value-free Neptune graph-schema discovery tests."""

import pytest

from application.services.redshift_tool_service import RedshiftToolService
from infrastructure.graph_ontology.neptune_enricher import NeptuneGraphOntologyEnricher


class FakeNeptuneClient:
    def __init__(self):
        self.queries = []

    def submit(self, query):
        self.queries.append(query)
        if query.startswith("g.V().label()"):
            return ["Client", "Product"]
        if query.startswith("g.E().label()"):
            return ["OWNS"]
        if "g.V().hasLabel('Client')" in query:
            return ["clientId", "clientName"]
        if "g.V().hasLabel('Product')" in query:
            return ["productId", "productName"]
        if "g.E().hasLabel('OWNS')" in query:
            return ["effectiveDate"]
        if "g.V().hasLabel('Client\\'Unsafe').limit(1).label()" in query:
            return ["Client'Unsafe"]
        if query.startswith("g.E().limit("):
            return [{"from": "Client", "edge": "OWNS", "to": "Product"}]
        raise AssertionError(f"Unexpected query: {query}")


def test_schema_discovery_returns_names_and_connections_only():
    client = FakeNeptuneClient()
    enricher = NeptuneGraphOntologyEnricher(client=client)

    result = enricher.get_schema()

    assert result["source"] == "neptune"
    assert result["complete"] is False
    assert result["sampled"] is True
    assert result["vertex_labels"] == ["Client", "Product"]
    assert result["edge_labels"] == ["OWNS"]
    assert result["vertex_properties"]["Client"] == ["clientId", "clientName"]
    assert result["edge_properties"]["OWNS"] == ["effectiveDate"]
    assert result["edge_connections"] == [
        {"from": "Client", "edge": "OWNS", "to": "Product"}
    ]
    assert all("valueMap" not in query and "values(" not in query for query in client.queries)


def test_requested_labels_are_escaped_and_server_limits_are_capped():
    client = FakeNeptuneClient()
    enricher = NeptuneGraphOntologyEnricher(client=client)

    result = enricher.get_schema(
        vertex_labels=["Client'Unsafe"],
        include_properties=False,
        include_edge_properties=False,
        max_labels=999,
        max_properties_per_label=999,
        sample_size=9999,
        max_connections=9999,
    )

    assert result["vertex_labels"] == ["Client'Unsafe"]
    assert result["vertex_properties"] == {}
    assert result["edge_properties"] == {}
    assert result["limits_applied"] == {
        "max_labels": 100,
        "max_properties_per_label": 200,
        "sample_size": 1000,
        "max_connections": 500,
    }
    assert any("hasLabel('Client\\'Unsafe')" in query for query in client.queries)


def test_service_reports_unavailable_neptune():
    service = RedshiftToolService(
        redshift=object(),
        vector_store=object(),
        graph_enricher=None,
    )

    with pytest.raises(RuntimeError, match="not configured or connected"):
        service.get_neptune_schema()