"""Shared test setup — ensure the repo root is importable."""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Guard: make sure the eager Lambda INIT path never runs during tests even if
# the runner inherits an AWS_LAMBDA_FUNCTION_NAME from the environment.
os.environ.pop("AWS_LAMBDA_FUNCTION_NAME", None)
