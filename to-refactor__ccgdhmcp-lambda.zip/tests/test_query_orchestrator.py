"""QueryOrchestrator — exactly-one-vector-search contract, routing, and the
ambiguity short-circuit (no RedshiftToolService call when ambiguous).

Uses fakes, not the real PgVectorGateway/RedshiftToolService, so these tests
run with no network/DB dependency.
"""

from types import SimpleNamespace

import pytest

from application.services.datasource_router import (
    AmbiguousDatasourceWarning,
    DatasourceRouter,
)
from application.services.query_orchestrator import QueryOrchestrator


class _FakeVectorStore:
    def __init__(self, tables):
        self._tables = tables
        self.call_count = 0

    def search_tables_and_columns(self, query, table_count=10, column_count=30):
        self.call_count += 1
        return {"tables": [{"schema_name": s} for s in self._tables], "columns": []}


class _FakeService:
    def __init__(self, name):
        self.name = name
        self.calls = []

    async def process_query(self, user_message, precomputed_vector_results=None):
        self.calls.append((user_message, precomputed_vector_results))
        return SimpleNamespace(answer=f"handled-by-{self.name}", rows=[], columns=[])


def _ds(schemas):
    return SimpleNamespace(schemas=tuple(schemas))


@pytest.fixture
def router():
    return DatasourceRouter(
        {
            "discovery": _ds(["ARD_CLIENT_POLICY"]),
            "gdh": _ds(["GDH_DL_BENEFITFLOW"]),
            "actuarial": _ds(["BOB"]),
        }
    )


@pytest.mark.asyncio
async def test_single_schema_routes_and_calls_correct_service(router):
    vector_store = _FakeVectorStore(["ARD_CLIENT_POLICY"])
    services = {"discovery": _FakeService("discovery"), "gdh": _FakeService("gdh")}
    orch = QueryOrchestrator(services=services, router=router, vector_store=vector_store)

    result = await orch.handle_query("show broker clients with active policies")

    assert result.answer == "handled-by-discovery"
    assert vector_store.call_count == 1
    assert len(services["discovery"].calls) == 1
    assert len(services["gdh"].calls) == 0
    # RedshiftToolService reused the SAME vector_results object — no re-search.
    _, passed_results = services["discovery"].calls[0]
    assert passed_results is not None


@pytest.mark.asyncio
async def test_conflicting_schemas_short_circuits_before_any_service_call(router):
    vector_store = _FakeVectorStore(["ARD_CLIENT_POLICY", "GDH_DL_BENEFITFLOW"])
    services = {"discovery": _FakeService("discovery"), "gdh": _FakeService("gdh")}
    orch = QueryOrchestrator(services=services, router=router, vector_store=vector_store)

    result = await orch.handle_query("some ambiguous query", intent="gdh")

    assert isinstance(result, AmbiguousDatasourceWarning)
    assert vector_store.call_count == 1  # still exactly one search, even when ambiguous
    assert len(services["discovery"].calls) == 0
    assert len(services["gdh"].calls) == 0


@pytest.mark.asyncio
async def test_router_selects_unregistered_datasource_fails_safely(router):
    # actuarial resolves from schema evidence but has no registered service
    # (e.g. Conjur credentials unavailable) -> must not silently fall back.
    vector_store = _FakeVectorStore(["BOB"])
    services = {"discovery": _FakeService("discovery")}  # actuarial missing
    orch = QueryOrchestrator(services=services, router=router, vector_store=vector_store)

    result = await orch.handle_query("actuarial book of business query")

    assert isinstance(result, AmbiguousDatasourceWarning)
    assert result.reason == "datasource_unavailable"
    assert len(services["discovery"].calls) == 0


@pytest.mark.asyncio
async def test_exactly_one_vector_search_regardless_of_outcome(router):
    for schemas in (["ARD_CLIENT_POLICY"], ["ARD_CLIENT_POLICY", "BOB"], []):
        vector_store = _FakeVectorStore(schemas)
        services = {"discovery": _FakeService("discovery"), "actuarial": _FakeService("actuarial")}
        orch = QueryOrchestrator(services=services, router=router, vector_store=vector_store)
        await orch.handle_query("query text")
        assert vector_store.call_count == 1
