"""Book-of-Business pipeline: user query preserved verbatim; domain guidance
injected into the SCHEMA CONTEXT passed to SQL generation (not the query)."""

import pytest

from application.services.redshift_tool_service import RedshiftToolService


class FakeVectorStore:
    def search_tables_and_columns(self, query, table_count, column_count):
        return {
            "tables": [{
                "full_table_name": "so.opportunity",
                "schema_name": "so", "table_name": "opportunity",
                "column_names": ["opp_id", "acct_id", "amount"],
                "primary_key_columns": ["opp_id"],
                "foreign_key_columns": ["acct_id"],
                "table_description": "", "_score": 0.1,
            }],
            "columns": [],
        }

    def search(self, query, top_k=5):
        return []


class FakeRedshift:
    def __init__(self):
        self.generate_calls = []

    async def generate_sql(self, prompt, schema_context=None):
        self.generate_calls.append({"prompt": prompt, "schema_context": schema_context})
        return "SELECT opp_id FROM so.opportunity"

    def execute_query(self, sql):
        return {"rows": [{"opp_id": 1}], "columns": ["opp_id"], "total_rows": 1}


@pytest.mark.asyncio
async def test_bob_preserves_query_and_injects_domain_context():
    rs = FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=FakeVectorStore(), graph_enricher=None)

    user_q = "show my book of business revenue for the Northeast territory in 2025"
    result = await svc.process_book_of_business_query(user_q)

    assert result.row_count == 1
    assert rs.generate_calls, "generate_sql should have been called"
    first = rs.generate_calls[0]

    # 1. The user's question is passed through verbatim (attempt 0 prompt == query).
    assert first["prompt"] == user_q

    # 2. Domain guidance is injected into the SCHEMA CONTEXT, not the query.
    assert "BOOK OF BUSINESS" in first["schema_context"]
    assert "Northeast" not in first["schema_context"]  # user scope not leaked into guidance
    # 3. Retrieved schema is still present in the context.
    assert "so.opportunity" in first["schema_context"]


@pytest.mark.asyncio
async def test_plain_query_has_no_domain_context():
    rs = FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=FakeVectorStore(), graph_enricher=None)
    await svc.process_query("how many opportunities are there")
    assert "BOOK OF BUSINESS" not in (rs.generate_calls[0]["schema_context"] or "")
