"""Regression tests: Book-of-Business retrieval returns multiple relevant
tables (client/policy/product golden-record views) but generated SQL only
referenced one of them (client_golden_record_mvw).

Root cause: PgVectorMetadataVectorStore.search_tables_and_columns() ranks
ALL columns across the ENTIRE dictionary in a single shared top-K pool. A
table whose own columns don't happen to score in that global top-K (e.g.
policy_golden_record_mvw / policy_product_mvw when client_golden_record_mvw's
columns dominate the pool for a "book of business" query) is still returned
as a table, but with a severely truncated (sometimes single-column) column
list. A table that looks nearly empty in the schema context reads as unusable
to the LLM, which drops it — and without any visible shared key, it has no
basis to attempt a join across it either.

Fix: per-table column backfill (_backfill_table_columns) guarantees every
selected table carries a fair column list, plus a shared-column join-key hint
in _build_schema_context, plus strengthened Book-of-Business instructions
that explicitly require using every retrieved table.
"""

import sys
import types

import pytest


def _stub(name):
    if name not in sys.modules:
        sys.modules[name] = types.ModuleType(name)


_stub("psycopg2")
_stub("psycopg2.extras")
_stub("psycopg2.extensions")
_stub("pgvector")
_stub("pgvector.psycopg2")
_stub("boto3")
sys.modules["psycopg2"].extensions = types.SimpleNamespace(connection=object)
sys.modules["pgvector.psycopg2"].register_vector = lambda conn: None

from infrastructure.vector_store.pgvector_store import PgVectorMetadataVectorStore
from application.services.redshift_tool_service import RedshiftToolService
from core.mcp_tools import BOOK_OF_BUSINESS_INSTRUCTIONS


def _rows(table, cols, score=0.2):
    return [
        {"tbl_catlg_nm": "", "tbl_schema_nm": "ard_client_policy", "tbl_nm": table,
         "colmn_nm": c, "_score": score}
        for c in cols
    ]


# A global similarity pool where client_golden_record_mvw's columns dominate,
# leaving the other two domain tables with just one column each — reproducing
# the exact production symptom.
_CLIENT_COLS = [
    "client_id", "client_account_name", "client_name", "client_dob",
    "client_addr", "client_phone", "client_email", "client_status",
]
_GLOBAL_POOL = (
    _rows("client_golden_record_mvw", _CLIENT_COLS, score=0.1)
    + _rows("policy_golden_record_mvw", ["policy_id"], score=0.3)
    + _rows("policy_product_mvw", ["policy_id"], score=0.3)
)

_TABLE_SCOPED = {
    "policy_golden_record_mvw": _rows("policy_golden_record_mvw", [
        "policy_id", "client_id", "policy_status", "policy_eff_dt",
        "policy_premium_amt", "policy_type", "policy_owner_cd", "book_of_business_cd",
    ], score=0.2),
    "policy_product_mvw": _rows("policy_product_mvw", [
        "policy_id", "product_cd", "product_name", "product_category",
        "product_line", "coverage_amt", "product_status",
    ], score=0.2),
}


class _FakeStore(PgVectorMetadataVectorStore):
    def __init__(self):
        pass

    def search(self, query, top_k=50, filter_dict=None):
        if filter_dict:
            return _TABLE_SCOPED.get(filter_dict.get("tbl_nm"), [])[:top_k]
        return _GLOBAL_POOL[:top_k]


# --------------------------------------------------------------------------- #
# 1. Vector-store fix: per-table column backfill                              #
# --------------------------------------------------------------------------- #

def test_all_three_tables_are_retrieved():
    result = _FakeStore().search_tables_and_columns(
        "give me 5 records of AE book of business", table_count=10, column_count=30,
    )
    names = {t["table_name"] for t in result["tables"]}
    assert names == {"client_golden_record_mvw", "policy_golden_record_mvw", "policy_product_mvw"}


def test_starved_tables_are_backfilled_with_usable_columns():
    result = _FakeStore().search_tables_and_columns(
        "give me 5 records of AE book of business", table_count=10, column_count=30,
    )
    by_name = {t["table_name"]: t for t in result["tables"]}
    # Before the fix these had exactly 1 column each (whatever survived the
    # shared global top-K) — now each carries a usable, fuller column list.
    assert len(by_name["policy_golden_record_mvw"]["column_names"]) >= 8
    assert len(by_name["policy_product_mvw"]["column_names"]) >= 6
    assert "policy_status" in by_name["policy_golden_record_mvw"]["column_names"]
    assert "product_category" in by_name["policy_product_mvw"]["column_names"]


def test_dominant_table_is_unaffected_by_backfill():
    result = _FakeStore().search_tables_and_columns(
        "give me 5 records of AE book of business", table_count=10, column_count=30,
    )
    client = next(t for t in result["tables"] if t["table_name"] == "client_golden_record_mvw")
    assert len(client["column_names"]) >= len(_CLIENT_COLS)  # no regression


def test_backfill_skipped_when_table_already_has_enough_columns():
    store = _FakeStore()
    calls = []
    orig = store.search

    def spy(query, top_k=50, filter_dict=None):
        calls.append(filter_dict)
        return orig(query, top_k=top_k, filter_dict=filter_dict)

    store.search = spy
    store.search_tables_and_columns("x", table_count=10, column_count=30, min_columns_per_table=1)
    # With a floor of 1, no table needs backfilling (each already has >= 1 column).
    assert all(c is None for c in calls)


# --------------------------------------------------------------------------- #
# 2. Schema-context fix: shared-column join hints + all tables surfaced       #
# --------------------------------------------------------------------------- #

class _VSAdapter:
    def search_tables_and_columns(self, query, table_count, column_count):
        return _FakeStore().search_tables_and_columns(query, table_count=table_count, column_count=column_count)


class _FakeRedshift:
    def __init__(self):
        self.schema_contexts = []

    async def generate_sql(self, prompt, schema_context=None):
        self.schema_contexts.append(schema_context)
        return "SELECT client_id FROM ard_client_policy.client_golden_record_mvw LIMIT 5"

    def execute_query(self, sql):
        return {"rows": [{"client_id": 1}], "columns": ["client_id"], "total_rows": 1}


@pytest.mark.asyncio
async def test_schema_context_includes_all_retrieved_tables():
    rs = _FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=_VSAdapter(), graph_enricher=None)
    await svc.process_book_of_business_query("give me 5 records of AE book of business")
    sc = rs.schema_contexts[0]
    assert "client_golden_record_mvw" in sc
    assert "policy_golden_record_mvw" in sc
    assert "policy_product_mvw" in sc


@pytest.mark.asyncio
async def test_schema_context_includes_shared_column_join_hints():
    rs = _FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=_VSAdapter(), graph_enricher=None)
    await svc.process_book_of_business_query("give me 5 records of AE book of business")
    sc = rs.schema_contexts[0]
    assert "Shared columns across retrieved tables" in sc
    assert "client_id" in sc  # shared: client_golden_record_mvw <-> policy_golden_record_mvw
    assert "policy_id" in sc  # shared: policy_golden_record_mvw <-> policy_product_mvw


@pytest.mark.asyncio
async def test_book_of_business_instructions_require_using_every_table():
    rs = _FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=_VSAdapter(), graph_enricher=None)
    await svc.process_book_of_business_query("give me 5 records of AE book of business")
    sc = rs.schema_contexts[0]
    assert "USE EVERY TABLE RETRIEVED" in sc
    assert "BOOK OF BUSINESS" in sc


def test_book_of_business_instructions_mention_multi_table_join_requirement():
    assert "MULTIPLE related tables" in BOOK_OF_BUSINESS_INSTRUCTIONS
    assert "USE EVERY TABLE RETRIEVED" in BOOK_OF_BUSINESS_INSTRUCTIONS


@pytest.mark.asyncio
async def test_no_shared_column_hint_when_only_one_table_retrieved():
    class _SingleTableStore:
        def search_tables_and_columns(self, query, table_count, column_count):
            return {"tables": [{
                "full_table_name": "ard_client_policy.client_golden_record_mvw",
                "schema_name": "ard_client_policy", "table_name": "client_golden_record_mvw",
                "column_names": ["client_id", "client_account_name"],
                "primary_key_columns": [], "foreign_key_columns": [],
                "table_description": "", "_score": 0.1,
            }], "columns": []}

    rs = _FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=_SingleTableStore(), graph_enricher=None)
    await svc.process_query("how many clients are there")
    sc = rs.schema_contexts[0]
    assert "Shared columns across retrieved tables" not in sc
