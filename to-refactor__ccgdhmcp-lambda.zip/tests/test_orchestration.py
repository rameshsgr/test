"""Vector -> Graph -> Merge -> SQL orchestration.

Confirms the graph enricher is invoked with the original user query and that
its output (joins, business-term map, extra tables) reaches the schema context
handed to SQL generation.
"""

import pytest

from application.services.redshift_tool_service import RedshiftToolService


class FakeVectorStore:
    def __init__(self):
        self.calls = []

    def search_tables_and_columns(self, query, table_count, column_count):
        self.calls.append(query)
        return {
            "tables": [{
                "full_table_name": "so.opportunity", "schema_name": "so",
                "table_name": "opportunity", "column_names": ["opp_id", "acct_id"],
                "primary_key_columns": ["opp_id"], "foreign_key_columns": ["acct_id"],
                "table_description": "", "_score": 0.1,
            }],
            "columns": [],
        }


class FakeGraph:
    def __init__(self):
        self.enrich_calls = []

    def enrich(self, ctx, user_query=""):
        self.enrich_calls.append(user_query)
        ctx["graph_context"] = {
            "suggested_joins": ["JOIN cp.account ON so.opportunity.acct_id = cp.account.acct_id"],
            "logical_name_map": {"acct_id": "Account ID"},
            "extra_tables": [{"full_name": "cp.account", "column_names": ["acct_id", "acct_nm"]}],
        }
        return ctx


class FakeRedshift:
    def __init__(self):
        self.schema_contexts = []

    async def generate_sql(self, prompt, schema_context=None):
        self.schema_contexts.append(schema_context)
        return "SELECT opp_id FROM so.opportunity"

    def execute_query(self, sql):
        return {"rows": [{"opp_id": 1}], "columns": ["opp_id"], "total_rows": 1}


@pytest.mark.asyncio
async def test_graph_enricher_invoked_with_original_query():
    g = FakeGraph()
    svc = RedshiftToolService(redshift=FakeRedshift(), vector_store=FakeVectorStore(), graph_enricher=g)
    await svc.get_metadata_context("accounts in the Northeast territory")
    assert g.enrich_calls == ["accounts in the Northeast territory"]


@pytest.mark.asyncio
async def test_graph_output_reaches_sql_generation():
    rs = FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=FakeVectorStore(), graph_enricher=FakeGraph())
    await svc.process_query("revenue by account for my book of business")
    sc = rs.schema_contexts[0]
    assert "JOIN cp.account" in sc          # verified joins
    assert "acct_id = Account ID" in sc      # business-term mapping
    assert "cp.account" in sc                # graph-discovered extra table merged


@pytest.mark.asyncio
async def test_vector_only_mode_still_works_without_graph():
    rs = FakeRedshift()
    svc = RedshiftToolService(redshift=rs, vector_store=FakeVectorStore(), graph_enricher=None)
    r = await svc.process_query("how many opportunities")
    assert r.row_count == 1
    sc = rs.schema_contexts[0]
    assert "so.opportunity" in sc
    assert "Graph-assisted inferred JOIN paths" not in sc
