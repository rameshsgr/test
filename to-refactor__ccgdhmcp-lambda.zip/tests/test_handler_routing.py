"""Fix 2 — the Lambda handler must route on the AgentCore-supplied tool name,
so tools that share an argument shape (get_metadata_context vs the pipeline,
both take only `query`) are dispatched unambiguously.

NOTE: the deployed Lambda entry point is ``main.py`` (handler ``main.handler``,
per build_lambda.ps1) — a prior ``lambda_handler.py`` module was renamed to
``main.py``; tests import ``main`` accordingly.
"""

import types
from unittest.mock import MagicMock, patch

import pytest

import main as lh
from domain.entities.query_result import QueryResult


# --------------------------------------------------------------------------- #
# Fake service                                                                #
# --------------------------------------------------------------------------- #

class FakeService:
    def __init__(self):
        self.calls = []

    async def process_query(self, query):
        self.calls.append(("process_query", query))
        return QueryResult(
            answer="ok", sql_query="SELECT 1", execution_time=0.1,
            confidence=0.9, rows=[{"a": 1}], columns=["a"],
        )

    async def process_book_of_business_query(self, query):
        self.calls.append(("book_of_business", query))
        return QueryResult(
            answer="bob", sql_query="SELECT 2", execution_time=0.2,
            confidence=0.8, rows=[{"b": 2}], columns=["b"],
        )

    def get_metadata_context(self, query):
        self.calls.append(("get_metadata_context", query))
        return {"relevant_tables": [], "relevant_columns": [], "_enricher": object()}

    def vector_search(self, query, top_k=5):
        self.calls.append(("vector_search", query, top_k))
        return [{"col": "x"}]

    def query_redshift(self, sql):
        self.calls.append(("query_redshift", sql))
        return {"rows": [], "columns": [], "total_rows": 0}


class FakeOrchestrator:
    def __init__(self, service):
        self._service = service

    async def handle_query(self, query):
        return await self._service.process_query(query)


def _ctx(custom):
    """Build a fake Lambda context with a client_context.custom dict."""
    cc = types.SimpleNamespace(custom=custom)
    return types.SimpleNamespace(client_context=cc)


# --------------------------------------------------------------------------- #
# _tool_name_from_context                                                     #
# --------------------------------------------------------------------------- #

def test_tool_name_extracted_and_prefix_stripped():
    ctx = _ctx({"bedrockAgentCoreToolName": "gdh-redshift-tools___get_metadata_context"})
    assert lh._tool_name_from_context(ctx) == "get_metadata_context"


def test_tool_name_without_prefix():
    ctx = _ctx({"toolName": "query_redshift"})
    assert lh._tool_name_from_context(ctx) == "query_redshift"


def test_tool_name_missing_returns_none():
    assert lh._tool_name_from_context(_ctx({})) is None
    assert lh._tool_name_from_context(types.SimpleNamespace()) is None
    assert lh._tool_name_from_context(None) is None


# --------------------------------------------------------------------------- #
# _dispatch_named — the key ambiguity fix                                     #
# --------------------------------------------------------------------------- #

@pytest.mark.asyncio
async def test_query_routes_to_metadata_context_when_named():
    svc = FakeService()
    # Same argument shape as the pipeline, but the explicit name disambiguates.
    result = await lh._dispatch_named(
        svc, FakeOrchestrator(svc), "get_metadata_context", {"query": "show accounts"}
    )
    assert svc.calls == [("get_metadata_context", "show accounts")]
    assert "_enricher" not in result  # internal ref stripped


@pytest.mark.asyncio
async def test_query_routes_to_pipeline_when_named():
    svc = FakeService()
    result = await lh._dispatch_named(
        svc, FakeOrchestrator(svc), "process_query", {"query": "revenue by account"}
    )
    assert svc.calls == [("process_query", "revenue by account")]
    assert result["answer"] == "ok"
    assert result["row_count"] == 1


@pytest.mark.asyncio
async def test_book_of_business_routes_by_name():
    svc = FakeService()
    result = await lh._dispatch_named(
        svc, FakeOrchestrator(svc), "book_of_business", {"query": "show my book"}
    )
    assert svc.calls == [("book_of_business", "show my book")]
    assert result["answer"] == "bob"
    assert result["sql_query"] == "SELECT 2"


@pytest.mark.asyncio
async def test_named_vector_search_passes_top_k():
    svc = FakeService()
    await lh._dispatch_named(
        svc, FakeOrchestrator(svc), "vector_search", {"query": "premium", "top_k": 3}
    )
    assert svc.calls == [("vector_search", "premium", 3)]


@pytest.mark.asyncio
async def test_business_catalog_forwards_explicit_planner_routing():
    catalog_client = MagicMock()
    catalog_client.fetch_catalog_context.return_value = {
        "execution": {"executed_query_ids": [], "row_counts": {}},
    }
    args = {
        "task": "getApplicablePlanPatterns for SIT-006",
        "intent": "get_applicable_plan_patterns",
        "agent": "business-planner-agent",
        "policy_key": "business-planner-v1",
        "hints": {"situation_type_id": "SIT-006"},
        "limits": {"max_templates": 1, "max_rows": 50},
    }

    with patch("api.app.get_catalog_client", return_value=catalog_client):
        await lh._dispatch_tool(FakeService(), "get_business_catalog_context", args)

    catalog_client.fetch_catalog_context.assert_called_once_with(
        query_text=args["task"],
        intent=args["intent"],
        hints=args["hints"],
        limits=args["limits"],
        agent=args["agent"],
        policy_key=args["policy_key"],
    )


# --------------------------------------------------------------------------- #
# _dispatch_direct — fallback (no tool name) preserves old behaviour          #
# --------------------------------------------------------------------------- #

@pytest.mark.asyncio
async def test_bare_query_falls_back_to_pipeline():
    svc = FakeService()
    result = await lh._dispatch_direct(svc, FakeOrchestrator(svc), {"query": "anything"})
    assert svc.calls[0][0] == "process_query"
    assert result["sql_query"] == "SELECT 1"


@pytest.mark.asyncio
async def test_sql_key_routes_to_query_redshift():
    svc = FakeService()
    await lh._dispatch_direct(svc, FakeOrchestrator(svc), {"sql": "SELECT 1"})
    assert svc.calls == [("query_redshift", "SELECT 1")]
