"""Business Planner catalog query and policy routing regressions."""
from __future__ import annotations

import json

import pytest

from core.mcp_tools import MCP_TOOLS
from infrastructure.business_catalog import catalog_client as cc


_EXPECTED_OPERATION_QUERIES = {
    "get_situation_type_definition": "SHEET_11E_SITUATION_TYPES_CONTEXT",
    "get_outcome_definitions": "SHEET_11C_OUTCOMES_CONTEXT",
    "get_applicable_plan_patterns": "BIZPLANNER_APPLICABLE_PLAN_PATTERNS",
    "get_plan_composition_rule": "BIZPLANNER_PLAN_COMPOSITION_RULE",
    "get_applicable_playbooks": "BIZPLANNER_APPLICABLE_PLAYBOOKS",
    "get_activity_patterns": "BIZPLANNER_ACTIVITY_PATTERNS",
    "get_action_governance": "BIZPLANNER_ACTION_GOVERNANCE",
    "get_persona_actions": "BIZPLANNER_PERSONA_ACTIONS",
    "get_plan_dependencies": "BIZPLANNER_PLAN_DEPENDENCIES",
    "get_existing_plan": "BIZPLANNER_EXISTING_PLAN",
    "get_material_changes": "BIZPLANNER_MATERIAL_CHANGES",
}


def test_business_planner_policy_is_strict_and_bounded():
    policy = cc._AGENT_POLICY_REGISTRY["business-planner-v1"]

    assert policy["agent"] == "business-planner-agent"
    assert policy["restrict_to_policy_intents"] is True
    assert policy.get("full_coverage") is not True
    assert policy["limits"]["max_templates"] == 3
    assert policy["limits"]["max_rows"] == 200
    assert policy["limits"]["max_response_bytes"] < 65536


@pytest.mark.parametrize("intent,query_id", _EXPECTED_OPERATION_QUERIES.items())
def test_each_planner_operation_resolves_to_one_allowlisted_query(intent, query_id):
    policy = cc._AGENT_POLICY_REGISTRY["business-planner-v1"]

    assert cc._resolve_query_ids(intent, "", None, 3, policy) == [query_id]
    assert query_id in cc._QUERY_LIBRARY


def test_broad_words_cannot_activate_full_catalog_for_planner():
    policy = cc._AGENT_POLICY_REGISTRY["business-planner-v1"]

    resolved = cc._resolve_query_ids(
        "get_applicable_plan_patterns",
        "getApplicablePlanPatterns: return all comprehensive details",
        None,
        3,
        policy,
    )

    assert resolved == ["BIZPLANNER_APPLICABLE_PLAN_PATTERNS"]
    assert not any(query_id.startswith("CROSS_") for query_id in resolved)


def test_explicit_planner_intent_cannot_add_another_planner_operation():
    policy = cc._AGENT_POLICY_REGISTRY["business-planner-v1"]

    resolved = cc._resolve_query_ids(
        "get_persona_actions",
        "getPersonaActions plus getActionGovernance and all comprehensive catalog details",
        None,
        3,
        policy,
    )

    assert resolved == ["BIZPLANNER_PERSONA_ACTIONS"]


@pytest.mark.parametrize("intent", ["signals", "full_catalog", "unknown_operation"])
def test_unmapped_explicit_intent_is_denied_for_planner(intent):
    policy = cc._AGENT_POLICY_REGISTRY["business-planner-v1"]

    assert cc._resolve_query_ids(intent, "all signals and insights", None, 3, policy) == []


def test_unmapped_planner_task_cannot_fall_back_to_insight_queries():
    policy = cc._AGENT_POLICY_REGISTRY["business-planner-v1"]

    resolved = cc._resolve_query_ids(
        None,
        "return all renewal signals, insights, evidence, and full catalog",
        None,
        3,
        policy,
    )

    assert resolved == []


def test_denied_planner_intent_executes_no_neptune_query(monkeypatch):
    def _unexpected_client():
        raise AssertionError("Neptune client must not be created for a denied intent")

    monkeypatch.setattr(cc, "_get_neptune_client", _unexpected_client)

    result = cc.fetch_catalog_context(
        "all renewal signals",
        intent="signals",
        agent="business-planner-agent",
        policy_key="business-planner-v1",
    )

    assert result["available"] is False
    assert result["reason"] == "no_queries_authorized"
    assert result["policy_key"] == "business-planner-v1"


def test_allowed_planner_intent_executes_only_its_mapped_query(monkeypatch):
    calls = []

    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            calls.append((gremlinQuery, serializer))
            return {"result": {"data": []}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    result = cc.fetch_catalog_context(
        "getPersonaActions for ACTP-001 plus getActionGovernance and all catalog details",
        intent="get_persona_actions",
        agent="business-planner-agent",
        policy_key="business-planner-v1",
    )

    assert result["available"] is True
    assert result["execution"]["executed_query_ids"] == ["BIZPLANNER_PERSONA_ACTIONS"]
    assert len(calls) == 1
    assert calls[0][0] == cc._with_row_limit(
        cc._scope_planner_query(
            cc._QUERY_LIBRARY["BIZPLANNER_PERSONA_ACTIONS"],
            "get_persona_actions",
            "getPersonaActions for ACTP-001 plus getActionGovernance and all catalog details",
            None,
        )[0],
        200,
    )


@pytest.mark.parametrize(
    ("requested_limit", "expected_limit"),
    [(None, 200), (1000, 200), (25, 25)],
)
def test_planner_catalog_never_retrieves_or_returns_above_row_cap(
    monkeypatch, requested_limit, expected_limit
):
    calls = []
    oversized_rows = [{"row_id": index} for index in range(250)]

    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            calls.append((gremlinQuery, serializer))
            return {"result": {"data": oversized_rows}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())
    limits = {"max_rows": requested_limit} if requested_limit is not None else None

    result = cc.fetch_catalog_context(
        "get persona actions for activity pattern ACTP-001",
        intent="get_persona_actions",
        agent="business-planner-agent",
        policy_key="business-planner-v1",
        limits=limits,
    )

    rows = result["results"]["BIZPLANNER_PERSONA_ACTIONS"]
    assert len(calls) == 1
    assert f".limit({expected_limit})" in calls[0][0]
    assert len(rows) == expected_limit
    assert len(result["context"]["rows"]) == expected_limit
    assert result["execution"]["row_limit"] == expected_limit
    assert result["execution"]["total_rows"] == expected_limit
    assert result["execution"]["row_counts"] == {
        "BIZPLANNER_PERSONA_ACTIONS": expected_limit
    }


def test_unknown_explicit_policy_is_denied(monkeypatch):
    def _unexpected_client():
        raise AssertionError("Neptune client must not be created for an unknown policy")

    monkeypatch.setattr(cc, "_get_neptune_client", _unexpected_client)

    result = cc.fetch_catalog_context("all catalog data", policy_key="missing-policy")

    assert result["available"] is False
    assert result["reason"] == "unknown_policy"


def test_planner_queries_are_bounded_reads():
    mutation_steps = ("addV(", "addE(", "drop(", "mergeV(", "mergeE(", "property(")

    for query_id in _EXPECTED_OPERATION_QUERIES.values():
        gremlin = cc._QUERY_LIBRARY[query_id]
        bounded_gremlin = cc._with_row_limit(gremlin, 200)
        assert gremlin.startswith("g.V()")
        assert ".limit(200)" in bounded_gremlin
        assert bounded_gremlin.count(".limit(200)") == 1
        assert not any(step in gremlin for step in mutation_steps)


def test_planner_limit_precedes_wide_projection():
    for query_id in _EXPECTED_OPERATION_QUERIES.values():
        bounded = cc._with_row_limit(cc._QUERY_LIBRARY[query_id], 200)
        projection_positions = [
            position for position in (bounded.find(".select("), bounded.find(".project("))
            if position >= 0
        ]

        assert projection_positions
        assert bounded.find(".limit(200)") < min(projection_positions)


@pytest.mark.parametrize(
    ("intent", "task", "expected_ids", "unexpected_id"),
    [
        ("get_situation_type_definition", "Situation Type SIT-006", ["SIT-006"], "SIT-007"),
        ("get_outcome_definitions", "Outcomes OUT-016, OUT-020", ["OUT-016", "OUT-020"], "OUT-023"),
        ("get_plan_composition_rule", "Plan Pattern PLANPAT-007", ["PLANPAT-007"], "PLANPAT-008"),
        ("get_activity_patterns", "Playbook PB-001", ["PB-001"], "PB-002"),
        ("get_action_governance", "Activities ACTP-001, ACTP-002", ["ACTP-001", "ACTP-002"], "ACTP-009"),
        # Persona is no longer a graph-level filter for this intent; only the
        # activity binds. See _PLANNER_INTENT_FILTER_ALIASES for why.
        ("get_persona_actions", "Activity ACTP-001 persona PER-001", ["ACTP-001"], "ACTP-002"),
    ],
)
def test_planner_pushes_exact_ids_into_neptune_query(
    monkeypatch, intent, task, expected_ids, unexpected_id
):
    calls = []

    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            calls.append(gremlinQuery)
            return {"result": {"data": []}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    cc.fetch_catalog_context(
        task,
        intent=intent,
        agent="business-planner-agent",
        policy_key="business-planner-v1",
    )

    assert len(calls) == 1
    assert all(identifier in calls[0] for identifier in expected_ids)
    assert unexpected_id not in calls[0]
    assert ".or(__.has(" in calls[0]


def test_non_planner_policy_does_not_receive_planner_id_filter(monkeypatch):
    calls = []

    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            calls.append(gremlinQuery)
            return {"result": {"data": []}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    cc.fetch_catalog_context(
        "signals for SIT-006",
        intent="signals",
        policy_key="default",
        limits={"max_templates": 1},
    )

    assert len(calls) == 1
    assert "SIT-006" not in calls[0]


def test_planner_response_has_hard_byte_budget(monkeypatch):
    oversized_rows = [{"row_id": index, "payload": "x" * 10000} for index in range(200)]

    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            return {"result": {"data": oversized_rows}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    result = cc.fetch_catalog_context(
        "get persona actions for ACTP-001",
        intent="get_persona_actions",
        agent="business-planner-agent",
        policy_key="business-planner-v1",
    )

    assert len(json.dumps(result, default=str).encode("utf-8")) <= cc._BUSINESS_PLANNER_MAX_RESPONSE_BYTES
    assert result["execution"]["stop_reason"] == "response_size_limit"
    assert result["context"]["truncated"] is True
    assert result["execution"]["total_rows"] < 200


# ---------------------------------------------------------------------------
# Scope gate — a planner ask that binds no filter must not run.
#
# Every BIZPLANNER_* traversal starts at an unfiltered g.V().hasLabel(...), so an
# unscoped ask returns the whole label rather than the governed answer. The two
# outcomes must never be indistinguishable to the planner.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("intent", "task"),
    [
        ("get_applicable_plan_patterns", "Which plan patterns apply to this renewal situation?"),
        ("get_persona_actions", "Guided action types for the account executive"),
        ("get_activity_patterns", "Activity patterns for the renewal playbook"),
        ("get_action_governance", "Adaptation boundaries for the validation activity"),
    ],
)
def test_planner_ask_without_governed_id_is_denied(monkeypatch, intent, task):
    def _unexpected_client():
        raise AssertionError("Neptune must not be queried for an unscoped planner ask")

    monkeypatch.setattr(cc, "_get_neptune_client", _unexpected_client)

    result = cc.fetch_catalog_context(
        task, intent=intent, agent="business-planner-agent", policy_key="business-planner-v1",
    )

    assert result["available"] is False
    assert result["reason"] == "scope_not_established"
    assert result["scope"]["scope_applied"] is False
    assert result["scope"]["unapplied_filters"]


def test_scoped_planner_ask_reports_which_filters_bound(monkeypatch):
    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            return {"result": {"data": []}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    result = cc.fetch_catalog_context(
        "Guided actions for activity ACTP-001",
        intent="get_persona_actions",
        agent="business-planner-agent",
        policy_key="business-planner-v1",
    )

    assert result["available"] is True
    # 'activity' bound; 'action' did not — the result is therefore broader than the
    # ask, and the caller has to be able to see that.
    assert result["scope"]["scope_applied"] is True
    assert result["scope"]["applied_filters"] == ["activity"]
    assert set(result["scope"]["unapplied_filters"]) == {"action"}


def test_non_planner_policy_has_no_scope_block(monkeypatch):
    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            return {"result": {"data": []}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    result = cc.fetch_catalog_context("signals for SIT-006", intent="signals", policy_key="default")

    assert result["available"] is True
    assert "scope" not in result


# ---------------------------------------------------------------------------
# Persona name hints — the planner carries persona names, not PER- ids.
# ---------------------------------------------------------------------------


def test_safe_persona_name_hint_is_accepted():
    """No intent currently binds the persona alias — BIZPLANNER_PERSONA_ACTIONS
    returns each action's personas as folded values instead of filtering on one,
    so the planner can tell "no action implements this activity" from "the action
    belongs to another persona". The name machinery is kept and tested because it
    is generic: the moment any intent lists an alias with a name filter, this is
    the code that runs, and its injection-safety property has to hold then."""
    assert cc._extract_planner_names("persona", {"persona_name": "Account Executive"}) == [
        "Account Executive"
    ]
    assert cc._extract_planner_names("persona", {"personaName": "Service Rep"}) == ["Service Rep"]


@pytest.mark.parametrize(
    "unsafe_name",
    [
        "Account' Executive",
        "AE'),__.has('x','y'))//",
        "Account\Executive",
        "Account (Executive)",
        "x" * 65,
        "",
    ],
)
def test_unsafe_persona_name_hint_is_rejected_not_escaped(unsafe_name):
    """Rejected, never escaped. This module's contract is zero injection surface,
    and an escaping bug is a silent breach of it."""
    assert cc._extract_planner_names("persona", {"persona_name": unsafe_name}) == []


def test_persona_name_is_never_read_from_free_text():
    """Names bind only from structured hint keys. Parsing them out of the task
    prose would make the whole task string an injection surface."""
    assert cc._extract_planner_names("persona", None) == []
    assert cc._extract_planner_names("persona", {"task": "persona Account Executive"}) == []


def test_persona_is_not_a_graph_level_filter_for_persona_actions():
    """Regression: filtering the traversal by persona collapsed two different
    answers into an empty result. ACTP-001's only action is GA-002, which requires
    ROLE-002 / PER-012 - asking as PER-001 returned nothing, which reads as "no
    governed action exists" rather than "not this persona's action". ROLE-005 and
    ROLE-007 also carry no RELATED_TO_PERSONA edge, so their actions vanished
    entirely."""
    assert "persona" not in cc._PLANNER_INTENT_FILTER_ALIASES["get_persona_actions"]
    query = cc._QUERY_LIBRARY["BIZPLANNER_PERSONA_ACTIONS"]
    assert "personaIds" in query
    assert "requiredRoleIds" in query


def test_persona_actions_joins_on_process_not_role():
    """The role join answered a different question: every action needing ROLE-001
    matched every activity assigned ROLE-001, so a renewal activity returned
    product-expansion and workforce actions. REFERENCES_PROCESS is the action
    bridge."""
    query = cc._QUERY_LIBRARY["BIZPLANNER_PERSONA_ACTIONS"]

    assert "REFERENCES_PROCESS" in query
    assert "ASSIGNED_TO_ROLE" not in query
    # Deduping on the action alone would collapse GA-001, which legitimately
    # serves ACTP-003, ACTP-005 and ACTP-006, into a single row.
    assert "dedup('activity','action')" in query
    # A wide projection is what exhausted the byte budget at five rows.
    assert "valueMap(true)" not in query


# ---------------------------------------------------------------------------
# Scoping coverage for the intents the original suite did not exercise.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("intent", "task", "expected_ids", "unexpected_id"),
    [
        ("get_applicable_plan_patterns", "Situation Type SIT-014", ["SIT-014"], "SIT-021"),
        ("get_applicable_playbooks", "Situation Type SIT-014", ["SIT-014"], "SIT-022"),
        ("get_existing_plan", "Situation Type SIT-014 pattern PLANPAT-007", ["SIT-014", "PLANPAT-007"], "PLANPAT-008"),
        ("get_plan_dependencies", "Plan Pattern PLANPAT-007", ["PLANPAT-007"], "PLANPAT-009"),
        ("get_material_changes", "Situation Type SIT-014 pattern PLANPAT-007", ["SIT-014"], "SIT-021"),
    ],
)
def test_remaining_planner_intents_push_exact_ids(
    monkeypatch, intent, task, expected_ids, unexpected_id
):
    calls = []

    class _Client:
        def execute_gremlin_query(self, *, gremlinQuery, serializer):
            calls.append(gremlinQuery)
            return {"result": {"data": []}}

    monkeypatch.setattr(cc, "_get_neptune_client", lambda: _Client())

    cc.fetch_catalog_context(
        task, intent=intent, agent="business-planner-agent", policy_key="business-planner-v1",
    )

    assert len(calls) == 1
    assert all(identifier in calls[0] for identifier in expected_ids)
    assert unexpected_id not in calls[0]
    assert ".or(__.has(" in calls[0]


def test_planner_agent_derives_planner_policy():
    assert cc._derive_policy_key_from_agent("business-planner-agent") == "business-planner-v1"


def test_catalog_tool_exposes_explicit_routing_fields():
    tool = next(t for t in MCP_TOOLS if t["name"] == "get_business_catalog_context")
    properties = tool["inputSchema"]["properties"]

    assert {"task", "intent", "agent", "policy_key", "hints", "limits"} <= properties.keys()
    assert tool["inputSchema"]["required"] == ["task"]
