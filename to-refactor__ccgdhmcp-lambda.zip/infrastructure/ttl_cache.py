"""Simple in-process TTL + bounded-size cache.

Thread-safe, zero-dependency.  Used across three layers of the pipeline:

  Layer                   | TTL     | Max entries
  ──────────────────────────────────────────────
  Vector search results   | 30 min  | 256
  Redshift schema (DDL)   | 15 min  | 64
  Generated SQL           | 15 min  | 128

Design notes
------------
* All reads and writes hold a ``threading.Lock`` so the cache is safe when
  multiple ``asyncio.to_thread`` workers run concurrently.
* Eviction on full cache: the entry with the **oldest insertion timestamp**
  is removed first (FIFO approximation — avoids the overhead of a full
  doubly-linked-list LRU and is good enough for these access patterns).
* Expired entries are evicted lazily on the next ``get()`` for that key.
* ``invalidate()`` with no argument clears everything (useful after a
  schema change or forced refresh endpoint call).
"""

from __future__ import annotations

import threading
import time
from typing import Any, Optional


class TTLCache:
    """In-process cache with per-entry TTL and a bounded maximum size."""

    def __init__(self, ttl_seconds: int, max_size: int = 256) -> None:
        self._ttl   = ttl_seconds
        self._max   = max_size
        # key → (value, inserted_at)  using monotonic clock so wall-clock
        # jumps (NTP / DST) do not cause surprise expiry.
        self._store: dict[str, tuple[Any, float]] = {}
        self._lock  = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, key: str) -> Optional[Any]:
        """Return the cached value or *None* if absent / expired."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, ts = entry
            if time.monotonic() - ts > self._ttl:
                del self._store[key]
                return None
            return value

    def set(self, key: str, value: Any) -> None:
        """Insert or refresh *key* → *value*.

        If the cache is already at capacity the oldest entry is evicted first.
        """
        with self._lock:
            if key in self._store:
                # Refresh in place (reset TTL)
                self._store[key] = (value, time.monotonic())
                return
            if len(self._store) >= self._max:
                oldest = min(self._store, key=lambda k: self._store[k][1])
                del self._store[oldest]
            self._store[key] = (value, time.monotonic())

    def invalidate(self, key: str | None = None) -> None:
        """Remove a single *key* or flush the entire cache when *key* is ``None``."""
        with self._lock:
            if key is None:
                self._store.clear()
            else:
                self._store.pop(key, None)

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)

    def __repr__(self) -> str:
        with self._lock:
            return (
                f"TTLCache(ttl={self._ttl}s, max={self._max}, "
                f"entries={len(self._store)})"
            )
