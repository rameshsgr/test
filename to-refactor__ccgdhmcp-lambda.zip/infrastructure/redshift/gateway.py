﻿"""Redshift gateway — adapts RedshiftMCPServer to the domain interface.

All domain calls are dispatched through RedshiftMCPServer, preserving the
MCP tool contract for both in-process use and standalone MCP stdio mode.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from infrastructure.redshift.mcp_server import RedshiftMCPServer
from core.config import settings, RedshiftConfig
from domain.interfaces.redshift_gateway import RedshiftGateway

logger = logging.getLogger(__name__)


class RedshiftMCPGateway(RedshiftGateway):
    """Domain gateway backed by RedshiftMCPServer.

    Routes all calls through MCP tool dispatch so the same server instance
    can also serve MCP clients over stdio without any code changes.
    """

    def __init__(self, server: RedshiftMCPServer) -> None:
        self._server = server

    @classmethod
    def create(cls, cfg: RedshiftConfig | None = None) -> "RedshiftMCPGateway":
        return cls(RedshiftMCPServer.create(cfg))

    # ------------------------------------------------------------------
    # RedshiftGateway implementation
    # ------------------------------------------------------------------

    def execute_query(self, sql: str) -> Dict[str, Any]:
        return self._server.execute_query(sql)

    async def generate_sql(self, prompt: str, schema_context: str | None = None) -> str:
        return await self._server.invoke_tool(
            "generate_sql",
            {"prompt": prompt, "schema_context": schema_context, "validate": True, "max_attempts": 3},
        )

    async def generate_gremlin(self, prompt: str, graph_context: str | None = None) -> str:
        return await self._server.invoke_tool(
            "generate_gremlin",
            {"prompt": prompt, "graph_context": graph_context},
        )

    def list_tables(self, schema: str) -> Dict[str, Any]:
        return self._server.list_tables(schema)

    def describe_table(self, table_name: str, schema: str) -> Dict[str, Any]:
        return self._server.describe_table(table_name, schema)

    @property
    def schema(self) -> str:
        return self._server.schema
