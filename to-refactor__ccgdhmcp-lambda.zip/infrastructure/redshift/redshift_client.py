"""Self-contained Redshift client — query execution + LLM-based SQL generation.

No dependency on any external legacy service folder.
Uses psycopg2 for direct Redshift connections and LangChain/Bedrock for SQL generation.
"""

from __future__ import annotations

import asyncio
import decimal
import hashlib
import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from infrastructure.ttl_cache import TTLCache

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LLM initialiser — always fresh credentials
# ---------------------------------------------------------------------------

def _initialize_llm():
    """Create a fresh ChatBedrock LLM using current environment credentials.

    All config is sourced from core.config.settings (which merged env vars +
    config.yaml).  Boto3 retry config: max 3 attempts, adaptive mode
    (exponential back-off with jitter on ThrottlingException /
    ServiceUnavailableException).
    """
    import os
    import boto3
    from botocore.config import Config
    from langchain_aws import ChatBedrock

    from core.config import settings

    region   = settings.aws.region or "us-east-1"
    model_id = settings.chat_model.model_id
    max_tok  = settings.chat_model.max_tokens
    temp     = settings.chat_model.temperature

    _retry_cfg = Config(
        retries={"max_attempts": 3, "mode": "adaptive"},
        connect_timeout=10,
        read_timeout=120,
    )

    bedrock_rt = boto3.client(
        "bedrock-runtime",
        region_name=region,
        # Honour configured TLS verification instead of hardcoding it off.
        # Set AWS_VERIFY_SSL=true in production to verify Bedrock endpoint certs.
        verify=settings.aws.verify_ssl,
        config=_retry_cfg,
    )
    llm = ChatBedrock(
        client=bedrock_rt,
        region_name=region,
        model=model_id,
        max_tokens=max_tok,
        temperature=temp,
    )
    logger.info("LLM initialized (model=%s, region=%s)", model_id, region)
    return llm


# ---------------------------------------------------------------------------
# SQL generation system prompt — loaded from prompts/sql_generation.txt
# ---------------------------------------------------------------------------

def _load_prompt(filename: str, fallback: str) -> str:
    """Load a generation system prompt from the prompts folder.

    Looks relative to the project root.
    Falls back to an inline minimal prompt so the service never fails to start.
    """
    prompt_path = Path(__file__).parent.parent.parent / "prompts" / filename
    try:
        text = prompt_path.read_text(encoding="utf-8").strip()
        logger.info("System prompt loaded from %s  (%d chars)", prompt_path, len(text))
        return text
    except FileNotFoundError:
        logger.warning(
            "%s not found — using inline fallback.", prompt_path
        )
        return fallback


_SYSTEM_PROMPT: str = _load_prompt(
    "sql_generation.txt",
    "You are a SQL-ONLY code generator for Amazon Redshift. Output only valid SQL. No explanations.",
)
_GREMLIN_SYSTEM_PROMPT: str = _load_prompt(
    "gremlin_generation.txt",
    "You generate read-only Amazon Neptune Gremlin traversals. Output only one traversal beginning with g.V() or g.E().",
)

# Replacement template shared by all rcd_expir_tp rewrite rules — extracted
# to satisfy the DRY principle (4 identical occurrences in _rewrite_known_bad_patterns).
_RCD_EXPIR_REPL: str = r"CAST(\g<1>rcd_expir_tp AS DATE) = '9999-12-31'"

# Matches a FROM/JOIN target with 3+ dot-separated parts, e.g.
# "gdh_spectrum.ard_client_policy.client_golden_record_mvw".  This connection
# is a direct psycopg2 connection to a single Redshift database ("discovery");
# objects are addressed as schema.table ONLY.  A catalog-qualified reference
# (catalog.schema.table) is therefore unconditionally invalid here — most
# commonly caused by a Glue/Spectrum catalog name (e.g. "gdh_spectrum")
# leaking into the retrieved schema context and being copied verbatim by the
# LLM.  Caught statically, before ever hitting Redshift.
_CATALOG_QUALIFIED_REF_RE = re.compile(
    r'\b(?:FROM|JOIN)\s+([A-Za-z_]\w*\.[A-Za-z_]\w*\.[A-Za-z_]\w*)',
    re.IGNORECASE,
)

# Sentinel returned when SQL generation cannot produce a schema-valid
# statement after exhausting all repair attempts.  NEVER return the last
# known-invalid SQL to the caller.
_SQL_GENERATION_FAILED = "-- ERROR: Unable to generate valid SQL"

# Detects the placeholder sentinel the LLM sometimes emits instead of a real
# query when it cannot find schema context.  This MUST be rejected before
# execution — it masks a generation failure as a successful (but meaningless)
# 1-row result.
_PLACEHOLDER_SQL_RE = re.compile(
    r'\bSELECT\s+(?:1|NULL)\s+AS\s+placeholder',
    re.IGNORECASE,
)

# Extracts schema.table references from FROM and JOIN clauses so they can be
# validated against the known tables supplied in the schema context.
_FROM_JOIN_TABLE_RE = re.compile(
    r'(?:FROM|JOIN)\s+([A-Za-z_]\w*\.[A-Za-z_]\w*)(?:\s+(?:AS\s+)?[A-Za-z_]\w*)?',
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Redshift client
# ---------------------------------------------------------------------------

class RedshiftClient:
    """Direct Redshift connection + LLM-based SQL generation.

    Replaces the legacy mcp_server_v2.RedshiftMCPServerV2 with a clean,
    self-contained implementation that has no MCP server scaffolding.
    """

    def __init__(
        self,
        host: str,
        database: str,
        user: str,
        password: str,
        port: int = 5439,
        schema: str = "public",
        ssl: bool = True,
        ssl_insecure: bool = False,
        timeout: int = 300,
        model_id: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ):
        self.host         = host
        self.database     = database
        self.user         = user
        self.password     = password
        self.port         = port
        self.schema       = schema
        self.ssl          = ssl
        self.ssl_insecure = ssl_insecure
        self.timeout      = timeout
        # ── Schema introspection cache (list_tables + describe_table) ─────────
        # DDL changes in production are planned, infrequent events.
        # TTL 15 min keeps the cache warm across consecutive agent calls
        # while ensuring a restart or expiry picks up any schema change.
        self._schema_cache: TTLCache = TTLCache(ttl_seconds=900, max_size=64)
        # ── SQL generation cache ──────────────────────────────────────────────
        # Keyed on sha256(prompt + schema_context).  Saves the 3–5 s Bedrock
        # LLM round-trip when the supervisor agent repeats the same question.
        self._sql_gen_cache: TTLCache = TTLCache(ttl_seconds=900, max_size=128)
        self._gremlin_gen_cache: TTLCache = TTLCache(ttl_seconds=900, max_size=128)
        logger.info("RedshiftClient configured → %s:%d/%s (schema=%s)", host, port, database, schema)

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def _get_connection(self):
        """Open a Redshift connection, retrying up to 3 times on OperationalError."""
        import psycopg2 as _psycopg2
        # Enforce TLS: psycopg2 defaults to 'prefer', which silently falls back
        # to an UNENCRYPTED connection if the server allows it.  Require SSL so
        # the traffic is always encrypted.  'verify-full' (cert verification) is
        # used only when a CA bundle is provisioned via PGSSLROOTCERT; otherwise
        # we fall back to 'require' (encrypted, no cert chain verification).
        import os as _os
        if not self.ssl:
            sslmode = "disable"
        elif not self.ssl_insecure and _os.getenv("PGSSLROOTCERT"):
            sslmode = "verify-full"
        else:
            sslmode = "require"
        last_exc: Exception = RuntimeError("unreachable")
        for attempt in range(3):
            try:
                return _psycopg2.connect(
                    host=self.host,
                    database=self.database,
                    user=self.user,
                    password=self.password,
                    port=self.port,
                    connect_timeout=self.timeout,
                    sslmode=sslmode,
                )
            except _psycopg2.OperationalError as exc:
                last_exc = exc
                if attempt < 2:
                    wait = 2 ** attempt  # 1s, 2s
                    logger.warning(
                        "Redshift connect attempt %d/3 failed (%s) — retrying in %ds",
                        attempt + 1, exc, wait,
                    )
                    time.sleep(wait)
        raise last_exc

    # ------------------------------------------------------------------
    # Core query runner
    # ------------------------------------------------------------------

    @staticmethod
    def _rollback_conn(conn) -> None:
        """Silently rollback a psycopg2 connection; swallow any error."""
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass

    @staticmethod
    def _close_conn(conn) -> None:
        """Silently close a psycopg2 connection; swallow any error."""
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    def _run_query(self, sql: str, params: Optional[tuple] = None) -> Tuple[List[Dict], List[str]]:
        """Execute SQL against Redshift with automatic retry on connection failures.

        Parameters
        ----------
        params:
            Optional bind parameters passed to ``cursor.execute(sql, params)``.
            Used to parameterise identifiers/values (e.g. schema introspection)
            so untrusted input is never string-interpolated into SQL.

        Retry policy
        ------------
        * ``psycopg2.OperationalError`` (network drop, server restart, SSL timeout)
          → up to 3 attempts with 1 s / 2 s exponential back-off.
        * All other exceptions (bad SQL, constraint violations, etc.)
          → propagated immediately without retry.
        * A fresh connection is opened and closed for every attempt.
        """
        import psycopg2 as _psycopg2
        for attempt in range(3):
            conn = None
            try:
                conn = self._get_connection()
                with conn.cursor() as cur:
                    cur.execute(sql, params) if params else cur.execute(sql)
                    if cur.description is None:
                        conn.commit()
                        return [], []
                    col_names = [d[0] for d in cur.description]
                    rows = cur.fetchall()
                return [dict(zip(col_names, row)) for row in rows], col_names
            except _psycopg2.OperationalError as exc:
                self._rollback_conn(conn)
                if attempt < 2:
                    wait = 2 ** attempt  # 1s, 2s
                    logger.warning(
                        "Redshift query attempt %d/3 failed (%s) — retrying in %ds",
                        attempt + 1, exc, wait,
                    )
                    time.sleep(wait)
                else:
                    raise
            except Exception:
                self._rollback_conn(conn)
                raise  # non-transient error (bad SQL etc.) — propagate immediately
            finally:
                self._close_conn(conn)
        raise RuntimeError("Exhausted Redshift query retries")

    # ------------------------------------------------------------------
    # Read-only guard — enforced at every SQL execution point
    # ------------------------------------------------------------------

    # Regex that matches any write / DDL keyword at the start of a statement
    # or after a semicolon (multi-statement injection).  Case-insensitive.
    _WRITE_PATTERN = re.compile(
        r'(^|;)\s*('
        r'INSERT|UPDATE|DELETE|MERGE|UPSERT|'
        r'CREATE|ALTER|DROP|TRUNCATE|RENAME|'
        r'GRANT|REVOKE|DENY|'
        r'EXECUTE|CALL|'
        r'COPY|UNLOAD|VACUUM|ANALYZE'
        r')\b',
        re.IGNORECASE | re.MULTILINE,
    )

    @classmethod
    def _guard_readonly_sql(cls, sql: str) -> None:
        """Raise ``PermissionError`` if *sql* contains any write or DDL statement.

        This is the last line of defence before any SQL reaches the Redshift
        connection.  It catches:
        - Direct write statements submitted via the ``query_redshift`` tool.
        - LLM hallucinations that bypass the prompt constraints.
        - Multi-statement injection attempts (semicolon-separated).
        """
        match = cls._WRITE_PATTERN.search(sql)
        if match:
            raise PermissionError(
                f"Read-only policy violation: statement contains forbidden keyword "
                f"'{match.group(2).upper()}'. Only SELECT and WITH (CTE) queries "
                f"are permitted against this database."
            )

    # ------------------------------------------------------------------
    # Public tool methods (same interface as legacy mcp_server_v2)
    # ------------------------------------------------------------------

    @staticmethod
    def _clean_decimal(v: Any) -> Any:
        """Convert ``decimal.Decimal`` to ``float`` for JSON serialisation."""
        return float(v) if isinstance(v, decimal.Decimal) else v

    def _retry_regexp_ilike_fix(self, sql: str) -> Optional[Dict[str, Any]]:
        """Rewrite REGEXP_ILIKE → REGEXP_COUNT and re-execute; return result or ``None``."""
        fixed_sql = self._rewrite_regexp_ilike(sql)
        if fixed_sql == sql:
            return None
        logger.warning("Auto-fixing REGEXP_ILIKE → REGEXP_COUNT and retrying")
        try:
            rows, col_names = self._run_query(fixed_sql)
            clean_rows = [{k: self._clean_decimal(v) for k, v in row.items()} for row in rows]
            return {"rows": clean_rows, "columns": col_names, "total_rows": len(clean_rows)}
        except Exception as exc2:
            logger.exception("Retry also failed: %s", exc2)
            return {"error": str(exc2), "rows": [], "columns": []}

    def _execute_query(self, sql: str, params: Optional[tuple] = None) -> Dict[str, Any]:
        self._guard_readonly_sql(sql)
        sql = self._rewrite_known_bad_patterns(sql)
        try:
            rows, col_names = self._run_query(sql, params)
            if not rows:
                return {"rows": [], "columns": col_names, "total_rows": 0}
            clean_rows = [{k: self._clean_decimal(v) for k, v in row.items()} for row in rows]
            return {"rows": clean_rows, "columns": col_names, "total_rows": len(clean_rows)}
        except Exception as exc:
            err_msg = str(exc)
            # Auto-fix: REGEXP_ILIKE does not exist in Redshift — rewrite to REGEXP_COUNT.
            if "regexp_ilike" in err_msg.lower() and "does not exist" in err_msg.lower():
                result = self._retry_regexp_ilike_fix(sql)
                if result is not None:
                    return result
            logger.exception("Query error: %s", exc)
            return {"error": err_msg, "rows": [], "columns": []}

    def _list_tables(self, schema: str = "public") -> Dict[str, Any]:
        _key = f"list:{schema}"
        _hit = self._schema_cache.get(_key)
        if _hit is not None:
            logger.debug("Schema cache HIT  list_tables(schema=%r)", schema)
            return _hit
        sql = """
            SELECT table_schema, table_name, table_type
            FROM   information_schema.tables
            WHERE  table_schema = %s
            ORDER  BY table_name
        """
        result = self._execute_query(sql, params=(schema,))
        self._schema_cache.set(_key, result)
        return result

    def _describe_table(self, table_name: str, schema: str = "public") -> Dict[str, Any]:
        _key = f"describe:{schema}.{table_name}"
        _hit = self._schema_cache.get(_key)
        if _hit is not None:
            logger.debug("Schema cache HIT  describe_table(%r, %r)", table_name, schema)
            return _hit
        sql = """
            SELECT column_name, data_type, character_maximum_length,
                   is_nullable, column_default
            FROM   information_schema.columns
            WHERE  table_schema = %s
              AND  table_name   = %s
            ORDER  BY ordinal_position
        """
        result = self._execute_query(sql, params=(schema, table_name))
        self._schema_cache.set(_key, result)
        return result

    async def _generate_sql_from_prompt(
        self,
        prompt: str,
        schema_context: Optional[str] = None,
        validate: bool = False,
        max_attempts: int = 2,
    ) -> str:
        """Generate SQL from natural language using LLM.

        The schema_context is built by the caller from the top-k results returned
        by PgVectorGateway (cosine search over existing embeddings in pgvector).
        This method only performs LLM generation — it reads nothing and writes nothing
        to pgvector or any other store.

        Caching
        -------
        Results are stored in an in-process TTL cache keyed on
        ``sha256(prompt + "|" + schema_context)``.  Same question from the
        supervisor agent within the TTL window → instant return, no Bedrock call.
        """
        # ── In-process SQL generation cache ──────────────────────────────────
        _cache_key = hashlib.sha256(
            f"{prompt}|{schema_context or ''}".encode()
        ).hexdigest()
        _hit = self._sql_gen_cache.get(_cache_key)
        if _hit is not None:
            logger.info("🎯 SQL gen cache HIT  key=%.12s…", _cache_key)
            return _hit

        # ── LLM generation ────────────────────────────────────────────────────
        system_prompt = _SYSTEM_PROMPT
        if schema_context:
            system_prompt += f"\n\n=== SCHEMA CONTEXT ===\n{schema_context}\n=== END SCHEMA ==="

        sql = await self._call_sql_model(system_prompt, prompt)
        logger.info("Generated SQL:\n%s", sql)

        # ── Schema-adherence check ─────────────────────────────────────────
        # If schema_context was supplied, verify that the generated SQL
        # actually references at least one of the known table names.
        # If it uses none of them (i.e. LLM hallucinated generic names),
        # force a strict retry with an explicit list of allowed tables.
        if schema_context:
            sql = await self._enforce_schema_adherence(
                sql, prompt, schema_context, system_prompt
            )

        # ── Hard schema validation loop ─────────────────────────────────────
        # Always runs the cheap static catalog-qualification check (no DB
        # round-trip) regardless of `validate` — a catalog-qualified reference
        # is unconditionally wrong for this connection, so there is never a
        # reason to skip that check.  The EXPLAIN-based live check only runs
        # when `validate=True`.  At least one repair attempt is always allowed
        # so a caught violation gets a chance to be corrected.
        _valid_starts = ("SELECT", "WITH")
        attempts_to_run = max(int(max_attempts), 2)
        last_error = ""
        ok = False

        for attempt in range(attempts_to_run):
            # Structured error from the LLM (-- ERROR: ...) is a terminal signal -
            # the model confirmed it cannot generate valid SQL for this request
            # given the retrieved schema.  Propagate immediately without retrying
            # so the caller's -- ERROR handler surfaces a clean business error
            # instead of exhausting retries with hallucinated SQL.
            if sql.lstrip().startswith("-- ERROR"):
                logger.info(
                    "LLM returned structured error - propagating without retry: %s",
                    sql[:300],
                )
                self._sql_gen_cache.set(_cache_key, sql)
                return sql

            is_sql = any(sql.upper().lstrip().startswith(s) for s in _valid_starts)
            if not is_sql:
                ok, err = False, "LLM returned a non-SELECT response. Only SELECT or WITH (CTE) statements are allowed."
            else:
                ok, err = self._check_static_schema(sql)
                if ok and validate:
                    ok, err = self._validate_sql(sql)

            if ok:
                logger.info("Corrected SQL:\n%s", sql)
                self._sql_gen_cache.set(_cache_key, sql)
                return sql

            last_error = err
            logger.warning("Validation errors (attempt %d): %s", attempt + 1, err)

            if attempt < attempts_to_run - 1:
                sql = await self._revise_sql(prompt, schema_context, sql, err)
                logger.info("Corrected SQL (retry %d):\n%s", attempt + 2, sql)

        # Exhausted all attempts without a schema-valid result.  NEVER return
        # the last known-invalid SQL — return the failure sentinel instead,
        # and do NOT cache it (so the next identical request retries fresh
        # rather than replaying a cached failure forever).
        logger.error(
            "Unable to produce valid SQL after %d attempt(s). Last validation error: %s",
            attempts_to_run, last_error,
        )
        return _SQL_GENERATION_FAILED

    async def _generate_gremlin_from_prompt(
        self,
        prompt: str,
        graph_context: Optional[str] = None,
    ) -> str:
        """Generate, but never execute, one read-only Neptune traversal."""
        cache_key = hashlib.sha256(
            f"{prompt}|{graph_context or ''}".encode()
        ).hexdigest()
        cached = self._gremlin_gen_cache.get(cache_key)
        if cached is not None:
            logger.info("Gremlin gen cache HIT key=%.12s…", cache_key)
            return cached

        system_prompt = _GREMLIN_SYSTEM_PROMPT
        if graph_context:
            system_prompt += (
                f"\n\n=== GRAPH CONTEXT ===\n{graph_context}\n=== END GRAPH CONTEXT ==="
            )

        llm = _initialize_llm()
        response = await asyncio.to_thread(llm.invoke, [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ])
        raw = response.content.strip() if hasattr(response, "content") else str(response).strip()
        gremlin = self._clean_gremlin(raw)
        if gremlin.startswith("-- ERROR:"):
            logger.info("Gremlin generation returned a structured error: %s", gremlin)
            return gremlin
        self._guard_readonly_gremlin(gremlin)
        self._gremlin_gen_cache.set(cache_key, gremlin)
        logger.info("Generated read-only Gremlin traversal: %s", gremlin)
        return gremlin

    @staticmethod
    def _clean_gremlin(text: str) -> str:
        """Remove optional Markdown fencing without rewriting the traversal."""
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:gremlin|groovy)?\s*", "", cleaned, flags=re.IGNORECASE)
            cleaned = re.sub(r"\s*```$", "", cleaned)
        return cleaned.strip()

    @staticmethod
    def _guard_readonly_gremlin(gremlin: str) -> None:
        """Reject non-traversal, multi-statement, mutating, or scripted Gremlin."""
        query = gremlin.strip()
        if not query or len(query) > 10_000:
            raise ValueError("Gremlin traversal must contain between 1 and 10000 characters")
        if not re.match(r"^g\s*\.\s*[VE]\s*\(\s*\)", query):
            raise ValueError("Gremlin must begin with g.V() or g.E()")

        without_trailing_semicolon = query[:-1].rstrip() if query.endswith(";") else query
        if ";" in without_trailing_semicolon:
            raise PermissionError("Multiple Gremlin statements are not permitted")

        # Remove quoted values before checking step names so a property value
        # such as "drop" cannot trigger a false positive.
        unquoted = re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"", "''", query)
        if "{" in unquoted or "}" in unquoted:
            raise PermissionError("Gremlin closures and inline scripts are not permitted")
        forbidden_steps = (
            "addV", "addE", "property", "drop", "mergeV", "mergeE",
            "sideEffect", "io", "call", "iterate", "program", "profile",
            "repeat", "emit", "until",
        )
        mutation = re.search(
            r"\.\s*(" + "|".join(forbidden_steps) + r")\s*\(",
            unquoted,
            flags=re.IGNORECASE,
        )
        if mutation:
            raise PermissionError(
                f"Gremlin contains forbidden mutation step: {mutation.group(1)}"
            )


    async def _enforce_schema_adherence(
        self,
        sql: str,
        prompt: str,
        schema_context: str,
        system_prompt: str,
    ) -> str:
        """Re-generate SQL if the LLM ignored the schema context.

        Structured error responses (-- ERROR: ...) are returned unchanged -
        they are intentional signals from the model and must not be treated
        as schema-adherence failures.
        """
        # LLM issued a structured error - skip adherence check and propagate.
        if sql.lstrip().startswith("-- ERROR"):
            return sql

        # Parse all "schema.table" names from the schema context block
        known_tables = re.findall(
            r'\b([\w]+\.[\w]+)\b',
            schema_context,
            flags=re.IGNORECASE,
        )
        # Keep only entries that look like real schema-qualified names
        # (two-part names where neither part is a single keyword)
        _skip = {"data_type", "varchar", "timestamp", "integer", "numeric",
                 "bigint", "boolean", "date", "float", "text", "char"}
        known_tables = [
            t for t in known_tables
            if t.lower() not in _skip
            and not any(p.lower() in _skip for p in t.split('.'))
        ]
        unique_tables = list(dict.fromkeys(t.lower() for t in known_tables))

        if not unique_tables:
            return sql  # nothing to validate against

        sql_upper = sql.upper()
        uses_known = any(t.upper() in sql_upper for t in unique_tables)

        if uses_known:
            # Even when at least one known table is used, check that no
            # FROM/JOIN target is a table INVENTED outside the schema context
            # (e.g. the LLM joins ard_client_policy.client_golden_record_mvw
            # against an invented "ard_sales_opportunity.enrollments" that
            # does not exist).  Extract all FROM/JOIN targets, compare against
            # the known-table set, and force a retry if any unknown table is found.
            sql_tables = {t.lower() for t in _FROM_JOIN_TABLE_RE.findall(sql)}
            unknown_tables = sql_tables - set(unique_tables)
            # Strip any catalog prefix that survived into sql_tables before comparing
            unknown_tables = {
                t for t in unknown_tables
                if not any(t.endswith('.' + kt.split('.')[-1]) for kt in unique_tables)
            }
            if unknown_tables:
                invented = sorted(unknown_tables)
                logger.warning(
                    "⚠️  Generated SQL references invented table(s) not in schema context: %s"
                    " — forcing invention-rejection retry.",
                    invented,
                )
                strict_prompt = (
                    f"CRITICAL: The SQL you generated references table(s) that DO NOT EXIST "
                    f"in the schema context: {invented}.\n"
                    f"You MUST use ONLY the following tables:\n"
                    f"{chr(10).join('  - ' + t for t in unique_tables[:30])}\n\n"
                    f"Original request: {prompt}\n\n"
                    f"Rewrite the SQL using ONLY the listed tables. "
                    f"If you need a metric that does not appear, use the closest "
                    f"existing numeric column or respond with -- ERROR: <reason>."
                )
                retried_sql = await self._call_sql_model(system_prompt, strict_prompt)
                logger.info("🔁 Invention-rejection retry SQL:\n%s", retried_sql.strip()[:300])
                return retried_sql
            return sql  # SQL looks correct

        # LLM ignored the schema context — force a strict retry
        table_list = "\n".join(f"  - {t}" for t in unique_tables[:30])
        logger.warning(
            "⚠️  Generated SQL uses NO known table names — forcing schema-adherence retry.\n"
            "   Known tables: %s\n"
            "   Generated SQL: %s",
            unique_tables[:10], sql[:300],
        )
        strict_prompt = (
            f"CRITICAL: The SQL you generated used table names that DO NOT EXIST in this database.\n"
            f"You MUST use ONLY the following exact table names (schema.table format):\n"
            f"{table_list}\n\n"
            f"Original request: {prompt}\n\n"
            f"Rewrite the SQL using ONLY the table names listed above. "
            f"Copy the table names character-for-character — do not shorten, rename, or invent."
        )
        retried_sql = await self._call_sql_model(system_prompt, strict_prompt)
        logger.info("🔁 Schema-adherence retry SQL:\n%s", retried_sql.strip()[:200])
        return retried_sql

    def _check_static_schema(self, sql: str) -> Tuple[bool, str]:
        """Reject SQL that contains a catalog-qualified identifier or a
        placeholder sentinel.

        Runs statically (no DB round-trip):
        1. Placeholder sentinels (SELECT 1 AS placeholder_*) mask generation
           failures as successful results - always rejected.
        2. Catalog-qualified references (catalog.schema.table) are invalid for
           this direct psycopg2 connection.
        """
        # Check 1: placeholder sentinel
        if _PLACEHOLDER_SQL_RE.search(sql):
            return False, (
                'SQL contains the forbidden placeholder sentinel '
                '"SELECT 1/NULL AS placeholder_...". '
                'This is not a valid result - respond with -- ERROR: <reason> instead.'
            )
        # Check 2: catalog-qualified reference
        bad_refs = _CATALOG_QUALIFIED_REF_RE.findall(sql)
        if not bad_refs:
            return True, ""
        unique = list(dict.fromkeys(bad_refs))
        example = unique[0]
        corrected = example.split(".", 1)[1]  # drop the leading catalog segment
        return False, (
            f'"{example.split(".")[0]}" does not exist — catalog-qualified reference(s) '
            f"{unique} are not valid. This connection only supports schema.table "
            f"addressing (no catalog prefix). Remove the leading catalog segment "
            f"(use '{corrected}' instead of '{example}')."
        )

    async def _call_sql_model(self, system_prompt: str, user_prompt: str) -> str:
        """Call the LLM without blocking the event loop.

        ``llm.invoke()`` is a synchronous blocking network call (HTTP to Bedrock).
        Running it via ``asyncio.to_thread`` offloads it to the default thread-pool
        so the FastAPI event loop stays responsive to other requests while the
        Bedrock round-trip (~2–5 s) is in flight.

        Bedrock throttling / transient errors are already handled at the boto3
        level via ``retries={"max_attempts": 3, "mode": "adaptive"}``.
        """
        llm = _initialize_llm()
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ]
        response = await asyncio.to_thread(llm.invoke, messages)
        sql = response.content.strip() if hasattr(response, "content") else str(response).strip()
        sql = self._clean_sql(sql)

        valid_starts = ("SELECT", "WITH")
        if not any(sql.upper().lstrip().startswith(s) for s in valid_starts):
            # Structured error from the LLM (-- ERROR: ...) is intentional -
            # the model confirmed it cannot answer this request from the
            # retrieved schema.  Propagate it directly without a recovery
            # retry so the caller's -- ERROR handler surfaces a clean
            # business error instead of hallucinating invented tables/columns.
            if sql.lstrip().startswith("-- ERROR"):
                logger.info(
                    "[SQL-GEN] LLM issued structured error - propagating without recovery:\n%s", sql
                )
                return sql
            logger.warning("[SQL-GEN] LLM returned non-SELECT response:\n%s", sql)
            recovery = (
                f"Output ONLY a SELECT statement — no comments, no explanations.\n"
                f"This service is READ-ONLY. Write operations (INSERT/UPDATE/DELETE/CREATE etc.) are forbidden.\n"
                f"Original request: {user_prompt}\nUse tables from the schema context."
            )
            response2 = await asyncio.to_thread(llm.invoke, [
                {"role": "system", "content": "You are a read-only Redshift SQL analyst. Output ONLY a SELECT or WITH (CTE) statement. No comments. No write operations."},
                {"role": "user",   "content": recovery},
            ])
            sql = self._clean_sql(
                response2.content.strip() if hasattr(response2, "content") else str(response2).strip()
            )
        return sql

    # Ordered (label, pattern) checks for targeted revision hints — first
    # match wins. Identifier-shaped errors (column/relation/catalog "does not
    # exist") are checked before generic type-coercion errors so a specific
    # bad identifier is never masked by a vaguer type-mismatch message.
    _REVISION_HINT_RULES: Tuple[Tuple[str, "re.Pattern"], ...] = (
        ("unknown_column", re.compile(r'column\s+"?([^\s"]+)"?\s+does not exist', re.IGNORECASE)),
        ("unknown_relation", re.compile(r'relation\s+"?([^\s"]+)"?\s+does not exist', re.IGNORECASE)),
        ("unknown_identifier", re.compile(r'"([^"]+)"\s+does not exist', re.IGNORECASE)),
        ("integer_coercion", re.compile(r'invalid input syntax for integer', re.IGNORECASE)),
        ("numeric_coercion", re.compile(r'invalid input syntax for (?:type )?(numeric|bigint|decimal)', re.IGNORECASE)),
        ("cannot_cast", re.compile(r'cannot cast type', re.IGNORECASE)),
        ("operator_mismatch", re.compile(r'operator does not exist', re.IGNORECASE)),
        ("type_mismatch", re.compile(r'type mismatch', re.IGNORECASE)),
    )

    @classmethod
    def _build_revision_hint(cls, error: str) -> Tuple[str, str]:
        """Return (label, hint_text) for the first matching error pattern.

        ``label`` is a short machine-readable tag for diagnostic logging
        (e.g. "integer_coercion") — ``""`` if no rule matched.
        """
        for label, pattern in cls._REVISION_HINT_RULES:
            match = pattern.search(error)
            if not match:
                continue

            if label == "unknown_column":
                return label, f"\nThe column '{match.group(1)}' does NOT exist — choose a real column from SCHEMA CONTEXT.\n"
            if label == "unknown_relation":
                return label, f"\nThe table/relation '{match.group(1)}' does NOT exist — use ONLY tables listed in SCHEMA CONTEXT.\n"
            if label == "unknown_identifier":
                return label, (
                    f"\nThe identifier '{match.group(1)}' does NOT exist. This is almost always "
                    f"a catalog/database prefix (e.g. 'gdh_spectrum') mistakenly prepended to a "
                    f"table reference. REMOVE it — this connection only supports schema.table "
                    f"references, NEVER catalog.schema.table.\n"
                )
            if label in ("integer_coercion", "numeric_coercion"):
                return label, (
                    f"\nA numeric column was combined with a string default in a way Redshift "
                    f"cannot type-coerce (error: {error}).\n"
                    f"This is almost always COALESCE(numeric_col, '') or CAST(COALESCE(numeric_col, "
                    f"'') AS VARCHAR) — Redshift tries to parse '' AS the column's numeric type and "
                    f"fails.\n"
                    f"Fix: cast the column to VARCHAR FIRST, then COALESCE with the string default:\n"
                    f"  Use:      COALESCE(CAST(col AS VARCHAR), '')\n"
                    f"  NOT:      CAST(COALESCE(col, '') AS VARCHAR)\n"
                    f"  NOT:      COALESCE(col, '')\n"
                    f"Check the SCHEMA CONTEXT column type annotations (e.g. \"col (INTEGER)\") "
                    f"to identify every numeric column before applying COALESCE with a string.\n"
                )
            if label == "cannot_cast":
                return label, (
                    f"\nAn explicit CAST between incompatible types was attempted (error: {error}).\n"
                    f"Check the SCHEMA CONTEXT column type annotations for the actual type and cast "
                    f"through an intermediate compatible type if needed (e.g. numeric → VARCHAR → DATE "
                    f"is invalid; cast numeric → DATE directly only if the column truly stores an "
                    f"epoch/serial date value).\n"
                )
            if label == "operator_mismatch":
                return label, (
                    f"\nAn operator was applied between two incompatible types (error: {error}).\n"
                    f"Check the SCHEMA CONTEXT column type annotations — e.g. do not compare a VARCHAR "
                    f"column to an INTEGER literal without an explicit CAST, and do not use string "
                    f"operators (ILIKE, ||) on a numeric/date column without casting it to VARCHAR first.\n"
                )
            if label == "type_mismatch":
                return label, (
                    f"\nA type mismatch was reported (error: {error}).\n"
                    f"Re-check every column's type from the SCHEMA CONTEXT annotations and ensure "
                    f"UNION/CASE/COALESCE branches and JOIN keys use matching or explicitly cast types.\n"
                )

        return "", ""

    async def _revise_sql(self, prompt: str, schema_context: Optional[str], bad_sql: str, error: str) -> str:
        """Re-generate SQL after a validation (EXPLAIN) failure.

        The revision prompt includes:
        - the exact Redshift error message
        - the failed SQL
        - the full schema context so the LLM can choose correct names
        - explicit instructions not to invent identifiers

        Every correction attempt is logged with the original SQL, the
        database error, which revision-hint rule (if any) matched, and the
        corrected SQL the LLM produced — this is the trail needed to debug a
        SQL-generation failure without re-running the request.
        """
        hint_label, bad_hint = self._build_revision_hint(error)

        revision_prompt = (
            f"The following SQL failed Redshift validation with error:\n"
            f"  {error}\n"
            f"{bad_hint}\n"
            f"Original user request: {prompt}\n\n"
            f"Failed SQL:\n{bad_sql}\n\n"
            f"You MUST rewrite this SQL using ONLY tables and columns that appear in the "
            f"SCHEMA CONTEXT section of the system prompt.\n"
            f"- Do NOT invent table names, column names, or join keys.\n"
            f"- Copy all identifiers character-for-character from the schema.\n"
            f"- Use NULLIF for divisions. Use ILIKE for string filters.\n"
            f"Return ONLY the corrected SQL — no explanation, no markdown."
        )
        system = _SYSTEM_PROMPT
        if schema_context:
            system += f"\n\n=== SCHEMA CONTEXT ===\n{schema_context}\n=== END SCHEMA ==="

        corrected_sql = await self._call_sql_model(system, revision_prompt)

        logger.info(
            "SQL correction —\nOriginal SQL:\n%s\nDatabase Error:\n%s\n"
            "Revision Hint Applied: %s\nCorrected SQL:\n%s",
            bad_sql, error, hint_label or "(none — no rule matched this error)", corrected_sql,
        )
        return corrected_sql

    def _validate_sql(self, sql: str) -> Tuple[bool, str]:
        try:
            self._run_query(f"EXPLAIN {sql}")
            return True, ""
        except Exception as exc:
            return False, str(exc)

    @staticmethod
    def _rewrite_known_bad_patterns(sql: str) -> str:
        """Fix common LLM-generated SQL mistakes before execution.

        1. REGEXP_ILIKE → REGEXP_COUNT(..., 1, 'i') > 0
        2. rcd_expir_tp = '9999-12-31 23:59:59' → CAST(rcd_expir_tp AS DATE) = '9999-12-31'
        3. Remove JOIN to claim_case_map (it destroys row counts)
        """
        # Fix 2a: rcd_expir_tp = '9999-12-31 23:59:59'  (bare literal)
        sql = re.sub(
            r"(\w+\.)?rcd_expir_tp\s*=\s*'9999-12-31\s+23:59:59'",
            _RCD_EXPIR_REPL,
            sql,
            flags=re.IGNORECASE,
        )
        # Fix 2b: rcd_expir_tp = CAST('9999-12-31 23:59:59' AS TIMESTAMP)
        sql = re.sub(
            r"(\w+\.)?rcd_expir_tp\s*=\s*CAST\s*\(\s*'9999-12-31\s+23:59:59'\s+AS\s+TIMESTAMP\s*\)",
            _RCD_EXPIR_REPL,
            sql,
            flags=re.IGNORECASE,
        )
        # Fix 2c: rcd_expir_tp = '9999-12-31 00:00:00'  (bare midnight literal — still fragile)
        sql = re.sub(
            r"(\w+\.)?rcd_expir_tp\s*=\s*'9999-12-31\s+00:00:00'",
            _RCD_EXPIR_REPL,
            sql,
            flags=re.IGNORECASE,
        )
        # Fix 2d: rcd_expir_tp = CAST('9999-12-31 00:00:00' AS TIMESTAMP)
        sql = re.sub(
            r"(\w+\.)?rcd_expir_tp\s*=\s*CAST\s*\(\s*'9999-12-31\s+00:00:00'\s+AS\s+TIMESTAMP\s*\)",
            _RCD_EXPIR_REPL,
            sql,
            flags=re.IGNORECASE,
        )

        # Fix 3: remove claim_case_map join lines entirely
        sql = re.sub(
            r"\n?\s*(INNER\s+JOIN|LEFT\s+JOIN|JOIN)\s+\S*claim_case_map\s+\w+\s+ON\s+\S+\s*=\s*\S+",
            "",
            sql,
            flags=re.IGNORECASE,
        )

        # Fix 1: REGEXP_ILIKE
        sql = RedshiftClient._rewrite_regexp_ilike(sql)

        return sql

    @staticmethod
    def _skip_whitespace(sql: str, j: int) -> int:
        """Advance *j* past any whitespace characters and return the new position."""
        while j < len(sql) and sql[j].isspace():
            j += 1
        return j

    @staticmethod
    def _extract_arg(sql: str, j: int, *, stop_at_comma: bool) -> Tuple[str, int]:
        """Extract one parenthesised function argument starting at position *j*.

        If *stop_at_comma* is ``True`` the extraction stops at the first
        unquoted ``','`` at depth 1 (for the first argument of
        ``REGEXP_ILIKE``).  Otherwise it stops at the closing ``')'``
        (for the second argument).

        Returns ``(arg_text_stripped, new_j)`` where *new_j* points to the
        stopping character (``','`` or ``')'``).
        """
        depth = 1
        start = j
        while j < len(sql):
            ch = sql[j]
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    break
            elif ch == ',' and depth == 1 and stop_at_comma:
                break
            j += 1
        return sql[start:j].strip(), j

    @staticmethod
    def _rewrite_regexp_ilike(sql: str) -> str:
        """Rewrite REGEXP_ILIKE(col, 'pat') → REGEXP_COUNT(col, 'pat', 1, 'i') > 0.

        Uses a tokeniser-style approach to correctly handle quoted string literals
        that may contain commas or parentheses.
        """
        result = []
        i = 0
        upper = sql.upper()
        while i < len(sql):
            pos = upper.find('REGEXP_ILIKE', i)
            if pos == -1:
                result.append(sql[i:])
                break
            result.append(sql[i:pos])
            j = pos + len('REGEXP_ILIKE')
            j = RedshiftClient._skip_whitespace(sql, j)
            if j >= len(sql) or sql[j] != '(':
                # Not a function call — copy as-is
                result.append(sql[pos:j])
                i = j
                continue
            j += 1  # skip '('
            col_arg, j = RedshiftClient._extract_arg(sql, j, stop_at_comma=True)
            col_arg = re.sub(r'::(text|varchar)\b', '', col_arg, flags=re.IGNORECASE).strip()
            if j >= len(sql) or sql[j] != ',':
                # Malformed — copy as-is
                result.append(sql[pos:j])
                i = j
                continue
            j += 1  # skip ','
            pat_arg, j = RedshiftClient._extract_arg(sql, j, stop_at_comma=False)
            pat_arg = re.sub(r'::(text|varchar)\b', '', pat_arg, flags=re.IGNORECASE).strip()
            j += 1  # skip closing ')'
            result.append(f"REGEXP_COUNT({col_arg}, {pat_arg}, 1, 'i') > 0")
            i = j
        return ''.join(result)

    @staticmethod
    def _clean_sql(sql: str) -> str:
        """Strip markdown fences and leading/trailing whitespace."""
        sql = re.sub(r"```(?:sql)?", "", sql, flags=re.IGNORECASE).strip()
        sql = re.sub(r"```$", "", sql).strip()
        return sql


# ---------------------------------------------------------------------------
# Factory (mirrors legacy create_server_from_config interface)
# ---------------------------------------------------------------------------

def create_client_from_config(cfg: Dict[str, Any]) -> RedshiftClient:
    """Build a RedshiftClient from a config dict (same keys as legacy mcp_server_v2)."""
    return RedshiftClient(
        host=cfg["host"],
        database=cfg["database"],
        user=cfg["user"],
        password=cfg["password"],
        port=int(cfg.get("port", 5439)),
        schema=cfg.get("schema", "public"),
        ssl=bool(cfg.get("ssl", True)),
        ssl_insecure=bool(cfg.get("ssl_insecure", False)),
        timeout=int(cfg.get("timeout", 300)),
        model_id=cfg.get("model_id"),
        max_tokens=cfg.get("max_tokens"),
        temperature=cfg.get("temperature"),
    )
