"Redshift infrastructure."
