"""Redshift service facade over RedshiftClient.

This is an **in-process** facade used by :class:`RedshiftMCPGateway`.  It exposes
the Redshift capabilities as plain callable methods:

    server.execute_query(sql)
    server.list_tables(schema)
    server.describe_table(table_name, schema)
    await server.invoke_tool(name, args)   # generate_sql dispatch

The MCP wire protocol (tools/list, tools/call, initialize) is handled entirely
by the AWS Lambda handler + Bedrock AgentCore Gateway (see ``lambda_handler``),
so this module no longer depends on the ``mcp`` library or a stdio server.
The tool manifest lives in ``core.mcp_tools`` (single source of truth).
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from .redshift_client import RedshiftClient, create_client_from_config
from core.config import settings, RedshiftConfig

logger = logging.getLogger(__name__)


def _build_client_config(cfg: RedshiftConfig) -> dict:
    return {
        "host":         cfg.host,
        "database":     cfg.database,
        "user":         cfg.user,
        "password":     cfg.password,
        "port":         cfg.port,
        "schema":       cfg.schema,
        "ssl":          cfg.ssl,
        "ssl_insecure": cfg.ssl_insecure,
        "timeout":      cfg.timeout,
        "model_id":     settings.chat_model.model_id,
        "max_tokens":   settings.chat_model.max_tokens,
        "temperature":  settings.chat_model.temperature,
    }


class RedshiftMCPServer:
    """In-process facade wrapping :class:`RedshiftClient`.

    Exposes the query, discovery, SQL-generation and Gremlin-generation
    capabilities used by the gateway.
    """

    def __init__(self, client: RedshiftClient) -> None:
        self._client = client
        logger.info(
            "RedshiftMCPServer ready → %s:%d/%s (schema=%s)",
            client.host, client.port, client.database, client.schema,
        )

    @classmethod
    def create(cls, cfg: RedshiftConfig | None = None) -> "RedshiftMCPServer":
        cfg = cfg or settings.redshift
        if not cfg.host:
            logger.warning("REDSHIFT_HOST is not set — queries will fail at runtime.")
        client = create_client_from_config(_build_client_config(cfg))
        return cls(client)

    @property
    def schema(self) -> str:
        return self._client.schema

    # ------------------------------------------------------------------
    # Sync helpers — used by the gateway for in-process dispatch
    # ------------------------------------------------------------------

    def execute_query(self, sql: str) -> Dict[str, Any]:
        cleaned = self._client._rewrite_known_bad_patterns(sql)
        return self._client._execute_query(cleaned)

    def list_tables(self, schema: str) -> Dict[str, Any]:
        return self._client._list_tables(schema)

    def describe_table(self, table_name: str, schema: str) -> Dict[str, Any]:
        return self._client._describe_table(table_name, schema)

    # ------------------------------------------------------------------
    # Async dispatcher — used for generate_sql
    # ------------------------------------------------------------------

    async def invoke_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        """Dispatch a capability call by name."""
        if name == "query_redshift":
            return self.execute_query(arguments["sql"])
        if name == "list_tables":
            return self.list_tables(arguments.get("schema", self._client.schema))
        if name == "describe_table":
            return self.describe_table(
                arguments["table_name"],
                arguments.get("schema", self._client.schema),
            )
        if name == "generate_sql":
            return await self._client._generate_sql_from_prompt(
                prompt=arguments["prompt"],
                schema_context=arguments.get("schema_context"),
                validate=bool(arguments.get("validate", False)),
                max_attempts=int(arguments.get("max_attempts", 2)),
            )
        if name == "generate_gremlin":
            return await self._client._generate_gremlin_from_prompt(
                prompt=arguments["prompt"],
                graph_context=arguments.get("graph_context"),
            )
        raise ValueError(f"Unknown capability: {name}")
