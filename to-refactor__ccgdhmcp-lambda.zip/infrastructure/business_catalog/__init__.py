# Business Catalog Neptune client — semantic layer graph access.
