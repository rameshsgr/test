"""Business Catalog Neptune Client — semantic layer graph access.

Provides fixed, registered Gremlin queries against the business catalog
graph (BusinessDomain / BusinessObjectType / AttributeDefinition /
BusinessRule / BusinessSignalType / BusinessOutcomeType vertex families).

Design principles (same security posture as insights-neptune/neptune_read.py):
- No free-form / LLM-generated Gremlin at runtime.
- All queries are allowlisted constants — QUERY_LIBRARY keys.
- No caller-supplied values interpolated into query strings (zero injection surface).
- boto3 neptunedata REST data-plane (execute_gremlin_query), NOT gremlinpython websocket.
- Graceful degradation: if Neptune is unreachable, returns {"available": False} — never raises.

Transport note: this client uses boto3.client("neptunedata") which calls the
Neptune Gremlin REST endpoint (POST /gremlin). This is separate from the
existing graph_ontology NeptuneClient which uses gremlinpython websocket
transport — both can target the same cluster without conflict.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Hard server-side caps — callers may request lower values but never higher.
# ---------------------------------------------------------------------------
# Raised for richer Insight context while keeping bounded execution.
_SERVER_MAX_TEMPLATES = 15
_SERVER_MAX_ROWS = 1500
_SERVER_MAX_RESPONSE_BYTES = 262144
_BUSINESS_PLANNER_MAX_RESPONSE_BYTES = 60000
_SERVER_TEMPLATE_TIMEOUT_MS = 12000
_SERVER_TOTAL_TIMEOUT_MS = 60000

# ---------------------------------------------------------------------------
# Lazy singleton boto3 neptunedata client
# ---------------------------------------------------------------------------
_neptune_client = None


def _get_neptune_client():
    """Lazy singleton — never constructed unless a catalog tool is called.

    Endpoint resolution order:
    1. BUSINESS_CATALOG_NEPTUNE_ENDPOINT env var
    2. GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT env var  (same cluster, different vertex family)
    3. settings.graph_ontology.neptune_endpoint (config.yaml fallback)
    """
    global _neptune_client
    if _neptune_client is not None:
        return _neptune_client

    endpoint = os.getenv("BUSINESS_CATALOG_NEPTUNE_ENDPOINT", "").strip()
    if not endpoint:
        endpoint = os.getenv("GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT", "").strip()
    if not endpoint:
        try:
            from core.config import settings
            if settings.graph_ontology and settings.graph_ontology.neptune_endpoint:
                endpoint = settings.graph_ontology.neptune_endpoint
        except Exception:
            pass
    if not endpoint:
        raise RuntimeError(
            "Business catalog Neptune endpoint not configured. "
            "Set BUSINESS_CATALOG_NEPTUNE_ENDPOINT or GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT."
        )

    region = os.getenv("BUSINESS_CATALOG_NEPTUNE_REGION", "") or os.getenv("AWS_REGION", "") or "us-east-1"

    config = Config(
        connect_timeout=3,
        read_timeout=20,
        retries={"total_max_attempts": 2, "mode": "standard"},
    )
    _neptune_client = boto3.client(
        "neptunedata",
        region_name=region,
        endpoint_url=f"https://{endpoint}:8182",
        config=config,
    )
    logger.info("Business catalog Neptune client initialised — endpoint=%s region=%s", endpoint, region)
    return _neptune_client


# ---------------------------------------------------------------------------
# GraphSON v3 decoder — verbatim from insights-neptune/neptune_read.py
# ---------------------------------------------------------------------------

def _unwrap_graphson(value: Any) -> Any:
    """Recursively decode Neptune's typed GraphSON v3 response shapes.

    - {"@type": "g:Map", "@value": [k1,v1,...]} -> dict
    - {"@type": "g:List", "@value": [...]}       -> list
    - Any other {"@type":..., "@value":...}       -> its @value, recursively decoded
    - plain str/int/bool/None                     -> returned as-is
    """
    if isinstance(value, dict) and "@type" in value and "@value" in value:
        vtype, vval = value["@type"], value["@value"]
        if vtype == "g:Map":
            pairs = [_unwrap_graphson(v) for v in vval]
            return dict(zip(pairs[0::2], pairs[1::2]))
        if vtype == "g:List":
            return [_unwrap_graphson(v) for v in vval]
        return _unwrap_graphson(vval)
    if isinstance(value, list):
        return [_unwrap_graphson(v) for v in value]
    if isinstance(value, dict):
        return {k: _unwrap_graphson(v) for k, v in value.items()}
    return value


# ---------------------------------------------------------------------------
# Registered query library — sheet, cross-context, and agent-specific queries
# Source: CATALOG_QUERY_PACK.json (insights-neptune/ reference folder)
# Keys match queryId values in that file exactly.
# ---------------------------------------------------------------------------

_QUERY_LIBRARY: Dict[str, str] = {
    "SHEET_00_README_CONTEXT": "g.V().where(coalesce(values('Tab'), values('tab'), constant('')).is(neq(''))).project('Tab','Purpose','What It Contains','How Agents Use It','Predefined / Runtime Reference','Primary Owner','Feeds Graph','Important Distinction').by(coalesce(values('Tab'), values('tab'), constant(''))).by(coalesce(values('Purpose'), values('purpose'), constant(''))).by(coalesce(values('What It Contains'), values('WhatItContains'), values('what it contains'), values('whatItContains'), values('what_it_contains'), constant(''))).by(coalesce(values('How Agents Use It'), values('HowAgentsUseIt'), values('how agents use it'), values('howAgentsUseIt'), values('how_agents_use_it'), constant(''))).by(coalesce(values('Predefined Runtime Reference'), values('PredefinedRuntimeReference'), values('predefined runtime reference'), values('predefinedRuntimeReference'), values('predefined_runtime_reference'), constant(''))).by(coalesce(values('Primary Owner'), values('PrimaryOwner'), values('primary owner'), values('primaryOwner'), values('primary_owner'), constant(''))).by(coalesce(values('Feeds Graph'), values('FeedsGraph'), values('feeds graph'), values('feedsGraph'), values('feeds_graph'), constant(''))).by(coalesce(values('Important Distinction'), values('ImportantDistinction'), values('important distinction'), values('importantDistinction'), values('important_distinction'), constant(''))).dedup()",
    "SHEET_01_DOMAINS_CONTEXT": "g.V().where(coalesce(values('Domain ID'), values('DomainID'), values('DomainId'), values('domain id'), values('domainID'), values('domainId'), values('domain_id'), constant('')).is(neq(''))).project('Domain ID','Canonical ID','Domain Name','Domain Type','Definition','Scope Includes','Scope Excludes','Primary Owner','Steward','Namespace','Status','Version').by(coalesce(values('Domain ID'), values('DomainID'), values('DomainId'), values('domain id'), values('domainID'), values('domainId'), values('domain_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Domain Name'), values('DomainName'), values('domain name'), values('domainName'), values('domain_name'), constant(''))).by(coalesce(values('Domain Type'), values('DomainType'), values('domain type'), values('domainType'), values('domain_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Scope Includes'), values('ScopeIncludes'), values('scope includes'), values('scopeIncludes'), values('scope_includes'), constant(''))).by(coalesce(values('Scope Excludes'), values('ScopeExcludes'), values('scope excludes'), values('scopeExcludes'), values('scope_excludes'), constant(''))).by(coalesce(values('Primary Owner'), values('PrimaryOwner'), values('primary owner'), values('primaryOwner'), values('primary_owner'), constant(''))).by(coalesce(values('Steward'), values('steward'), constant(''))).by(coalesce(values('Namespace'), values('namespace'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_02_CORE_CONCEPTS_CONTEXT": "g.V().where(coalesce(values('Concept ID'), values('ConceptID'), values('ConceptId'), values('concept id'), values('conceptID'), values('conceptId'), values('concept_id'), constant('')).is(neq(''))).project('Concept ID','Canonical ID','Preferred Name','Asset Type','Owning Domain ID','Parent Concept ID','Definition','Synonyms','Important Distinction','Materialization Class','Status','Version','SME Validation').by(coalesce(values('Concept ID'), values('ConceptID'), values('ConceptId'), values('concept id'), values('conceptID'), values('conceptId'), values('concept_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Preferred Name'), values('PreferredName'), values('preferred name'), values('preferredName'), values('preferred_name'), constant(''))).by(coalesce(values('Asset Type'), values('AssetType'), values('asset type'), values('assetType'), values('asset_type'), constant(''))).by(coalesce(values('Owning Domain ID'), values('OwningDomainID'), values('OwningDomainId'), values('owning domain id'), values('owningDomainID'), values('owningDomainId'), values('owning_domain_id'), constant(''))).by(coalesce(values('Parent Concept ID'), values('ParentConceptID'), values('ParentConceptId'), values('parent concept id'), values('parentConceptID'), values('parentConceptId'), values('parent_concept_id'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Synonyms'), values('synonyms'), constant(''))).by(coalesce(values('Important Distinction'), values('ImportantDistinction'), values('important distinction'), values('importantDistinction'), values('important_distinction'), constant(''))).by(coalesce(values('Materialization Class'), values('MaterializationClass'), values('materialization class'), values('materializationClass'), values('materialization_class'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).by(coalesce(values('SME Validation'), values('SmeValidation'), values('sme validation'), values('smeValidation'), values('sme_validation'), constant(''))).dedup()",
    "SHEET_03_ATTRIBUTES_CONTEXT": "g.V().where(coalesce(values('Attribute ID'), values('AttributeID'), values('AttributeId'), values('attribute id'), values('attributeID'), values('attributeId'), values('attribute_id'), constant('')).is(neq(''))).project('Attribute ID','Canonical ID','Preferred Name','Parent Concept ID','Definition','Value Type ID','Required','Multi-Valued','Controlled Vocabulary ID','Temporal Handling','Store As','Graph Property Name','Owner','Status','Version').by(coalesce(values('Attribute ID'), values('AttributeID'), values('AttributeId'), values('attribute id'), values('attributeID'), values('attributeId'), values('attribute_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Preferred Name'), values('PreferredName'), values('preferred name'), values('preferredName'), values('preferred_name'), constant(''))).by(coalesce(values('Parent Concept ID'), values('ParentConceptID'), values('ParentConceptId'), values('parent concept id'), values('parentConceptID'), values('parentConceptId'), values('parent_concept_id'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Value Type ID'), values('ValueTypeID'), values('ValueTypeId'), values('value type id'), values('valueTypeID'), values('valueTypeId'), values('value_type_id'), constant(''))).by(coalesce(values('Required'), values('required'), constant(''))).by(coalesce(values('Multi-Valued'), values('MultiValued'), values('multi-valued'), values('multiValued'), values('multi_valued'), constant(''))).by(coalesce(values('Controlled Vocabulary ID'), values('ControlledVocabularyID'), values('ControlledVocabularyId'), values('controlled vocabulary id'), values('controlledVocabularyID'), values('controlledVocabularyId'), values('controlled_vocabulary_id'), constant(''))).by(coalesce(values('Temporal Handling'), values('TemporalHandling'), values('temporal handling'), values('temporalHandling'), values('temporal_handling'), constant(''))).by(coalesce(values('Store As'), values('StoreAs'), values('store as'), values('storeAs'), values('store_as'), constant(''))).by(coalesce(values('Graph Property Name'), values('GraphPropertyName'), values('graph property name'), values('graphPropertyName'), values('graph_property_name'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_04_RELATIONSHIPS_CONTEXT": "g.V().where(coalesce(values('Relationship ID'), values('RelationshipID'), values('RelationshipId'), values('relationship id'), values('relationshipID'), values('relationshipId'), values('relationship_id'), constant('')).is(neq(''))).project('Relationship ID','Canonical ID','Source Concept ID','Relationship Name','Target Concept ID','Inverse Name','Definition','Source Min','Source Max','Target Min','Target Max','Temporal','Materialize Runtime','Status','Version').by(coalesce(values('Relationship ID'), values('RelationshipID'), values('RelationshipId'), values('relationship id'), values('relationshipID'), values('relationshipId'), values('relationship_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Source Concept ID'), values('SourceConceptID'), values('SourceConceptId'), values('source concept id'), values('sourceConceptID'), values('sourceConceptId'), values('source_concept_id'), constant(''))).by(coalesce(values('Relationship Name'), values('RelationshipName'), values('relationship name'), values('relationshipName'), values('relationship_name'), constant(''))).by(coalesce(values('Target Concept ID'), values('TargetConceptID'), values('TargetConceptId'), values('target concept id'), values('targetConceptID'), values('targetConceptId'), values('target_concept_id'), constant(''))).by(coalesce(values('Inverse Name'), values('InverseName'), values('inverse name'), values('inverseName'), values('inverse_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Source Min'), values('SourceMin'), values('source min'), values('sourceMin'), values('source_min'), constant(''))).by(coalesce(values('Source Max'), values('SourceMax'), values('source max'), values('sourceMax'), values('source_max'), constant(''))).by(coalesce(values('Target Min'), values('TargetMin'), values('target min'), values('targetMin'), values('target_min'), constant(''))).by(coalesce(values('Target Max'), values('TargetMax'), values('target max'), values('targetMax'), values('target_max'), constant(''))).by(coalesce(values('Temporal'), values('temporal'), constant(''))).by(coalesce(values('Materialize Runtime'), values('MaterializeRuntime'), values('materialize runtime'), values('materializeRuntime'), values('materialize_runtime'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_05_CONTROLLED_VOCABULARIES_CONTEXT": "g.V().where(coalesce(values('Vocabulary ID'), values('VocabularyID'), values('VocabularyId'), values('vocabulary id'), values('vocabularyID'), values('vocabularyId'), values('vocabulary_id'), constant('')).is(neq(''))).project('Vocabulary ID','Canonical ID','Name','Definition','Applies To Attribute ID','Open or Closed','Hierarchical','Owner','Status','Version').by(coalesce(values('Vocabulary ID'), values('VocabularyID'), values('VocabularyId'), values('vocabulary id'), values('vocabularyID'), values('vocabularyId'), values('vocabulary_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Name'), values('name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Applies To Attribute ID'), values('AppliesToAttributeID'), values('AppliesToAttributeId'), values('applies to attribute id'), values('appliesToAttributeID'), values('appliesToAttributeId'), values('applies_to_attribute_id'), constant(''))).by(coalesce(values('Open or Closed'), values('OpenOrClosed'), values('open or closed'), values('openOrClosed'), values('open_or_closed'), constant(''))).by(coalesce(values('Hierarchical'), values('hierarchical'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_06_CONTROLLED_VALUES_CONTEXT": "g.V().where(coalesce(values('Value ID'), values('ValueID'), values('ValueId'), values('value id'), values('valueID'), values('valueId'), values('value_id'), constant('')).is(neq(''))).project('Value ID','Canonical ID','Vocabulary ID','Code','Preferred Label','Definition','Parent Value ID','Display Order','Status','Effective From','Effective To','Replaced By').by(coalesce(values('Value ID'), values('ValueID'), values('ValueId'), values('value id'), values('valueID'), values('valueId'), values('value_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Vocabulary ID'), values('VocabularyID'), values('VocabularyId'), values('vocabulary id'), values('vocabularyID'), values('vocabularyId'), values('vocabulary_id'), constant(''))).by(coalesce(values('Code'), values('code'), constant(''))).by(coalesce(values('Preferred Label'), values('PreferredLabel'), values('preferred label'), values('preferredLabel'), values('preferred_label'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Parent Value ID'), values('ParentValueID'), values('ParentValueId'), values('parent value id'), values('parentValueID'), values('parentValueId'), values('parent_value_id'), constant(''))).by(coalesce(values('Display Order'), values('DisplayOrder'), values('display order'), values('displayOrder'), values('display_order'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Effective From'), values('EffectiveFrom'), values('effective from'), values('effectiveFrom'), values('effective_from'), constant(''))).by(coalesce(values('Effective To'), values('EffectiveTo'), values('effective to'), values('effectiveTo'), values('effective_to'), constant(''))).by(coalesce(values('Replaced By'), values('ReplacedBy'), values('replaced by'), values('replacedBy'), values('replaced_by'), constant(''))).dedup()",
    "SHEET_07_RULES_CONTEXT": "g.V().where(coalesce(values('Rule ID'), values('RuleID'), values('RuleId'), values('rule id'), values('ruleID'), values('ruleId'), values('rule_id'), constant('')).is(neq(''))).project('Rule ID','Canonical ID','Rule Name','Rule Type','Applies To Concept ID','Input Attribute IDs','Output Concept ID','Expression Language','Expression or Reference','Deterministic','Override Allowed','Owner','Status','Version').by(coalesce(values('Rule ID'), values('RuleID'), values('RuleId'), values('rule id'), values('ruleID'), values('ruleId'), values('rule_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Rule Name'), values('RuleName'), values('rule name'), values('ruleName'), values('rule_name'), constant(''))).by(coalesce(values('Rule Type'), values('RuleType'), values('rule type'), values('ruleType'), values('rule_type'), constant(''))).by(coalesce(values('Applies To Concept ID'), values('AppliesToConceptID'), values('AppliesToConceptId'), values('applies to concept id'), values('appliesToConceptID'), values('appliesToConceptId'), values('applies_to_concept_id'), constant(''))).by(coalesce(values('Input Attribute IDs'), values('InputAttributeIds'), values('input attribute ids'), values('inputAttributeIds'), values('input_attribute_ids'), constant(''))).by(coalesce(values('Output Concept ID'), values('OutputConceptID'), values('OutputConceptId'), values('output concept id'), values('outputConceptID'), values('outputConceptId'), values('output_concept_id'), constant(''))).by(coalesce(values('Expression Language'), values('ExpressionLanguage'), values('expression language'), values('expressionLanguage'), values('expression_language'), constant(''))).by(coalesce(values('Expression or Reference'), values('ExpressionOrReference'), values('expression or reference'), values('expressionOrReference'), values('expression_or_reference'), constant(''))).by(coalesce(values('Deterministic'), values('deterministic'), constant(''))).by(coalesce(values('Override Allowed'), values('OverrideAllowed'), values('override allowed'), values('overrideAllowed'), values('override_allowed'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_08_CALCULATIONS_CONTEXT": "g.V().where(coalesce(values('Calculation ID'), values('CalculationID'), values('CalculationId'), values('calculation id'), values('calculationID'), values('calculationId'), values('calculation_id'), constant('')).is(neq(''))).project('Calculation ID','Canonical ID','Calculation Name','Definition','Input Attribute IDs','Output Attribute or Measure ID','Formula or Implementation Reference','Aggregation Type','Time Window','Null Handling','Owner','Status','Version').by(coalesce(values('Calculation ID'), values('CalculationID'), values('CalculationId'), values('calculation id'), values('calculationID'), values('calculationId'), values('calculation_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Calculation Name'), values('CalculationName'), values('calculation name'), values('calculationName'), values('calculation_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Input Attribute IDs'), values('InputAttributeIds'), values('input attribute ids'), values('inputAttributeIds'), values('input_attribute_ids'), constant(''))).by(coalesce(values('Output Attribute or Measure ID'), values('OutputAttributeOrMeasureID'), values('OutputAttributeOrMeasureId'), values('output attribute or measure id'), values('outputAttributeOrMeasureID'), values('outputAttributeOrMeasureId'), values('output_attribute_or_measure_id'), constant(''))).by(coalesce(values('Formula or Implementation Reference'), values('FormulaOrImplementationReference'), values('formula or implementation reference'), values('formulaOrImplementationReference'), values('formula_or_implementation_reference'), constant(''))).by(coalesce(values('Aggregation Type'), values('AggregationType'), values('aggregation type'), values('aggregationType'), values('aggregation_type'), constant(''))).by(coalesce(values('Time Window'), values('TimeWindow'), values('time window'), values('timeWindow'), values('time_window'), constant(''))).by(coalesce(values('Null Handling'), values('NullHandling'), values('null handling'), values('nullHandling'), values('null_handling'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_09_CAPABILITIES_CONTEXT": "g.V().where(coalesce(values('Capability ID'), values('CapabilityID'), values('CapabilityId'), values('capability id'), values('capabilityID'), values('capabilityId'), values('capability_id'), constant('')).is(neq(''))).project('Capability ID','Canonical ID','Capability Name','Definition','Owning Domain ID','Primary Outcome Concept ID','Primary Concept IDs','Owner','Status','Version').by(coalesce(values('Capability ID'), values('CapabilityID'), values('CapabilityId'), values('capability id'), values('capabilityID'), values('capabilityId'), values('capability_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Capability Name'), values('CapabilityName'), values('capability name'), values('capabilityName'), values('capability_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Owning Domain ID'), values('OwningDomainID'), values('OwningDomainId'), values('owning domain id'), values('owningDomainID'), values('owningDomainId'), values('owning_domain_id'), constant(''))).by(coalesce(values('Primary Outcome Concept ID'), values('PrimaryOutcomeConceptID'), values('PrimaryOutcomeConceptId'), values('primary outcome concept id'), values('primaryOutcomeConceptID'), values('primaryOutcomeConceptId'), values('primary_outcome_concept_id'), constant(''))).by(coalesce(values('Primary Concept IDs'), values('PrimaryConceptIds'), values('primary concept ids'), values('primaryConceptIds'), values('primary_concept_ids'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_10_PROCESSES_ACTIONS_CONTEXT": "g.V().where(coalesce(values('Work ID'), values('WorkID'), values('WorkId'), values('work id'), values('workID'), values('workId'), values('work_id'), constant('')).is(neq(''))).project('Work ID','Canonical ID','Name','Work Type','Capability ID','Definition','Input Concept IDs','Output Concept IDs','Persona IDs','Status','Version').by(coalesce(values('Work ID'), values('WorkID'), values('WorkId'), values('work id'), values('workID'), values('workId'), values('work_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Name'), values('name'), constant(''))).by(coalesce(values('Work Type'), values('WorkType'), values('work type'), values('workType'), values('work_type'), constant(''))).by(coalesce(values('Capability ID'), values('CapabilityID'), values('CapabilityId'), values('capability id'), values('capabilityID'), values('capabilityId'), values('capability_id'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Input Concept IDs'), values('InputConceptIds'), values('input concept ids'), values('inputConceptIds'), values('input_concept_ids'), constant(''))).by(coalesce(values('Output Concept IDs'), values('OutputConceptIds'), values('output concept ids'), values('outputConceptIds'), values('output_concept_ids'), constant(''))).by(coalesce(values('Persona IDs'), values('PersonaIds'), values('persona ids'), values('personaIds'), values('persona_ids'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_11A_SIGNALS_CONTEXT": "g.V().where(coalesce(values('Signal ID'), values('SignalID'), values('SignalId'), values('signal id'), values('signalID'), values('signalId'), values('signal_id'), constant('')).is(neq(''))).project('Signal ID','Canonical ID','Signal Name','Signal Type','Definition','Subject Concept ID','Evidence Concept IDs','Evidence Attribute IDs','Trigger Rule IDs','Calculation IDs','Related Event IDs','Related Situation Type','Supports Capability IDs','Severity','Confidence Requirement','Freshness Requirement','Status','Version','Source Reference','Steward Notes').by(coalesce(values('Signal ID'), values('SignalID'), values('SignalId'), values('signal id'), values('signalID'), values('signalId'), values('signal_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Signal Name'), values('SignalName'), values('signal name'), values('signalName'), values('signal_name'), constant(''))).by(coalesce(values('Signal Type'), values('SignalType'), values('signal type'), values('signalType'), values('signal_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Subject Concept ID'), values('SubjectConceptID'), values('SubjectConceptId'), values('subject concept id'), values('subjectConceptID'), values('subjectConceptId'), values('subject_concept_id'), constant(''))).by(coalesce(values('Evidence Concept IDs'), values('EvidenceConceptIds'), values('evidence concept ids'), values('evidenceConceptIds'), values('evidence_concept_ids'), constant(''))).by(coalesce(values('Evidence Attribute IDs'), values('EvidenceAttributeIds'), values('evidence attribute ids'), values('evidenceAttributeIds'), values('evidence_attribute_ids'), constant(''))).by(coalesce(values('Trigger Rule IDs'), values('TriggerRuleIds'), values('trigger rule ids'), values('triggerRuleIds'), values('trigger_rule_ids'), constant(''))).by(coalesce(values('Calculation IDs'), values('CalculationIds'), values('calculation ids'), values('calculationIds'), values('calculation_ids'), constant(''))).by(coalesce(values('Related Event IDs'), values('RelatedEventIds'), values('related event ids'), values('relatedEventIds'), values('related_event_ids'), constant(''))).by(coalesce(values('Related Situation Type'), values('RelatedSituationType'), values('related situation type'), values('relatedSituationType'), values('related_situation_type'), constant(''))).by(coalesce(values('Supports Capability IDs'), values('SupportsCapabilityIds'), values('supports capability ids'), values('supportsCapabilityIds'), values('supports_capability_ids'), constant(''))).by(coalesce(values('Severity'), values('severity'), constant(''))).by(coalesce(values('Confidence Requirement'), values('ConfidenceRequirement'), values('confidence requirement'), values('confidenceRequirement'), values('confidence_requirement'), constant(''))).by(coalesce(values('Freshness Requirement'), values('FreshnessRequirement'), values('freshness requirement'), values('freshnessRequirement'), values('freshness_requirement'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).by(coalesce(values('Source Reference'), values('SourceReference'), values('source reference'), values('sourceReference'), values('source_reference'), constant(''))).by(coalesce(values('Steward Notes'), values('StewardNotes'), values('steward notes'), values('stewardNotes'), values('steward_notes'), constant(''))).dedup()",
    "SHEET_11B_EVENTS_CONTEXT": "g.V().where(coalesce(values('Event ID'), values('EventID'), values('EventId'), values('event id'), values('eventID'), values('eventId'), values('event_id'), constant('')).is(neq(''))).project('Event ID','Canonical ID','Event Name','Event Type','Definition','Subject Concept ID','Related Concept IDs','Event Timestamp Type','Effective Date Type','Source System ID','Technical Asset IDs','Initiating Persona or System','Preceding Status','Resulting Status','Related Process Action IDs','May Generate Signal IDs','Supports Capability IDs','Materialization Class','Status','Version','Source Reference','Steward Notes').by(coalesce(values('Event ID'), values('EventID'), values('EventId'), values('event id'), values('eventID'), values('eventId'), values('event_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Event Name'), values('EventName'), values('event name'), values('eventName'), values('event_name'), constant(''))).by(coalesce(values('Event Type'), values('EventType'), values('event type'), values('eventType'), values('event_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Subject Concept ID'), values('SubjectConceptID'), values('SubjectConceptId'), values('subject concept id'), values('subjectConceptID'), values('subjectConceptId'), values('subject_concept_id'), constant(''))).by(coalesce(values('Related Concept IDs'), values('RelatedConceptIds'), values('related concept ids'), values('relatedConceptIds'), values('related_concept_ids'), constant(''))).by(coalesce(values('Event Timestamp Type'), values('EventTimestampType'), values('event timestamp type'), values('eventTimestampType'), values('event_timestamp_type'), constant(''))).by(coalesce(values('Effective Date Type'), values('EffectiveDateType'), values('effective date type'), values('effectiveDateType'), values('effective_date_type'), constant(''))).by(coalesce(values('Source System ID'), values('SourceSystemID'), values('SourceSystemId'), values('source system id'), values('sourceSystemID'), values('sourceSystemId'), values('source_system_id'), constant(''))).by(coalesce(values('Technical Asset IDs'), values('TechnicalAssetIds'), values('technical asset ids'), values('technicalAssetIds'), values('technical_asset_ids'), constant(''))).by(coalesce(values('Initiating Persona or System'), values('InitiatingPersonaOrSystem'), values('initiating persona or system'), values('initiatingPersonaOrSystem'), values('initiating_persona_or_system'), constant(''))).by(coalesce(values('Preceding Status'), values('PrecedingStatus'), values('preceding status'), values('precedingStatus'), values('preceding_status'), constant(''))).by(coalesce(values('Resulting Status'), values('ResultingStatus'), values('resulting status'), values('resultingStatus'), values('resulting_status'), constant(''))).by(coalesce(values('Related Process Action IDs'), values('RelatedProcessActionIds'), values('related process action ids'), values('relatedProcessActionIds'), values('related_process_action_ids'), constant(''))).by(coalesce(values('May Generate Signal IDs'), values('MayGenerateSignalIds'), values('may generate signal ids'), values('mayGenerateSignalIds'), values('may_generate_signal_ids'), constant(''))).by(coalesce(values('Supports Capability IDs'), values('SupportsCapabilityIds'), values('supports capability ids'), values('supportsCapabilityIds'), values('supports_capability_ids'), constant(''))).by(coalesce(values('Materialization Class'), values('MaterializationClass'), values('materialization class'), values('materializationClass'), values('materialization_class'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).by(coalesce(values('Source Reference'), values('SourceReference'), values('source reference'), values('sourceReference'), values('source_reference'), constant(''))).by(coalesce(values('Steward Notes'), values('StewardNotes'), values('steward notes'), values('stewardNotes'), values('steward_notes'), constant(''))).dedup()",
    "SHEET_11C_OUTCOMES_CONTEXT": "g.V().where(coalesce(values('Outcome ID'), values('OutcomeID'), values('OutcomeId'), values('outcome id'), values('outcomeID'), values('outcomeId'), values('outcome_id'), constant('')).is(neq(''))).project('Outcome ID','Canonical ID','Outcome Name','Outcome Type','Definition','Desired or Actual Indicator','Subject Concept ID','Parent Outcome ID','Measure IDs','Target Type','Achievement Status Vocabulary ID','Supporting Event IDs','Contributing Action IDs','Related Situation Types','Related Plan Concept ID','Supports Capability IDs','Materialization Class','Status','Version','Source Reference','Steward Notes').by(coalesce(values('Outcome ID'), values('OutcomeID'), values('OutcomeId'), values('outcome id'), values('outcomeID'), values('outcomeId'), values('outcome_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Outcome Name'), values('OutcomeName'), values('outcome name'), values('outcomeName'), values('outcome_name'), constant(''))).by(coalesce(values('Outcome Type'), values('OutcomeType'), values('outcome type'), values('outcomeType'), values('outcome_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Desired or Actual Indicator'), values('DesiredOrActualIndicator'), values('desired or actual indicator'), values('desiredOrActualIndicator'), values('desired_or_actual_indicator'), constant(''))).by(coalesce(values('Subject Concept ID'), values('SubjectConceptID'), values('SubjectConceptId'), values('subject concept id'), values('subjectConceptID'), values('subjectConceptId'), values('subject_concept_id'), constant(''))).by(coalesce(values('Parent Outcome ID'), values('ParentOutcomeID'), values('ParentOutcomeId'), values('parent outcome id'), values('parentOutcomeID'), values('parentOutcomeId'), values('parent_outcome_id'), constant(''))).by(coalesce(values('Measure IDs'), values('MeasureIds'), values('measure ids'), values('measureIds'), values('measure_ids'), constant(''))).by(coalesce(values('Target Type'), values('TargetType'), values('target type'), values('targetType'), values('target_type'), constant(''))).by(coalesce(values('Achievement Status Vocabulary ID'), values('AchievementStatusVocabularyID'), values('AchievementStatusVocabularyId'), values('achievement status vocabulary id'), values('achievementStatusVocabularyID'), values('achievementStatusVocabularyId'), values('achievement_status_vocabulary_id'), constant(''))).by(coalesce(values('Supporting Event IDs'), values('SupportingEventIds'), values('supporting event ids'), values('supportingEventIds'), values('supporting_event_ids'), constant(''))).by(coalesce(values('Contributing Action IDs'), values('ContributingActionIds'), values('contributing action ids'), values('contributingActionIds'), values('contributing_action_ids'), constant(''))).by(coalesce(values('Related Situation Types'), values('RelatedSituationTypes'), values('related situation types'), values('relatedSituationTypes'), values('related_situation_types'), constant(''))).by(coalesce(values('Related Plan Concept ID'), values('RelatedPlanConceptID'), values('RelatedPlanConceptId'), values('related plan concept id'), values('relatedPlanConceptID'), values('relatedPlanConceptId'), values('related_plan_concept_id'), constant(''))).by(coalesce(values('Supports Capability IDs'), values('SupportsCapabilityIds'), values('supports capability ids'), values('supportsCapabilityIds'), values('supports_capability_ids'), constant(''))).by(coalesce(values('Materialization Class'), values('MaterializationClass'), values('materialization class'), values('materializationClass'), values('materialization_class'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).by(coalesce(values('Source Reference'), values('SourceReference'), values('source reference'), values('sourceReference'), values('source_reference'), constant(''))).by(coalesce(values('Steward Notes'), values('StewardNotes'), values('steward notes'), values('stewardNotes'), values('steward_notes'), constant(''))).dedup()",
    "SHEET_11D_INSIGHTS_CONTEXT": "g.V().where(coalesce(values('Insight ID'), values('InsightID'), values('InsightId'), values('insight id'), values('insightID'), values('insightId'), values('insight_id'), constant('')).is(neq(''))).project('Insight ID','Canonical ID','Insight Name','Insight Category','Definition','Subject Concept ID','Observational Dimension Concept ID','Supporting Signal IDs','Supporting Event IDs','Interpretation Method','Evidence Requirements','Confidence Treatment','Freshness / Expiration','Potential Situation Type IDs','Producing Capability ID','Producing Agent Role','Primary Store / Technical Asset ID','Materialization Class','Owner','Status','Version','Source Reference','Steward Notes','Applicable Capability IDs','Business Outcome IDs Affected','Persona Relevance','Interpretation Rule IDs','Internal Knowledge Required','Industry Context Used','Capability-Specific Meaning').by(coalesce(values('Insight ID'), values('InsightID'), values('InsightId'), values('insight id'), values('insightID'), values('insightId'), values('insight_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Insight Name'), values('InsightName'), values('insight name'), values('insightName'), values('insight_name'), constant(''))).by(coalesce(values('Insight Category'), values('InsightCategory'), values('insight category'), values('insightCategory'), values('insight_category'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Subject Concept ID'), values('SubjectConceptID'), values('SubjectConceptId'), values('subject concept id'), values('subjectConceptID'), values('subjectConceptId'), values('subject_concept_id'), constant(''))).by(coalesce(values('Observational Dimension Concept ID'), values('ObservationalDimensionConceptID'), values('ObservationalDimensionConceptId'), values('observational dimension concept id'), values('observationalDimensionConceptID'), values('observationalDimensionConceptId'), values('observational_dimension_concept_id'), constant(''))).by(coalesce(values('Supporting Signal IDs'), values('SupportingSignalIds'), values('supporting signal ids'), values('supportingSignalIds'), values('supporting_signal_ids'), constant(''))).by(coalesce(values('Supporting Event IDs'), values('SupportingEventIds'), values('supporting event ids'), values('supportingEventIds'), values('supporting_event_ids'), constant(''))).by(coalesce(values('Interpretation Method'), values('InterpretationMethod'), values('interpretation method'), values('interpretationMethod'), values('interpretation_method'), constant(''))).by(coalesce(values('Evidence Requirements'), values('EvidenceRequirements'), values('evidence requirements'), values('evidenceRequirements'), values('evidence_requirements'), constant(''))).by(coalesce(values('Confidence Treatment'), values('ConfidenceTreatment'), values('confidence treatment'), values('confidenceTreatment'), values('confidence_treatment'), constant(''))).by(coalesce(values('Freshness Expiration'), values('FreshnessExpiration'), values('freshness expiration'), values('freshnessExpiration'), values('freshness_expiration'), constant(''))).by(coalesce(values('Potential Situation Type IDs'), values('PotentialSituationTypeIds'), values('potential situation type ids'), values('potentialSituationTypeIds'), values('potential_situation_type_ids'), constant(''))).by(coalesce(values('Producing Capability ID'), values('ProducingCapabilityID'), values('ProducingCapabilityId'), values('producing capability id'), values('producingCapabilityID'), values('producingCapabilityId'), values('producing_capability_id'), constant(''))).by(coalesce(values('Producing Agent Role'), values('ProducingAgentRole'), values('producing agent role'), values('producingAgentRole'), values('producing_agent_role'), constant(''))).by(coalesce(values('Primary Store Technical Asset ID'), values('PrimaryStoreTechnicalAssetID'), values('PrimaryStoreTechnicalAssetId'), values('primary store technical asset id'), values('primaryStoreTechnicalAssetID'), values('primaryStoreTechnicalAssetId'), values('primary_store_technical_asset_id'), constant(''))).by(coalesce(values('Materialization Class'), values('MaterializationClass'), values('materialization class'), values('materializationClass'), values('materialization_class'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).by(coalesce(values('Source Reference'), values('SourceReference'), values('source reference'), values('sourceReference'), values('source_reference'), constant(''))).by(coalesce(values('Steward Notes'), values('StewardNotes'), values('steward notes'), values('stewardNotes'), values('steward_notes'), constant(''))).by(coalesce(values('Applicable Capability IDs'), values('ApplicableCapabilityIds'), values('applicable capability ids'), values('applicableCapabilityIds'), values('applicable_capability_ids'), constant(''))).by(coalesce(values('Business Outcome IDs Affected'), values('BusinessOutcomeIdsAffected'), values('business outcome ids affected'), values('businessOutcomeIdsAffected'), values('business_outcome_ids_affected'), constant(''))).by(coalesce(values('Persona Relevance'), values('PersonaRelevance'), values('persona relevance'), values('personaRelevance'), values('persona_relevance'), constant(''))).by(coalesce(values('Interpretation Rule IDs'), values('InterpretationRuleIds'), values('interpretation rule ids'), values('interpretationRuleIds'), values('interpretation_rule_ids'), constant(''))).by(coalesce(values('Internal Knowledge Required'), values('InternalKnowledgeRequired'), values('internal knowledge required'), values('internalKnowledgeRequired'), values('internal_knowledge_required'), constant(''))).by(coalesce(values('Industry Context Used'), values('IndustryContextUsed'), values('industry context used'), values('industryContextUsed'), values('industry_context_used'), constant(''))).by(coalesce(values('Capability-Specific Meaning'), values('CapabilitySpecificMeaning'), values('capability-specific meaning'), values('capabilitySpecificMeaning'), values('capability_specific_meaning'), constant(''))).dedup()",
    "SHEET_11E_SITUATION_TYPES_CONTEXT": "g.V().where(coalesce(values('Situation Type ID'), values('SituationTypeID'), values('SituationTypeId'), values('situation type id'), values('situationTypeID'), values('situationTypeId'), values('situation_type_id'), constant('')).is(neq(''))).project('Situation Type ID','Canonical ID','Situation Type Name','Situation Category','Definition','Primary Subject Concept ID','Related Concept IDs','Supporting Insight IDs','Supporting Signal IDs','Business Intent / Goal IDs','Outcome IDs at Risk or Within Reach','Enterprise Priority Factors','Plan Disposition Options','Composite Eligibility','Merge / Duplicate Guidance','Lifecycle Vocabulary ID','Owning Capability ID','Relevant Persona IDs','Default Plan Pattern IDs','Primary Store / Technical Asset ID','Materialization Class','Owner','Status','Version','Source Reference','Steward Notes','Primary Capability ID','Supporting Capability IDs','Capability Requirement Summary','Outcomes to Advance','Responsible Persona IDs','Owning Organizational Unit','Decision / Approval IDs','Required Rule IDs').by(coalesce(values('Situation Type ID'), values('SituationTypeID'), values('SituationTypeId'), values('situation type id'), values('situationTypeID'), values('situationTypeId'), values('situation_type_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Situation Type Name'), values('SituationTypeName'), values('situation type name'), values('situationTypeName'), values('situation_type_name'), constant(''))).by(coalesce(values('Situation Category'), values('SituationCategory'), values('situation category'), values('situationCategory'), values('situation_category'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Primary Subject Concept ID'), values('PrimarySubjectConceptID'), values('PrimarySubjectConceptId'), values('primary subject concept id'), values('primarySubjectConceptID'), values('primarySubjectConceptId'), values('primary_subject_concept_id'), constant(''))).by(coalesce(values('Related Concept IDs'), values('RelatedConceptIds'), values('related concept ids'), values('relatedConceptIds'), values('related_concept_ids'), constant(''))).by(coalesce(values('Supporting Insight IDs'), values('SupportingInsightIds'), values('supporting insight ids'), values('supportingInsightIds'), values('supporting_insight_ids'), constant(''))).by(coalesce(values('Supporting Signal IDs'), values('SupportingSignalIds'), values('supporting signal ids'), values('supportingSignalIds'), values('supporting_signal_ids'), constant(''))).by(coalesce(values('Business Intent Goal IDs'), values('BusinessIntentGoalIds'), values('business intent goal ids'), values('businessIntentGoalIds'), values('business_intent_goal_ids'), constant(''))).by(coalesce(values('Outcome IDs at Risk or Within Reach'), values('OutcomeIdsAtRiskOrWithinReach'), values('outcome ids at risk or within reach'), values('outcomeIdsAtRiskOrWithinReach'), values('outcome_ids_at_risk_or_within_reach'), constant(''))).by(coalesce(values('Enterprise Priority Factors'), values('EnterprisePriorityFactors'), values('enterprise priority factors'), values('enterprisePriorityFactors'), values('enterprise_priority_factors'), constant(''))).by(coalesce(values('Plan Disposition Options'), values('PlanDispositionOptions'), values('plan disposition options'), values('planDispositionOptions'), values('plan_disposition_options'), constant(''))).by(coalesce(values('Composite Eligibility'), values('CompositeEligibility'), values('composite eligibility'), values('compositeEligibility'), values('composite_eligibility'), constant(''))).by(coalesce(values('Merge Duplicate Guidance'), values('MergeDuplicateGuidance'), values('merge duplicate guidance'), values('mergeDuplicateGuidance'), values('merge_duplicate_guidance'), constant(''))).by(coalesce(values('Lifecycle Vocabulary ID'), values('LifecycleVocabularyID'), values('LifecycleVocabularyId'), values('lifecycle vocabulary id'), values('lifecycleVocabularyID'), values('lifecycleVocabularyId'), values('lifecycle_vocabulary_id'), constant(''))).by(coalesce(values('Owning Capability ID'), values('OwningCapabilityID'), values('OwningCapabilityId'), values('owning capability id'), values('owningCapabilityID'), values('owningCapabilityId'), values('owning_capability_id'), constant(''))).by(coalesce(values('Relevant Persona IDs'), values('RelevantPersonaIds'), values('relevant persona ids'), values('relevantPersonaIds'), values('relevant_persona_ids'), constant(''))).by(coalesce(values('Default Plan Pattern IDs'), values('DefaultPlanPatternIds'), values('default plan pattern ids'), values('defaultPlanPatternIds'), values('default_plan_pattern_ids'), constant(''))).by(coalesce(values('Primary Store Technical Asset ID'), values('PrimaryStoreTechnicalAssetID'), values('PrimaryStoreTechnicalAssetId'), values('primary store technical asset id'), values('primaryStoreTechnicalAssetID'), values('primaryStoreTechnicalAssetId'), values('primary_store_technical_asset_id'), constant(''))).by(coalesce(values('Materialization Class'), values('MaterializationClass'), values('materialization class'), values('materializationClass'), values('materialization_class'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).by(coalesce(values('Source Reference'), values('SourceReference'), values('source reference'), values('sourceReference'), values('source_reference'), constant(''))).by(coalesce(values('Steward Notes'), values('StewardNotes'), values('steward notes'), values('stewardNotes'), values('steward_notes'), constant(''))).by(coalesce(values('Primary Capability ID'), values('PrimaryCapabilityID'), values('PrimaryCapabilityId'), values('primary capability id'), values('primaryCapabilityID'), values('primaryCapabilityId'), values('primary_capability_id'), constant(''))).by(coalesce(values('Supporting Capability IDs'), values('SupportingCapabilityIds'), values('supporting capability ids'), values('supportingCapabilityIds'), values('supporting_capability_ids'), constant(''))).by(coalesce(values('Capability Requirement Summary'), values('CapabilityRequirementSummary'), values('capability requirement summary'), values('capabilityRequirementSummary'), values('capability_requirement_summary'), constant(''))).by(coalesce(values('Outcomes to Advance'), values('OutcomesToAdvance'), values('outcomes to advance'), values('outcomesToAdvance'), values('outcomes_to_advance'), constant(''))).by(coalesce(values('Responsible Persona IDs'), values('ResponsiblePersonaIds'), values('responsible persona ids'), values('responsiblePersonaIds'), values('responsible_persona_ids'), constant(''))).by(coalesce(values('Owning Organizational Unit'), values('OwningOrganizationalUnit'), values('owning organizational unit'), values('owningOrganizationalUnit'), values('owning_organizational_unit'), constant(''))).by(coalesce(values('Decision Approval IDs'), values('DecisionApprovalIds'), values('decision approval ids'), values('decisionApprovalIds'), values('decision_approval_ids'), constant(''))).by(coalesce(values('Required Rule IDs'), values('RequiredRuleIds'), values('required rule ids'), values('requiredRuleIds'), values('required_rule_ids'), constant(''))).dedup()",
    "SHEET_11F_PLAN_PATTERNS_CONTEXT": "g.V().where(coalesce(values('Plan Pattern ID'), values('PlanPatternID'), values('PlanPatternId'), values('plan pattern id'), values('planPatternID'), values('planPatternId'), values('plan_pattern_id'), constant('')).is(neq(''))).project('Plan Pattern ID','Canonical ID','Plan Pattern Name','Pattern Type','Definition','Supported Situation Type IDs','Intended Outcome IDs','Owner','Status','Version').by(coalesce(values('Plan Pattern ID'), values('PlanPatternID'), values('PlanPatternId'), values('plan pattern id'), values('planPatternID'), values('planPatternId'), values('plan_pattern_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Plan Pattern Name'), values('PlanPatternName'), values('plan pattern name'), values('planPatternName'), values('plan_pattern_name'), constant(''))).by(coalesce(values('Pattern Type'), values('PatternType'), values('pattern type'), values('patternType'), values('pattern_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Supported Situation Type IDs'), values('SupportedSituationTypeIds'), values('supported situation type ids'), values('supportedSituationTypeIds'), values('supported_situation_type_ids'), constant(''))).by(coalesce(values('Intended Outcome IDs'), values('IntendedOutcomeIds'), values('intended outcome ids'), values('intendedOutcomeIds'), values('intended_outcome_ids'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_12_PERSONAS_CONTEXT": "g.V().where(coalesce(values('Persona ID'), values('PersonaID'), values('PersonaId'), values('persona id'), values('personaID'), values('personaId'), values('persona_id'), constant('')).is(neq(''))).project('Persona ID','Canonical ID','Persona Name','Persona Type','Business Definition','Primary Responsibilities','Business Goals','Status','Version').by(coalesce(values('Persona ID'), values('PersonaID'), values('PersonaId'), values('persona id'), values('personaID'), values('personaId'), values('persona_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Persona Name'), values('PersonaName'), values('persona name'), values('personaName'), values('persona_name'), constant(''))).by(coalesce(values('Persona Type'), values('PersonaType'), values('persona type'), values('personaType'), values('persona_type'), constant(''))).by(coalesce(values('Business Definition'), values('BusinessDefinition'), values('business definition'), values('businessDefinition'), values('business_definition'), constant(''))).by(coalesce(values('Primary Responsibilities'), values('PrimaryResponsibilities'), values('primary responsibilities'), values('primaryResponsibilities'), values('primary_responsibilities'), constant(''))).by(coalesce(values('Business Goals'), values('BusinessGoals'), values('business goals'), values('businessGoals'), values('business_goals'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_12A_PERSONA_EXPERIENCES_CONTEXT": "g.V().where(coalesce(values('Persona Experience ID'), values('PersonaExperienceID'), values('PersonaExperienceId'), values('persona experience id'), values('personaExperienceID'), values('personaExperienceId'), values('persona_experience_id'), constant('')).is(neq(''))).project('Persona Experience ID','Canonical ID','Experience Name','Persona ID','Experience Type','Business Definition','User Intent','Status','Version').by(coalesce(values('Persona Experience ID'), values('PersonaExperienceID'), values('PersonaExperienceId'), values('persona experience id'), values('personaExperienceID'), values('personaExperienceId'), values('persona_experience_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Experience Name'), values('ExperienceName'), values('experience name'), values('experienceName'), values('experience_name'), constant(''))).by(coalesce(values('Persona ID'), values('PersonaID'), values('PersonaId'), values('persona id'), values('personaID'), values('personaId'), values('persona_id'), constant(''))).by(coalesce(values('Experience Type'), values('ExperienceType'), values('experience type'), values('experienceType'), values('experience_type'), constant(''))).by(coalesce(values('Business Definition'), values('BusinessDefinition'), values('business definition'), values('businessDefinition'), values('business_definition'), constant(''))).by(coalesce(values('User Intent'), values('UserIntent'), values('user intent'), values('userIntent'), values('user_intent'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_12B_EXPERIENCE_COMPONENTS_CONTEXT": "g.V().where(coalesce(values('Experience Component ID'), values('ExperienceComponentID'), values('ExperienceComponentId'), values('experience component id'), values('experienceComponentID'), values('experienceComponentId'), values('experience_component_id'), constant('')).is(neq(''))).project('Experience Component ID','Canonical ID','Component Name','Component Type','Business Definition','Status','Version').by(coalesce(values('Experience Component ID'), values('ExperienceComponentID'), values('ExperienceComponentId'), values('experience component id'), values('experienceComponentID'), values('experienceComponentId'), values('experience_component_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Component Name'), values('ComponentName'), values('component name'), values('componentName'), values('component_name'), constant(''))).by(coalesce(values('Component Type'), values('ComponentType'), values('component type'), values('componentType'), values('component_type'), constant(''))).by(coalesce(values('Business Definition'), values('BusinessDefinition'), values('business definition'), values('businessDefinition'), values('business_definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_12C_EXPERIENCE_CONFIGURATIONS_CONTEXT": "g.V().where(coalesce(values('Experience Configuration ID'), values('ExperienceConfigurationID'), values('ExperienceConfigurationId'), values('experience configuration id'), values('experienceConfigurationID'), values('experienceConfigurationId'), values('experience_configuration_id'), constant('')).is(neq(''))).project('Experience Configuration ID','Canonical ID','Configuration Name','Status','Version').by(coalesce(values('Experience Configuration ID'), values('ExperienceConfigurationID'), values('ExperienceConfigurationId'), values('experience configuration id'), values('experienceConfigurationID'), values('experienceConfigurationId'), values('experience_configuration_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Configuration Name'), values('ConfigurationName'), values('configuration name'), values('configurationName'), values('configuration_name'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_12D_DECISIONS_INTERVENTIONS_CONTEXT": "g.V().where(coalesce(values('Decision Intervention ID'), values('DecisionInterventionID'), values('DecisionInterventionId'), values('decision intervention id'), values('decisionInterventionID'), values('decisionInterventionId'), values('decision_intervention_id'), constant('')).is(neq(''))).project('Decision Intervention ID','Canonical ID','Name','Record Type','Business Definition','Status','Version').by(coalesce(values('Decision Intervention ID'), values('DecisionInterventionID'), values('DecisionInterventionId'), values('decision intervention id'), values('decisionInterventionID'), values('decisionInterventionId'), values('decision_intervention_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Name'), values('name'), constant(''))).by(coalesce(values('Record Type'), values('RecordType'), values('record type'), values('recordType'), values('record_type'), constant(''))).by(coalesce(values('Business Definition'), values('BusinessDefinition'), values('business definition'), values('businessDefinition'), values('business_definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_12E_PERSONA_ORGANIZATION_MAP_CONTEXT": "g.V().where(coalesce(values('Organization Map ID'), values('OrganizationMapID'), values('OrganizationMapId'), values('organization map id'), values('organizationMapID'), values('organizationMapId'), values('organization_map_id'), constant('')).is(neq(''))).project('Organization Map ID','Canonical ID','Persona ID','Department','Status','Version').by(coalesce(values('Organization Map ID'), values('OrganizationMapID'), values('OrganizationMapId'), values('organization map id'), values('organizationMapID'), values('organizationMapId'), values('organization_map_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Persona ID'), values('PersonaID'), values('PersonaId'), values('persona id'), values('personaID'), values('personaId'), values('persona_id'), constant(''))).by(coalesce(values('Department'), values('department'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_13_SOURCE_SYSTEMS_CONTEXT": "g.V().where(coalesce(values('System ID'), values('SystemID'), values('SystemId'), values('system id'), values('systemID'), values('systemId'), values('system_id'), constant('')).is(neq(''))).project('System ID','Canonical ID','System Name','System Type','Definition','Authoritative For','Owner','Status','Version').by(coalesce(values('System ID'), values('SystemID'), values('SystemId'), values('system id'), values('systemID'), values('systemId'), values('system_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('System Name'), values('SystemName'), values('system name'), values('systemName'), values('system_name'), constant(''))).by(coalesce(values('System Type'), values('SystemType'), values('system type'), values('systemType'), values('system_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Authoritative For'), values('AuthoritativeFor'), values('authoritative for'), values('authoritativeFor'), values('authoritative_for'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_14_TECHNICAL_ASSETS_CONTEXT": "g.V().where(coalesce(values('Technical Asset ID'), values('TechnicalAssetID'), values('TechnicalAssetId'), values('technical asset id'), values('technicalAssetID'), values('technicalAssetId'), values('technical_asset_id'), constant('')).is(neq(''))).project('Technical Asset ID','Canonical ID','Asset Name','Asset Type','System ID','Definition','Status','Version').by(coalesce(values('Technical Asset ID'), values('TechnicalAssetID'), values('TechnicalAssetId'), values('technical asset id'), values('technicalAssetID'), values('technicalAssetId'), values('technical_asset_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Asset Name'), values('AssetName'), values('asset name'), values('assetName'), values('asset_name'), constant(''))).by(coalesce(values('Asset Type'), values('AssetType'), values('asset type'), values('assetType'), values('asset_type'), constant(''))).by(coalesce(values('System ID'), values('SystemID'), values('SystemId'), values('system id'), values('systemID'), values('systemId'), values('system_id'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_15_SEMANTIC_MAPPINGS_CONTEXT": "g.V().where(coalesce(values('Mapping ID'), values('MappingID'), values('MappingId'), values('mapping id'), values('mappingID'), values('mappingId'), values('mapping_id'), constant('')).is(neq(''))).project('Mapping ID','Canonical ID','Semantic Asset ID','Technical Asset ID','Mapping Type','Owner','Status','Version').by(coalesce(values('Mapping ID'), values('MappingID'), values('MappingId'), values('mapping id'), values('mappingID'), values('mappingId'), values('mapping_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Semantic Asset ID'), values('SemanticAssetID'), values('SemanticAssetId'), values('semantic asset id'), values('semanticAssetID'), values('semanticAssetId'), values('semantic_asset_id'), constant(''))).by(coalesce(values('Technical Asset ID'), values('TechnicalAssetID'), values('TechnicalAssetId'), values('technical asset id'), values('technicalAssetID'), values('technicalAssetId'), values('technical_asset_id'), constant(''))).by(coalesce(values('Mapping Type'), values('MappingType'), values('mapping type'), values('mappingType'), values('mapping_type'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_16_GOVERNANCE_CONTEXT": "g.V().where(coalesce(values('Governance ID'), values('GovernanceID'), values('GovernanceId'), values('governance id'), values('governanceID'), values('governanceId'), values('governance_id'), constant('')).is(neq(''))).project('Governance ID','Canonical ID','Name','Governance Type','Definition','Status','Version').by(coalesce(values('Governance ID'), values('GovernanceID'), values('GovernanceId'), values('governance id'), values('governanceID'), values('governanceId'), values('governance_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Name'), values('name'), constant(''))).by(coalesce(values('Governance Type'), values('GovernanceType'), values('governance type'), values('governanceType'), values('governance_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_17_PUBLICATION_QUEUE_CONTEXT": "g.V().where(coalesce(values('Change Set ID'), values('ChangeSetID'), values('ChangeSetId'), values('change set id'), values('changeSetID'), values('changeSetId'), values('change_set_id'), constant('')).is(neq(''))).project('Change Set ID','Canonical ID','Change Set Name','Status').by(coalesce(values('Change Set ID'), values('ChangeSetID'), values('ChangeSetId'), values('change set id'), values('changeSetID'), values('changeSetId'), values('change_set_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Change Set Name'), values('ChangeSetName'), values('change set name'), values('changeSetName'), values('change_set_name'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).dedup()",
    "SHEET_18_INDUSTRY_SOURCES_CONTEXT": "g.V().where(coalesce(values('Source Reference ID'), values('SourceReferenceID'), values('SourceReferenceId'), values('source reference id'), values('sourceReferenceID'), values('sourceReferenceId'), values('source_reference_id'), constant('')).is(neq(''))).project('Source Reference ID','Source Family','Evidence Level','Canonical ID').by(coalesce(values('Source Reference ID'), values('SourceReferenceID'), values('SourceReferenceId'), values('source reference id'), values('sourceReferenceID'), values('sourceReferenceId'), values('source_reference_id'), constant(''))).by(coalesce(values('Source Family'), values('SourceFamily'), values('source family'), values('sourceFamily'), values('source_family'), constant(''))).by(coalesce(values('Evidence Level'), values('EvidenceLevel'), values('evidence level'), values('evidenceLevel'), values('evidence_level'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).dedup()",
    "SHEET_19_INDUSTRY_TERM_CROSSWALK_CONTEXT": "g.V().where(coalesce(values('Crosswalk ID'), values('CrosswalkID'), values('CrosswalkId'), values('crosswalk id'), values('crosswalkID'), values('crosswalkId'), values('crosswalk_id'), constant('')).is(neq(''))).project('Crosswalk ID','GBS Semantic Asset ID','GBS Preferred Name','External Term / Path','Mapping Relation','Status','Canonical ID').by(coalesce(values('Crosswalk ID'), values('CrosswalkID'), values('CrosswalkId'), values('crosswalk id'), values('crosswalkID'), values('crosswalkId'), values('crosswalk_id'), constant(''))).by(coalesce(values('GBS Semantic Asset ID'), values('GbsSemanticAssetID'), values('GbsSemanticAssetId'), values('gbs semantic asset id'), values('gbsSemanticAssetID'), values('gbsSemanticAssetId'), values('gbs_semantic_asset_id'), constant(''))).by(coalesce(values('GBS Preferred Name'), values('GbsPreferredName'), values('gbs preferred name'), values('gbsPreferredName'), values('gbs_preferred_name'), constant(''))).by(coalesce(values('External Term Path'), values('ExternalTermPath'), values('external term path'), values('externalTermPath'), values('external_term_path'), constant(''))).by(coalesce(values('Mapping Relation'), values('MappingRelation'), values('mapping relation'), values('mappingRelation'), values('mapping_relation'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).dedup()",
    "SHEET_20_DESIGN_DECISIONS_OPEN_QUES_CONTEXT": "g.V().where(coalesce(values('Decision Question ID'), values('DecisionQuestionID'), values('DecisionQuestionId'), values('decision question id'), values('decisionQuestionID'), values('decisionQuestionId'), values('decision_question_id'), constant('')).is(neq(''))).project('Decision / Question ID','Area','Decision or Open Question','Status','Canonical ID').by(coalesce(values('Decision Question ID'), values('DecisionQuestionID'), values('DecisionQuestionId'), values('decision question id'), values('decisionQuestionID'), values('decisionQuestionId'), values('decision_question_id'), constant(''))).by(coalesce(values('Area'), values('area'), constant(''))).by(coalesce(values('Decision or Open Question'), values('DecisionOrOpenQuestion'), values('decision or open question'), values('decisionOrOpenQuestion'), values('decision_or_open_question'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).dedup()",
    "SHEET_21_OBSERVATORY_DIMENSIONS_CONTEXT": "g.V().where(coalesce(values('Dimension ID'), values('DimensionID'), values('DimensionId'), values('dimension id'), values('dimensionID'), values('dimensionId'), values('dimension_id'), constant('')).is(neq(''))).project('Dimension ID','Canonical ID','Dimension Name','Definition','Status','Version').by(coalesce(values('Dimension ID'), values('DimensionID'), values('DimensionId'), values('dimension id'), values('dimensionID'), values('dimensionId'), values('dimension_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Dimension Name'), values('DimensionName'), values('dimension name'), values('dimensionName'), values('dimension_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_22_SIGNAL_GUIDANCE_CONTEXT": "g.V().where(coalesce(values('Guidance ID'), values('GuidanceID'), values('GuidanceId'), values('guidance id'), values('guidanceID'), values('guidanceId'), values('guidance_id'), constant('')).is(neq(''))).project('Guidance ID','Canonical ID','Dimension ID','Guidance Category','What to Look For','Status','Version').by(coalesce(values('Guidance ID'), values('GuidanceID'), values('GuidanceId'), values('guidance id'), values('guidanceID'), values('guidanceId'), values('guidance_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Dimension ID'), values('DimensionID'), values('DimensionId'), values('dimension id'), values('dimensionID'), values('dimensionId'), values('dimension_id'), constant(''))).by(coalesce(values('Guidance Category'), values('GuidanceCategory'), values('guidance category'), values('guidanceCategory'), values('guidance_category'), constant(''))).by(coalesce(values('What to Look For'), values('WhatToLookFor'), values('what to look for'), values('whatToLookFor'), values('what_to_look_for'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_23_INSIGHT_FRAMEWORK_CONTEXT": "g.V().where(coalesce(values('Framework ID'), values('FrameworkID'), values('FrameworkId'), values('framework id'), values('frameworkID'), values('frameworkId'), values('framework_id'), constant('')).is(neq(''))).project('Framework ID','Canonical ID','Insight Classification','Purpose','Status','Version').by(coalesce(values('Framework ID'), values('FrameworkID'), values('FrameworkId'), values('framework id'), values('frameworkID'), values('frameworkId'), values('framework_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Insight Classification'), values('InsightClassification'), values('insight classification'), values('insightClassification'), values('insight_classification'), constant(''))).by(coalesce(values('Purpose'), values('purpose'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_24_SITUATION_DEFINITIONS_CONTEXT": "g.V().where(coalesce(values('Situation Type ID (Reference)'), values('SituationTypeIdReference'), values('situation type id (reference)'), values('situationTypeIdReference'), values('situation_type_id_reference'), constant('')).is(neq(''))).project('Situation Type ID (Reference)','Operating Guidance Name','Runtime Interpretation','Status').by(coalesce(values('Situation Type ID (Reference)'), values('SituationTypeIdReference'), values('situation type id (reference)'), values('situationTypeIdReference'), values('situation_type_id_reference'), constant(''))).by(coalesce(values('Operating Guidance Name'), values('OperatingGuidanceName'), values('operating guidance name'), values('operatingGuidanceName'), values('operating_guidance_name'), constant(''))).by(coalesce(values('Runtime Interpretation'), values('RuntimeInterpretation'), values('runtime interpretation'), values('runtimeInterpretation'), values('runtime_interpretation'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).dedup()",
    "SHEET_25_PLAYBOOKS_ACTIVITIES_CONTEXT": "g.V().where(coalesce(values('Playbook ID'), values('PlaybookID'), values('PlaybookId'), values('playbook id'), values('playbookID'), values('playbookId'), values('playbook_id'), constant('')).is(neq(''))).project('Playbook ID','Canonical ID','Playbook Name','Purpose','Status','Version').by(coalesce(values('Playbook ID'), values('PlaybookID'), values('PlaybookId'), values('playbook id'), values('playbookID'), values('playbookId'), values('playbook_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Playbook Name'), values('PlaybookName'), values('playbook name'), values('playbookName'), values('playbook_name'), constant(''))).by(coalesce(values('Purpose'), values('purpose'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_25A_ACTIVITY_PATTERNS_CONTEXT": "g.V().where(coalesce(values('Activity Pattern ID'), values('ActivityPatternID'), values('ActivityPatternId'), values('activity pattern id'), values('activityPatternID'), values('activityPatternId'), values('activity_pattern_id'), constant('')).is(neq(''))).project('Activity Pattern ID','Canonical ID','Activity Pattern Name','Purpose','Status','Version').by(coalesce(values('Activity Pattern ID'), values('ActivityPatternID'), values('ActivityPatternId'), values('activity pattern id'), values('activityPatternID'), values('activityPatternId'), values('activity_pattern_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Activity Pattern Name'), values('ActivityPatternName'), values('activity pattern name'), values('activityPatternName'), values('activity_pattern_name'), constant(''))).by(coalesce(values('Purpose'), values('purpose'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_26_PLAN_COMPOSITION_CONTEXT": "g.V().where(coalesce(values('Composition Rule ID'), values('CompositionRuleID'), values('CompositionRuleId'), values('composition rule id'), values('compositionRuleID'), values('compositionRuleId'), values('composition_rule_id'), constant('')).is(neq(''))).project('Composition Rule ID','Canonical ID','Rule Name','Status','Version').by(coalesce(values('Composition Rule ID'), values('CompositionRuleID'), values('CompositionRuleId'), values('composition rule id'), values('compositionRuleID'), values('compositionRuleId'), values('composition_rule_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Rule Name'), values('RuleName'), values('rule name'), values('ruleName'), values('rule_name'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_27_VALUE_CHAIN_FUNCTIONS_CONTEXT": "g.V().where(coalesce(values('Function ID'), values('FunctionID'), values('FunctionId'), values('function id'), values('functionID'), values('functionId'), values('function_id'), constant('')).is(neq(''))).project('Function ID','Canonical ID','Business Function Name','Definition','Status','Version').by(coalesce(values('Function ID'), values('FunctionID'), values('FunctionId'), values('function id'), values('functionID'), values('functionId'), values('function_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Business Function Name'), values('BusinessFunctionName'), values('business function name'), values('businessFunctionName'), values('business_function_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_28_ROLES_ASSIGNMENTS_CONTEXT": "g.V().where(coalesce(values('Role ID'), values('RoleID'), values('RoleId'), values('role id'), values('roleID'), values('roleId'), values('role_id'), constant('')).is(neq(''))).project('Role ID','Canonical ID','Role Name','Definition','Status','Version').by(coalesce(values('Role ID'), values('RoleID'), values('RoleId'), values('role id'), values('roleID'), values('roleId'), values('role_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Role Name'), values('RoleName'), values('role name'), values('roleName'), values('role_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_29_GUIDED_ACTIONS_WORKOPS_CONTEXT": "g.V().where(coalesce(values('Asset ID'), values('AssetID'), values('AssetId'), values('asset id'), values('assetID'), values('assetId'), values('asset_id'), constant('')).is(neq(''))).project('Asset ID','Canonical ID','Name','Asset Type','Definition','Status','Version').by(coalesce(values('Asset ID'), values('AssetID'), values('AssetId'), values('asset id'), values('assetID'), values('assetId'), values('asset_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Name'), values('name'), constant(''))).by(coalesce(values('Asset Type'), values('AssetType'), values('asset type'), values('assetType'), values('asset_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_30_OUTCOMES_LEARNING_CONTEXT": "g.V().where(coalesce(values('Asset ID'), values('AssetID'), values('AssetId'), values('asset id'), values('assetID'), values('assetId'), values('asset_id'), constant('')).is(neq(''))).project('Asset ID','Canonical ID','Name','Asset Type','Definition','Status','Version').by(coalesce(values('Asset ID'), values('AssetID'), values('AssetId'), values('asset id'), values('assetID'), values('assetId'), values('asset_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Name'), values('name'), constant(''))).by(coalesce(values('Asset Type'), values('AssetType'), values('asset type'), values('assetType'), values('asset_type'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_31_EVIDENCE_PROVENANCE_CONTEXT": "g.V().where(coalesce(values('Evidence Type ID'), values('EvidenceTypeID'), values('EvidenceTypeId'), values('evidence type id'), values('evidenceTypeID'), values('evidenceTypeId'), values('evidence_type_id'), constant('')).is(neq(''))).project('Evidence Type ID','Canonical ID','Evidence Type Name','Definition','Status','Version').by(coalesce(values('Evidence Type ID'), values('EvidenceTypeID'), values('EvidenceTypeId'), values('evidence type id'), values('evidenceTypeID'), values('evidenceTypeId'), values('evidence_type_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Evidence Type Name'), values('EvidenceTypeName'), values('evidence type name'), values('evidenceTypeName'), values('evidence_type_name'), constant(''))).by(coalesce(values('Definition'), values('definition'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_32_CLASSIFICATION_REFERENCE_CONTEXT": "g.V().where(coalesce(values('Classification ID'), values('ClassificationID'), values('ClassificationId'), values('classification id'), values('classificationID'), values('classificationId'), values('classification_id'), constant('')).is(neq(''))).project('Classification ID','Canonical ID','Classification Scheme','Value','Status','Version').by(coalesce(values('Classification ID'), values('ClassificationID'), values('ClassificationId'), values('classification id'), values('classificationID'), values('classificationId'), values('classification_id'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).by(coalesce(values('Classification Scheme'), values('ClassificationScheme'), values('classification scheme'), values('classificationScheme'), values('classification_scheme'), constant(''))).by(coalesce(values('Value'), values('value'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Version'), values('version'), constant(''))).dedup()",
    "SHEET_33_E2E_EXAMPLE_CONTEXT": "g.V().where(coalesce(values('Stage'), values('stage'), constant('')).is(neq(''))).project('Stage','Catalog Definition Used','Agent Operation','Example').by(coalesce(values('Stage'), values('stage'), constant(''))).by(coalesce(values('Catalog Definition Used'), values('CatalogDefinitionUsed'), values('catalog definition used'), values('catalogDefinitionUsed'), values('catalog_definition_used'), constant(''))).by(coalesce(values('Agent Operation'), values('AgentOperation'), values('agent operation'), values('agentOperation'), values('agent_operation'), constant(''))).by(coalesce(values('Example'), values('example'), constant(''))).dedup()",
    "SHEET_34_AGENT_SPECIFICATION_CONTEXT": "g.V().where(coalesce(values('Section'), values('section'), constant('')).is(neq(''))).project('Section','Instruction / Specification','Required Inputs','Required Output').by(coalesce(values('Section'), values('section'), constant(''))).by(coalesce(values('Instruction Specification'), values('InstructionSpecification'), values('instruction specification'), values('instructionSpecification'), values('instruction_specification'), constant(''))).by(coalesce(values('Required Inputs'), values('RequiredInputs'), values('required inputs'), values('requiredInputs'), values('required_inputs'), constant(''))).by(coalesce(values('Required Output'), values('RequiredOutput'), values('required output'), values('requiredOutput'), values('required_output'), constant(''))).dedup()",
    "SHEET_35_RUNTIME_EVIDENCE_CONTEXT_CONTEXT": "g.V().where(coalesce(values('Guidance ID'), values('GuidanceID'), values('GuidanceId'), values('guidance id'), values('guidanceID'), values('guidanceId'), values('guidance_id'), constant('')).is(neq(''))).project('Guidance ID','Guidance Area','Subject','Status','Canonical ID').by(coalesce(values('Guidance ID'), values('GuidanceID'), values('GuidanceId'), values('guidance id'), values('guidanceID'), values('guidanceId'), values('guidance_id'), constant(''))).by(coalesce(values('Guidance Area'), values('GuidanceArea'), values('guidance area'), values('guidanceArea'), values('guidance_area'), constant(''))).by(coalesce(values('Subject'), values('subject'), constant(''))).by(coalesce(values('Status'), values('status'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).dedup()",
    "SHEET_36_CATALOG_VALIDATION_CONTEXT": "g.V().where(coalesce(values('Check'), values('check'), constant('')).is(neq(''))).project('Check','Scope','Result','Severity').by(coalesce(values('Check'), values('check'), constant(''))).by(coalesce(values('Scope'), values('scope'), constant(''))).by(coalesce(values('Result'), values('result'), constant(''))).by(coalesce(values('Severity'), values('severity'), constant(''))).dedup()",
    "SHEET_37_SITUATION_PRIORITY_POLICY_CONTEXT": "g.V().where(coalesce(values('Policy ID'), values('PolicyID'), values('PolicyId'), values('policy id'), values('policyID'), values('policyId'), values('policy_id'), constant('')).is(neq(''))).project('Policy ID','Policy Name','Policy Status','Factor Type','Configured Weight','Owner','Canonical ID').by(coalesce(values('Policy ID'), values('PolicyID'), values('PolicyId'), values('policy id'), values('policyID'), values('policyId'), values('policy_id'), constant(''))).by(coalesce(values('Policy Name'), values('PolicyName'), values('policy name'), values('policyName'), values('policy_name'), constant(''))).by(coalesce(values('Policy Status'), values('PolicyStatus'), values('policy status'), values('policyStatus'), values('policy_status'), constant(''))).by(coalesce(values('Factor Type'), values('FactorType'), values('factor type'), values('factorType'), values('factor_type'), constant(''))).by(coalesce(values('Configured Weight'), values('ConfiguredWeight'), values('configured weight'), values('configuredWeight'), values('configured_weight'), constant(''))).by(coalesce(values('Owner'), values('owner'), constant(''))).by(coalesce(values('Canonical ID'), values('CanonicalID'), values('CanonicalId'), values('canonical id'), values('canonicalID'), values('canonicalId'), values('canonical_id'), values('uri'), constant(''))).dedup()",
    # Cross-context composite queries
    "CROSS_SEMANTIC_LINEAGE_FULL": "g.V().has('conceptId').project('concept','domain','attributes','rules','signals','insights').by(valueMap(true)).by(both('BELONGS_TO_DOMAIN','HAS_DOMAIN').valueMap(true).fold()).by(both('HAS_ATTRIBUTE','ATTRIBUTE_OF').valueMap(true).fold()).by(both('GOVERNED_BY_RULE','APPLIES_TO','INPUT_TO').valueMap(true).fold()).by(both('TRIGGERS','INDICATES','HAS_SIGNAL').valueMap(true).fold()).by(both('SUPPORTS_INSIGHT','HAS_INSIGHT','INFORMS').valueMap(true).fold())",
    "CROSS_RULE_SIGNAL_INSIGHT_CHAIN": "g.V().has('ruleId').project('rule','appliesTo','triggeredSignals','downstreamInsights').by(valueMap(true)).by(both('APPLIES_TO','GOVERNS').valueMap(true).dedup().fold()).by(both('TRIGGERS','DERIVES_SIGNAL').valueMap(true).dedup().fold()).by(both('SUPPORTS_INSIGHT','INFORMS_INSIGHT').valueMap(true).dedup().fold())",
    "CROSS_SIGNAL_EVIDENCE_CONTEXT": "g.V().has('signalId').project('signal','subjectConcept','evidenceConcepts','evidenceAttributes','rules','freshness','confidence').by(valueMap(true)).by(both('SUBJECT_OF','FOR_CONCEPT').valueMap(true).fold()).by(both('EVIDENCED_BY_CONCEPT','SUPPORTED_BY_CONCEPT').valueMap(true).fold()).by(both('EVIDENCED_BY_ATTRIBUTE','SUPPORTED_BY_ATTRIBUTE').valueMap(true).fold()).by(both('TRIGGERED_BY_RULE','RULE_FOR_SIGNAL').valueMap(true).fold()).by(coalesce(values('freshnessRequirement'), values('freshnessExpiration'), constant(''))).by(coalesce(values('confidenceRequirement'), values('confidenceTreatment'), constant('')))",
    "CROSS_INSIGHT_GOVERNANCE_CONTEXT": "g.V().has('insightId').project('insight','supportingSignals','supportingEvents','interpretationRules','capabilities','outcomes','personaRelevance').by(valueMap(true)).by(both('SUPPORTED_BY_SIGNAL','SIGNAL_FOR_INSIGHT').valueMap(true).fold()).by(both('SUPPORTED_BY_EVENT','EVENT_FOR_INSIGHT').valueMap(true).fold()).by(both('INTERPRETED_BY_RULE','RULE_FOR_INSIGHT').valueMap(true).fold()).by(both('PRODUCED_BY_CAPABILITY','APPLICABLE_TO_CAPABILITY').valueMap(true).fold()).by(both('AFFECTS_OUTCOME','DRIVES_OUTCOME').valueMap(true).fold()).by(coalesce(values('personaRelevance'), values('personaIds'), constant('')))",
    "CROSS_CONTROLLED_VOCAB_CONTEXT": "g.V().has('controlledVocabularyId').project('vocabulary','values','attributes','rules','signals','insights').by(valueMap(true)).by(out('HAS_VALUE').valueMap(true).fold()).by(in('USES_VOCABULARY').valueMap(true).fold()).by(in('GOVERNS_RULE').valueMap(true).fold()).by(in('GOVERNS_SIGNAL').valueMap(true).fold()).by(in('GOVERNS_INSIGHT').valueMap(true).fold())",
    "CROSS_CAPABILITY_PROCESS_ACTION_MAP": "g.V().has('capabilityId').project('capability','processActions','playbooks','guidedActions','outcomes','roles').by(valueMap(true)).by(both('ENABLES_PROCESS','USES_PROCESS').valueMap(true).fold()).by(both('USES_PLAYBOOK','PLAYBOOK_FOR').valueMap(true).fold()).by(both('EMITS_GUIDED_ACTION','GUIDED_ACTION_FOR').valueMap(true).fold()).by(both('TARGETS_OUTCOME','OUTCOME_FOR').valueMap(true).fold()).by(both('OWNED_BY_ROLE','ROLE_FOR').valueMap(true).fold())",
    "CROSS_RUNTIME_EVIDENCE_AND_PROVENANCE": "g.V().has('sourceSystemId').project('sourceSystem','technicalAssets','runtimeEvidence','provenance','publicationQueue').by(valueMap(true)).by(both('BACKED_BY_TECH_ASSET','TECH_ASSET_FOR').valueMap(true).fold()).by(both('EMITS_RUNTIME_EVIDENCE','RUNTIME_EVIDENCE_FOR').valueMap(true).fold()).by(both('HAS_PROVENANCE','PROVENANCE_FOR').valueMap(true).fold()).by(both('PUBLISHES_TO_QUEUE','QUEUE_FOR').valueMap(true).fold())",
    "CROSS_PRIORITY_POLICY_CONTEXT": "g.V().has('situationTypeId').project('situationType','priorityPolicy','dimensions','rules','thresholds','classification').by(valueMap(true)).by(both('PRIORITIZED_BY_POLICY','POLICY_FOR').valueMap(true).fold()).by(both('USES_DIMENSION','DIMENSION_FOR').valueMap(true).fold()).by(both('GOVERNED_BY_RULE','RULE_FOR').valueMap(true).fold()).by(both('USES_THRESHOLD','THRESHOLD_FOR').valueMap(true).fold()).by(both('CLASSIFIED_AS','CLASSIFIES').valueMap(true).fold())",
    # Business semantic graph traversals — insight/signal to guidance/dimension/concept chains
    "CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN": "g.V().hasLabel('InsightType').as('insight').bothE().as('r0').otherV().has('signalId').as('signal').match(__.as('signal').bothE().as('r1').otherV().has('ruleId').as('rule'),__.as('rule').bothE().as('r2').otherV().has('guidanceId').as('guidance'),__.as('guidance').bothE().as('r3').otherV().has('dimensionId').as('dimension'),__.as('dimension').bothE().as('r4').otherV().has('conceptId').as('concept')).select('insight','r0','signal','r1','rule','r2','guidance','r3','dimension','r4','concept').by(valueMap('preferredName','definition','insightId','confidenceRequirement')).by(label()).by(valueMap('preferredName','definition','signalId','severity','confidenceRequirement')).by(label()).by(valueMap('name','definition','ruleId','ruleType','deterministic','overrideAllowed')).by(label()).by(valueMap('preferredName','guidanceId','guidanceCategory','whatToLookFor','evidenceRequirement','cautions','exclusionsCautions')).by(label()).by(valueMap('preferredName','definition','dimensionId','coreBusinessQuestions')).by(label()).by(valueMap('preferredName','definition','conceptId'))",
    "CROSS_SIGNAL_GUIDANCE_CHAIN": "g.V().has('signalId').as('signal').match(__.as('signal').bothE().as('r1').otherV().has('ruleId').as('rule'),__.as('rule').bothE().as('r2').otherV().has('guidanceId').as('guidance'),__.as('guidance').bothE().as('r3').otherV().has('dimensionId').as('dimension'),__.as('dimension').bothE().as('r4').otherV().has('conceptId').as('concept')).select('signal','r1','rule','r2','guidance','r3','dimension','r4','concept').by(valueMap('preferredName','definition','signalId','severity','confidenceRequirement')).by(label()).by(valueMap('name','definition','ruleId','ruleType','deterministic','overrideAllowed')).by(label()).by(valueMap('preferredName','guidanceId','guidanceCategory','whatToLookFor','evidenceRequirement','cautions','exclusionsCautions')).by(label()).by(valueMap('preferredName','definition','dimensionId','coreBusinessQuestions')).by(label()).by(valueMap('preferredName','definition','conceptId'))",
    # Business Planner governed-definition traversals. These are fixed,
    # allowlisted reads; caller hints are never interpolated into Gremlin.
    "BIZPLANNER_APPLICABLE_PLAN_PATTERNS": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').bothE('SUPPORTS_SITUATION').as('r1').otherV().hasLabel('PlanPattern').as('planPattern')).select('situationType','r1','planPattern').by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    "BIZPLANNER_PLAN_COMPOSITION_RULE": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').bothE().as('r1').otherV().hasLabel('PlanPattern').as('planPattern'),__.as('planPattern').bothE().as('r2').otherV().hasLabel('PlanCompositionRule').as('rule')).select('situationType','r1','planPattern','r2','rule').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    "BIZPLANNER_APPLICABLE_PLAYBOOKS": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').bothE('APPLICABLE_TO_SITUATION').as('r1').otherV().hasLabel('Playbook').as('playbook')).select('situationType','r1','playbook').by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    "BIZPLANNER_ACTIVITY_PATTERNS": "g.V().hasLabel('Playbook').as('playbook').match(__.as('playbook').outE('USES_ACTIVITY_PATTERN').as('r1').inV().hasLabel('ActivityPattern').as('activityPattern')).select('playbook','r1','activityPattern').by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    "BIZPLANNER_ACTION_GOVERNANCE": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').inE('APPLICABLE_TO_SITUATION').as('r1').outV().hasLabel('Playbook').as('playbook'),__.as('playbook').outE('USES_ACTIVITY_PATTERN').as('r2').inV().hasLabel('ActivityPattern').as('activity'),__.as('activity').outE('REQUIRES_CAPABILITY').as('r3').inV().hasLabel('BusinessCapability').as('capability'),__.as('capability').bothE('PERSONA_PERFORMING','PERSONA_SUPPORTED','SUPPORTS_CAPABILITY').as('r4').otherV().hasLabel('Persona').as('persona')).select('situationType','r1','playbook','r2','activity','r3','capability','r4','persona').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    # Joined on the shared BusinessProcess, not on the shared role.
    #
    # The previous version matched ActivityPattern -ASSIGNED_TO_ROLE-> RoleAssignment
    # <-REQUIRES_ROLE- GuidedAction, so every action needing ROLE-001 matched every
    # activity assigned ROLE-001. Asking for the Guided Actions of ACTP-001 ("Assess
    # Renewal Context") returned GA-009..GA-012 — product-expansion, opportunity and
    # workforce actions — and no renewal action at all. A role is who may act, not
    # what the action implements.
    #
    # REFERENCES_PROCESS is the action bridge, and it was already in the graph.
    # Verified against the live cluster: ACTP-003 -> GA-001, ACTP-001 -> GA-002,
    # ACTP-002 -> GA-002/003/004, ACTP-004 -> none. That matches the v6 workbook's
    # Referenced Process / Action ID column exactly.
    #
    # Role and persona are folded sub-traversals, NOT inner joins. Joining through
    # them drops rows two ways: ROLE-005 and ROLE-007 carry no RELATED_TO_PERSONA
    # edge, so their actions vanish entirely; and filtering to one persona hides the
    # governed answer "this activity's action belongs to a different persona".
    # ACTP-001's only action is GA-002, which requires ROLE-002 / PER-012 — an empty
    # result would have read as "no action exists" rather than "not this persona's".
    # The planner needs the action plus who may perform it, and decides actionability
    # itself.
    #
    # dedup is on the ('activity','action') PAIR. Deduping on the action alone
    # collapses GA-001 to a single row when it legitimately serves ACTP-003, ACTP-005
    # and ACTP-006, silently losing two mappings.
    #
    # The projection is deliberately narrow. valueMap(true) returned every property
    # including full definition prose, which exhausted the 60 KB planner budget after
    # five rows; these ten fields carry all 30 governed pairs in about 4 KB.
    # permittedDispositions and completionEvidence are the two fields that decide
    # whether the planner can emit a Guided Action at all: without them it discards
    # the action rather than inventing governed action states. They are folded so a
    # missing value comes back as [] — an honest "not established" — rather than
    # collapsing the whole row.
    "BIZPLANNER_PERSONA_ACTIONS": "g.V().hasLabel('ActivityPattern').as('activity').out('REFERENCES_PROCESS').in('REFERENCES_PROCESS').hasLabel('GuidedAction').as('action').dedup('activity','action').project('activityPatternId','guidedActionId','guidedActionName','permittedDispositions','completionEvidence','requiredRoleIds','personaIds','assetType','triggerApplicability','workspaceTemplateId','workspaceTemplate','status','version').by(select('activity').values('activityPatternId')).by(select('action').values('assetId')).by(select('action').values('preferredName')).by(select('action').values('permittedDispositions').dedup().fold()).by(select('action').values('completionEvidence').fold()).by(select('action').out('REQUIRES_ROLE').values('roleId').dedup().fold()).by(select('action').out('REQUIRES_ROLE').out('RELATED_TO_PERSONA').values('personaId').dedup().fold()).by(coalesce(select('action').values('assetType'),constant(''))).by(coalesce(select('action').values('triggerApplicability'),constant(''))).by(coalesce(select('action').out('USES_WORKSPACE_TEMPLATE').values('workspaceTemplateId'),constant(''))).by(coalesce(select('action').out('USES_WORKSPACE_TEMPLATE').values('templateName'),constant(''))).by(coalesce(select('action').values('status'),constant(''))).by(coalesce(select('action').values('version'),constant(''))).limit(200)",
    "BIZPLANNER_PLAN_DEPENDENCIES": "g.V().hasLabel('PlanPattern').as('planPattern').match(__.as('planPattern').outE('TRIGGERS').as('r1').inV().hasLabel('DecisionIntervention').as('decision'),__.as('decision').outE('USES','USES_ATTRIBUTE','USES_SIGNAL','APPLIES_CALCULATION','RESULTS_IN_ACTION').as('r2').inV().as('target')).select('planPattern','r1','decision','r2','target').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    "BIZPLANNER_EXISTING_PLAN": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').outE('RECOMMENDS').as('r1').inV().hasLabel('PlanPattern').as('planPattern'),__.as('situationType').inE('APPLICABLE_TO_SITUATION').as('r2').outV().hasLabel('PlanCompositionRule').as('rule'),__.as('rule').outE('REFERENCES_PLAN_PATTERN').as('r3').inV().hasLabel('PlanPattern').as('referencePlanPattern'),__.as('rule').outE('COMPOSES_PLAYBOOK').as('r4').inV().hasLabel('Playbook').as('playbook')).select('situationType','r1','planPattern','r2','rule','r3','referencePlanPattern','r4','playbook').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",
    "BIZPLANNER_MATERIAL_CHANGES": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').outE('RECOMMENDS').as('r1').inV().hasLabel('PlanPattern').as('planPattern'),__.as('planPattern').outE('TRIGGERS').as('r2').inV().hasLabel('DecisionIntervention').as('decision'),__.as('decision').outE('CHANGE_SET').as('r3').inV().hasLabel('ChangeSet').as('changeSet')).select('situationType','r1','planPattern','r2','decision','r3','changeSet').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).limit(200)",

    # Situation Analyzer Agent — plan/playbook/activity/governance traversals
    # getApplicablePlanPatterns(situationType) — SituationType → PlanPattern via SUPPORTS_SITUATION
    "SITUATION_APPLICABLE_PLAN_PATTERNS": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').bothE('SUPPORTS_SITUATION').as('r1').otherV().hasLabel('PlanPattern').as('planPattern')).select('situationType','r1','planPattern').by(valueMap(true)).by(label()).by(valueMap(true))",
    # getPlanCompositionRule(situationType) — SituationType → PlanPattern → PlanCompositionRule
    "SITUATION_PLAN_COMPOSITION_RULE": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').bothE().as('r1').otherV().hasLabel('PlanPattern').as('planPattern'),__.as('planPattern').bothE().as('r2').otherV().hasLabel('PlanCompositionRule').as('rule')).select('situationType','r1','planPattern','r2','rule').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true))",
    # getApplicablePlaybooks(situation, signals, insights) — SituationType → Playbook via APPLICABLE_TO_SITUATION
    "SITUATION_APPLICABLE_PLAYBOOKS": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').bothE('APPLICABLE_TO_SITUATION').as('r1').otherV().hasLabel('Playbook').as('playbook')).select('situationType','r1','playbook').by(valueMap(true)).by(label()).by(valueMap(true))",
    # getActivityPatterns(playbook) — Playbook → ActivityPattern via USES_ACTIVITY_PATTERN
    "SITUATION_ACTIVITY_PATTERNS": "g.V().hasLabel('Playbook').as('playbook').match(__.as('playbook').outE('USES_ACTIVITY_PATTERN').as('r1').inV().hasLabel('ActivityPattern').as('activityPattern')).select('playbook','r1','activityPattern').by(valueMap(true)).by(label()).by(valueMap(true))",
    # getActionGovernance(activity) — SituationType → Playbook → ActivityPattern → BusinessCapability → Persona
    "SITUATION_ACTION_GOVERNANCE": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').inE('APPLICABLE_TO_SITUATION').as('r1').outV().hasLabel('Playbook').as('playbook'),__.as('playbook').outE('USES_ACTIVITY_PATTERN').as('r2').inV().hasLabel('ActivityPattern').as('activity'),__.as('activity').outE('REQUIRES_CAPABILITY').as('r3').inV().hasLabel('BusinessCapability').as('capability'),__.as('capability').bothE('PERSONA_PERFORMING').as('r4').otherV().hasLabel('Persona').as('persona')).select('situationType','r1','playbook','r2','activity','r3','capability','r4','persona').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true))",
    # getPlanDependencies(plan) — PlanPattern → DecisionIntervention → downstream targets
    "SITUATION_PLAN_DEPENDENCIES": "g.V().hasLabel('PlanPattern').as('planPattern').match(__.as('planPattern').outE('TRIGGERS').as('r1').inV().hasLabel('DecisionIntervention').as('decision'),__.as('decision').outE('USES','USES_ATTRIBUTE','USES_SIGNAL','APPLIES_CALCULATION','RESULTS_IN_ACTION').as('r2').inV().as('target')).select('planPattern','r1','decision','r2','target').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true))",
    # getExistingPlan(situation) — SituationType → PlanPattern + PlanCompositionRule → Playbook
    "SITUATION_EXISTING_PLAN": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').outE('RECOMMENDS').as('r1').inV().hasLabel('PlanPattern').as('planPattern'),__.as('situationType').inE('APPLICABLE_TO_SITUATION').as('r2').outV().hasLabel('PlanCompositionRule').as('rule'),__.as('rule').outE('REFERENCES_PLAN_PATTERN').as('r3').inV().hasLabel('PlanPattern').as('referencePlanPattern'),__.as('rule').outE('COMPOSES_PLAYBOOK').as('r4').inV().hasLabel('Playbook').as('playbook')).select('situationType','r1','planPattern','r2','rule','r3','referencePlanPattern','r4','playbook').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true))",
    # getMaterialChanges(situation, since) — SituationType → PlanPattern → DecisionIntervention → ChangeSet
    "SITUATION_MATERIAL_CHANGES": "g.V().hasLabel('SituationType').as('situationType').match(__.as('situationType').outE('RECOMMENDS').as('r1').inV().hasLabel('PlanPattern').as('planPattern'),__.as('planPattern').outE('TRIGGERS').as('r2').inV().hasLabel('DecisionIntervention').as('decision'),__.as('decision').outE('CHANGE_SET').as('r3').inV().hasLabel('ChangeSet').as('changeSet')).select('situationType','r1','planPattern','r2','decision','r3','changeSet').by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true)).by(label()).by(valueMap(true))",
    # getSituationSupportingSignalInsight() — SituationType plus related InsightType/signal vertices
    "SITUATION_SUPPORTING_SIGNAL_INSIGHT": "g.V().hasLabel('SituationType').project('situation','target').by(valueMap('preferredName','definition','situationId')).by(__.bothE().as('r1').otherV().or(__.hasLabel('InsightType'),__.has('signalId')).project('r1','type','data').by(select('r1').label()).by(label()).by(elementMap()).fold())",

    # getDocumentTemplateForGuidedAction() — tab 42 "Guided Action Workspaces".
    # Resolves the Workspace Template a Guided Action produces, which is what the
    # Document Generator needs to know WHICH document to generate.
    #
    # Traverses the USES_WORKSPACE_TEMPLATE edge rather than filtering on the
    # register's "Supported Guided Action IDs" cell. That cell mixes typed ids
    # with prose — WST-003 reads "GA-001; GA-007; GA-022 and other governed
    # outreach Guided Actions" — and matching prose would make "and other
    # governed outreach Guided Actions" behave as a wildcard. The edges carry the
    # same mapping without the ambiguity.
    #
    # The GuidedAction short id lives in `assetId` (see BIZPLANNER_PERSONA_ACTIONS,
    # which reads it the same way); `guidedActionId` is not a property on these
    # nodes. `_PLANNER_FILTERS["action"]` lists both so the scope filter binds.
    #
    # `.as('action')` is required: _scope_planner_query injects the exact-ID
    # predicate at that marker. Without it the traversal returns every Guided
    # Action's template rather than the one asked for.
    "DOCGENERATOR_GUIDED_ACTION_TEMPLATE_MAPPING": "g.V().hasLabel('GuidedAction').as('action').out('USES_WORKSPACE_TEMPLATE').as('template').project('guidedActionId','guidedActionName','workspaceTemplateId','canonicalId','templateName','contentType','status','version').by(coalesce(select('action').values('assetId'),constant(''))).by(coalesce(select('action').values('preferredName'),constant(''))).by(coalesce(select('template').values('workspaceTemplateId'),constant(''))).by(coalesce(select('template').values('canonicalId'),constant(''))).by(coalesce(select('template').values('templateName'),constant(''))).by(coalesce(select('template').values('contentType'),constant(''))).by(coalesce(select('template').values('status'),constant(''))).by(coalesce(select('template').values('version'),constant('')))",
}

# ---------------------------------------------------------------------------
# Content Type (VOC-071) resolution — tab 42, column "Content Type (VOC-071)"
#
# TODO(catalog-load): DELETE THIS MAP once `contentType` is loaded onto the
# GuidedActionWorkspaceTemplate nodes. It duplicates one catalog column and can
# therefore drift from tab 42 silently.
#
# It exists because the column is published in the catalog but is NOT in the
# graph. The nodes carry `templateName` and `canonicalId` only — see
# NEPTUNE_LOAD_SPEC_BUSINESS_PLANNER.md §2.3, which already requests the missing
# `workspaceTemplateId` for the same three nodes. Load `contentType` in the same
# change and this map goes away: the traversal above already projects the
# property, so it starts returning the real value the moment it exists, and
# _apply_content_type() below only fills a blank.
#
# Keyed on canonicalId because that IS loaded and is a stable governed urn.
# templateName is prose and can be reworded without a version bump; the short
# WST id is not loaded at all.
_CANONICAL_ID_TO_CONTENT_TYPE: Dict[str, str] = {
    "urn:gbs:workspace-template:planning:situation-strategy": "STRATEGY_RECOMMENDATION",
    "urn:gbs:workspace-template:stewardship:strategic-review": "STRATEGIC_REVIEW",
    "urn:gbs:workspace-template:engagement:outreach-talking-points": "TALKING_POINTS",
    "urn:gbs:workspace-template:engagement:strategy-alignment-meeting": "MEETING_PREPARATION",
}


def _apply_content_type(rows: List[Any]) -> List[Any]:
    """Fill a blank `contentType` from the canonicalId map. Never overwrites.

    A value already on the node is authoritative — that is the post-load state,
    and this must not shadow it. Rows whose canonicalId is unknown keep an empty
    contentType rather than guessing: an unmapped template is a catalog gap the
    caller has to see, not something to paper over.
    """
    for row in rows:
        if not isinstance(row, dict) or row.get("contentType"):
            continue
        canonical = str(row.get("canonicalId", "") or "").strip().lower()
        mapped = _CANONICAL_ID_TO_CONTENT_TYPE.get(canonical)
        if mapped:
            row["contentType"] = mapped
        else:
            logger.warning(
                "No content type for workspace template canonicalId=%r — "
                "tab 42 may have gained a row that _CANONICAL_ID_TO_CONTENT_TYPE "
                "does not carry",
                canonical or "(none)",
            )
    return rows

# ---------------------------------------------------------------------------
# Intent → query bundle mapping
# Includes both canonical names and Insight Agent handoff aliases.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Query Template Registry — versioned metadata per query ID.
# Keeps query Gremlin text in _QUERY_LIBRARY above; only metadata lives here.
# To disable a query at runtime without code change, set status to "disabled".
# ---------------------------------------------------------------------------

_QUERY_METADATA: Dict[str, Dict[str, Any]] = {
    qid: {
        "version": "v1",
        "status": "active",          # "active" | "disabled"
        "max_rows_default": 50,      # per-query row cap when no per-query override set
        "timeout_ms_default": 4000,  # per-query timeout hint
    }
    for qid in _QUERY_LIBRARY
}


# ---------------------------------------------------------------------------
# Helpers operating on _QUERY_METADATA / _QUERY_LIBRARY
# ---------------------------------------------------------------------------

def _active_query_ids() -> List[str]:
    """Return all query IDs from _QUERY_LIBRARY whose status is 'active' in
    _QUERY_METADATA, preserving _QUERY_LIBRARY insertion order (deterministic)."""
    return [
        qid for qid in _QUERY_LIBRARY
        if _QUERY_METADATA.get(qid, {}).get("status", "active") == "active"
    ]


def _build_insight_full_coverage_intent_map() -> Dict[str, List[str]]:
    """Build a full-coverage intent map from _INTENT_QUERY_MAP, retaining only
    active query IDs.  Called once at module import; result is stored in the
    insight-agent-v0 policy entry so the policy is deterministic at runtime."""
    result: Dict[str, List[str]] = {}
    for intent_key, qids in _INTENT_QUERY_MAP.items():
        active = [
            q for q in qids
            if _QUERY_METADATA.get(q, {}).get("status", "active") == "active"
        ]
        if active:
            result[intent_key] = active
    return result


def _dedupe_rows(rows: List[Any]) -> List[Any]:
    """Remove duplicate rows from a query result list.
    Dict rows are compared by JSON-serialised canonical form (sort_keys=True).
    Non-serialisable rows fall back to repr()-based deduplication."""
    seen: set = set()
    out: List[Any] = []
    for row in rows:
        try:
            key = json.dumps(row, sort_keys=True, default=str)
        except Exception:
            key = repr(row)
        if key not in seen:
            seen.add(key)
            out.append(row)
    return out


def _with_row_limit(gremlin_query: str, max_rows: int) -> str:
    """Apply the row cap before wide projection when the traversal permits it."""
    without_terminal_limit = re.sub(r"\.limit\(\d+\)\s*$", "", gremlin_query)
    projection_positions = [
        position for position in (
            without_terminal_limit.rfind(".select("),
            without_terminal_limit.find(".project("),
        )
        if position >= 0
    ]
    if projection_positions:
        position = min(projection_positions)
        return (
            f"{without_terminal_limit[:position]}.limit({max_rows})"
            f"{without_terminal_limit[position:]}"
        )
    return f"{without_terminal_limit}.limit({max_rows})"


_PLANNER_ID_PATTERN = re.compile(
    r"\b(?:SIT|OUT|PLANPAT|PCR|PB|ACTP|PER|GA|WST)-[A-Z0-9][A-Z0-9_-]*\b",
    re.IGNORECASE,
)
_PLANNER_FILTERS = {
    "situationType": (
        "SIT-",
        ("situationTypeId", "Situation Type ID", "SituationTypeID", "SituationTypeId"),
    ),
    "outcome": (
        "OUT-",
        ("outcomeId", "Outcome ID", "OutcomeID", "OutcomeId"),
    ),
    "planPattern": (
        "PLANPAT-",
        ("planPatternId", "Plan Pattern ID", "PlanPatternID", "PlanPatternId"),
    ),
    "playbook": (
        "PB-",
        ("playbookId", "Playbook ID", "PlaybookID", "PlaybookId"),
    ),
    "activity": (
        "ACTP-",
        ("activityPatternId", "Activity Pattern ID", "ActivityPatternID", "ActivityPatternId"),
    ),
    "persona": (
        "PER-",
        ("personaId", "Persona ID", "PersonaID", "PersonaId"),
    ),
    # `assetId` is first because it is the property GuidedAction nodes actually
    # carry the GA- short id on (confirmed against the cluster — see
    # NEPTUNE_LOAD_SPEC_BUSINESS_PLANNER.md §1). The remaining spellings are kept
    # for other labels and for a future load that adds an explicit column.
    "action": (
        "GA-",
        ("assetId", "guidedActionId", "Guided Action ID", "GuidedActionID", "GuidedActionId"),
    ),
}
_PLANNER_INTENT_FILTER_ALIASES = {
    "get_situation_type_definition": ("situationType",),
    "get_outcome_definitions": ("outcome",),
    "get_applicable_plan_patterns": ("situationType",),
    "get_plan_composition_rule": ("situationType", "planPattern"),
    "get_applicable_playbooks": ("situationType",),
    "get_activity_patterns": ("playbook",),
    "get_action_governance": ("activity",),
    # Document Generator: the Guided Action is the only scope, and it is required.
    # Unscoped, DOCGENERATOR_GUIDED_ACTION_TEMPLATE_MAPPING returns every action's
    # template and the caller would take the first as "the" answer.
    "get_document_template": ("action",),
    # Persona is deliberately not a graph-level filter here. BIZPLANNER_PERSONA_ACTIONS
    # returns each action's required roles and personas as folded values instead, so
    # the planner can tell "no action implements this activity" from "the action
    # belongs to another persona". Filtering in the traversal collapses those two
    # into an empty result.
    "get_persona_actions": ("activity", "action"),
    "get_plan_dependencies": ("planPattern",),
    "get_existing_plan": ("situationType", "planPattern"),
    "get_material_changes": ("situationType", "planPattern"),
}


# Structured hint keys that carry a governed *name* rather than an ID. Names are
# read ONLY from these keys, never parsed out of the free-text task: prose parsing
# would make the injection surface the whole task string, and a mis-parsed clause
# would silently scope the traversal to the wrong persona.
_PLANNER_NAME_FILTERS = {
    "persona": (
        ("persona_name", "personaName"),
        ("personaName", "Persona Name", "PersonaName", "preferredName", "Preferred Name"),
    ),
}

# A governed name is interpolated into Gremlin, so the accepted charset is
# deliberately narrower than "any string": letters, digits and a short list of
# separators seen in role/persona labels. Quotes, backslashes and parentheses are
# rejected outright rather than escaped — this module's contract is zero injection
# surface, and an escaping bug is a silent breach of it.
_PLANNER_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._&/-]{0,63}$")

# Policies whose traversals begin at an unfiltered g.V().hasLabel(...) and are
# therefore only meaningful once an exact-ID filter has been pushed in. For these,
# an ask that binds no filter is denied rather than answered with the whole label
# — see the scope gate in fetch_catalog_context.
_SCOPE_ENFORCED_POLICY_KEYS = frozenset({"business-planner-v1", "docgenerator-agent-v0"})


def _extract_planner_ids(query_text: str, hints: Optional[Dict[str, Any]]) -> List[str]:
    """Extract only syntactically safe governed IDs from planner inputs."""
    hint_text = json.dumps(hints or {}, default=str)
    return list(dict.fromkeys(match.upper() for match in _PLANNER_ID_PATTERN.findall(
        f"{query_text or ''} {hint_text}"
    )))


def _extract_planner_names(alias: str, hints: Optional[Dict[str, Any]]) -> List[str]:
    """Return validated governed names supplied under structured hint keys."""
    hint_keys, _ = _PLANNER_NAME_FILTERS.get(alias, ((), ()))
    if not hint_keys or not isinstance(hints, dict):
        return []
    names: List[str] = []
    for hint_key in hint_keys:
        value = hints.get(hint_key)
        if not isinstance(value, str):
            continue
        candidate = value.strip()
        if not _PLANNER_NAME_PATTERN.match(candidate):
            if candidate:
                logger.warning(
                    "Rejected planner %s name hint that failed the safe-name pattern", alias,
                )
            continue
        if candidate not in names:
            names.append(candidate)
    return names


def _id_predicate(property_names: tuple[str, ...], identifiers: List[str]) -> str:
    values = ",".join(f"'{identifier}'" for identifier in identifiers)
    traversals = ",".join(
        f"__.has('{property_name}',within({values}))" for property_name in property_names
    )
    return f".or({traversals})"


def _scope_planner_query(
    gremlin_query: str,
    intent: Optional[str],
    query_text: str,
    hints: Optional[Dict[str, Any]],
) -> tuple[str, List[str], List[str]]:
    """Push validated exact-ID filters into a Business Planner traversal.

    Returns ``(scoped_query, applied_aliases, unapplied_aliases)``.

    The alias lists are what let the caller tell a governed answer from a whole-sheet
    scan. Every ``BIZPLANNER_*`` traversal starts at an unfiltered
    ``g.V().hasLabel(...)``, so an alias that binds no filter does not narrow the
    result — it returns the entire label. Reporting that is the difference between
    "the catalog says these are the applicable Playbooks" and "here is every Playbook
    in the graph", and those must never look the same to a planner.
    """
    aliases = _PLANNER_INTENT_FILTER_ALIASES.get(intent or "", ())
    identifiers = _extract_planner_ids(query_text, hints)
    scoped = gremlin_query
    applied: List[str] = []
    unapplied: List[str] = []

    for alias in aliases:
        prefix, property_names = _PLANNER_FILTERS[alias]
        matching_ids = [identifier for identifier in identifiers if identifier.startswith(prefix)]
        predicate = ""
        if matching_ids:
            predicate = _id_predicate(property_names, matching_ids)
        else:
            # No governed ID for this alias. A structured name hint is the only
            # other authoritative way to bind it; prose is never consulted.
            names = _extract_planner_names(alias, hints)
            if names:
                _, name_properties = _PLANNER_NAME_FILTERS[alias]
                predicate = _id_predicate(name_properties, names)
        if not predicate:
            unapplied.append(alias)
            continue

        alias_marker = f".as('{alias}')"
        if alias_marker in scoped:
            scoped = scoped.replace(alias_marker, f"{predicate}{alias_marker}", 1)
        elif scoped.startswith("g.V()"):
            scoped = f"g.V(){predicate}{scoped[len('g.V()'):]}"
        else:
            unapplied.append(alias)
            continue
        applied.append(alias)

    return scoped, applied, unapplied


def _bound_results_by_bytes(
    results: Dict[str, List[Any]], max_bytes: int
) -> tuple[Dict[str, List[Any]], bool]:
    """Bound duplicated ``results``/``context.rows`` data before serialization."""
    # Leave room for execution and coverage metadata in the final response.
    data_budget = max(max_bytes - 32768, 0)
    bounded = {query_id: [] for query_id in results}
    flattened: List[Any] = []
    truncated = False
    for query_id, rows in results.items():
        for row in rows:
            bounded[query_id].append(row)
            flattened.append(row)
            candidate = {"results": bounded, "context": {"rows": flattened}}
            if len(json.dumps(candidate, default=str).encode("utf-8")) > data_budget:
                bounded[query_id].pop()
                flattened.pop()
                truncated = True
                break
        if truncated:
            break
    return bounded, truncated


_INTENT_QUERY_MAP: Dict[str, List[str]] = {
    # Canonical intents
    "domains":          ["SHEET_01_DOMAINS_CONTEXT"],
    "concepts":         ["SHEET_02_CORE_CONCEPTS_CONTEXT"],
    "attributes":       ["SHEET_03_ATTRIBUTES_CONTEXT"],
    "relationships":    ["SHEET_04_RELATIONSHIPS_CONTEXT"],
    "vocabularies":     ["SHEET_05_CONTROLLED_VOCABULARIES_CONTEXT", "SHEET_06_CONTROLLED_VALUES_CONTEXT"],
    "rules":            ["SHEET_07_RULES_CONTEXT", "SHEET_08_CALCULATIONS_CONTEXT"],
    "capabilities":     ["SHEET_09_CAPABILITIES_CONTEXT", "SHEET_10_PROCESSES_ACTIONS_CONTEXT"],
    "signals":          ["CROSS_SIGNAL_GUIDANCE_CHAIN"],
    "insights":         ["CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN"],
    "outcomes":         ["CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN", "CROSS_SIGNAL_GUIDANCE_CHAIN"],
    "situations":       ["SHEET_11E_SITUATION_TYPES_CONTEXT", "SHEET_11F_PLAN_PATTERNS_CONTEXT"],
    "personas":         ["SHEET_12_PERSONAS_CONTEXT", "SHEET_12A_PERSONA_EXPERIENCES_CONTEXT"],
    "governance":       ["SHEET_16_GOVERNANCE_CONTEXT", "SHEET_17_PUBLICATION_QUEUE_CONTEXT"],
    "lineage":          ["CROSS_SEMANTIC_LINEAGE_FULL"],
    "rule_chain":       ["CROSS_RULE_SIGNAL_INSIGHT_CHAIN"],
    "signal_evidence":  ["CROSS_SIGNAL_EVIDENCE_CONTEXT"],
    "insight_governance": ["CROSS_INSIGHT_GOVERNANCE_CONTEXT"],
    "priority_policy":  ["CROSS_PRIORITY_POLICY_CONTEXT"],
    # Insight Agent handoff aliases (mcp_lambda_handoff.md)
    "renewal_risk":     ["SHEET_07_RULES_CONTEXT", "SHEET_11A_SIGNALS_CONTEXT", "SHEET_11E_SITUATION_TYPES_CONTEXT", "CROSS_RULE_SIGNAL_INSIGHT_CHAIN"],
    "eligibility":      ["SHEET_07_RULES_CONTEXT", "SHEET_03_ATTRIBUTES_CONTEXT", "SHEET_05_CONTROLLED_VOCABULARIES_CONTEXT"],
    "opportunity":      ["SHEET_11A_SIGNALS_CONTEXT", "SHEET_11D_INSIGHTS_CONTEXT", "SHEET_11C_OUTCOMES_CONTEXT"],

    # Business Planner operation intents. Each resolves to one bounded,
    # relationship-preserving traversal rather than a broad catalog bundle.
    "get_situation_type_definition": ["SHEET_11E_SITUATION_TYPES_CONTEXT"],
    "get_outcome_definitions": ["SHEET_11C_OUTCOMES_CONTEXT"],
    "get_applicable_plan_patterns": ["BIZPLANNER_APPLICABLE_PLAN_PATTERNS"],
    "get_plan_composition_rule": ["BIZPLANNER_PLAN_COMPOSITION_RULE"],
    "get_applicable_playbooks": ["BIZPLANNER_APPLICABLE_PLAYBOOKS"],
    "get_activity_patterns": ["BIZPLANNER_ACTIVITY_PATTERNS"],
    "get_action_governance": ["BIZPLANNER_ACTION_GOVERNANCE"],
    "get_persona_actions": ["BIZPLANNER_PERSONA_ACTIONS"],
    "get_plan_dependencies": ["BIZPLANNER_PLAN_DEPENDENCIES"],
    "get_existing_plan": ["BIZPLANNER_EXISTING_PLAN"],
    "get_material_changes": ["BIZPLANNER_MATERIAL_CHANGES"],

    # Document Generator — which document a Guided Action produces (tab 42).
    "get_document_template": ["DOCGENERATOR_GUIDED_ACTION_TEMPLATE_MAPPING"],
    # Full catalog — every registered query

    # Situation Analyzer Agent intents — one intent per registered traversal
    "applicable_plan_patterns": ["SITUATION_APPLICABLE_PLAN_PATTERNS"],
    "plan_composition_rule":    ["SITUATION_PLAN_COMPOSITION_RULE"],
    "applicable_playbooks":     ["SITUATION_APPLICABLE_PLAYBOOKS"],
    "activity_patterns":        ["SITUATION_ACTIVITY_PATTERNS"],
    "action_governance":        ["SITUATION_ACTION_GOVERNANCE"],
    "plan_dependencies":        ["SITUATION_PLAN_DEPENDENCIES"],
    "existing_plan":            ["SITUATION_EXISTING_PLAN"],
    "material_changes":         ["SITUATION_MATERIAL_CHANGES"],
    "situation_supporting_signal_insight": ["SITUATION_SUPPORTING_SIGNAL_INSIGHT"],
    # Full catalog — all queries

    "full_catalog":     list(_QUERY_LIBRARY.keys()),
}

# Default bundle used when no intent can be inferred.
# Uses the two business semantic graph traversal queries — insight chain and signal chain.
_DEFAULT_QUERY_IDS: List[str] = [
    "CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN",
    "CROSS_SIGNAL_GUIDANCE_CHAIN",
]

# ---------------------------------------------------------------------------
# Agent Policy Registry — per-policy_key bundle maps, limits, and coverage gates.
#
# Each policy entry controls:
#   intent_bundle_map  — which query IDs to run per intent (overrides global map)
#   fallback_bundle    — single fallback list executed once if coverage fails
#   limits             — max_templates / max_rows / timeouts (caller may go lower;
#                        server hard caps always win)
#   coverage_gate      — which checks must pass before returning
#   status             — "active" | "disabled"  (disabled policies are rejected)
#
# The "default" policy is used when no policy_key is sent (or key not found).
# ---------------------------------------------------------------------------

_AGENT_POLICY_REGISTRY: Dict[str, Dict[str, Any]] = {
    # ---- Business Planner V1 — strict operation-scoped policy -----------------
    # The planner asks one governed question at a time. Restrict resolution to
    # these nine fixed traversals so words such as "all" cannot activate the
    # global full_catalog bundle and flood the model context.
    "business-planner-v1": {
        "policy_key": "business-planner-v1",
        "agent": "business-planner-agent",
        "status": "active",
        "restrict_to_policy_intents": True,
        "intent_bundle_map": {
            "get_situation_type_definition": ["SHEET_11E_SITUATION_TYPES_CONTEXT"],
            "get_outcome_definitions": ["SHEET_11C_OUTCOMES_CONTEXT"],
            "get_applicable_plan_patterns": ["BIZPLANNER_APPLICABLE_PLAN_PATTERNS"],
            "get_plan_composition_rule": ["BIZPLANNER_PLAN_COMPOSITION_RULE"],
            "get_applicable_playbooks": ["BIZPLANNER_APPLICABLE_PLAYBOOKS"],
            "get_activity_patterns": ["BIZPLANNER_ACTIVITY_PATTERNS"],
            "get_action_governance": ["BIZPLANNER_ACTION_GOVERNANCE"],
            "get_persona_actions": ["BIZPLANNER_PERSONA_ACTIONS"],
            "get_plan_dependencies": ["BIZPLANNER_PLAN_DEPENDENCIES"],
            "get_existing_plan": ["BIZPLANNER_EXISTING_PLAN"],
            "get_material_changes": ["BIZPLANNER_MATERIAL_CHANGES"],
        },
        "fallback_bundle": ["BIZPLANNER_APPLICABLE_PLAN_PATTERNS"],
        "limits": {
            "max_templates": 3,
            "max_rows": 200,
            "max_response_bytes": _BUSINESS_PLANNER_MAX_RESPONSE_BYTES,
            "template_timeout_ms": _SERVER_TEMPLATE_TIMEOUT_MS,
            "total_timeout_ms": _SERVER_TOTAL_TIMEOUT_MS,
        },
        "coverage_gate": {
            "definition_present": False,
            "rule_present": False,
            "relationship_present": False,
        },
        "priority_order": [],
    },
    # ---- Insight Agent V0 — full-coverage policy --------------------------------
    # Supports ALL intents in _INTENT_QUERY_MAP (not restricted to 3).
    # intent_bundle_map is built at import time from _INTENT_QUERY_MAP filtered to
    # active queries.  For unknown/missing intent, full_coverage=True ensures
    # _resolve_query_ids() falls through to the complete active query set instead
    # of the narrow _DEFAULT_QUERY_IDS.
    "insight-agent-v0": {
        "policy_key": "insight-agent-v0",
        "agent": "insight-agent",
        "status": "active",
        # intent_bundle_map: explicit intent → single query.
        # No intent → _DEFAULT_QUERY_IDS (both queries).
        # signals  → signal chain only
        # insights → insight chain only
        # outcomes → both chains
        "intent_bundle_map": {
            "signals":  ["CROSS_SIGNAL_GUIDANCE_CHAIN"],
            "insights": ["CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN"],
            "outcomes": ["CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN", "CROSS_SIGNAL_GUIDANCE_CHAIN"],
        },
        "fallback_bundle": [
            "CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN",
            "CROSS_SIGNAL_GUIDANCE_CHAIN",
        ],
        "limits": {
            "max_templates": _SERVER_MAX_TEMPLATES,
            # elementMap() traversal rows are large JSON objects — cap well below
            # Lambda's 6 MB synchronous response limit to avoid 413 errors.
            "max_rows": 250,
            "template_timeout_ms": _SERVER_TEMPLATE_TIMEOUT_MS,
            "total_timeout_ms": _SERVER_TOTAL_TIMEOUT_MS,
        },
        "coverage_gate": {
            "definition_present": False,
            "rule_present": False,
            "relationship_present": False,
        },
        "priority_order": [],
    },
    # ---- Situation Analyzer V0 — situation → plan → playbook → activity policy --
    # Each explicit intent maps to a single registered Gremlin traversal.
    # No intent → applicable plan patterns + applicable playbooks (broadest
    # situation-scoped defaults).  Fallback re-runs the applicable-playbooks
    # query if coverage is not met after the primary bundle.
    "situation-analyzer-v0": {
        "policy_key": "situation-analyzer-v0",
        "agent": "situation-analyzer-agent",
        "status": "active",
        "intent_bundle_map": {
            "applicable_plan_patterns": ["SITUATION_APPLICABLE_PLAN_PATTERNS"],
            "plan_composition_rule":    ["SITUATION_PLAN_COMPOSITION_RULE"],
            "applicable_playbooks":     ["SITUATION_APPLICABLE_PLAYBOOKS"],
            "activity_patterns":        ["SITUATION_ACTIVITY_PATTERNS"],
            "action_governance":        ["SITUATION_ACTION_GOVERNANCE"],
            "plan_dependencies":        ["SITUATION_PLAN_DEPENDENCIES"],
            "existing_plan":            ["SITUATION_EXISTING_PLAN"],
            "material_changes":         ["SITUATION_MATERIAL_CHANGES"],
            "situation_supporting_signal_insight": ["SITUATION_SUPPORTING_SIGNAL_INSIGHT"],
        },
        "fallback_bundle": [
            "SITUATION_APPLICABLE_PLAN_PATTERNS",
            "SITUATION_APPLICABLE_PLAYBOOKS",
        ],
        "limits": {
            "max_templates": _SERVER_MAX_TEMPLATES,
            # valueMap()-based traversal rows are bounded but rich — keep the
            # same cap as insight-agent-v0 to stay well under Lambda 6 MB limit.
            "max_rows": 200,
            "template_timeout_ms": _SERVER_TEMPLATE_TIMEOUT_MS,
            "total_timeout_ms": _SERVER_TOTAL_TIMEOUT_MS,
        },
        "coverage_gate": {
            "definition_present": False,
            "rule_present": False,
            "relationship_present": False,
        },
        "priority_order": [],
    },

    # ---- Document Generator V0 — single-operation policy -----------------------
    # This agent asks the catalog exactly one question: which document does this
    # Guided Action produce? One intent, one traversal, one row.
    #
    # restrict_to_policy_intents is the important flag. Without it,
    # _resolve_query_ids() falls through to the global _INTENT_QUERY_MAP and then
    # to _DEFAULT_QUERY_IDS — the two broad cross-chain traversals — and the
    # Document Generator would silently receive insight-chain rows that look like
    # an answer. Fail closed instead: an unrecognised ask returns nothing.
    "docgenerator-agent-v0": {
        "policy_key": "docgenerator-agent-v0",
        "agent": "docgenerator-agent",
        "status": "active",
        "restrict_to_policy_intents": True,
        "intent_bundle_map": {
            "get_document_template": ["DOCGENERATOR_GUIDED_ACTION_TEMPLATE_MAPPING"],
        },
        # Unreachable while restrict_to_policy_intents is set (the coverage gate
        # below never fails), and deliberately so: a fallback that widened this
        # policy would defeat the point of restricting it.
        "fallback_bundle": [],
        "limits": {
            # One guided action resolves to one template. A budget larger than
            # that only makes an unscoped result look plausible.
            "max_templates": 1,
            "max_rows": 25,
            "template_timeout_ms": _SERVER_TEMPLATE_TIMEOUT_MS,
            "total_timeout_ms": _SERVER_TOTAL_TIMEOUT_MS,
        },
        # No coverage checks: the tab 42 register carries no Definition or Rule
        # rows, so every gate would fail and trigger a pointless fallback.
        "coverage_gate": {
            "definition_present": False,
            "rule_present": False,
            "relationship_present": False,
        },
        "priority_order": [],
    },
    # ---- Default policy — used by any caller that omits policy_key -------------
    # signals intent  → signal chain only
    # insights intent → insight chain only
    # outcomes intent → both chains
    # no intent       → both chains (_DEFAULT_QUERY_IDS)
    "default": {
        "policy_key": "default",
        "agent": "*",
        "status": "active",
        "intent_bundle_map": {
            "signals":  ["CROSS_SIGNAL_GUIDANCE_CHAIN"],
            "insights": ["CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN"],
            "outcomes": ["CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN", "CROSS_SIGNAL_GUIDANCE_CHAIN"],
        },
        "fallback_bundle": [
            "CROSS_INSIGHT_SIGNAL_GUIDANCE_CHAIN",
            "CROSS_SIGNAL_GUIDANCE_CHAIN",
        ],
        "limits": {
            "max_templates": _SERVER_MAX_TEMPLATES,
            "max_rows": 250,
            "template_timeout_ms": _SERVER_TEMPLATE_TIMEOUT_MS,
            "total_timeout_ms": _SERVER_TOTAL_TIMEOUT_MS,
        },
        "coverage_gate": {
            "definition_present": False,
            "rule_present": False,
            "relationship_present": False,
        },
        "priority_order": [],
    },
}


def _infer_intents(query_text: str, hints: Optional[Dict[str, Any]] = None) -> List[str]:
    """Keyword-based intent detection from query text and optional hints."""
    text = (query_text or "").lower()
    hint_values = " ".join(str(v) for v in (hints or {}).values() if v).lower()
    combined = f"{text} {hint_values}"

    intents: List[str] = []

    def add(intent: str) -> None:
        if intent not in intents:
            intents.append(intent)

    # Business Planner operation names are explicit and take precedence over
    # broad catalog keywords that may also occur in the question.
    planner_operations = {
        "getapplicableplanpatterns": "get_applicable_plan_patterns",
        "getplancompositionrule": "get_plan_composition_rule",
        "getapplicableplaybooks": "get_applicable_playbooks",
        "getactivitypatterns": "get_activity_patterns",
        "getactiongovernance": "get_action_governance",
        "getpersonaactions": "get_persona_actions",
        "getplandependencies": "get_plan_dependencies",
        "getexistingplan": "get_existing_plan",
        "getmaterialchanges": "get_material_changes",
    }
    compact = re.sub(r"[^a-z0-9]", "", combined)
    for operation, operation_intent in planner_operations.items():
        if operation in compact:
            add(operation_intent)

    # Insight Agent aliases first (higher specificity)
    if any(k in combined for k in ("renewal", "lapse", "retention", "at risk", "expir")):
        add("renewal_risk")
    if any(k in combined for k in ("eligib", "constraint", "qualify", "qualify")):
        add("eligibility")
    if any(k in combined for k in ("opportunit", "missing product", "gap", "upsell", "cross")):
        add("opportunity")

    # Canonical intents
    if any(k in combined for k in ("domain", "governance", "glossary", "business context")):
        add("domains")
    if any(k in combined for k in ("concept", "entity", "object type", "taxonomy")):
        add("concepts")
    if any(k in combined for k in ("attribute", "field", "property", "freshness", "confidence")):
        add("attributes")
    if any(k in combined for k in ("relationship", "relation", "linked", "belongs to")):
        add("relationships")
    if any(k in combined for k in ("vocabulary", "controlled value", "code", "lookup")):
        add("vocabularies")
    if any(k in combined for k in ("rule", "calculation", "formula", "deterministic")):
        add("rules")
    if any(k in combined for k in ("capability", "process", "action", "workflow")):
        add("capabilities")
    if any(k in combined for k in ("signal", "event", "trigger", "evidence")):
        add("signals")
    if any(k in combined for k in ("insight",)):
        add("insights")
    if any(k in combined for k in ("outcome", "result", "measure")):
        add("outcomes")
    if any(k in combined for k in ("situation", "plan pattern", "playbook", "disposition")):
        add("situations")
    if any(k in combined for k in ("persona", "role", "user", "advisor", "broker")):
        add("personas")

    # Situation Analyzer Agent intents (higher specificity than "situations")
    if any(k in combined for k in ("applicable plan pattern", "plan pattern for situation", "recommend plan pattern")):
        add("applicable_plan_patterns")
    if any(k in combined for k in ("plan composition", "composition rule", "compose plan")):
        add("plan_composition_rule")
    if any(k in combined for k in ("applicable playbook", "playbook for situation", "recommend playbook")):
        add("applicable_playbooks")
    if any(k in combined for k in ("activity pattern", "playbook activit")):
        add("activity_patterns")
    if any(k in combined for k in ("action governance", "activity governance", "required capability", "performing persona")):
        add("action_governance")
    if any(k in combined for k in ("plan dependencies", "decision intervention", "triggers decision")):
        add("plan_dependencies")
    if any(k in combined for k in ("existing plan", "current plan", "active plan")):
        add("existing_plan")
    if any(k in combined for k in ("material change", "change set", "changes since")):
        add("material_changes")
    if any(k in combined for k in ("supporting signal", "supporting insight", "situation signal", "situation insight")):
        add("situation_supporting_signal_insight")
    if any(k in combined for k in ("lineage", "traceability", "end-to-end", "chain")):
        add("lineage")
    if any(k in combined for k in ("priority", "policy", "weight", "threshold")):
        add("priority_policy")
    if any(k in combined for k in ("360", "full", "comprehensive", "everything", "all")):
        add("full_catalog")

    return intents if intents else []


def _resolve_query_ids(
    intent: Optional[str],
    query_text: str,
    hints: Optional[Dict[str, Any]],
    max_templates: int,
    policy: Optional[Dict[str, Any]] = None,
) -> List[str]:
    """Resolve the ordered list of active query IDs to execute.

    Resolution order:
    1. Explicit intent looked up in policy's intent_bundle_map (if policy provided
       and intent key present), else falls back to global _INTENT_QUERY_MAP.
    2. Inferred intents from query text / hints fill remaining budget.
    3. If policy has full_coverage=True and still no IDs, use entire active set.
       Otherwise fall back to _DEFAULT_QUERY_IDS.
    Policies with restrict_to_policy_intents=True fail closed: an explicit intent
    returns only that policy mapping, and unresolved requests return no queries.
    Queries with status != "active" in _QUERY_METADATA are silently excluded.
    Final list is truncated to max_templates.
    """
    # fixed_bundle: if set, always return exactly those active queries — intent/inference skipped.
    fixed_bundle: Optional[List[str]] = (policy or {}).get("fixed_bundle")
    if fixed_bundle is not None:
        active_fixed = [q for q in fixed_bundle if _QUERY_METADATA.get(q, {}).get("status", "active") == "active"]
        return active_fixed[:max_templates]

    policy_bundle_map: Dict[str, List[str]] = (policy or {}).get("intent_bundle_map") or {}
    full_coverage: bool = bool((policy or {}).get("full_coverage", False))
    restrict_to_policy_intents: bool = bool((policy or {}).get("restrict_to_policy_intents", False))
    priority_order: List[str] = (policy or {}).get("priority_order") or []

    def _active(qid: str) -> bool:
        return _QUERY_METADATA.get(qid, {}).get("status", "active") == "active"

    ids: List[str] = []

    # 1. Explicit intent — policy map takes precedence over global map
    if intent:
        bundle = policy_bundle_map.get(intent, [])
        if not bundle and not restrict_to_policy_intents:
            bundle = _INTENT_QUERY_MAP.get(intent, [])
        for qid in bundle:
            if qid not in ids and _active(qid):
                ids.append(qid)
        # A strict operation-scoped policy must not infer additional operations
        # from words in the task or fall through to another agent's defaults.
        if restrict_to_policy_intents:
            return ids[:max_templates]

    # 2. If a caller explicitly named an intent, treat it as authoritative and
    # do not broaden the bundle with inferred intents. This keeps scoped policies
    # (for example, situation-analyzer material_changes) from being mixed with
    # generic rules/signals/outcomes context.
    if ids and intent:
        return ids[:max_templates]

    # 3. Inferred intents fill remaining budget when no explicit intent was set.
    if len(ids) < max_templates:
        for inf_intent in _infer_intents(query_text, hints):
            bundle = policy_bundle_map.get(inf_intent, [])
            if not bundle and not restrict_to_policy_intents:
                bundle = _INTENT_QUERY_MAP.get(inf_intent, [])
            for qid in bundle:
                if qid not in ids and _active(qid):
                    ids.append(qid)
            if len(ids) >= max_templates:
                break


    # 4. Nothing resolved — full_coverage policy → entire active set; else defaults.
    #
    # restrict_to_policy_intents is honoured here as well as at step 1. Step 1
    # only covers the case where an intent was NAMED and did not match; a request
    # that names no intent at all reached this line and was handed
    # _DEFAULT_QUERY_IDS — the two broad cross-chain traversals belonging to
    # another agent's policy. That is the precise leak a restricted policy exists
    # to prevent, and it made the flag a half-measure: fail closed on a wrong
    # intent, fail open on no intent.
    if not ids and not restrict_to_policy_intents:
        if full_coverage:
            ordered: List[str] = []
            for qid in priority_order:
                if _active(qid) and qid not in ordered:
                    ordered.append(qid)
            for qid in _active_query_ids():
                if qid not in ordered:
                    ordered.append(qid)
            ids = ordered
        else:
            ids = [q for q in _DEFAULT_QUERY_IDS if _active(q)]

    # Enforce template budget (server cap already applied by caller)
    return ids[:max_templates]


def _check_coverage(results: Dict[str, List[Any]]) -> Dict[str, bool]:
    """Evaluate coverage gate per mcp_lambda_handoff.md requirements."""
    all_rows: List[Any] = [row for rows in results.values() for row in rows]
    definition_present = any(
        (isinstance(r, dict) and (r.get("Definition") or r.get("definition")))
        for r in all_rows
    )
    rule_present = bool(results.get("SHEET_07_RULES_CONTEXT") or results.get("CROSS_RULE_SIGNAL_INSIGHT_CHAIN"))
    relationship_present = bool(
        results.get("SHEET_04_RELATIONSHIPS_CONTEXT")
        or results.get("CROSS_SEMANTIC_LINEAGE_FULL")
        or any(r for r in results.values() if r)
    )
    return {
        "definition_present": definition_present,
        "rule_present": rule_present,
        "relationship_present": relationship_present,
    }


def _extract_labeled_value(query_text: str, labels: List[str]) -> Optional[str]:
    text = query_text or ""
    for label in labels:
        # No space in character class — extracts only a single identifier token.
        # Space was previously included, causing multi-word values like
        # "insight-agent-v0. Requested semantic limits" to be captured,
        # which then failed the exact-key registry lookup.
        pattern = re.compile(rf"{re.escape(label)}\s*:\s*([A-Za-z0-9_.\-]+)", re.IGNORECASE)
        match = pattern.search(text)
        if match:
            value = (match.group(1) or "").strip().strip(".,;: ")
            if value:
                return value
    return None


def _normalize_agent_name(agent_name: Optional[str]) -> str:
    if not agent_name:
        return ""
    normalized = agent_name.strip().lower().replace(" ", "")
    aliases = {normalized}
    for suffix in ("-agent", "_agent", " agent"):
        if normalized.endswith(suffix):
            aliases.add(normalized[: -len(suffix)])
    return next(iter(sorted(aliases, key=len)), normalized)


def _derive_policy_key_from_agent(agent_name: Optional[str]) -> Optional[str]:
    if not agent_name:
        return None
    normalized = _normalize_agent_name(agent_name)
    for key, policy in _AGENT_POLICY_REGISTRY.items():
        if policy.get("status") != "active":
            continue
        policy_agent = str(policy.get("agent", "")).strip().lower().replace(" ", "")
        if not policy_agent or policy_agent == "*":
            continue
        if policy_agent == normalized:
            return key
        if policy_agent.endswith("-agent") and policy_agent[:-6] == normalized:
            return key
        if policy_agent.endswith("_agent") and policy_agent[:-6] == normalized:
            return key
        if normalized.endswith("-agent") and policy_agent == normalized[:-6]:
            return key
        if normalized.endswith("_agent") and policy_agent == normalized[:-6]:
            return key
    return None


def _normalize_intent_token(raw_intent: Optional[str]) -> Optional[str]:
    if not raw_intent:
        return None
    token = raw_intent.strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "renewal": "renewal_risk",
        "risk": "renewal_risk",
        "eligibility": "eligibility",
        "opportunity": "opportunity",
    }
    token = aliases.get(token, token)
    return token if token in _INTENT_QUERY_MAP else None


def _resolve_context_hints_from_query(
    query_text: str,
    *,
    intent: Optional[str],
    agent: Optional[str],
    policy_key: Optional[str],
) -> Dict[str, Optional[str]]:
    resolved_intent = intent or _normalize_intent_token(
        _extract_labeled_value(query_text, ["semantic intent", "intent"])
    )
    resolved_agent = agent or _extract_labeled_value(query_text, ["caller agent", "agent"])
    resolved_policy_key = policy_key or _extract_labeled_value(query_text, ["policy key", "policy"])
    if not resolved_policy_key:
        resolved_policy_key = _derive_policy_key_from_agent(resolved_agent)
    return {
        "intent": resolved_intent,
        "agent": resolved_agent,
        "policy_key": resolved_policy_key,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_connectivity() -> bool:
    """Probe Neptune — return True if reachable, False otherwise. Never raises."""
    try:
        client = _get_neptune_client()
        client.execute_gremlin_query(gremlinQuery="g.V().limit(1).count()", serializer="application/json")
        return True
    except Exception as exc:
        logger.warning("Business catalog Neptune connectivity check failed: %s", exc)
        return False


def fetch_catalog_context(
    query_text: str,
    intent: Optional[str] = None,
    hints: Optional[Dict[str, Any]] = None,
    limits: Optional[Dict[str, Any]] = None,
    agent: Optional[str] = None,
    policy_key: Optional[str] = None,
) -> Dict[str, Any]:
    """Execute the appropriate catalog query bundle and return structured results.

    Looks up agent policy from _AGENT_POLICY_REGISTRY by policy_key (or "default").
    Policy controls intent bundle map, fallback bundle, limits, and coverage gate.
    Query template metadata from _QUERY_METADATA enforces per-query status (active/disabled).

    Args:
        query_text:  Free-text business topic — used for intent inference if intent not given.
        intent:      Explicit intent key — looked up in policy's intent_bundle_map first,
                     then global _INTENT_QUERY_MAP. Never interpolated into Gremlin.
        hints:       Optional filters (situation_id, canonical_id, concept_id, product_code,
                     segment). Used for intent inference only — zero injection surface.
        limits:      Optional caller budget hints. Capped by policy limits, then server caps.
        agent:       Caller agent name — logged for audit only.
        policy_key:  Agent policy key from _AGENT_POLICY_REGISTRY. Falls back to "default".
    """
    resolved = _resolve_context_hints_from_query(
        query_text,
        intent=intent,
        agent=agent,
        policy_key=policy_key,
    )
    effective_intent = resolved.get("intent")
    effective_agent = resolved.get("agent")
    requested_policy_key = resolved.get("policy_key")

    if effective_agent or requested_policy_key:
        logger.info(
            "Catalog context request — agent=%s policy_key=%s",
            effective_agent,
            requested_policy_key,
        )

    # ---- Resolve agent policy ------------------------------------------------
    # An explicitly requested policy must resolve exactly. Falling an unknown
    # agent policy through to "default" could authorize another agent's query
    # bundles. Only callers that omit policy_key use the default policy.
    policy = _AGENT_POLICY_REGISTRY.get(requested_policy_key or "")
    if requested_policy_key and not policy:
        logger.warning("Unknown catalog policy '%s' — request denied", requested_policy_key)
        return {
            "available": False,
            "reason": "unknown_policy",
            "policy_key": requested_policy_key,
        }
    policy = policy or _AGENT_POLICY_REGISTRY["default"]
    if policy.get("status") != "active":
        logger.warning("Catalog policy '%s' is disabled — request denied", requested_policy_key)
        return {
            "available": False,
            "reason": "policy_disabled",
            "policy_key": requested_policy_key or policy.get("policy_key"),
        }
    effective_policy_key = policy["policy_key"]
    policy_limits = policy.get("limits", {})
    policy_fallback = policy.get("fallback_bundle") or _DEFAULT_QUERY_IDS
    policy_coverage_gate: Dict[str, bool] = policy.get("coverage_gate") or {
        "definition_present": True,
        "rule_present": True,
        "relationship_present": True,
    }
    logger.info(
        "Using policy '%s' for agent='%s'", effective_policy_key, policy.get("agent", "*")
    )

    # ---- Resolve effective limits --------------------------------------------
    # Priority: caller hint -> policy cap -> server hard cap.
    # Caller can only go lower than the policy cap, never higher.
    # Server hard caps are the absolute ceiling regardless.
    caller_limits = limits or {}

    def _cap(field: str, server_cap: int) -> int:
        caller_val = int(caller_limits.get(field) or 0)
        policy_val = int(policy_limits.get(field) or server_cap)
        # Use caller value if explicitly provided and within policy; else use policy
        effective = caller_val if caller_val and caller_val <= policy_val else policy_val
        return min(effective, server_cap)

    max_templates      = _cap("max_templates",      _SERVER_MAX_TEMPLATES)
    max_rows           = _cap("max_rows",           _SERVER_MAX_ROWS)
    template_timeout_ms = _cap("template_timeout_ms", _SERVER_TEMPLATE_TIMEOUT_MS)
    total_timeout_ms   = _cap("total_timeout_ms",   _SERVER_TOTAL_TIMEOUT_MS)
    max_response_bytes = min(
        int(policy_limits.get("max_response_bytes") or _SERVER_MAX_RESPONSE_BYTES),
        _SERVER_MAX_RESPONSE_BYTES,
    )

    query_ids = _resolve_query_ids(effective_intent, query_text, hints, max_templates, policy)

    if not query_ids:
        logger.warning(
            "No query authorized — policy=%s intent=%s", effective_policy_key, effective_intent
        )
        return {
            "available": False,
            "reason": "no_queries_authorized",
            "policy_key": effective_policy_key,
            "intent": effective_intent,
        }

    # ---- Planner scope gate (fail closed) ------------------------------------
    # Every BIZPLANNER_* traversal begins at an unfiltered g.V().hasLabel(...), so
    # a planner ask that binds no filter at all does not retrieve "the governed
    # answer" — it retrieves the whole label, capped at max_rows. Returning that
    # invites the planner to read unrelated Situations as applicable governance,
    # which is the precise failure the governed-definition contract exists to
    # prevent. Deny instead, and name what was missing so the caller can re-ask
    # with the identifier rather than guess why the answer looked wrong.
    planner_scope: Optional[Dict[str, Any]] = None
    if effective_policy_key in _SCOPE_ENFORCED_POLICY_KEYS:
        expected_aliases = _PLANNER_INTENT_FILTER_ALIASES.get(effective_intent or "", ())
        if expected_aliases:
            _, applied, unapplied = _scope_planner_query(
                _QUERY_LIBRARY.get(query_ids[0], "g.V()"),
                effective_intent, query_text, hints,
            )
            if not applied:
                logger.warning(
                    "Planner scope not established — policy=%s intent=%s expected=%s",
                    effective_policy_key, effective_intent, list(expected_aliases),
                )
                return {
                    "available": False,
                    "reason": "scope_not_established",
                    "policy_key": effective_policy_key,
                    "intent": effective_intent,
                    "scope": {
                        "scope_applied": False,
                        "applied_filters": [],
                        "unapplied_filters": list(unapplied),
                        "message": (
                            "No governed identifier was supplied for this ask, so the "
                            "traversal would have returned every record of its type "
                            "rather than the governed answer. Re-ask naming the exact "
                            f"identifier for: {', '.join(unapplied)}."
                        ),
                    },
                }
            planner_scope = {
                "scope_applied": True,
                "applied_filters": applied,
                "unapplied_filters": unapplied,
            }

    # Compute activation_reasons for the execution record (logged + returned)
    inferred_intents = _infer_intents(query_text, hints)
    activation_reasons: List[str] = []
    if effective_intent:
        activation_reasons.append(f"explicit_intent:{effective_intent}")
    for inf in inferred_intents:
        activation_reasons.append(f"inferred_intent:{inf}")
    if not activation_reasons:
        activation_reasons.append("default_bundle")

    logger.info(
        "Catalog resolve — policy=%s intent=%s inferred=%s selected_ids=%s",
        effective_policy_key, effective_intent, inferred_intents, query_ids,
    )

    try:
        client = _get_neptune_client()
    except Exception as exc:
        logger.warning("Business catalog Neptune client unavailable: %s", exc)
        return {"available": False, "reason": str(exc)}

    results: Dict[str, List[Any]] = {}
    executed: List[str] = []
    skipped: List[str] = []
    row_counts: Dict[str, int] = {}
    stop_reason = "coverage_met"
    total_rows = 0
    start_ms = time.time() * 1000
    fallback_used = False

    for qid in query_ids:
        # Total timeout guard
        elapsed_ms = (time.time() * 1000) - start_ms
        if elapsed_ms >= total_timeout_ms:
            stop_reason = "timeout"
            skipped.extend(q for q in query_ids if q not in executed and q != qid)
            break

        # Row budget guard
        if total_rows >= max_rows:
            stop_reason = "budget_limit"
            skipped.extend(q for q in query_ids if q not in executed and q != qid)
            break

        # Skip unknown or disabled queries
        gremlin_query = _QUERY_LIBRARY.get(qid)
        if not gremlin_query:
            logger.warning("Unknown query ID '%s' — skipping", qid)
            skipped.append(qid)
            continue
        if _QUERY_METADATA.get(qid, {}).get("status", "active") != "active":
            logger.info("Query '%s' is disabled in registry — skipping", qid)
            skipped.append(qid)
            continue

        try:
            if effective_policy_key in _SCOPE_ENFORCED_POLICY_KEYS:
                gremlin_query, _, _ = _scope_planner_query(
                    gremlin_query, effective_intent, query_text, hints
                )
            response = client.execute_gremlin_query(
                gremlinQuery=_with_row_limit(gremlin_query, max_rows - total_rows),
                serializer="application/json",
            )
            raw = response.get("result", {}).get("data", {})
            rows = _unwrap_graphson(raw)
            if not isinstance(rows, list):
                rows = [rows] if rows else []
            rows = _dedupe_rows(rows)
            if qid == "DOCGENERATOR_GUIDED_ACTION_TEMPLATE_MAPPING":
                rows = _apply_content_type(rows)

            # Enforce per-query row cap
            remaining = max_rows - total_rows
            if len(rows) > remaining:
                rows = rows[:remaining]
                stop_reason = "budget_limit"

            results[qid] = rows
            executed.append(qid)
            row_counts[qid] = len(rows)
            total_rows += len(rows)

        except ClientError as exc:
            logger.warning("Catalog query '%s' ClientError: %s", qid, exc)
            skipped.append(qid)
        except Exception as exc:
            logger.warning("Catalog query '%s' failed: %s", qid, exc)
            skipped.append(qid)

    # Coverage gate — if minimum coverage not met and budget allows, run fallback
    # Required checks come from the policy's coverage_gate (not hardcoded).
    coverage = _check_coverage(results)
    required_coverage_checks = [k for k, required in policy_coverage_gate.items() if required]
    coverage_met = all(coverage.get(k, False) for k in required_coverage_checks)
    if (
        not coverage_met
        and stop_reason not in ("timeout", "budget_limit")
        and len(executed) < max_templates
    ):
        # Guard: skip fallback entirely if row budget is already exhausted.
        # This mirrors the budget guard at the top of the main query loop.
        _fallback_remaining = max_rows - total_rows
        if _fallback_remaining <= 0:
            stop_reason = "budget_limit"
        else:
            fallback_ids = [
                q for q in policy_fallback
                if q not in executed and q not in skipped
                and _QUERY_METADATA.get(q, {}).get("status", "active") == "active"
            ]
            for fid in fallback_ids[:1]:  # single fallback per handoff spec
                gremlin_query = _QUERY_LIBRARY.get(fid)
                if not gremlin_query:
                    continue
                # The fallback runs the same unfiltered traversals as the main loop,
                # so it needs the same scoping. Without this a planner request that
                # was correctly scoped could still be answered by an unscoped
                # whole-label read whenever a coverage gate is enabled.
                if effective_policy_key == "business-planner-v1":
                    gremlin_query, _, _ = _scope_planner_query(
                        gremlin_query, effective_intent, query_text, hints
                    )
                try:
                    response = client.execute_gremlin_query(
                        gremlinQuery=_with_row_limit(gremlin_query, _fallback_remaining),
                        serializer="application/json",
                    )
                    raw = response.get("result", {}).get("data", {})
                    rows = _unwrap_graphson(raw)
                    if not isinstance(rows, list):
                        rows = [rows] if rows else []
                    rows = _dedupe_rows(rows)
                    # Budget parity with main loop: cap to remaining row allowance
                    remaining = max_rows - total_rows
                    if len(rows) > remaining:
                        rows = rows[:remaining]
                        stop_reason = "budget_limit"
                    results[fid] = rows
                    executed.append(fid)
                    row_counts[fid] = len(rows)
                    total_rows += len(rows)
                    fallback_used = True
                    coverage = _check_coverage(results)
                except Exception as exc:
                    logger.warning("Fallback query '%s' failed: %s", fid, exc)

    results, response_size_limited = _bound_results_by_bytes(results, max_response_bytes)
    if response_size_limited:
        stop_reason = "response_size_limit"
        row_counts = {query_id: len(rows) for query_id, rows in results.items()}
        total_rows = sum(row_counts.values())

    # Re-evaluate coverage with final results
    coverage = _check_coverage(results)
    coverage_met = all(coverage.get(k, False) for k in required_coverage_checks)
    if stop_reason == "coverage_met":
        stop_reason = "coverage_met" if coverage_met else "no_more_bundles"

    logger.info(
        "Catalog complete — policy=%s executed=%s skipped=%s fallback_used=%s stop=%s",
        effective_policy_key, executed, skipped, fallback_used, stop_reason,
    )

    all_rows = [row for rows in results.values() for row in rows]
    response_payload: Dict[str, Any] = {
        "available": True,
        "results": results,
        "execution": {
            "policy_version": effective_policy_key,
            "executed_query_ids": executed,
            "skipped_query_ids": skipped,
            "row_counts": row_counts,
            "row_limit": max_rows,
            "total_rows": total_rows,
            "fallback_used": fallback_used,
            "stop_reason": stop_reason,
            "activation_reasons": activation_reasons,
        },
        "coverage": coverage,
        # Additive convenience key — matches mcp_lambda_handoff.md shape;
        # existing consumers using `results` are unaffected.
        "context": {
            "rows": all_rows,
            "truncated": stop_reason in ("budget_limit", "response_size_limit"),
        },
    }
    # Only planner asks carry a scope block. `unapplied_filters` is the honest
    # record that the result is broader than the ask: the traversal bound some
    # filters but not all, so rows outside the requested scope may be present.
    if planner_scope is not None:
        response_payload["scope"] = planner_scope
    return response_payload
