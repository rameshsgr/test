"Vector store infrastructure."
