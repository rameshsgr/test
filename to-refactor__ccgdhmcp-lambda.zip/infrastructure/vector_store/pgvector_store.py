"""PgVector-backed metadata vector store using AWS Bedrock Titan embeddings.

Self-contained implementation — no dependency on any external legacy service.
All configuration is passed explicitly via constructor arguments; values are
read from environment variables (already loaded by core.config at startup).
"""

from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

import boto3
import numpy as np
import psycopg2
import psycopg2.extras
from pgvector.psycopg2 import register_vector

from infrastructure.ttl_cache import TTLCache

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# DDL
# ---------------------------------------------------------------------------

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS {schema}.{table} (
    id               BIGSERIAL PRIMARY KEY,
    tbl_catlg_nm     TEXT,
    tbl_schema_nm    TEXT,
    zone_nm          TEXT,
    tbl_nm           TEXT,
    colmn_nm         TEXT,
    ordinal_pos_num  TEXT,
    colmn_deflt_val  TEXT,
    nullable_flg     TEXT,
    data_ty          TEXT,
    cmmnt_txt        TEXT,
    extra_info_txt   TEXT,
    tbl_lgcl_nm      TEXT,
    tbl_cmmnt_txt    TEXT,
    colmn_lgcl_nm    TEXT,
    colmn_cmmnt_txt  TEXT,
    fk_flg           TEXT,
    pk_flg           TEXT,
    phi_pii_ind      TEXT,
    deflt_val_txt    TEXT,
    prnt_tbl_phy_nm  TEXT,
    vw_ty_desc       TEXT,
    embedding        VECTOR({dim})
);
"""

_CREATE_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS {table}_embedding_idx
ON {schema}.{table}
USING ivfflat (embedding vector_l2_ops)
WITH (lists = 100);
"""


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class PgVectorMetadataVectorStore:
    """Cosine-similarity vector store backed by PostgreSQL + pgvector.

    Constructor arguments are all keyword-only and correspond 1:1 to the
    env vars / config.yaml values already resolved by ``core.config.settings``.
    Nothing here reads config.yaml or .env directly.
    """

    def __init__(
        self,
        *,
        # PgVector DB connection
        pg_host: str,
        pg_port: int = 5432,
        pg_db: str,
        pg_user: str,
        pg_password: str,
        pg_sslmode: bool = True,
        vector_schema: str = "public",
        vector_table: str = "discovery_clientreporting",
        # AWS Bedrock
        region: str = "us-east-1",
        verify_ssl: bool = False,
        # Embedding config
        embedding_dimension: int = 1024,
        titan_model_id: str = "amazon.titan-embed-text-v2:0",
        # Provisioning — READ-ONLY by default. See VectorDbConfig.auto_provision
        # docstring in core/config.py. Only the offline provisioning script
        # (infrastructure/vector_store/provision_pgvector.py) should pass True.
        auto_provision: bool = False,
    ):
        self._pg_host    = pg_host
        self._pg_port    = pg_port
        self._pg_db      = pg_db
        self._pg_user    = pg_user
        self._pg_password = pg_password
        self._pg_sslmode = "require" if pg_sslmode else "disable"
        self._schema     = vector_schema
        self._table      = vector_table
        self.dimension   = embedding_dimension
        self.embedding_model = titan_model_id
        self._auto_provision = auto_provision

        # Bedrock client — built fresh on each embedding call via property
        self._region             = region
        self._verify_ssl         = verify_ssl

        # In-process embedding LRU cache — avoids re-embedding repeated queries.
        # Key: query text  Value: embedding as list[float]
        # Capped at 256 entries; oldest entry evicted when full.
        self._embedding_cache: Dict[str, List[float]] = {}
        self._embedding_cache_max: int = 256

        # In-process vector search result cache.
        # The pgvector table holds static schema metadata — it changes only when
        # the DBA reloads the data dictionary.  30 min TTL keeps results warm
        # across consecutive agent calls without holding stale schema indefinitely.
        # Only unfiltered searches are cached (filter_dict=None is the common path).
        self._search_cache: TTLCache = TTLCache(ttl_seconds=1800, max_size=256)

        # Ingestion-only buffer (populated by add_metadata / cleared by clear).
        # NOT used for serving — every search() query hits the DB directly.
        self.metadata_store: List[Dict[str, Any]] = []

        # Deferred connection
        self._conn: Optional[psycopg2.extensions.connection] = None

        logger.info(
            "PgVector store configured  →  %s/%s  [%s.%s]  dim=%d  model=%s  "
            "auto_provision=%s (read_only=%s)",
            pg_host, pg_db, vector_schema, vector_table, embedding_dimension, titan_model_id,
            auto_provision, not auto_provision,
        )
        logger.info(
            "PgVector runtime mode: %s\nschema=%s\ntable=%s\nauto_provision=%s",
            "READ_ONLY" if not auto_provision else "AUTO_PROVISION",
            vector_schema, vector_table, auto_provision,
        )

    # ------------------------------------------------------------------
    # Bedrock client — always fresh (picks up rotated STS tokens)
    # ------------------------------------------------------------------

    def _get_bedrock_client(self):
        """Create a fresh boto3 bedrock-runtime client using current env vars.

        Adaptive retry config: up to 3 attempts with exponential back-off +
        jitter on ThrottlingException / ServiceUnavailableException.
        """
        import os
        from botocore.config import Config

        region = os.getenv("AWS_REGION") or self._region or "us-east-1"

        _retry_cfg = Config(
            retries={"max_attempts": 3, "mode": "adaptive"},
            connect_timeout=10,
            read_timeout=60,
        )

        return boto3.client(
            service_name="bedrock-runtime",
            region_name=region,
            verify=self._verify_ssl,
            config=_retry_cfg,
        )

    # ------------------------------------------------------------------
    # DB helpers
    # ------------------------------------------------------------------

    def _connect(self) -> psycopg2.extensions.connection:
        """Open an Aurora/pgvector connection, retrying up to 3 times on OperationalError."""
        last_exc: Exception = RuntimeError("unreachable")
        for attempt in range(3):
            try:
                conn = psycopg2.connect(
                    host=self._pg_host,
                    port=self._pg_port,
                    dbname=self._pg_db,
                    user=self._pg_user,
                    password=self._pg_password,
                    sslmode=self._pg_sslmode,
                    connect_timeout=15,
                )
                conn.autocommit = False
                register_vector(conn)
                return conn
            except psycopg2.OperationalError as exc:
                last_exc = exc
                if attempt < 2:
                    wait = 2 ** attempt  # 1s, 2s
                    logger.warning(
                        "pgvector connect attempt %d/3 failed (%s) — retrying in %ds",
                        attempt + 1, exc, wait,
                    )
                    time.sleep(wait)
        raise last_exc

    def _get_conn(self) -> psycopg2.extensions.connection:
        first_connect = self._conn is None
        try:
            if self._conn is None or self._conn.closed:
                raise psycopg2.OperationalError("not open")
            # Use context manager so the health-check cursor is always closed.
            with self._conn.cursor() as _hc:
                _hc.execute("SELECT 1")
        except Exception:
            self._conn = self._connect()
            if first_connect:
                # Temporary diagnostic log for the pgvector read-only-mode
                # investigation — confirms, per-connection, which branch this
                # container actually took (DDL-provisioning vs read-only-validate).
                logger.info(
                    "First pgvector connection — auto_provision=%s", self._auto_provision,
                )
                # READ-ONLY by default: runtime never issues DDL. Provisioning
                # (schema/table/index creation) is infrastructure's job, done
                # out-of-band. auto_provision=True is for the offline
                # provision_pgvector.py script / non-prod bootstrap only —
                # the running service must never set it.
                if self._auto_provision:
                    self._ensure_schema_and_table()
                else:
                    self._validate_schema_and_table_exist()
                # Retrieval is fully dynamic (every search hits the DB), so we no
                # longer preload the entire table into memory.  A cheap COUNT(*)
                # both surfaces the row count in logs and warms the connection.
                logger.info(
                    "PgVector store ready  →  %s/%s  [%s.%s]  rows=%d",
                    self._pg_host, self._pg_db, self._schema, self._table,
                    self._db_count(),
                )
        return self._conn

    def _validate_schema_and_table_exist(self) -> None:
        """Read-only startup check — NEVER issues DDL.

        Confirms the schema/table already exist, since infrastructure is
        responsible for provisioning them out-of-band. Logs a warning (does
        not raise) on a missing table so a transient permissions hiccup on
        this check doesn't block the whole service from starting — the real
        error still surfaces individually on the first actual search/count
        call against a genuinely missing table.
        """
        conn = self._conn
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT EXISTS (
                    SELECT 1 FROM information_schema.tables
                    WHERE table_schema = %s AND table_name = %s
                );
                """,
                (self._schema, self._table),
            )
            exists = cur.fetchone()[0]

        if exists:
            logger.info(
                "Vector store validated (read-only, no DDL) — %s.%s exists.",
                self._schema, self._table,
            )
        else:
            logger.warning(
                "Vector store validation FAILED (read-only mode, no DDL attempted) — "
                "%s.%s does not exist. Runtime never creates schema/table/index. "
                "Run infrastructure/vector_store/provision_pgvector.py (non-prod) "
                "or have infrastructure provision it out-of-band.",
                self._schema, self._table,
            )

    def _ensure_schema_and_table(self) -> None:
        """Provisioning DDL — offline/dev use only.

        Only reached when ``auto_provision=True`` (set exclusively by
        infrastructure/vector_store/provision_pgvector.py). The running
        service must never call this — see ``_get_conn``.
        """
        conn = self._conn
        with conn.cursor() as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            cur.execute(f"CREATE SCHEMA IF NOT EXISTS {self._schema};")
            cur.execute(_CREATE_TABLE_SQL.format(
                schema=self._schema, table=self._table, dim=self.dimension))
            try:
                cur.execute(_CREATE_INDEX_SQL.format(
                    schema=self._schema, table=self._table))
            except Exception:
                pass
        conn.commit()

    # Columns we expose for each row (everything except the embedding/id)
    _ROW_COLUMNS: List[str] = [
        "tbl_catlg_nm", "tbl_schema_nm", "zone_nm", "tbl_nm", "colmn_nm",
        "ordinal_pos_num", "colmn_deflt_val", "nullable_flg", "data_ty",
        "cmmnt_txt", "extra_info_txt", "tbl_lgcl_nm", "tbl_cmmnt_txt",
        "colmn_lgcl_nm", "colmn_cmmnt_txt", "fk_flg", "pk_flg",
        "phi_pii_ind", "deflt_val_txt", "prnt_tbl_phy_nm", "vw_ty_desc",
    ]

    def _db_count(self) -> int:
        conn = self._get_conn()
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {self._schema}.{self._table};")
            return cur.fetchone()[0]

    # ------------------------------------------------------------------
    # Embedding helpers
    # ------------------------------------------------------------------

    def _embed_text(self, text: str) -> np.ndarray:
        # ── In-process cache: avoid re-embedding repeated queries ────────────
        if text in self._embedding_cache:
            logger.debug("Embedding cache HIT  text=%r", text[:60])
            return np.array(self._embedding_cache[text], dtype="float32")

        # ── Bedrock call with retry (mirrors _embed_texts_batch) ─────────────
        last_exc: Exception = RuntimeError("unreachable")
        for attempt in range(3):
            try:
                client = self._get_bedrock_client()
                response = client.invoke_model(
                    modelId=self.embedding_model,
                    body=json.dumps({"inputText": text}),
                )
                body = json.loads(response["body"].read())
                embedding: List[float] = body["embedding"]
                if len(embedding) != self.dimension:
                    self.dimension = len(embedding)

                # Store in cache; evict oldest entry when cap reached
                if len(self._embedding_cache) >= self._embedding_cache_max:
                    self._embedding_cache.pop(next(iter(self._embedding_cache)))
                self._embedding_cache[text] = embedding

                return np.array(embedding, dtype="float32")
            except Exception as exc:
                last_exc = exc
                if attempt < 2:
                    wait = 2 ** attempt  # 1s, 2s
                    logger.warning(
                        "Bedrock embed attempt %d/3 failed (%s) — retrying in %ds",
                        attempt + 1, exc, wait,
                    )
                    time.sleep(wait)

        raise last_exc

    def _embed_texts_batch(self, texts: List[str], batch_size: int = 20) -> List[Optional[np.ndarray]]:
        results: List[Optional[np.ndarray]] = [None] * len(texts)

        def _embed_one(args):
            idx, text = args
            for attempt in range(3):
                try:
                    return idx, self._embed_text(text)
                except Exception as exc:
                    if attempt == 2:
                        logger.warning("Embedding failed for index %d: %s", idx, exc)
                        return idx, None
                    time.sleep(1)

        completed = 0
        with ThreadPoolExecutor(max_workers=batch_size) as pool:
            futures = {pool.submit(_embed_one, (i, t)): i for i, t in enumerate(texts)}
            for fut in as_completed(futures):
                idx, vec = fut.result()
                results[idx] = vec
                completed += 1
                step = max(1, len(texts) // 10)
                if completed % step == 0:
                    logger.debug("Embedding progress: %d/%d", completed, len(texts))

        return results

    # ------------------------------------------------------------------
    # Searchable text builder
    # ------------------------------------------------------------------

    # Mapping of human-readable label -> physical column name in the DB row.
    _SEARCHABLE_FIELDS: List[tuple] = [
        ("Catalog",            "tbl_catlg_nm"),
        ("Schema",             "tbl_schema_nm"),
        ("Zone",               "zone_nm"),
        ("Table",              "tbl_nm"),
        ("Table Logical Name", "tbl_lgcl_nm"),
        ("Table Comment",      "tbl_cmmnt_txt"),
        ("View Type",          "vw_ty_desc"),
        ("Column",             "colmn_nm"),
        ("Column Logical Name", "colmn_lgcl_nm"),
        ("Column Comment",     "colmn_cmmnt_txt"),
        ("Comment",            "cmmnt_txt"),
        ("Extra Info",         "extra_info_txt"),
        ("Data Type",          "data_ty"),
        ("Ordinal Position",   "ordinal_pos_num"),
        ("Nullable",           "nullable_flg"),
        ("Default Value",      "deflt_val_txt"),
        ("Column Default",     "colmn_deflt_val"),
        ("Primary Key",        "pk_flg"),
        ("Foreign Key",        "fk_flg"),
        ("Parent Table",       "prnt_tbl_phy_nm"),
        ("PHI/PII",            "phi_pii_ind"),
    ]

    @classmethod
    def _create_searchable_text(cls, row: Dict[str, Any]) -> str:
        parts: List[str] = []
        for label, col in cls._SEARCHABLE_FIELDS:
            val = row.get(col)
            if val not in (None, "", "null"):
                parts.append(f"{label}: {val}")
        return " | ".join(parts)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_metadata(self, metadata_entries: List[Dict[str, Any]], batch_size: int = 10) -> None:
        """Insert flat row-per-column entries. Each entry must have the
        ``tbl_*`` / ``colmn_*`` keys defined in :pyattr:`_ROW_COLUMNS`."""
        if not metadata_entries:
            return
        logger.info("Adding %d entries to PgVector store…", len(metadata_entries))
        texts = [self._create_searchable_text(e) for e in metadata_entries]
        embeddings = self._embed_texts_batch(texts, batch_size=batch_size)
        conn = self._get_conn()
        inserted = 0
        cols = self._ROW_COLUMNS + ["embedding"]
        placeholders = ",".join(["%s"] * len(cols))
        cols_sql = ", ".join(cols)
        insert_sql = (
            f"INSERT INTO {self._schema}.{self._table} ({cols_sql}) "
            f"VALUES ({placeholders})"
        )
        with conn.cursor() as cur:
            for entry, vec in zip(metadata_entries, embeddings):
                if vec is None:
                    continue
                values = [entry.get(c) for c in self._ROW_COLUMNS] + [vec.tolist()]
                cur.execute(insert_sql, values)
                inserted += 1
        conn.commit()
        self.metadata_store.extend(
            e for e, v in zip(metadata_entries, embeddings) if v is not None
        )
        logger.info(
            "Inserted %d/%d entries. Total in DB: %d",
            inserted, len(metadata_entries), self._db_count(),
        )

    def _build_search_sql(
        self,
        query_vec: Any,
        filter_dict: Optional[Dict[str, Any]],
        top_k: int,
    ) -> tuple:
        """Build the SQL query and parameter list for a vector similarity search.

        Returns ``(sql, params)`` ready to pass to a psycopg2 cursor.
        """
        where_clauses: List[str] = []
        params: List[Any] = [query_vec.tolist()]

        if filter_dict:
            for k, v in filter_dict.items():
                if k not in self._ROW_COLUMNS:
                    continue
                where_clauses.append(f"{k} = %s")
                params.append(v)

        params.append(top_k)
        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
        cols_sql  = ", ".join(self._ROW_COLUMNS)
        sql = f"""
            SELECT {cols_sql},
                   embedding <-> %s::vector AS distance
            FROM   {self._schema}.{self._table}
            {where_sql}
            ORDER  BY distance
            LIMIT  %s;
        """
        return sql, params

    def _run_search_query(self, sql: str, params: List[Any]) -> List[Any]:
        """Execute the search query with automatic retry on ``OperationalError``."""
        for attempt in range(3):
            try:
                conn = self._get_conn()
                with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                    cur.execute(sql, params)
                    return cur.fetchall()
            except psycopg2.OperationalError as exc:
                self._conn = None  # force full reconnect on next _get_conn() call
                if attempt < 2:
                    wait = 2 ** attempt  # 1s, 2s
                    logger.warning(
                        "pgvector search attempt %d/3 failed (%s) — retrying in %ds",
                        attempt + 1, exc, wait,
                    )
                    time.sleep(wait)
                else:
                    raise
        return []  # unreachable; satisfies type checker

    def search(
        self,
        query: str,
        top_k: int = 50,
        filter_dict: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Single semantic similarity search across all rows (each row = one column).

        Returns the top-k matching rows as flat dicts (one per column) with
        ``_score`` and ``_similarity`` populated.

        Results are cached in-process for 30 minutes when no filter is applied
        (the common agent path).  Filtered searches bypass the cache because
        their results are specific to the filter values.
        """
        # ── In-process search result cache ───────────────────────────────────
        _cache_key = f"{query}|{top_k}" if not filter_dict else None
        if _cache_key is not None:
            _hit = self._search_cache.get(_cache_key)
            if _hit is not None:
                logger.debug(
                    "Vector search cache HIT  query=%r  top_k=%d  results=%d",
                    query[:60], top_k, len(_hit),
                )
                return _hit

        if self._db_count() == 0:
            logger.warning("PgVector store is empty.")
            return []

        query_vec       = self._embed_text(query)
        sql, params     = self._build_search_sql(query_vec, filter_dict, top_k)
        logger.debug("[PgVector] query=%r  top_k=%d", query[:80], top_k)
        _rows_raw       = self._run_search_query(sql, params)

        results: List[Dict[str, Any]] = []
        for row in _rows_raw:
            d = {c: row[c] for c in self._ROW_COLUMNS}
            distance = float(row["distance"])
            d["_score"]      = distance
            d["_similarity"] = float(1.0 / (1.0 + distance))
            results.append(d)

        # Store in search result cache (unfiltered calls only)
        if _cache_key is not None:
            self._search_cache.set(_cache_key, results)
            logger.debug(
                "Vector search cache STORE  query=%r  top_k=%d  results=%d",
                query[:60], top_k, len(results),
            )

        return results

    # ------------------------------------------------------------------
    # Grouping helper
    # ------------------------------------------------------------------

    # Column-level fields kept inside each table's `columns` array.
    _COLUMN_FIELDS: List[str] = [
        "zone_nm",
        "colmn_nm", "colmn_lgcl_nm", "colmn_cmmnt_txt",
        "ordinal_pos_num", "data_ty", "nullable_flg",
        "colmn_deflt_val", "deflt_val_txt",
        "pk_flg", "fk_flg", "prnt_tbl_phy_nm",
        "phi_pii_ind", "cmmnt_txt", "extra_info_txt",
    ]

    # ── Metric-aware retrieval ────────────────────────────────────────────────
    # Query keywords that signal a metric-oriented intent.  When any of these
    # appear in the user's query, numeric metric columns in every retrieved
    # table receive a ranking boost and are force-included even when the table
    # already satisfies the min_columns_per_table threshold.
    _METRIC_QUERY_KEYWORDS: tuple = (
        "count", "total", "metric", "amount", "lives",
        "members", "employees", "enrollment",
    )

    # Column-name keywords that identify a pre-aggregated numeric metric column.
    _METRIC_COL_KEYWORDS: tuple = (
        "count", "total", "sum", "amount", "lives", "enrolled",
        "eligible", "premium", "balance", "rate", "percent", "pct",
        "revenue", "headcount", "volume", "qty", "quantity",
    )

    # Numeric Redshift data types — mirrors RedshiftToolService._NUMERIC_TYPES.
    _NUMERIC_TYPES_PGV: tuple = (
        "integer", "int", "bigint", "smallint", "numeric", "decimal",
        "float", "double", "real", "number",
    )

    # Column-name suffixes that indicate a numeric identifier, not a metric —
    # excluded even when a metric keyword appears as a substring in their name.
    _IDENTIFIER_SUFFIXES_PGV: tuple = ("_id", "_key", "_number")

    # Distance multiplier for metric columns in metric-oriented queries.
    # L2 distance is lower-is-better, so multiplying by < 1.0 boosts rank.
    # 0.6 brings a metric column with distance 0.5 up to 0.30, overtaking
    # a text column with distance 0.35 in the original flat ranking.
    _METRIC_BOOST_FACTOR: float = 0.6

    @classmethod
    def _is_metric_query(cls, query: str) -> bool:
        """Return True when the query has a metric-oriented intent."""
        q = f" {query.lower()} "
        return any(kw in q for kw in cls._METRIC_QUERY_KEYWORDS)

    @classmethod
    def _is_metric_column_row(cls, row: Dict[str, Any]) -> bool:
        """Return True when a flat pgvector row represents a numeric metric column.

        A metric column must:
        1. Have a name containing a metric keyword.
        2. Have a numeric data type.
        3. NOT end with an identifier suffix (_id, _key, _number).
        """
        col_name = (row.get("colmn_nm") or "").lower()
        data_type = (row.get("data_ty") or "").lower()
        has_metric_kw = any(kw in col_name for kw in cls._METRIC_COL_KEYWORDS)
        is_numeric = any(nt in data_type for nt in cls._NUMERIC_TYPES_PGV)
        is_identifier = col_name.endswith(cls._IDENTIFIER_SUFFIXES_PGV)
        return has_metric_kw and is_numeric and not is_identifier

    @classmethod
    def _apply_metric_boost(
        cls, rows: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Return *rows* re-sorted after applying a distance boost to metric columns.

        Metric column rows have their ``_score`` (L2 distance) multiplied by
        ``_METRIC_BOOST_FACTOR`` (< 1.0), reducing their distance and lifting
        them higher in the ranking.  Non-metric rows are unchanged.  The
        returned list is sorted ascending by the (possibly boosted) score.
        """
        boosted: List[Dict[str, Any]] = []
        for row in rows:
            r = dict(row)  # shallow copy — never mutate the cached list
            if cls._is_metric_column_row(r):
                r["_score"] = r["_score"] * cls._METRIC_BOOST_FACTOR
                r["_similarity"] = 1.0 / (1.0 + r["_score"])
                r["_metric_boosted"] = True
            boosted.append(r)
        return sorted(boosted, key=lambda x: x["_score"])

    @classmethod
    def _group_rows_by_table(
        cls, rows: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Group flat result rows by (catalog, schema, table)."""
        grouped: Dict[tuple, Dict[str, Any]] = {}
        order: List[tuple] = []  # preserve best-rank order

        for row in rows:
            key = (
                row.get("tbl_catlg_nm") or "",
                row.get("tbl_schema_nm") or "",
                row.get("tbl_nm") or "",
            )
            if key not in grouped:
                grouped[key] = {
                    "catalog_name":  row.get("tbl_catlg_nm"),
                    "schema_name":   row.get("tbl_schema_nm"),
                    "zone_name":     row.get("zone_nm"),
                    "table_name":    row.get("tbl_nm"),
                    "table_logical_name": row.get("tbl_lgcl_nm"),
                    "table_comment": row.get("tbl_cmmnt_txt"),
                    "view_type":     row.get("vw_ty_desc"),
                    "best_score":    row.get("_score"),
                    "columns":       [],
                }
                order.append(key)

            col_entry = {f: row.get(f) for f in cls._COLUMN_FIELDS}
            col_entry["_score"] = row.get("_score")
            col_entry["_similarity"] = row.get("_similarity")
            grouped[key]["columns"].append(col_entry)

        return [grouped[k] for k in order]

    def search_grouped_by_table(
        self,
        query: str,
        top_k: int = 50,
        filter_dict: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Run a single semantic search and return results grouped by table:

        ``[{catalog_name, schema_name, table_name, columns:[{...}, ...]}, ...]``
        """
        rows = self.search(query, top_k=top_k, filter_dict=filter_dict)
        return self._group_rows_by_table(rows)

    def _backfill_table_columns(
        self, query: str, table: Dict[str, Any], min_columns: int,
    ) -> None:
        """Ensure *table* has a fair column list, independent of global ranking.

        ``search()`` returns a SINGLE flat top-K list of column-level rows
        ranked by similarity across the ENTIRE dictionary — not per table.
        A table whose own columns don't happen to score in that shared global
        top-K appears with a severely truncated (sometimes single-column)
        list, even when the table itself is highly relevant — e.g. a
        Book-of-Business query where ``client_golden_record_mvw`` columns
        dominate the pool and leave ``policy_golden_record_mvw`` /
        ``policy_product_mvw`` with almost no visible columns.  A table that
        looks nearly empty in the schema context reads as unusable to the
        LLM, which then omits it and any join across it — exactly the
        "retrieved but not used" symptom.

        Runs a table-scoped search (via ``filter_dict``) to top up the
        column list for any selected table below *min_columns*.
        """
        if len(table["columns"]) >= min_columns:
            return
        filt = {"tbl_schema_nm": table["schema_name"], "tbl_nm": table["table_name"]}
        extra_rows = self.search(query, top_k=min_columns, filter_dict=filt)
        seen = {c.get("colmn_nm") for c in table["columns"]}
        for row in extra_rows:
            cname = row.get("colmn_nm")
            if not cname or cname in seen:
                continue
            seen.add(cname)
            col_entry = {f: row.get(f) for f in self._COLUMN_FIELDS}
            col_entry["_score"] = row.get("_score")
            col_entry["_similarity"] = row.get("_similarity")
            table["columns"].append(col_entry)

    def _force_metric_columns_for_table(
        self,
        query: str,
        table: Dict[str, Any],
        max_force: int = 3,
    ) -> List[str]:
        """Force include the best numeric metric columns from a table.

        Runs a table-scoped similarity search (up to 50 candidates) and adds
        any numeric metric column not already present in ``table["columns"]``.
        Entries added here are marked ``_force_included=True`` so downstream
        logging can distinguish them from normally-retrieved columns.

        Returns a list of ``schema.table.column`` strings that were injected,
        for logging.  Always safe to call even if the table already has ample
        columns — guard logic prevents duplicates.

        Called only for metric-oriented queries (see ``_is_metric_query``).
        """
        filt = {"tbl_schema_nm": table["schema_name"], "tbl_nm": table["table_name"]}
        # top_k=50 covers the full column set of most views; filters bypass
        # the in-process cache so results are always fresh (correct behavior).
        candidate_rows = self.search(query, top_k=50, filter_dict=filt)

        seen = {c.get("colmn_nm") for c in table["columns"]}
        forced: List[str] = []

        for row in candidate_rows:
            if len(forced) >= max_force:
                break
            col_name = row.get("colmn_nm")
            if not col_name or col_name in seen:
                continue
            if not self._is_metric_column_row(row):
                continue
            seen.add(col_name)
            col_entry = {f: row.get(f) for f in self._COLUMN_FIELDS}
            col_entry["_score"] = row.get("_score")
            col_entry["_similarity"] = row.get("_similarity")
            col_entry["_force_included"] = True
            table["columns"].append(col_entry)
            full = (
                f"{table.get('schema_name', '')}"
                f".{table.get('table_name', '')}"
                f".{col_name}"
            )
            forced.append(full)
            logger.info(
                "FORCE_INCLUDE_METRIC_COLUMN table=%s.%s column=%s score=%.4f",
                table["schema_name"], table["table_name"],
                col_name, row.get("_score", 0.0),
            )

        return forced

    def search_tables_and_columns(
        self,
        query: str,
        table_count: int = 10,
        column_count: int = 30,
        min_columns_per_table: int = 8,
        **_: Any,
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Backward-compatible wrapper with metric-aware retrieval.

        Performs a single semantic search over rows and reshapes the output
        into the legacy ``{"tables": [...], "columns": [...]}`` shape.

        Metric-aware additions:
        - When the query is metric-oriented (contains words like "count",
          "lives", "employees", "enrollment" etc.), numeric metric columns
          receive an L2-distance boost so they rank ahead of text/description
          columns in the flat similarity list.
        - After backfill, every selected table is additionally scanned for
          numeric metric columns that did not make the global top-K.  Up to
          3 such columns per table are force-injected into the schema context
          regardless of whether the table's column count already satisfied
          min_columns_per_table — preventing metric columns like
          ``total_eligible_employees_count`` from being silently excluded when
          text columns dominate the global ranking.
        """
        metric_query = self._is_metric_query(query)
        rows = self.search(query, top_k=max(column_count, table_count))

        # ── Log raw retrieval scores before any modification ─────────────────
        logger.info(
            "TOP_RETRIEVED_COLUMNS_WITH_SCORES (raw, before boost)=%s",
            [
                (
                    f"{r.get('tbl_schema_nm', '')}.{r.get('tbl_nm', '')}.{r.get('colmn_nm', '')}",
                    round(r.get("_score", 0.0), 4),
                    r.get("data_ty", ""),
                )
                for r in rows[:30]
            ],
        )

        if metric_query:
            metric_raw = [
                r for r in rows if self._is_metric_column_row(r)
            ]
            logger.info(
                "METRIC_COLUMNS_WITH_SCORES (pre-boost, in raw top-%d)=%s",
                len(rows),
                [
                    (
                        f"{r.get('tbl_schema_nm', '')}.{r.get('tbl_nm', '')}.{r.get('colmn_nm', '')}",
                        round(r.get("_score", 0.0), 4),
                        r.get("data_ty", ""),
                    )
                    for r in metric_raw[:20]
                ],
            )
            # Apply distance boost and re-sort so metric columns rank higher.
            rows = self._apply_metric_boost(rows)

        grouped = self._group_rows_by_table(rows)
        selected = grouped[:table_count]

        for t in selected:
            self._backfill_table_columns(query, t, min_columns_per_table)

        # ── Metric force-include ──────────────────────────────────────────────
        # For metric-oriented queries, run a table-scoped search for each
        # selected table and force-inject any numeric metric column not yet
        # present in the column list, regardless of how many columns the table
        # already has.  This is the safety net that catches metric columns
        # like ``total_eligible_employees_count`` when text columns dominate
        # the shared global top-K and crowd them out.
        all_forced: List[str] = []
        forced_rows_by_table: Dict[str, List[Dict[str, Any]]] = {}
        if metric_query:
            for t in selected:
                tbl_key = f"{t.get('schema_name', '')}.{t.get('table_name', '')}"
                forced = self._force_metric_columns_for_table(query, t)
                if forced:
                    all_forced.extend(forced)
                    # Collect the raw rows for the forced columns so they can
                    # be included in the `columns` output list below.
                    forced_rows_by_table[tbl_key] = [
                        c for c in t["columns"] if c.get("_force_included")
                    ]

        if all_forced:
            logger.info("FORCED_METRIC_COLUMNS=%s", all_forced)

        tables: List[Dict[str, Any]] = []
        for t in selected:
            tables.append({
                # NOTE: intentionally schema.table ONLY — never catalog.schema.table.
                # ``tbl_catlg_nm`` (catalog_name) is the AWS Glue Data Catalog / Spectrum
                # catalog name (e.g. "gdh_spectrum") recorded for lineage/bookkeeping in
                # the data dictionary.  It is NOT a valid identifier segment for this
                # direct psycopg2 connection to the "discovery" database — Redshift
                # resolves unqualified two-part names as schema.table within the
                # connected database.  Prefixing it produces
                # ``psycopg2.errors.InvalidCatalogName: "gdh_spectrum" does not exist``.
                # catalog_name is still exposed as a separate metadata field below for
                # callers that need lineage info, but it must NEVER be concatenated
                # into full_table_name / full_column_name.
                "full_table_name": ".".join(
                    p for p in [t.get("schema_name"), t.get("table_name")] if p
                ),
                "catalog_name":   t.get("catalog_name"),
                "schema_name":    t.get("schema_name"),
                "zone_name":      t.get("zone_name"),
                "table_name":     t.get("table_name"),
                "table_description": t.get("table_logical_name"),
                "table_comment":  t.get("table_comment"),
                "column_names":   [c.get("colmn_nm") for c in t.get("columns", []) if c.get("colmn_nm")],
                # name -> Redshift data type (e.g. "INTEGER", "VARCHAR(50)"), so
                # callers building the LLM schema context can show types and
                # avoid type-coercion mistakes (e.g. COALESCE(integer_col, '')).
                "column_types": {
                    c["colmn_nm"]: c.get("data_ty") or "unknown"
                    for c in t.get("columns", []) if c.get("colmn_nm")
                },
                "primary_key_columns":
                    [c.get("colmn_nm") for c in t.get("columns", []) if (c.get("pk_flg") or "").upper() in ("Y", "YES", "TRUE", "1")],
                "foreign_key_columns":
                    [c.get("colmn_nm") for c in t.get("columns", []) if (c.get("fk_flg") or "").upper() in ("Y", "YES", "TRUE", "1")],
                "_score": t.get("best_score"),
            })

        # Build the column-level output list from the (possibly boosted) rows
        # plus any force-included metric columns not already present.
        columns: List[Dict[str, Any]] = []
        seen_col_keys: set = set()

        def _row_to_col_dict(row: Dict[str, Any]) -> Dict[str, Any]:
            return {
                # schema.table.column ONLY — see full_table_name note above re: catalog_name.
                "full_column_name": ".".join(
                    p for p in [row.get("tbl_schema_nm"),
                                row.get("tbl_nm"), row.get("colmn_nm")] if p
                ),
                "catalog_name":  row.get("tbl_catlg_nm"),
                "schema_name":   row.get("tbl_schema_nm"),
                "zone_name":     row.get("zone_nm"),
                "table_name":    row.get("tbl_nm"),
                "column_name":   row.get("colmn_nm"),
                "data_type":     row.get("data_ty"),
                "is_primary_key": (row.get("pk_flg") or "").upper() in ("Y", "YES", "TRUE", "1"),
                "is_foreign_key": (row.get("fk_flg") or "").upper() in ("Y", "YES", "TRUE", "1"),
                "parent_table_physical_name": row.get("prnt_tbl_phy_nm"),
                "column_description": row.get("colmn_lgcl_nm"),
                "column_comment":     row.get("colmn_cmmnt_txt"),
                "_score": row.get("_score"),
                "_metric_boosted": row.get("_metric_boosted", False),
                "_force_included": row.get("_force_included", False),
            }

        for row in rows[:column_count]:
            key = (
                row.get("tbl_schema_nm", ""),
                row.get("tbl_nm", ""),
                row.get("colmn_nm", ""),
            )
            if key not in seen_col_keys:
                seen_col_keys.add(key)
                columns.append(_row_to_col_dict(row))

        # Append force-included metric columns that didn't make the top-K rows.
        for tbl_key, forced_col_entries in forced_rows_by_table.items():
            # col_entry is a _COLUMN_FIELDS dict (colmn_nm, data_ty …), not a
            # full pgvector row — it lacks tbl_schema_nm/tbl_nm.  Reconstruct
            # the dedup key from tbl_key (which is "schema.table").
            schema_nm, tbl_nm = (tbl_key.split(".", 1) + [""])[:2]
            for col_entry in forced_col_entries:
                key = (schema_nm, tbl_nm, col_entry.get("colmn_nm", ""))
                if key not in seen_col_keys:
                    seen_col_keys.add(key)
                    columns.append({
                        "full_column_name": ".".join(filter(None, list(key))),
                        "catalog_name":  None,
                        "schema_name":   schema_nm,
                        "zone_name":     col_entry.get("zone_nm"),
                        "table_name":    tbl_nm,
                        "column_name":   col_entry.get("colmn_nm"),
                        "data_type":     col_entry.get("data_ty"),
                        "is_primary_key": (col_entry.get("pk_flg") or "").upper() in ("Y", "YES", "TRUE", "1"),
                        "is_foreign_key": (col_entry.get("fk_flg") or "").upper() in ("Y", "YES", "TRUE", "1"),
                        "parent_table_physical_name": col_entry.get("prnt_tbl_phy_nm"),
                        "column_description": col_entry.get("colmn_lgcl_nm"),
                        "column_comment":     col_entry.get("colmn_cmmnt_txt"),
                        "_score": col_entry.get("_score"),
                        "_force_included": True,
                    })

        return {"tables": tables, "columns": columns}

    def persist(self) -> None:
        """No-op: Postgres commits are immediate."""

    def clear(self) -> None:
        """Ingestion-only op — TRUNCATEs the vector table. Disabled at runtime.

        Not called anywhere in the request-serving path today, but guarded
        the same way as the DDL-provisioning path in case an ingestion
        script reuses this class in-process: a read-only-mode role should
        never even attempt it, rather than surfacing a bare InsufficientPrivilege.
        """
        if not self._auto_provision:
            raise PermissionError(
                "PgVectorMetadataVectorStore.clear() issues TRUNCATE, which is "
                "disabled in read-only runtime mode (VECTOR_AUTO_PROVISION=false). "
                "Only offline ingestion/provisioning tooling may call this."
            )
        conn = self._get_conn()
        with conn.cursor() as cur:
            cur.execute(f"TRUNCATE TABLE {self._schema}.{self._table};")
        conn.commit()
        self.metadata_store.clear()
        logger.info("PgVector store cleared.")
