"""Offline pgvector provisioning tool — NOT imported by the running service.

Runtime is read-only by default (see ``VectorDbConfig.auto_provision`` in
``core/config.py`` and ``PgVectorMetadataVectorStore._get_conn`` in
``pgvector_store.py``): it only ever validates that the schema/table/index
already exist and never issues ``CREATE SCHEMA`` / ``CREATE TABLE`` /
``CREATE INDEX`` / ``CREATE EXTENSION``.

Use this script instead, run manually (or via CI) against a non-prod
Aurora instance / a role that actually holds CREATE privilege, to perform
the one-time (or schema-change) provisioning:

    CREATE EXTENSION IF NOT EXISTS vector;
    CREATE SCHEMA IF NOT EXISTS <schema>;
    CREATE TABLE IF NOT EXISTS <schema>.<table> (...);
    CREATE INDEX IF NOT EXISTS <table>_embedding_idx ...;

Usage
-----
::

    python -m infrastructure.vector_store.provision_pgvector \\
        --pg-host <aurora-host> --pg-db pgvector --pg-user <provisioning_role> \\
        --pg-password <password> --schema gbs_clientreporting \\
        --table discovery_clientreporting --embedding-dimension 1024

Or, to reuse the values already resolved by ``core.config.settings``
(still requires the configured DB user to actually hold CREATE privilege —
this script does not elevate permissions, it only opts into issuing the DDL
that runtime now refuses to issue)::

    python -m infrastructure.vector_store.provision_pgvector --from-settings

This script must never run inside the Lambda/EKS runtime path — it is a
standalone provisioning step for environments where infrastructure-as-code
does not already own schema/table/index creation.
"""

from __future__ import annotations

import argparse
import logging
import sys
from typing import Optional

logger = logging.getLogger(__name__)


def main(argv: Optional[list] = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    from infrastructure.vector_store.pgvector_store import PgVectorMetadataVectorStore

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-settings", action="store_true",
                         help="Use core.config.settings.vector_db for all connection values")
    parser.add_argument("--pg-host")
    parser.add_argument("--pg-port", type=int, default=5432)
    parser.add_argument("--pg-db")
    parser.add_argument("--pg-user")
    parser.add_argument("--pg-password")
    parser.add_argument("--schema", default="public")
    parser.add_argument("--table", default="discovery_clientreporting")
    parser.add_argument("--embedding-dimension", type=int, default=1024)
    parser.add_argument("--region", default="us-east-1")
    args = parser.parse_args(argv)

    if args.from_settings:
        from core.config import settings
        vdb = settings.vector_db
        kwargs = dict(
            region=settings.aws.region,
            pg_host=vdb.host, pg_port=vdb.port, pg_db=vdb.database,
            pg_user=vdb.user, pg_password=vdb.password, pg_sslmode=vdb.ssl,
            vector_schema=vdb.schema, vector_table=vdb.table,
            embedding_dimension=vdb.embedding_dimension,
            titan_model_id=vdb.embedding_model,
        )
    else:
        missing = [n for n in ("pg_host", "pg_db", "pg_user", "pg_password")
                   if getattr(args, n) is None]
        if missing:
            parser.error(f"--{', --'.join(m.replace('_', '-') for m in missing)} required "
                         "unless --from-settings is passed")
        kwargs = dict(
            region=args.region,
            pg_host=args.pg_host, pg_port=args.pg_port, pg_db=args.pg_db,
            pg_user=args.pg_user, pg_password=args.pg_password, pg_sslmode=True,
            vector_schema=args.schema, vector_table=args.table,
            embedding_dimension=args.embedding_dimension,
        )

    logger.warning(
        "Provisioning DDL will be issued against %s/%s [%s.%s] — "
        "confirm this role holds CREATE privilege and this is NOT a "
        "production read-only environment.",
        kwargs["pg_host"], kwargs["pg_db"], kwargs["vector_schema"], kwargs["vector_table"],
    )

    # auto_provision=True is the whole point of this standalone script —
    # the running service must never set this itself.
    store = PgVectorMetadataVectorStore(auto_provision=True, **kwargs)
    conn = store._connect()
    store._conn = conn
    store._ensure_schema_and_table()
    logger.info(
        "Provisioning complete — %s.%s ready (rows=%d).",
        kwargs["vector_schema"], kwargs["vector_table"], store._db_count(),
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
