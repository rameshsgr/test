"""Vector-store gateway — adapts PgVectorMetadataVectorStore to the domain interface."""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from infrastructure.vector_store.pgvector_store import PgVectorMetadataVectorStore
from core.config import settings
from domain.interfaces.vector_store_gateway import VectorStoreGateway

logger = logging.getLogger(__name__)


class PgVectorGateway(VectorStoreGateway):
    """Concrete implementation backed by pgvector / Aurora PostgreSQL."""

    def __init__(self, store: PgVectorMetadataVectorStore) -> None:
        self._store = store

    @classmethod
    def create(cls, region: str | None = None, verify_ssl: bool = False) -> "PgVectorGateway":
        """Build PgVectorMetadataVectorStore with all config values passed explicitly.

        Passing values explicitly means the legacy store never needs to open
        config.yaml — it always gets its config from our env-var-first
        core.config.settings regardless of the working directory.
        """
        region = region or settings.aws.region
        vdb = settings.vector_db

        store = PgVectorMetadataVectorStore(
            region=region,
            verify_ssl=verify_ssl,
            pg_host=vdb.host,
            pg_port=vdb.port,
            pg_db=vdb.database,
            pg_user=vdb.user,
            pg_password=vdb.password,
            pg_sslmode=vdb.ssl,
            vector_schema=vdb.schema,
            vector_table=vdb.table,
            embedding_dimension=vdb.embedding_dimension,
            titan_model_id=vdb.embedding_model,
            auto_provision=vdb.auto_provision,
        )
        return cls(store)


    # ------------------------------------------------------------------
    # VectorStoreGateway implementation
    # ------------------------------------------------------------------

    def search_tables_and_columns(
        self,
        query: str,
        table_count: int = 10,
        column_count: int = 30,
    ) -> Dict[str, List[Any]]:
        return self._store.search_tables_and_columns(
            query,
            table_count=table_count,
            column_count=column_count,
        )

    def search(self, query: str, top_k: int = 5) -> List[Any]:
        return self._store.search(query, top_k=top_k)

    def search_grouped_by_table(
        self,
        query: str,
        top_k: int = 50,
    ) -> List[Dict[str, Any]]:
        return self._store.search_grouped_by_table(query, top_k=top_k)

    @property
    def entry_count(self) -> Optional[int]:
        """Number of rows in the vector table, or ``None`` if it cannot be determined.

        Queries the DB directly (retrieval no longer preloads rows into memory —
        see PgVectorMetadataVectorStore.metadata_store).  This is typically the
        *first* connection the store makes in a container's lifetime, since it
        is read once at INIT time from ``api.app._build_tool_service`` before any
        real search has run.  That means a transient connection issue, or a
        failure in ``PgVectorMetadataVectorStore._ensure_schema_and_table()``
        (e.g. the DB role lacking CREATE/ALTER privilege for the one-time
        schema/table/index-ensure DDL), surfaces here even though the
        underlying connection itself may have already succeeded — explaining
        why a failed count here does not imply retrieval is broken.

        Returns ``None`` — never a sentinel int like ``-1`` that could be
        mistaken for a real (impossible) COUNT(*) result — so callers must
        branch on ``is None`` rather than checking for a negative number.
        """
        t0 = time.perf_counter()
        try:
            count = self._store._db_count()
            logger.debug(
                "Vector store count query OK — %d rows (%.3fs)",
                count, time.perf_counter() - t0,
            )
            return count
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Vector store count query FAILED after %.3fs — %s: %s — "
                "falling back to 'count unavailable'. This does NOT necessarily "
                "mean the store is empty: if the underlying connection succeeded "
                "and only a schema/table-ensure step failed, retrieval can still "
                "work normally on subsequent calls.",
                time.perf_counter() - t0, type(exc).__name__, exc,
            )
            return None
