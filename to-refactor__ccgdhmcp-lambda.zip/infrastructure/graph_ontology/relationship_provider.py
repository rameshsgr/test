"""Pluggable relationship-discovery strategies for NeptuneGraphOntologyEnricher.

property_match (default): pkFlag/fkFlag/column-name matching, unchanged
from the original implementation.

graph_traversal: DarColumn -REFERENCES-> DarColumn (NOT REFERENCES_TABLE —
live Neptune inspection confirmed REFERENCES_TABLE only links a column back
to its OWN containing table (columnTable == targetTable in every sampled
instance), so it cannot express an inter-table join. The genuine
join-discovery edge is REFERENCES, confirmed via
`g.E().hasLabel('REFERENCES')...`:

    policy_golden_record_mvw.universal_client_id
        -REFERENCES-> client_golden_record_mvw.universal_client_id
    policy_product_mvw.universal_policy_id
        -REFERENCES-> policy_golden_record_mvw.universal_policy_id

Only 2 such edges exist today, so this provider will legitimately return
nothing for most resolved table sets — enrich() falls back to
PropertyBasedRelationshipProvider whenever that happens (see
neptune_enricher.py).
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)


class RelationshipProvider(ABC):
    """Produces (table_relationships, suggested_joins) — the exact tuple
    shape enrich() has always emitted into graph_context."""

    @abstractmethod
    def discover(
        self,
        resolved: List[Tuple[Dict[str, Any], Dict[str, Any]]],
        pk_cols_by_table: Dict[str, List[str]],
    ) -> Tuple[List[str], List[str]]:
        ...


class PropertyBasedRelationshipProvider(RelationshipProvider):
    """Existing behavior, unmodified: delegates to
    NeptuneGraphOntologyEnricher._build_fk_relationships(), which still
    contains _cross_set_fk_match()/_fallback_fk_match() exactly as before."""

    def __init__(self, enricher: "NeptuneGraphOntologyEnricher") -> None:  # noqa: F821
        self._enricher = enricher

    def discover(self, resolved, pk_cols_by_table):
        return self._enricher._build_fk_relationships(resolved, pk_cols_by_table)


class GraphTraversalRelationshipProvider(RelationshipProvider):
    """Edge-driven: DarColumn -REFERENCES-> DarColumn.

    Traverses from each resolved table's already-fetched DarColumn rows
    (fetched["columns"]) in both directions (out() primary — this column
    holds the FK; in() as a fallback in case a resolved table happens to
    hold the referenced side instead). The target DarColumn row itself
    carries schemaName/tableName/columnName, so no further hop through
    DarTable/HAS_COLUMN is needed to build the join.
    """

    def __init__(self, enricher: "NeptuneGraphOntologyEnricher") -> None:  # noqa: F821
        self._enricher = enricher

    def discover(self, resolved, pk_cols_by_table):
        table_relationships: List[str] = []
        suggested_joins: List[str] = []
        seen: set = set()
        edges_found = 0

        for ctx_tbl, fetched in resolved:
            source_name = ctx_tbl.get("full_name") or ctx_tbl.get("table", "")
            source_table = ctx_tbl.get("table", "")

            for col in fetched["columns"]:
                found = self._discover_for_column(col, source_name, source_table, seen)
                edges_found += found[0]
                table_relationships.extend(found[1])
                suggested_joins.extend(found[2])

        logger.info(
            "GRAPH_TRAVERSAL_SUMMARY references_edges_found=%d inferred_joins=%d",
            edges_found, len(suggested_joins),
        )
        return table_relationships, suggested_joins

    def _discover_for_column(
        self, col: Dict[str, Any], source_name: str, source_table: str, seen: set,
    ) -> Tuple[int, List[str], List[str]]:
        m = self._enricher._m
        table_relationships: List[str] = []
        suggested_joins: List[str] = []
        edges_found = 0

        col_id = col.get("id")
        source_col_name = self._enricher._unwrap(col, m.column_name_property)
        if not (col_id and source_col_name):
            return edges_found, table_relationships, suggested_joins

        target_rows = self._enricher._traverse_column_references(col_id, direction="out")
        if not target_rows:
            target_rows = self._enricher._traverse_column_references(col_id, direction="in")

        for target_row in target_rows:
            edges_found += 1
            join = self._build_join(source_name, source_col_name, source_table, target_row, seen)
            if join:
                table_relationships.append(join[0])
                suggested_joins.append(join[1])

        return edges_found, table_relationships, suggested_joins

    def _build_join(self, source_name, source_col_name, source_table, target_row, seen):
        m = self._enricher._m
        target_schema = self._enricher._unwrap(target_row, m.schema_property)
        target_table = self._enricher._unwrap(target_row, m.table_name_property)
        target_col_name = self._enricher._unwrap(target_row, m.column_name_property)
        if not (target_table and target_col_name):
            return None
        if target_table == source_table:
            return None  # same-table edge — not a cross-table relationship
        if not self._enricher._schema_allowed(target_schema):
            return None

        target_full = f"{target_schema}.{target_table}" if target_schema else target_table
        key = f"{source_name}.{source_col_name}|{target_full}.{target_col_name}"
        if key in seen:
            return None
        seen.add(key)

        logger.info(
            "GRAPH_TRAVERSAL_JOIN source_table=%s source_column=%s target_table=%s target_column=%s",
            source_name, source_col_name, target_full, target_col_name,
        )

        relationship = (
            f"{source_name}.{source_col_name} → {target_full}.{target_col_name} "
            f"(graph-verified relationship — REFERENCES edge, DarColumn→DarColumn)"
        )
        join = f"JOIN {target_full} ON {source_name}.{source_col_name} = {target_full}.{target_col_name}"
        return relationship, join
