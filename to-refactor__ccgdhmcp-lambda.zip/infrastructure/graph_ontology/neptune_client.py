"""Minimal Gremlin client for Amazon Neptune — infrastructure layer.

Replaces the old S3 compact-index download with direct, bounded Gremlin
queries against the Neptune **reader** endpoint. This module owns only the
connection/transport concern (IAM SigV4 signing when the cluster requires
it, connect/submit/close, graceful failure); query shape and enrichment
scope live in :mod:`infrastructure.graph_ontology.neptune_enricher`.

Event-loop isolation (read before touching this file)
--------------------------------------------------------
``gremlin_python``'s default transport (``AiohttpTransport``) manages its
own asyncio event loop internally and drives it synchronously with
``loop.run_until_complete()`` the moment ``Client(...)`` is constructed
(inside ``Connection.connect()``). That blows up with::

    RuntimeError: Cannot run the event loop while another loop is running

whenever ``NeptuneClient`` is constructed or queried on a thread that
*already* has a running event loop — which happens on Lambda: FastAPI
routes here are ``async def``, and at least one caller
(``api/routes/tools.py``) calls ``get_tool_service()`` — which builds
``NeptuneClient`` on cold start — directly inside the coroutine body
*before* offloading to ``asyncio.to_thread``. On Lambda, that coroutine
runs on the same OS thread as Mangum's per-invocation event loop, so
gremlinpython's internal ``run_until_complete()`` collides with it and the
resulting `async_connect` coroutine is abandoned mid-construction
(the "coroutine was never awaited" warning).

Fix: ``NeptuneClient`` never lets gremlinpython run on *whatever* thread
happens to call it. Every gremlinpython call — connect AND every
``submit()`` — is dispatched through a single dedicated background thread
(``concurrent.futures.ThreadPoolExecutor(max_workers=1)``) that this class
owns and that never has an ambient asyncio loop of its own. This class
itself never creates/manages an asyncio event loop and never calls
``run_until_complete()`` — gremlinpython does that internally, but always
on its own private worker thread, so it can never collide with whatever
loop (Mangum's, FastAPI's, or none) is running on the calling thread. This
also guarantees every gremlinpython call for a given connection lands on
the exact same thread its ``Connection``/transport was created on, which
gremlinpython's transport otherwise assumes.

Design notes
------------
* One connection (and its dedicated worker thread) is opened per Lambda
  container and reused across warm invocations (module-level construction
  happens once in ``api.app._build_tool_service``), the same lifecycle as
  the Redshift and pgvector gateways.
* If the cluster cannot be reached (VPC/DNS/auth failure) construction
  raises; the caller (``api/app.py``) catches this and disables graph
  enrichment entirely rather than failing the request path — see the
  "Fallback" behaviour required for this integration.
* IAM auth: Neptune clusters with IAM database authentication enabled
  require each Gremlin websocket handshake to carry a SigV4-signed
  ``Authorization`` header. Signing is done here with botocore's
  ``SigV4Auth`` against the execution role's credentials (no secrets
  needed — same pattern as the rest of this service's AWS access).
"""

from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Optional

import boto3
from botocore.awsrequest import AWSRequest
from botocore.auth import SigV4Auth

from gremlin_python.driver import client as gremlin_client

logger = logging.getLogger(__name__)

_NEPTUNE_SERVICE = "neptune-db"


def gremlin_string_literal(value: Any) -> str:
    """Render *value* as a safely-escaped, single-quoted Gremlin/Groovy
    string literal for direct interpolation into a query string.

    This Neptune cluster rejects Gremlin bindings entirely
    (``MalformedQueryException: Bindings in Gremlin are not supported`` —
    e.g. ``.has('schemaName', schemaVal)`` with a separate bindings dict),
    so every query builder in ``neptune_enricher.py`` must render fully
    concrete query strings instead. Centralizing escaping here (rather
    than each caller hand-rolling it) is what keeps that interpolation
    safe: backslashes and single quotes are escaped, and newlines are
    stripped, so a value containing ``'`` or ``\\`` cannot break out of
    the string literal or inject additional Gremlin steps.

    Single-quoted Groovy strings (unlike double-quoted ``"..."``) never
    perform ``${...}`` GString interpolation, so escaping quote/backslash/
    newline is sufficient — there is no template-expression channel to
    close off.
    """
    if value is None:
        return "null"
    text = str(value).replace("\\", "\\\\").replace("'", "\\'")
    text = text.replace("\n", " ").replace("\r", " ")
    return f"'{text}'"


def _sigv4_headers(host: str, port: int, region: str) -> dict:
    """Sign a Neptune Gremlin websocket handshake with the execution role's
    credentials. Returns headers to attach to the connection request.
    """
    session = boto3.Session()
    credentials = session.get_credentials()
    if credentials is None:
        raise RuntimeError("No AWS credentials available to sign Neptune request")

    request = AWSRequest(
        method="GET",
        url=f"wss://{host}:{port}/gremlin",
        data="",
    )
    SigV4Auth(credentials, _NEPTUNE_SERVICE, region).add_auth(request)
    return dict(request.headers)


class NeptuneClient:
    """Thin wrapper around ``gremlin_python.driver.client.Client``.

    Parameters
    ----------
    endpoint:
        Neptune **reader** endpoint hostname (no scheme/port), e.g.
        ``gbs-dev-...cluster-ro-....neptune.amazonaws.com``. Reads only —
        enrichment never writes to the graph.
    port:
        Gremlin websocket port, default 8182.
    region:
        AWS region for SigV4 signing.
    iam_auth:
        Whether the cluster requires IAM database authentication (SigV4
        signed handshake). Set False for clusters relying purely on VPC
        network isolation.
    timeout_s:
        Per-query timeout. Gremlin queries here are always single-hop /
        bounded, so this can stay short.
    """

    def __init__(
        self,
        endpoint: str,
        port: int = 8182,
        region: str = "us-east-1",
        iam_auth: bool = True,
        timeout_s: float = 5.0,
    ) -> None:
        self.endpoint = endpoint
        self.port = port
        self.region = region
        self.iam_auth = iam_auth
        self.timeout_s = timeout_s
        self._client: Optional[gremlin_client.Client] = None

        # THE fix: gremlinpython's AiohttpTransport drives its own event
        # loop synchronously the moment Client(...) is constructed, which
        # collides with a loop already running on the calling thread (e.g.
        # Mangum's per-invocation loop on Lambda). Isolating every
        # gremlinpython call — connect included — onto one dedicated,
        # loop-free worker thread means gremlinpython can safely run its
        # own internal loop there without ever touching whatever loop (or
        # lack of one) the caller's thread has. We never create/manage an
        # asyncio loop ourselves and never call run_until_complete()
        # directly — see module docstring.
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="NeptuneWorker")
        # Connect happens on that same worker thread too, so it, and every
        # later submit(), always run on the one thread gremlinpython's
        # Connection/transport is bound to.
        calling_thread = threading.current_thread().name
        logger.info("NEPTUNE_INIT_CALLER_THREAD=%s", calling_thread)
        self._executor.submit(self._connect, calling_thread).result(timeout=timeout_s * 2)

    def _connect(self, calling_thread: str) -> None:
        """Runs on ``self._executor``'s dedicated thread — never call directly."""
        worker_thread = threading.current_thread().name
        logger.info("NEPTUNE_THREAD=%s operation=connect caller_thread=%s", worker_thread, calling_thread)

        url = f"wss://{self.endpoint}:{self.port}/gremlin"
        transport_kwargs: dict[str, Any] = {}
        if self.iam_auth:
            transport_kwargs["headers"] = _sigv4_headers(self.endpoint, self.port, self.region)

        logger.info(
            "Connecting to Neptune reader endpoint=%s port=%d iam_auth=%s",
            self.endpoint, self.port, self.iam_auth,
        )
        self._client = gremlin_client.Client(
            url,
            "g",
            message_serializer=gremlin_client.serializer.GraphSONSerializersV3d0(),
            **transport_kwargs,
        )

    def _submit_sync(self, gremlin_query: str) -> list:
        """Runs on ``self._executor``'s dedicated thread — never call directly."""
        logger.info("NEPTUNE_THREAD=%s operation=submit", threading.current_thread().name)
        # No bindings dict: this Neptune cluster rejects Gremlin bindings
        # outright (MalformedQueryException: "Bindings in Gremlin are not
        # supported"). gremlin_query must already be a fully concrete
        # string — see gremlin_string_literal() and neptune_enricher.py's
        # query builders.
        result_set = self._client.submit(gremlin_query)
        return result_set.all().result(timeout=self.timeout_s)

    def submit(self, gremlin_query: str) -> list:
        """Submit a fully-rendered Gremlin string query and return the
        result list.

        *gremlin_query* must be a concrete query string with all values
        already interpolated (via ``gremlin_string_literal()``) — this
        Neptune cluster does not support Gremlin bindings. Callers are
        also responsible for keeping the query single-hop / bounded (see
        neptune_enricher.py) — this client does not enforce scope, it only
        executes.

        Always dispatched onto the dedicated connection thread (see
        module docstring) — safe to call from any thread, including one
        with its own running asyncio event loop.
        """
        if self._client is None:
            raise RuntimeError("Neptune client is not connected")

        logger.info(
            "GRAPH_SOURCE=NEPTUNE NEPTUNE_QUERY=%s caller_thread=%s",
            gremlin_query, threading.current_thread().name,
        )
        results = self._executor.submit(
            self._submit_sync, gremlin_query
        ).result(timeout=self.timeout_s * 2)
        logger.info("NEPTUNE_RESULT_COUNT=%d", len(results))
        return results

    def close(self) -> None:
        if self._client is not None:
            try:
                self._executor.submit(self._client.close).result(timeout=self.timeout_s)
            except Exception:  # noqa: BLE001 — best-effort cleanup only
                logger.debug("Neptune client close() raised, ignoring", exc_info=True)
            self._client = None
        self._executor.shutdown(wait=False)

    @classmethod
    def try_connect(
        cls,
        endpoint: str,
        port: int = 8182,
        region: str = "us-east-1",
        iam_auth: bool = True,
        timeout_s: float = 5.0,
    ) -> Optional["NeptuneClient"]:
        """Construct a client, returning ``None`` (and logging a warning)
        instead of raising if the cluster is unreachable.

        Used at startup so a Neptune outage disables graph enrichment
        rather than failing service initialisation — see the "Fallback"
        requirement for this integration.
        """
        if not endpoint:
            logger.info("Neptune not configured (no endpoint) — vector-only mode.")
            return None
        try:
            return cls(endpoint=endpoint, port=port, region=region, iam_auth=iam_auth, timeout_s=timeout_s)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Neptune connection failed: %s — graph enrichment disabled (vector-only mode).",
                exc,
            )
            return None
