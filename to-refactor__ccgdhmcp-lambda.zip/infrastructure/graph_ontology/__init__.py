"""Graph ontology infrastructure package — Neptune-backed enrichment."""

from .neptune_client import NeptuneClient
from .neptune_enricher import NeptuneGraphOntologyEnricher as GraphOntologyEnricher

__all__ = ["GraphOntologyEnricher", "NeptuneClient"]
