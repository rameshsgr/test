"""Graph label/property mapping — the single place that knows the Neptune
graph's vocabulary for SQL-generation-relevant metadata.

Why this exists
----------------
The enterprise Neptune graph is not modeled around ``Table``/``View`` +
generic ``HAS_OBJECT``/``HAS_COLUMN`` edges (that was an unvalidated
assumption carried over from an earlier S3-based prototype). The validated
graph sample instead uses:

    DarDatabase, DarSchema, DarTable, DarColumn

with ``DarTable`` properties ``schemaName``, ``tableName``, ``logicalName``,
``physicalName``, ``preferredName``, ``databaseName`` (plus ``conceptId``/
``domainName``, which point into the enterprise concept graph and are
deliberately not traversed here — out of scope for SQL generation) and
``DarColumn`` properties ``columnName``, ``logicalName``, ``pkFlag``,
``fkFlag``, ``keyType`` — importantly, **``DarColumn`` also carries its own
``schemaName``/``tableName``/``databaseName``**, so columns resolve via a
flat property lookup without needing to traverse an edge from their table.

Manual Neptune discovery has since confirmed a ``DarTable -HAS_COLUMN->
DarColumn`` edge exists. ``column_resolution_strategy`` (below) lets
``NeptuneGraphOntologyEnricher`` use it (``"edge_traversal"``) instead of
the flat-property scan — but the default stays ``"flat_properties"`` so
production behavior is unchanged unless explicitly opted into. Other
hierarchy edges (``HAS_SCHEMA``, ``DAR_CONCEPT_OF``, ``DAR_DOMAIN_OF``) and
``REFERENCES``/``REFERENCES_TABLE`` are not used here — the former overlap
with data already flat on ``DarTable``, and the latter haven't had their
endpoint types/population validated yet (see
``scripts/discover_neptune_schema.py``).

Centralizing every label/property name here (instead of inlining them in
Gremlin query strings) is what makes the enricher graph-model-*tolerant*:
if the enterprise graph is later renamed/re-modeled, only this mapping
(config-driven, overridable per-deployment) needs to change.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class GraphSchemaMapping:
    """Vertex labels + property names for the DAR portion of the graph.

    Every field is overridable via env var / config.yaml (see
    ``GraphOntologyConfig.from_dict``) so this can be corrected without a
    code change if discovery reveals different names on the live cluster.

    ``pk_key_type_value`` / ``fk_key_type_value`` are the ``keyType``
    property's literal values (redundant with, and cross-checked against,
    ``pk_flag_property`` / ``fk_flag_property``).

    ``lineage_edge_label`` is intentionally blank by default: no
    view/lineage edge exists in the validated graph sample. Leave blank
    until confirmed; the enricher skips lineage enrichment entirely when    blank rather than guessing an edge name.
    """

    table_label: str = "dataProperties_coreConcepts"
    column_label: str = "dataProperties_coreConcepts"

    schema_property: str = "schema_name"
    table_name_property: str = "table_name"
    database_property: str = "databaseName"
    table_logical_name_property: str = "logicalName"
    table_physical_name_property: str = "physicalName"
    table_preferred_name_property: str = "preferredName"

    column_name_property: str = "column_name"
    column_logical_name_property: str = "logicalName"
    pk_flag_property: str = "primary_key"
    fk_flag_property: str = "foreign_key"
    key_type_property: str = "keyType"
    pk_key_type_value: str = "PRIMARY_KEY"
    fk_key_type_value: str = "FOREIGN_KEY"

    # Not present in the validated DarColumn sample — left blank (disabled)
    # rather than assumed. Set via config if/when a PII/PHI property is
    # confirmed on DarColumn.
    pii_flag_property: str = ""

    # No lineage/view-derivation edge exists in the validated sample.
    # Blank = feature disabled. Set both if discovery confirms an edge.
    lineage_edge_label: str = ""
    lineage_target_table_label: str = ""

    # How NeptuneGraphOntologyEnricher resolves a table's columns.
    # "flat_properties" (default, production behavior): DarColumn carries
    # its own schemaName/tableName, so columns resolve via a property scan
    # with no traversal — safe, but can't distinguish two DarColumn/DarTable
    # vertices that happen to share the same (schemaName, tableName) pair.
    # "edge_traversal": scope columns to the exact resolved DarTable vertex
    # via out(column_edge_label) — confirmed to exist (DarTable-HAS_COLUMN->
    # DarColumn), implemented in _fetch_columns_via_edge(). Opt-in only
    # (config/env var) — the default stays "flat_properties" so production
    # behavior is unchanged unless explicitly switched. Any failure at
    # runtime (missing vertex id, query error) falls back to
    # "flat_properties" automatically — see _resolve_columns().
    column_resolution_strategy: str = "flat_properties"  # or "edge_traversal"

    # Edge label for DarTable -> DarColumn, only consulted when
    # column_resolution_strategy == "edge_traversal". Confirmed via manual
    # Neptune discovery (HAS_COLUMN, DarTable -> DarColumn direction).
    column_edge_label: str = "HAS_COLUMN"

    # Additional DarColumn properties (confirmed present, previously unused
    # by the enrichment) — surfaced into graph_context but not consumed by
    # schema-context construction or SQL generation; purely additive data.
    datatype_property: str = "datatype"
    nullable_flag_property: str = "nullableFlag"
    ordinal_position_property: str = "ordinalPosition"

    # Properties probed by the bounded keyword-expansion lookup (DarTable
    # only, capped with .limit() — see neptune_enricher.py).
    table_search_properties: tuple = field(
        default_factory=lambda: ("tableName", "logicalName", "preferredName")
    )

    # Edge label for DarColumn -> DarTable (confirmed direction from live
    # Neptune evidence, but confirmed to be a column-to-its-OWN-table
    # containment edge, NOT a foreign-key/join edge — every sampled
    # instance has columnTable == targetTable). Kept for reference/
    # discovery use only; NOT used for relationship/join generation.
    reference_table_edge_label: str = "REFERENCES_TABLE"

    # Edge label for DarColumn -> DarColumn (confirmed via live Neptune
    # inspection: outV is the FK-holding column, inV is the referenced
    # column — e.g. policy_golden_record_mvw.universal_client_id
    # -REFERENCES-> client_golden_record_mvw.universal_client_id). This is
    # the genuine join-discovery edge. Only consulted when
    # relationship_strategy == "graph_traversal". Sparse today (2 edges
    # observed) — GraphTraversalRelationshipProvider falls back to
    # property_match whenever a resolved table set has none.
    reference_edge_label: str = "REFERENCES"

    # "property_match" (default, current production behavior — pkFlag/
    # fkFlag/column-name matching via PropertyBasedRelationshipProvider) or
    # "graph_traversal" (GraphTraversalRelationshipProvider, edge-driven via
    # REFERENCES_TABLE). enrich() automatically falls back to
    # property_match within the same call if graph_traversal yields no
    # relationships — see neptune_enricher.py.
    relationship_strategy: str = "property_match"  # or "graph_traversal"

    @classmethod
    def from_dict(cls, d: dict, env_getter) -> "GraphSchemaMapping":
        """Build from config.yaml's ``graph_ontology.schema_mapping`` dict,
        with env-var overrides via *env_getter* (``core.config._env``).
        """
        def _get(key: str, default: str) -> str:
            return env_getter(f"GRAPH_ONTOLOGY_MAPPING_{key.upper()}", d.get(key, default)) or default

        search_props_raw = _get("table_search_properties", "")
        search_props = (
            tuple(p.strip() for p in search_props_raw.split(",") if p.strip())
            if search_props_raw            else ("tableName", "logicalName", "preferredName")
        )
        return cls(
            table_label=_get("table_label", "dataProperties_coreConcepts"),
            column_label=_get("column_label", "dataProperties_coreConcepts"),
            schema_property=_get("schema_property", "schema_name"),
            table_name_property=_get("table_name_property", "table_name"),
            database_property=_get("database_property", "databaseName"),
            table_logical_name_property=_get("table_logical_name_property", "logicalName"),
            table_physical_name_property=_get("table_physical_name_property", "physicalName"),
            table_preferred_name_property=_get("table_preferred_name_property", "preferredName"),
            column_name_property=_get("column_name_property", "column_name"),
            column_logical_name_property=_get("column_logical_name_property", "logicalName"),
            pk_flag_property=_get("pk_flag_property", "primary_key"),
            fk_flag_property=_get("fk_flag_property", "foreign_key"),
            key_type_property=_get("key_type_property", "keyType"),
            pk_key_type_value=_get("pk_key_type_value", "PRIMARY_KEY"),
            fk_key_type_value=_get("fk_key_type_value", "FOREIGN_KEY"),
            pii_flag_property=_get("pii_flag_property", ""),
            lineage_edge_label=_get("lineage_edge_label", ""),
            lineage_target_table_label=_get("lineage_target_table_label", ""),
            column_resolution_strategy=_get("column_resolution_strategy", "flat_properties"),
            column_edge_label=_get("column_edge_label", "HAS_COLUMN"),
            datatype_property=_get("datatype_property", "datatype"),
            nullable_flag_property=_get("nullable_flag_property", "nullableFlag"),
            ordinal_position_property=_get("ordinal_position_property", "ordinalPosition"),
            table_search_properties=search_props,
            reference_table_edge_label=_get("reference_table_edge_label", "REFERENCES_TABLE"),
            reference_edge_label=_get("reference_edge_label", "REFERENCES"),
            relationship_strategy=_get("relationship_strategy", "property_match"),
        )
