"""Neptune-backed Business Ontology Graph Enricher — infrastructure layer.

Built on the *validated* DAR graph model (``DarDatabase``/``DarSchema``/
``DarTable``/``DarColumn`` — see a real sample dump), not on the earlier
S3/compact-index prototype's unvalidated ``Table``/``View`` +
``HAS_OBJECT``/``HAS_COLUMN``/``DERIVED_FROM`` assumptions.

Key structural fact from the validated sample: ``DarColumn`` carries its
own ``schemaName``/``tableName``/``databaseName`` properties, so both
tables and columns resolve via **flat property lookups** —
``g.V().hasLabel('DarTable').has('schemaName', s).has('tableName', t)`` and
the equivalent for ``DarColumn``. No edge traversal is required (and none
is assumed) for table resolution, column resolution, or PK/FK flags.

No relationship/lineage edge exists anywhere in the validated sample, so
join-path enrichment here is a documented heuristic (FK/PK column-name
matching), not a graph-confirmed relationship — see ``enrich()`` below.

Scope discipline
-----------------
This enricher queries only ``DarTable``/``DarColumn`` vertices (as named by
``GraphSchemaMapping``, not hardcoded), restricted to:

  * the (schema, table) pairs PGVector already returned,
  * their own columns (single property-filtered lookup, no traversal),
  * a capped (`.limit()`) property-filtered lookup for FK→PK candidates
    and for keyword expansion.

It never traverses into ``conceptId``/``domainName`` (the enterprise
concept graph) or any other label family (``Concept``, ``Persona``,
``Capability``, ``Governance``, ``SemanticMapping``, ...) — those are
out of scope for SQL generation.

Graph-model tolerance
----------------------
Every label/property name is read from ``GraphSchemaMapping`` (config-
driven — see ``schema_mapping.py``), not hardcoded here. If the graph is
extended with new node types, nothing in this file needs to change unless
those new types carry metadata relevant to SQL generation (PK/FK, joins,
logical names) — this is intentionally not a generic graph explorer.

Public contract is unchanged from the previous enrichers — same
``enrich()``, ``is_loaded``, ``stats``, ``find_by_logical_name()``,
``from_settings()`` — so ``RedshiftToolService`` requires no changes.

Abstraction boundary (read before "fixing" table/column resolution)
---------------------------------------------------------------------
Today's flat-property lookup (``DarTable``/``DarColumn`` each carrying
their own ``schemaName``/``tableName``) is an artifact of the *current*
validated graph sample, not a permanent contract. If a future graph
version introduces explicit ``DarSchema -> DarTable -> DarColumn`` edges,
or replaces these labels with canonical metadata entities entirely, only
this file (concretely: ``_fetch_table_row``, ``_fetch_columns``,
``_fetch_table_and_columns``, and ``GraphSchemaMapping``) should need to
change. PGVector retrieval, schema-context construction
(``RedshiftToolService._build_schema_context``), SQL generation, and MCP
tool contracts all consume ``enrich()``'s output shape only and are
unaware of how table/column resolution happens underneath — that is the
whole point of keeping this a narrow metadata-provider abstraction rather
than a generic graph explorer.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Set, Tuple

from infrastructure.graph_ontology.neptune_client import NeptuneClient, gremlin_string_literal
from infrastructure.graph_ontology.relationship_provider import (
    GraphTraversalRelationshipProvider,
    PropertyBasedRelationshipProvider,
)
from infrastructure.graph_ontology.schema_mapping import GraphSchemaMapping
from infrastructure.ttl_cache import TTLCache

logger = logging.getLogger(__name__)

_OWNER_ROLE_KEYWORDS = ("owner", "advisor", "producer", "executive", "manager", "agent")

_CACHE_TTL_SECONDS = 900   # 15 min
_CACHE_MAX_ENTRIES = 256


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().upper() in ("TRUE", "Y", "YES", "1")


class NeptuneGraphOntologyEnricher:
    """Live Neptune-backed metadata provider for SQL-generation enrichment.

    Parameters
    ----------
    client:
        Connected :class:`NeptuneClient`, or ``None`` if Neptune is
        unreachable — the enricher then operates as a no-op (vector-only
        mode).
    mapping:
        :class:`GraphSchemaMapping` — the graph's vertex/property
        vocabulary. Defaults to the validated DAR model.
    allowed_schemas:
        Lowercase schema-name prefixes the Redshift user can access.
    """

    def __init__(
        self,
        client: Optional[NeptuneClient],
        mapping: Optional[GraphSchemaMapping] = None,
        allowed_schemas: tuple = (),
    ) -> None:
        self._client = client
        self._m = mapping or GraphSchemaMapping()
        self._allowed_schema_prefixes: tuple = tuple(
            s.lower() for s in allowed_schemas if s.strip()
        )
        self._cache = TTLCache(ttl_seconds=_CACHE_TTL_SECONDS, max_size=_CACHE_MAX_ENTRIES)
        self._loaded = client is not None
        self._property_provider = PropertyBasedRelationshipProvider(self)
        self._relationship_provider = (
            GraphTraversalRelationshipProvider(self)
            if self._m.relationship_strategy == "graph_traversal"
            else self._property_provider
        )

    # ------------------------------------------------------------------
    # Schema access control
    # ------------------------------------------------------------------

    def _schema_allowed(self, schema_name: str) -> bool:
        if not self._allowed_schema_prefixes:
            return True
        sname = (schema_name or "").lower()
        return any(sname.startswith(pfx) for pfx in self._allowed_schema_prefixes)

    # ------------------------------------------------------------------
    # Bounded Gremlin queries — flat property lookups, no edge traversal
    # ------------------------------------------------------------------

    def _fetch_table_row(self, schema_name: str, table_name: str) -> Optional[Dict[str, Any]]:
        """Resolve one DarTable vertex by (schemaName, tableName).

        Renders a fully concrete query string — this Neptune cluster
        rejects Gremlin bindings (MalformedQueryException), so schema/table
        values are escaped via gremlin_string_literal() and interpolated
        directly rather than passed as a bindings dict.

        Includes the vertex id() (via project(), not valueMap()) so
        column_resolution_strategy == "edge_traversal" can traverse
        out(column_edge_label) from this exact vertex — see
        _resolve_columns()/_fetch_columns_via_edge(). Unused (and
        harmless) when the default "flat_properties" strategy is active.
        """
        m = self._m
        schema_lit = gremlin_string_literal(schema_name)
        table_lit = gremlin_string_literal(table_name)
        query = (
            f"g.V().hasLabel('{m.table_label}')"
            f".has('{m.schema_property}', {schema_lit})"
            f".has('{m.table_name_property}', {table_lit})"
            f".limit(1)"
            f".project('id','{m.schema_property}','{m.table_name_property}','{m.database_property}',"
            f"'{m.table_logical_name_property}','{m.table_physical_name_property}',"
            f"'{m.table_preferred_name_property}')"
            f".by(id())"
            f".by('{m.schema_property}')"
            f".by('{m.table_name_property}')"
            f".by('{m.database_property}')"
            f".by('{m.table_logical_name_property}')"
            f".by('{m.table_physical_name_property}')"
            f".by('{m.table_preferred_name_property}')"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=fetch_table schema=%r table=%r rendered_schema=%s rendered_table=%s",
            schema_name, table_name, schema_lit, table_lit,
        )
        try:
            rows = self._client.submit(query)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Neptune DarTable query failed for %s.%s: %s", schema_name, table_name, exc)
            return None
        return rows[0] if rows else None

    def _column_value_map_properties(self) -> str:
        """Comma-joined, quoted DarColumn property list shared by both the
        flat-property and edge-traversal column queries, so the two
        strategies return an identical row shape regardless of how the
        columns were found.
        """
        m = self._m
        return (
            f"'{m.column_name_property}','{m.column_logical_name_property}',"
            f"'{m.pk_flag_property}','{m.fk_flag_property}','{m.key_type_property}',"
            f"'{m.datatype_property}','{m.nullable_flag_property}','{m.ordinal_position_property}'"
        )

    def _fetch_columns(self, schema_name: str, table_name: str) -> List[Dict[str, Any]]:
        """Default/fallback strategy: resolve a table's DarColumn vertices by
        flat property match. DarColumn carries its own schemaName/tableName,
        so this needs no traversal from DarTable — this is production
        behavior and stays the default regardless of
        column_resolution_strategy's value (see _resolve_columns()).

        Includes each column's vertex id() (via project(), not valueMap())
        so GraphTraversalRelationshipProvider can traverse
        out(reference_table_edge_label) from it — harmless/unused when
        relationship_strategy stays "property_match".
        """
        m = self._m
        schema_lit = gremlin_string_literal(schema_name)
        table_lit = gremlin_string_literal(table_name)
        props = self._column_value_map_properties()
        prop_names = [p.strip("'") for p in props.split(",")]
        by_clauses = "".join(f".by('{p}')" for p in prop_names)
        query = (
            f"g.V().hasLabel('{m.column_label}')"
            f".has('{m.schema_property}', {schema_lit})"
            f".has('{m.table_name_property}', {table_lit})"
            f".project('id',{props})"
            f".by(id()){by_clauses}"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=fetch_columns strategy=flat_properties "
            "schema=%r table=%r rendered_schema=%s rendered_table=%s",
            schema_name, table_name, schema_lit, table_lit,
        )
        try:
            return self._client.submit(query)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Neptune DarColumn query failed for %s.%s: %s", schema_name, table_name, exc)
            return []

    def _fetch_pk_fk_columns(self, schema_name: str, table_name: str) -> Dict[str, List[str]]:
        """Fetch primary-key and foreign-key column names for a table in a
        single round-trip using ``g.inject(1).project(...)``.

        Returns a dict with two keys:

        * ``"primaryKeys"`` — list of ``columnName`` values where
          ``pkFlag == true``
        * ``"secondaryKeys"`` — list of ``columnName`` values where
          ``fkFlag == true``

        Both lists are empty (never absent) if no matching vertices exist.
        The return shape is intentionally flat so callers can consume it
        directly without ``_unwrap()``.

        This is a pure *addition* — it does not replace ``_fetch_columns``
        or alter any existing return shapes.  Use it when only PK/FK column
        name lists are needed and you want to avoid fetching the full column
        set.
        """
        if not self._client:
            return {"primaryKeys": [], "secondaryKeys": []}
        m = self._m
        schema_lit = gremlin_string_literal(schema_name)
        table_lit = gremlin_string_literal(table_name)
        query = (
            f"g.inject(1)"
            f".project('primaryKeys','secondaryKeys')"
            f".by("
            f"g.V().hasLabel('{m.column_label}')"
            f".has('{m.schema_property}', {schema_lit})"
            f".has('{m.table_name_property}', {table_lit})"
            f".has('{m.pk_flag_property}', true)"
            f".values('{m.column_name_property}').fold()"
            f")"
            f".by("
            f"g.V().hasLabel('{m.column_label}')"
            f".has('{m.schema_property}', {schema_lit})"
            f".has('{m.table_name_property}', {table_lit})"
            f".has('{m.fk_flag_property}', true)"
            f".values('{m.column_name_property}').fold()"
            f")"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=fetch_pk_fk_columns schema=%r table=%r "
            "rendered_schema=%s rendered_table=%s",
            schema_name, table_name, schema_lit, table_lit,
        )
        try:
            rows = self._client.submit(query)
            if rows:
                row = rows[0]
                return {
                    "primaryKeys": list(row.get("primaryKeys") or []),
                    "secondaryKeys": list(row.get("secondaryKeys") or []),
                }
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Neptune pk/fk column-name query failed for %s.%s: %s",
                schema_name, table_name, exc,
            )
        return {"primaryKeys": [], "secondaryKeys": []}

    def _fetch_columns_via_edge(self, table_vertex_id: str) -> List[Dict[str, Any]]:
        """Optional strategy (column_resolution_strategy == "edge_traversal"):
        scope columns to the exact resolved DarTable vertex via
        out(column_edge_label) — confirmed to exist as DarTable -HAS_COLUMN->
        DarColumn. Unlike the flat-property scan, this can't cross-match a
        DarColumn belonging to a different vertex that happens to share the
        same (schemaName, tableName) string pair.
        """
        m = self._m
        id_lit = gremlin_string_literal(table_vertex_id)
        query = (
            f"g.V({id_lit})"
            f".out('{m.column_edge_label}')"
            f".valueMap({self._column_value_map_properties()})"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=fetch_columns strategy=edge_traversal "
            "table_vertex_id=%r rendered=%s edge=%s",
            table_vertex_id, id_lit, m.column_edge_label,
        )
        return self._client.submit(query)

    def _resolve_columns(
        self, schema_name: str, table_name: str, table_row: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Dispatch to the configured column-resolution strategy, with the
        property-based lookup always available as a fallback.

        THE resolution seam: this is the one method that knows *how* a
        table's columns are found. Everything above it (``enrich()``, join
        logic, ``RedshiftToolService``, MCP contracts) only ever sees the
        row shape ``_column_value_map_properties()`` defines — never how it
        was obtained — so switching strategies here never requires changes
        outside this file.

        column_resolution_strategy == "edge_traversal" is opt-in only
        (config/env var) — default stays "flat_properties" so production
        behavior is unchanged unless explicitly switched. Any failure in
        the edge path (missing vertex id, query error) degrades to the
        flat-property lookup rather than losing column data.
        """
        m = self._m
        if m.column_resolution_strategy == "edge_traversal":
            table_id = self._unwrap(table_row, "id")
            if not table_id:
                logger.warning(
                    "column_resolution_strategy='edge_traversal' but no vertex id resolved for "
                    "%s.%s — falling back to property-based lookup.",
                    schema_name, table_name,
                )
            else:
                try:
                    return self._fetch_columns_via_edge(table_id)
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "Neptune edge-based column resolution failed for %s.%s (%s) — "
                        "falling back to property-based lookup.",
                        schema_name, table_name, exc,
                    )

        return self._fetch_columns(schema_name, table_name)

    def _fetch_table_and_columns(self, schema_name: str, table_name: str) -> Optional[Dict[str, Any]]:
        cache_key = f"{schema_name.lower()}.{table_name.lower()}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached
        if self._client is None:
            return None

        table_row = self._fetch_table_row(schema_name, table_name)
        if not table_row:
            self._cache.set(cache_key, None)
            return None

        columns = self._resolve_columns(schema_name, table_name, table_row)

        result = {"table": table_row, "columns": columns}
        self._cache.set(cache_key, result)
        return result

    def _traverse_column_references(self, column_vertex_id: str, direction: str = "out") -> List[Dict[str, Any]]:
        """g.V(<column_id>).out('REFERENCES') / .in('REFERENCES') — the
        genuine join-discovery edge (DarColumn -> DarColumn), confirmed via
        live Neptune inspection. Direction "out" is the primary/expected
        case (this column holds the FK); "in" is tried as a fallback by the
        caller in case a resolved table happens to hold the referenced
        side instead. Returns target DarColumn rows (schemaName, tableName,
        columnName) — DarColumn carries these flat, so no further hop
        through DarTable/HAS_COLUMN is needed. Bounded with .limit(5); only
        used by GraphTraversalRelationshipProvider.

        NOTE: distinct from _traverse_reference_edges's earlier use of
        REFERENCES_TABLE, which was confirmed to be a column-to-its-own-
        table containment edge, not a join edge — see schema_mapping.py.
        """
        if not self._client:
            return []
        m = self._m
        id_lit = gremlin_string_literal(column_vertex_id)
        step = "out" if direction == "out" else "in"
        query = (
            f"g.V({id_lit})"
            f".{step}('{m.reference_edge_label}')"
            f".limit(5)"
            f".project('{m.schema_property}','{m.table_name_property}','{m.column_name_property}')"
            f".by('{m.schema_property}')"
            f".by('{m.table_name_property}')"
            f".by('{m.column_name_property}')"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=traverse_column_references column_id=%r edge=%s direction=%s",
            column_vertex_id, m.reference_edge_label, direction,
        )
        try:
            return self._client.submit(query)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Neptune REFERENCES traversal failed for column %s (direction=%s): %s",
                column_vertex_id, direction, exc,
            )
            return []

    def _lookup_fk_candidates(self, fk_col_name: str) -> List[Dict[str, Any]]:
        """Bounded (.limit(5)), single-label, property-indexed lookup for
        DarColumn vertices elsewhere in the graph that could be the
        referenced PK for *fk_col_name* — a naming-convention heuristic,
        not a graph-confirmed relationship (no such edge exists in the
        validated sample).
        """
        if not self._client:
            return []
        m = self._m
        fk_col_lit = gremlin_string_literal(fk_col_name)
        query = (
            f"g.V().hasLabel('{m.column_label}')"
            f".has('{m.column_name_property}', {fk_col_lit})"
            f".has('{m.pk_flag_property}', true)"
            f".limit(5)"
            f".valueMap('{m.schema_property}','{m.table_name_property}','{m.column_name_property}')"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=lookup_fk_candidates fk_col_name=%r rendered=%s",
            fk_col_name, fk_col_lit,
        )
        try:
            return self._client.submit(query)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Neptune FK-candidate lookup failed for column %s: %s", fk_col_name, exc)
            return []

    def _search_tables_by_keyword(self, keyword: str) -> List[Dict[str, Any]]:
        """Bounded (.limit(20)) keyword lookup restricted to the table
        label only.
        """
        if not self._client or not keyword:
            return []
        m = self._m
        kw_lit = gremlin_string_literal(keyword)
        or_clauses = ", ".join(f"has('{prop}', containing({kw_lit}))" for prop in m.table_search_properties)
        query = (
            f"g.V().hasLabel('{m.table_label}')"
            f".or({or_clauses})"
            f".limit(20)"
            f".valueMap("
            f"'{m.schema_property}','{m.table_name_property}',"
            f"'{m.table_logical_name_property}','{m.table_preferred_name_property}',"
            f"'{m.database_property}')"
        )
        logger.info(
            "NEPTUNE_QUERY_PARAMS operation=search_tables_by_keyword keyword=%r rendered=%s",
            keyword, kw_lit,
        )
        try:
            return self._client.submit(query)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Neptune keyword-expansion query failed: %s", exc)
            return []

    # ------------------------------------------------------------------
    # valueMap() results come back as {prop: [value]} — unwrap helper
    # ------------------------------------------------------------------

    @staticmethod
    def _unwrap(row: Dict[str, Any], key: str, default: Any = "") -> Any:
        val = row.get(key, default)
        if isinstance(val, list):
            return val[0] if val else default
        return val

    # ------------------------------------------------------------------
    # Main enrichment entry point
    # ------------------------------------------------------------------

    def _resolve_tables(self, relevant_tables: List[Dict]) -> List[Tuple[Dict, Dict[str, Any]]]:
        """Resolve PGVector's (schema, table) pairs directly against DarTable."""
        resolved: List[Tuple[Dict, Dict[str, Any]]] = []
        for tbl in relevant_tables:
            schema = tbl.get("schema", "")
            table = tbl.get("table", "")
            if not table:
                continue
            fetched = self._fetch_table_and_columns(schema, table)
            if fetched:
                resolved.append((tbl, fetched))
        return resolved

    def _pk_columns_by_table(self, resolved: List[Tuple[Dict, Dict[str, Any]]]) -> Dict[str, List[str]]:
        m = self._m
        return {
            ctx_tbl.get("table", ""): [
                self._unwrap(c, m.column_name_property)
                for c in fetched["columns"]
                if _truthy(self._unwrap(c, m.pk_flag_property, False))
            ]
            for ctx_tbl, fetched in resolved
        }

    def _collect_column_metadata(
        self, resolved: List[Tuple[Dict, Dict[str, Any]]],
    ) -> Dict[str, Dict[str, Any]]:
        """Surface DarColumn's datatype/nullableFlag/ordinalPosition into a
        standalone, purely additive map — keyed ``"table.column"``.

        Deliberately separate from ``_collect_names_and_ownership()`` and
        untouched by join inference: this is optional supplementary data,
        not consumed by schema-context construction, SQL generation, or
        join logic. Callers that don't look at
        ``graph_context["column_metadata"]`` are completely unaffected.
        """
        m = self._m
        column_metadata: Dict[str, Dict[str, Any]] = {}
        for ctx_tbl, fetched in resolved:
            tname = ctx_tbl.get("table", "")
            for c in fetched["columns"]:
                col_name = self._unwrap(c, m.column_name_property)
                if not col_name:
                    continue
                column_metadata[f"{tname}.{col_name}"] = {
                    "datatype": self._unwrap(c, m.datatype_property),
                    "nullable": self._unwrap(c, m.nullable_flag_property),
                    "ordinal_position": self._unwrap(c, m.ordinal_position_property),
                }
        return column_metadata

    def _collect_names_and_ownership(
        self, resolved: List[Tuple[Dict, Dict[str, Any]]],
    ) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
        """Logical-name mapping (table + column) and ownership-shaped columns —
        both derived from already-fetched column rows, no extra queries.
        """
        m = self._m
        logical_name_map: Dict[str, str] = {}
        ownership_columns: Dict[str, List[str]] = {}

        for ctx_tbl, fetched in resolved:
            tname = ctx_tbl.get("table", "")
            table_row = fetched["table"]
            columns = fetched["columns"]

            best_logical = (
                self._unwrap(table_row, m.table_logical_name_property)
                or self._unwrap(table_row, m.table_preferred_name_property)
            )
            if best_logical and best_logical != tname:
                logical_name_map[tname] = best_logical

            for c in columns:
                phys_col = self._unwrap(c, m.column_name_property)
                logic_col = self._unwrap(c, m.column_logical_name_property)
                if logic_col and logic_col != phys_col:
                    logical_name_map[f"{tname}.{phys_col}"] = logic_col

            owner_cols = [
                self._unwrap(c, m.column_name_property) for c in columns
                if any(kw in (self._unwrap(c, m.column_name_property) or "").lower() for kw in _OWNER_ROLE_KEYWORDS)
            ]
            if owner_cols:
                ownership_columns[tname] = owner_cols

        return logical_name_map, ownership_columns

    def _cross_set_fk_match(
        self,
        full_name: str, tname: str, fk_col_name: str,
        resolved: List[Tuple[Dict, Dict[str, Any]]],
        pk_cols_by_table: Dict[str, List[str]],
        seen_rels: Set[str],
    ) -> Optional[Tuple[str, str]]:
        """FK column matching a PK column already inside the resolved set.
        Returns (relationship_str, join_str) for the first match, or None.
        """
        for ctx_tbl2, _ in resolved:
            tname2 = ctx_tbl2.get("table", "")
            if tname2 == tname or fk_col_name not in pk_cols_by_table.get(tname2, []):
                continue
            key = f"{full_name}|{tname2}|{fk_col_name}"
            if key in seen_rels:
                continue
            seen_rels.add(key)
            return (
                f"{full_name}.{fk_col_name} → {tname2}.{fk_col_name} "
                f"(graph-assisted inferred join — fkFlag/pkFlag column-name match within "
                f"the resolved table set; not a verified graph relationship)",
                f"JOIN {tname2} ON {full_name}.{fk_col_name} = {tname2}.{fk_col_name}",
            )
        return None

    def _fallback_fk_match(
        self, full_name: str, tname: str, fk_col_name: str, seen_rels: Set[str],
    ) -> Optional[Tuple[str, str]]:
        """Bounded, capped candidate lookup elsewhere in the graph.

        This is a graph-assisted *inference*, not a graph-confirmed
        relationship: the validated DarColumn sample has no relationship/
        reference edge between an FK column and the PK it points to, so
        this is purely a same-column-name match against other DarColumn
        vertices with ``pkFlag=true``. Callers/prompts must not present
        this (or the resolved-set match above) as a verified join.
        """
        for cand in self._lookup_fk_candidates(fk_col_name):
            cand_schema = self._unwrap(cand, self._m.schema_property)
            cand_table = self._unwrap(cand, self._m.table_name_property)
            if not cand_table or cand_table == tname or not self._schema_allowed(cand_schema):
                continue
            cand_full = f"{cand_schema}.{cand_table}" if cand_schema else cand_table
            key = f"{full_name}.{fk_col_name}→{cand_full}"
            if key in seen_rels:
                return None
            seen_rels.add(key)
            return (
                f"{full_name}.{fk_col_name} → {cand_full}.{fk_col_name} "
                f"(graph-assisted inferred join — unverified naming-convention match "
                f"outside the resolved table set; no relationship edge exists in the graph)",
                f"JOIN {cand_full} ON {full_name}.{fk_col_name} = {cand_full}.{fk_col_name}",
            )
        return None

    def _build_fk_relationships(
        self, resolved: List[Tuple[Dict, Dict[str, Any]]], pk_cols_by_table: Dict[str, List[str]],
    ) -> Tuple[List[str], List[str]]:
        m = self._m
        table_relationships: List[str] = []
        suggested_joins: List[str] = []
        seen_rels: Set[str] = set()

        for ctx_tbl, fetched in resolved:
            full_name = ctx_tbl.get("full_name") or ctx_tbl.get("table", "")
            tname = ctx_tbl.get("table", "")

            for c in fetched["columns"]:
                if not _truthy(self._unwrap(c, m.fk_flag_property, False)):
                    continue
                fk_col_name = self._unwrap(c, m.column_name_property)
                if not fk_col_name:
                    continue

                match = self._cross_set_fk_match(
                    full_name, tname, fk_col_name, resolved, pk_cols_by_table, seen_rels
                ) or self._fallback_fk_match(full_name, tname, fk_col_name, seen_rels)
                if match:
                    table_relationships.append(match[0])
                    suggested_joins.append(match[1])

        return table_relationships, suggested_joins

    def _row_to_extra_table(self, row: Dict[str, Any]) -> Dict[str, Any]:
        m = self._m
        tname = (self._unwrap(row, m.table_name_property) or "").lower()
        schema = self._unwrap(row, m.schema_property)
        return {
            "full_name": f"{schema}.{tname}" if schema else tname,
            "schema": schema,
            "table": tname,
            "logical_name": self._unwrap(row, m.table_logical_name_property)
                            or self._unwrap(row, m.table_preferred_name_property),
            "description": "",
            "object_type": "TABLE",
            "source": "graph_ontology",
            "relevance_score": 0.0,
        }

    def _keyword_probe(
        self, keyword: str, exclude_names: Set[str], seen_extra: Set[str],
    ) -> List[Dict[str, Any]]:
        """One bounded keyword lookup, filtered to new/allowed/unseen tables."""
        found: List[Dict[str, Any]] = []
        for row in self._search_tables_by_keyword(keyword):
            tname = (self._unwrap(row, self._m.table_name_property) or "").lower()
            schema = self._unwrap(row, self._m.schema_property)
            if not tname or tname in exclude_names or tname in seen_extra:
                continue
            if not self._schema_allowed(schema):
                continue
            seen_extra.add(tname)
            found.append(self._row_to_extra_table(row))
        return found

    def _build_extra_tables(self, user_query: str, relevant_tables: List[Dict]) -> List[Dict[str, Any]]:
        """Keyword-expanded tables, bounded to DarTable and capped per probe."""
        if not user_query:
            return []
        extra_tables: List[Dict[str, Any]] = []
        keywords = [w for w in re.findall(r"\b\w+\b", user_query.lower()) if len(w) > 3]
        vector_table_names = {t.get("table", "").lower() for t in relevant_tables}
        seen_extra: Set[str] = set()

        for kw in keywords[:5]:  # cap probes — keep this bounded per request
            extra_tables.extend(self._keyword_probe(kw, vector_table_names, seen_extra))
        return extra_tables

    @staticmethod
    def _annotate_context(
        relevant_tables: List[Dict], relevant_columns: List[Dict], logical_name_map: Dict[str, str],
    ) -> None:
        for col in relevant_columns:
            lkey = f"{col.get('table','')}.{col.get('column','')}"
            if lkey in logical_name_map:
                col["logical_name"] = logical_name_map[lkey]

        for tbl in relevant_tables:
            tname = tbl.get("table", "")
            if tname in logical_name_map:
                tbl["logical_name"] = logical_name_map[tname]

    def _filter_by_allowed_schema(
        self, table_relationships: List[str], suggested_joins: List[str],
    ) -> Tuple[List[str], List[str]]:
        if not self._allowed_schema_prefixes:
            return table_relationships, suggested_joins
        suggested_joins = [
            j for j in suggested_joins
            if self._schema_allowed(j.split(".")[0].replace("JOIN ", "").strip())
        ]
        table_relationships = [
            r for r in table_relationships
            if all(self._schema_allowed(part.split(".")[0]) for part in r.split(" → ") if "." in part)
        ]
        return table_relationships, suggested_joins

    def enrich(self, metadata_context: Dict[str, Any], user_query: str = "") -> Dict[str, Any]:
        if not self._loaded:
            logger.debug("Neptune enricher not connected — skipping enrichment.")
            return metadata_context

        relevant_tables = metadata_context.get("relevant_tables", [])
        relevant_columns = metadata_context.get("relevant_columns", [])

        resolved = self._resolve_tables(relevant_tables)
        pk_cols_by_table = self._pk_columns_by_table(resolved)
        logical_name_map, ownership_columns = self._collect_names_and_ownership(resolved)
        column_metadata = self._collect_column_metadata(resolved)

        table_relationships, suggested_joins = self._relationship_provider.discover(
            resolved, pk_cols_by_table
        )
        join_inference_method = (
            "graph_edge_traversal" if self._m.relationship_strategy == "graph_traversal" else "column_name_match"
        )
        if not suggested_joins and self._m.relationship_strategy == "graph_traversal":
            # REFERENCES_TABLE yielded nothing usable for this table set —
            # fall back to property-based matching within this same
            # enrich() call, before RedshiftToolService's own PK/FK
            # fallback ever gets involved.
            table_relationships, suggested_joins = self._property_provider.discover(
                resolved, pk_cols_by_table
            )
            join_inference_method = "column_name_match_fallback_from_graph_traversal"

        extra_tables = self._build_extra_tables(user_query, relevant_tables)

        self._annotate_context(relevant_tables, relevant_columns, logical_name_map)
        table_relationships, suggested_joins = self._filter_by_allowed_schema(
            table_relationships, suggested_joins
        )

        metadata_context["graph_context"] = {
            # NOTE: table_relationships / suggested_joins are GRAPH-ASSISTED
            # INFERRED joins (fkFlag/pkFlag column-name matching), NOT
            # verified graph relationships — Neptune's DarColumn vertices
            # carry no relationship/reference edge confirming an FK's
            # target PK. Do not present these as authoritative. See
            # `join_inference_method` and the per-entry wording above.
            "table_relationships": table_relationships,
            "suggested_joins": suggested_joins,
            "join_inference_method": join_inference_method,
            "view_lineage": {},   # not implemented — no validated lineage edge (see module docstring)
            "logical_name_map": logical_name_map,
            "pii_columns": {},    # not implemented — no validated PII property on DarColumn
            "central_tables": [],  # requires a whole-graph degree scan — out of scope for live enrichment
            "extra_tables": extra_tables,
            "ownership_columns": ownership_columns,
            # Additive, optional — datatype/nullableFlag/ordinalPosition from
            # DarColumn. Not consumed by schema-context construction or SQL
            # generation; available for future use without any contract change.
            "column_metadata": column_metadata,
        }

        logger.info(
            "GRAPH_SOURCE=NEPTUNE TABLES_ENRICHED=%d inferred_relationships=%d "
            "inferred_joins=%d (join_inference_method=%s) "
            "extra_tables=%d ownership_tables=%d",
            len(resolved), len(table_relationships), len(suggested_joins),
            join_inference_method,
            len(extra_tables), len(ownership_columns),
        )
        return metadata_context

    # ------------------------------------------------------------------
    # Public utilities
    # ------------------------------------------------------------------

    def find_by_logical_name(self, term: str) -> List[Dict[str, Any]]:
        """Business-term → physical-name lookup, bounded to DarTable
        (same scope discipline as ``enrich()``).
        """
        if not self._client:
            return []
        m = self._m
        results: List[Dict[str, Any]] = []
        for row in self._search_tables_by_keyword(term):
            logical = self._unwrap(row, m.table_logical_name_property) or self._unwrap(row, m.table_preferred_name_property)
            if term.lower() in (logical or "").lower():
                results.append({
                    "type": "Table",
                    "physical_name": self._unwrap(row, m.table_name_property),
                    "logical_name": logical,
                    "schema": self._unwrap(row, m.schema_property),
                    "table": self._unwrap(row, m.table_name_property),
                })
        return results

    def get_schema(
        self,
        vertex_labels: Optional[List[str]] = None,
        include_properties: bool = True,
        include_edge_properties: bool = True,
        max_labels: int = 25,
        max_properties_per_label: int = 50,
        sample_size: int = 100,
        max_connections: int = 100,
    ) -> Dict[str, Any]:
        """Return an observed, value-free summary of the Neptune graph-ontology shape.

        Neptune is schemaless, so this is explicitly a sampled observation,
        not a guarantee that every label/property/connection is represented.
        Every traversal is fixed by the server, read-only, output-bounded, and
        returns names only — no vertex IDs or property values are exposed.
        This method does not search PGVector, query Redshift, or inspect the
        separately managed Neptune business-catalog graph.
        """
        if not self._client:
            raise RuntimeError("Neptune graph ontology is not configured or connected")

        label_limit = min(max(int(max_labels), 1), 100)
        property_limit = min(max(int(max_properties_per_label), 1), 200)
        sample_limit = min(max(int(sample_size), 1), 1000)
        connection_limit = min(max(int(max_connections), 1), 500)

        requested_labels = list(dict.fromkeys(
            str(label).strip() for label in (vertex_labels or []) if str(label).strip()
        ))[:label_limit]
        if requested_labels:
            observed_vertex_labels = self._existing_vertex_labels(requested_labels)
        else:
            observed_vertex_labels = self._schema_names(
                f"g.V().label().dedup().limit({label_limit})"
            )

        edge_labels = self._schema_names(
            f"g.E().label().dedup().limit({label_limit})"
        )

        vertex_properties = self._schema_properties_by_label(
            "V", observed_vertex_labels, include_properties, sample_limit, property_limit
        )
        edge_properties = self._schema_properties_by_label(
            "E", edge_labels, include_edge_properties, sample_limit, property_limit
        )

        connections_query = (
            f"g.E().limit({sample_limit})"
            ".project('from','edge','to')"
            ".by(outV().label()).by(label()).by(inV().label())"
            f".dedup().limit({connection_limit})"
        )
        raw_connections = self._client.submit(connections_query)
        edge_connections = [
            {"from": str(row["from"]), "edge": str(row["edge"]), "to": str(row["to"])}
            for row in raw_connections
            if isinstance(row, dict) and all(key in row for key in ("from", "edge", "to"))
        ]

        return {
            "source": "neptune",
            "complete": False,
            "sampled": True,
            "vertex_labels": observed_vertex_labels,
            "edge_labels": edge_labels,
            "vertex_properties": vertex_properties,
            "edge_properties": edge_properties,
            "edge_connections": edge_connections,
            "limits_applied": {
                "max_labels": label_limit,
                "max_properties_per_label": property_limit,
                "sample_size": sample_limit,
                "max_connections": connection_limit,
            },
        }

    def query_readonly(self, gremlin: str, max_results: int = 100) -> Dict[str, Any]:
        """Execute one pre-validated traversal with a server-side result cap.

        Read-only validation belongs to the service boundary. This method adds
        a final ``limit`` step as defense in depth, executes only against the
        graph-ontology client, and normalizes GraphSON values for MCP/JSON.
        """
        if not self._client:
            raise RuntimeError("Neptune graph ontology is not configured or connected")

        result_limit = min(max(int(max_results), 1), 500)
        query = gremlin.strip()
        if query.endswith(";"):
            query = query[:-1].rstrip()
        bounded_query = f"{query}.limit({result_limit + 1})"
        raw_rows = self._client.submit(bounded_query)
        truncated = len(raw_rows) > result_limit
        rows = [self._json_safe(row) for row in raw_rows[:result_limit]]
        return {
            "source": "neptune",
            "rows": rows,
            "row_count": len(rows),
            "truncated": truncated,
            "max_results": result_limit,
        }

    @classmethod
    def _json_safe(cls, value: Any) -> Any:
        """Recursively normalize GraphSON values into JSON-safe primitives."""
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, dict):
            return {str(key): cls._json_safe(item) for key, item in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [cls._json_safe(item) for item in value]
        return str(value)

    def _schema_names(self, query: str) -> List[str]:
        """Execute one fixed schema traversal and normalize scalar names."""
        rows = self._client.submit(query)
        return list(dict.fromkeys(str(row) for row in rows if row is not None))

    def _existing_vertex_labels(self, requested_labels: List[str]) -> List[str]:
        """Return only requested labels observed in Neptune, preserving order."""
        return [
            label for label in requested_labels
            if self._schema_names(
                f"g.V().hasLabel({gremlin_string_literal(label)}).limit(1).label()"
            )
        ]

    def _schema_properties_by_label(
        self,
        element: str,
        labels: List[str],
        enabled: bool,
        sample_limit: int,
        property_limit: int,
    ) -> Dict[str, List[str]]:
        """Return observed property names for vertex or edge labels."""
        if not enabled:
            return {}
        return {
            label: self._schema_names(
                f"g.{element}().hasLabel({gremlin_string_literal(label)}).limit({sample_limit})"
                f".properties().key().dedup().limit({property_limit})"
            )
            for label in labels
        }

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    @property
    def stats(self) -> Dict[str, int]:
        """Live enrichment has no whole-graph node/edge counts to report
        (that would require a full scan, which is out of scope) — reports
        cache occupancy instead.
        """
        return {"nodes": 0, "edges": 0, "tables": len(self._cache)}

    @classmethod
    def from_settings(cls, graph_ontology_settings: Any) -> "NeptuneGraphOntologyEnricher":
        """Convenience factory — builds an enricher from a
        :class:`core.config.GraphOntologyConfig` instance, connecting to
        the Neptune reader endpoint. Returns a non-loaded (no-op) enricher
        if the cluster is unreachable — see ``NeptuneClient.try_connect``.
        """
        endpoint = getattr(graph_ontology_settings, "neptune_endpoint", "")
        port = getattr(graph_ontology_settings, "neptune_port", 8182)
        region = getattr(graph_ontology_settings, "neptune_region", "us-east-1")
        iam_auth = getattr(graph_ontology_settings, "neptune_iam_auth", True)
        allowed = getattr(graph_ontology_settings, "allowed_schemas", ())
        mapping = getattr(graph_ontology_settings, "schema_mapping", None) or GraphSchemaMapping()

        client = NeptuneClient.try_connect(
            endpoint=endpoint, port=port, region=region, iam_auth=iam_auth,
        )
        return cls(client=client, mapping=mapping, allowed_schemas=allowed)
