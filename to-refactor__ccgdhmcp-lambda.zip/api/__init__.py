"API layer — FastAPI routes, models, middleware, app factory."
