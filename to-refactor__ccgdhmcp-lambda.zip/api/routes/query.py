"""Query route — POST /query."""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request

from api.models.request import QueryRequest
from api.models.response import QueryResponse
from application.services.redshift_tool_service import RedshiftToolService

logger = logging.getLogger(__name__)

router = APIRouter(tags=["query"])


def _get_service(request: Request) -> RedshiftToolService:
    """Pull the RedshiftToolService singleton from app state.

    EKS/gunicorn: populated by the FastAPI lifespan handler.
    Lambda: lifespan is off; fall back to the module-level singleton
    maintained by api.app.get_tool_service().
    """
    svc: RedshiftToolService | None = getattr(request.app.state, "tool_service", None)
    if svc is None:
        from api.app import get_tool_service
        svc = get_tool_service()
    if svc is None:
        raise HTTPException(status_code=503, detail="Tool service not ready")
    return svc


@router.post(
    "/query",
    include_in_schema=False,
    responses={
        422: {"description": "Invalid or missing request body"},
        503: {"description": "Tool service not ready"},
        500: {"description": "Internal query-processing error"},
    },
)
async def process_query(
    request: Request,
) -> QueryResponse:
    """Accept a raw JSON body ``{"query": "..."}`` and return an answer.

    Stateless — each request is independent.
    """
    try:
        body = await request.json()
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"Invalid JSON: {exc}")

    if not isinstance(body, dict) or "query" not in body:
        raise HTTPException(status_code=422, detail="Missing required field: 'query'")

    query_text: str = body.get("query", "").strip()
    if not query_text:
        raise HTTPException(status_code=422, detail="'query' must not be empty")

    logger.info(f"📥 Received query: {query_text[:100]}")

    service = _get_service(request)
    try:
        result = await service.process_query(query_text)
        return QueryResponse(
            answer=result.answer,
            execution_time=result.execution_time,
            sql_query=result.sql_query or None,
            confidence=result.confidence,
            rows=result.rows,
            row_count=result.row_count,
            columns=result.columns,
        )
    except Exception as exc:
        logger.exception("❌ Query processing failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Query processing failed: {exc}")
