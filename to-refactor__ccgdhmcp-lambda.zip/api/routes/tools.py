"""MCP Tool endpoints — GET /tools (manifest) + POST /tools/<tool_name>.

An external agent discovers available tools via GET /tools and invokes
them individually via the POST endpoints.

Async strategy
--------------
* Route handlers are always ``async def`` (FastAPI best-practice).
* ``generate_sql`` is natively async (Bedrock network call) — awaited directly.
* All other service methods are **sync-blocking** (psycopg2 / pgvector).
  They are offloaded to the default thread-pool via ``asyncio.to_thread`` so
  the event loop is never blocked and concurrent requests remain responsive.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from application.services.redshift_tool_service import RedshiftToolService
from core.mcp_tools import rest_manifest

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tools", tags=["tools"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------

class ListTablesRequest(BaseModel):
    schema_name: Optional[str] = None


class DescribeTableRequest(BaseModel):
    table_name: str
    schema_name: Optional[str] = None


class GenerateSQLRequest(BaseModel):
    prompt: str
    schema_context: Optional[str] = None


class GenerateGremlinRequest(BaseModel):
    prompt: str
    graph_context: Optional[str] = None


class NeptuneSchemaRequest(BaseModel):
    vertex_labels: Optional[List[str]] = None
    include_properties: bool = True
    include_edge_properties: bool = True
    max_labels: int = 25
    max_properties_per_label: int = 50
    sample_size: int = 100
    max_connections: int = 100


class QueryNeptuneRequest(BaseModel):
    gremlin: str
    max_results: int = 100


class QueryRedshiftRequest(BaseModel):
    sql: str


class VectorSearchRequest(BaseModel):
    query: str
    top_k: int = 5


class MetadataContextRequest(BaseModel):
    query: str


class BookOfBusinessRequest(BaseModel):
    query: str


class ClientScopedRequest(BaseModel):
    query: str
    client_name: Optional[str] = None
    client_id: Optional[str] = None


class ClientQueryRequest(BaseModel):
    query: str


# ---------------------------------------------------------------------------
# Dependency helper
# ---------------------------------------------------------------------------

def _get_service(request: Request) -> RedshiftToolService:
    # EKS/gunicorn: service is stored in app.state by the lifespan handler.
    # Lambda: lifespan is off (Mangum), so fall back to the module-level
    # singleton initialised by api.app.get_tool_service().
    svc: RedshiftToolService | None = getattr(request.app.state, "tool_service", None)
    if svc is None:
        from api.app import get_tool_service
        svc = get_tool_service()
    if svc is None:
        raise HTTPException(status_code=503, detail="Tool service not ready")
    return svc


# ---------------------------------------------------------------------------
# Tool manifest — derived from the single source of truth in core.mcp_tools.
# ---------------------------------------------------------------------------

TOOL_MANIFEST: List[Dict[str, Any]] = rest_manifest()


@router.get("", summary="List available MCP tools", include_in_schema=False)
async def list_tools() -> Dict[str, Any]:
    """Return the tool manifest so agents can discover available capabilities."""
    return {"tools": TOOL_MANIFEST, "count": len(TOOL_MANIFEST)}


# ---------------------------------------------------------------------------
# Individual tool endpoints
# ---------------------------------------------------------------------------

@router.post(
    "/list_tables",
    summary="List tables in a schema",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_list_tables(
    body: ListTablesRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        result = await asyncio.to_thread(svc.list_tables, body.schema_name)
        return {"tool": "list_tables", "result": result}
    except Exception as exc:
        logger.exception("list_tables failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/describe_table",
    summary="Describe a table's columns and keys",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_describe_table(
    body: DescribeTableRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        result = await asyncio.to_thread(svc.describe_table, body.table_name, body.schema_name)
        return {"tool": "describe_table", "table": body.table_name, "result": result}
    except Exception as exc:
        logger.exception("describe_table failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/generate_sql",
    summary="Generate SQL from a natural-language prompt",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_generate_sql(
    body: GenerateSQLRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        # generate_sql is natively async (Bedrock) — awaited directly
        sql = await svc.generate_sql(body.prompt, body.schema_context)
        return {"tool": "generate_sql", "sql": sql}
    except Exception as exc:
        logger.exception("generate_sql failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/generate_gremlin",
    summary="Generate a read-only Gremlin traversal from a natural-language prompt",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_generate_gremlin(
    body: GenerateGremlinRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        gremlin = await svc.generate_gremlin(body.prompt, body.graph_context)
        return {"tool": "generate_gremlin", "gremlin": gremlin}
    except Exception as exc:
        logger.exception("generate_gremlin failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/get_neptune_schema",
    summary="Inspect the observed Neptune graph schema",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Neptune not configured or connected"},
    },
)
async def tool_get_neptune_schema(
    body: NeptuneSchemaRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        result = await asyncio.to_thread(
            svc.get_neptune_schema,
            body.vertex_labels,
            body.include_properties,
            body.include_edge_properties,
            body.max_labels,
            body.max_properties_per_label,
            body.sample_size,
            body.max_connections,
        )
        return {"tool": "get_neptune_schema", "result": result}
    except RuntimeError as exc:
        logger.warning("get_neptune_schema unavailable: %s", exc)
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        logger.exception("get_neptune_schema failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/query_neptune",
    summary="Execute a bounded, read-only Gremlin traversal against Neptune",
    responses={
        403: {"description": "Read-only policy violation"},
        500: {"description": "Internal error"},
        503: {"description": "Neptune not configured or connected"},
    },
)
async def tool_query_neptune(
    body: QueryNeptuneRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        result = await asyncio.to_thread(
            svc.query_neptune, body.gremlin, body.max_results
        )
        return {"tool": "query_neptune", **result}
    except (PermissionError, ValueError) as exc:
        logger.warning("query_neptune blocked (read-only policy): %s", exc)
        raise HTTPException(status_code=403, detail=str(exc))
    except RuntimeError as exc:
        logger.warning("query_neptune unavailable: %s", exc)
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        logger.exception("query_neptune failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/query_redshift",
    summary="Execute SQL against Redshift",
    responses={
        403: {"description": "Read-only policy violation"},
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_query_redshift(
    body: QueryRedshiftRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        rows = await asyncio.to_thread(svc.query_redshift, body.sql)
        row_count = len(rows) if isinstance(rows, list) else None
        return {"tool": "query_redshift", "row_count": row_count, "rows": rows}
    except PermissionError as exc:
        logger.warning("query_redshift blocked (read-only policy): %s", exc)
        raise HTTPException(status_code=403, detail=str(exc))
    except Exception as exc:
        logger.exception("query_redshift failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/vector_search",
    summary="Semantic search over table/column metadata",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_vector_search(
    body: VectorSearchRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        result = await asyncio.to_thread(svc.vector_search, body.query, body.top_k)
        return {"tool": "vector_search", "result": result}
    except Exception as exc:
        logger.exception("vector_search failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/get_metadata_context",
    summary="Get enriched table/column context for a query",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_get_metadata_context(
    body: MetadataContextRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        context = await asyncio.to_thread(svc.get_metadata_context, body.query)
        # Strip internal enricher reference before serialising
        context.pop("_enricher", None)
        return {"tool": "get_metadata_context", "result": context}
    except Exception as exc:
        logger.exception("get_metadata_context failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/book_of_business",
    summary="Answer a Book-of-Business question (retrieval + graph + SQL)",
    responses={
        500: {"description": "Internal error"},
        503: {"description": "Tool service not ready"},
    },
)
async def tool_book_of_business(
    body: BookOfBusinessRequest,
    request: Request,
) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        result = await svc.process_book_of_business_query(body.query)
        return {
            "tool": "book_of_business",
            "answer": result.answer,
            "sql_query": result.sql_query or None,
            "confidence": result.confidence,
            "execution_time": result.execution_time,
            "row_count": result.row_count,
            "rows": result.rows,
            "columns": result.columns,
        }
    except Exception as exc:
        logger.exception("book_of_business failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


def _serialize_qr(tool: str, r) -> Dict[str, Any]:
    return {
        "tool": tool,
        "answer": r.answer,
        "sql_query": r.sql_query or None,
        "confidence": r.confidence,
        "execution_time": r.execution_time,
        "row_count": r.row_count,
        "rows": r.rows,
        "columns": r.columns,
    }


@router.post("/getClientProducts", summary="Products owned by / associated with a client")
async def tool_get_client_products(body: ClientScopedRequest, request: Request) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        r = await svc.get_client_products(body.query, body.client_name, body.client_id)
        return _serialize_qr("getClientProducts", r)
    except Exception as exc:
        logger.exception("getClientProducts failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/getClientPolicies", summary="Policies associated with a client")
async def tool_get_client_policies(body: ClientScopedRequest, request: Request) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        r = await svc.get_client_policies(body.query, body.client_name, body.client_id)
        return _serialize_qr("getClientPolicies", r)
    except Exception as exc:
        logger.exception("getClientPolicies failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/getClientByDemographics", summary="Find/analyse clients by demographic attributes")
async def tool_get_client_by_demographics(body: ClientQueryRequest, request: Request) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        r = await svc.get_client_by_demographics(body.query)
        return _serialize_qr("getClientByDemographics", r)
    except Exception as exc:
        logger.exception("getClientByDemographics failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/getClientBySegment", summary="Retrieve/analyse clients by customer segment")
async def tool_get_client_by_segment(body: ClientQueryRequest, request: Request) -> Dict[str, Any]:
    svc = _get_service(request)
    try:
        r = await svc.get_client_by_segment(body.query)
        return _serialize_qr("getClientBySegment", r)
    except Exception as exc:
        logger.exception("getClientBySegment failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


# ---------------------------------------------------------------------------
# Business catalog tool — additive, no existing endpoints changed
# ---------------------------------------------------------------------------

class BusinessCatalogRequest(BaseModel):
    task: str
    intent: Optional[str] = None
    agent: Optional[str] = None
    policy_key: Optional[str] = None
    hints: Optional[Dict[str, Any]] = None
    limits: Optional[Dict[str, Any]] = None


def _get_catalog_client(request: Request):
    client = getattr(request.app.state, "catalog_client", None)
    if client is None:
        from api.app import get_catalog_client
        client = get_catalog_client()
    if client is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Business catalog Neptune not configured. "
                "Set BUSINESS_CATALOG_NEPTUNE_ENDPOINT or GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT."
            ),
        )
    return client


@router.post(
    "/get_business_catalog_context",
    summary="Retrieve semantic layer context from the business catalog graph",
    responses={
        503: {"description": "Business catalog not configured or Neptune unreachable"},
        500: {"description": "Internal error"},
    },
)
async def tool_get_business_catalog_context(
    body: BusinessCatalogRequest,
    request: Request,
) -> Dict[str, Any]:
    catalog_client = _get_catalog_client(request)
    try:
        result = await asyncio.to_thread(
            catalog_client.fetch_catalog_context,
            query_text=body.task,
            intent=body.intent,
            hints=body.hints,
            limits=body.limits,
            agent=body.agent,
            policy_key=body.policy_key,
        )
        if not result.get("available"):
            raise HTTPException(status_code=503, detail=result.get("reason", "Catalog unavailable"))

        # Flatten results dict -> context.rows (matches mcp_lambda_handoff.md response contract)
        raw_results: Dict[str, List] = result.get("results", {})
        all_rows = [row for rows in raw_results.values() for row in rows]
        execution = result.get("execution", {})
        stop_reason = execution.get("stop_reason", "")

        shaped = {
            "context": {
                "rows": all_rows,
                "truncated": stop_reason in ("budget_limit", "response_size_limit"),
            },
            "execution": {
                "policy_version": execution.get("policy_version", "default"),
                "executed_query_ids": execution.get("executed_query_ids", []),
                "skipped_query_ids": execution.get("skipped_query_ids", []),
                "activation_reasons": execution.get("activation_reasons", []),
                "row_counts": execution.get("row_counts", {}),
                "row_limit": execution.get("row_limit"),
                "total_rows": execution.get("total_rows"),
                "fallback_used": execution.get("fallback_used", False),
                "stop_reason": stop_reason,
            },
            "coverage": result.get("coverage", {}),
        }
        return {"tool": "get_business_catalog_context", "result": shaped}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("get_business_catalog_context failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

