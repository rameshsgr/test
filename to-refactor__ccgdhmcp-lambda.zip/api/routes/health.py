"""Health-check routes."""

from __future__ import annotations

import os

from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/", include_in_schema=False)
async def root() -> dict:
    return {
        "name": "GBS NexusStudio Redshift MCP Service",
        "version": "4.0.0",
        "mode": "mcp-server",
        "status": "running",
        "region": os.getenv("AWS_REGION", "us-east-1"),
        "database": os.getenv("REDSHIFT_DATABASE", "gdh"),
        "tools_endpoint": "/tools",
    }


@router.get("/health", include_in_schema=False)
async def health() -> dict:
    return {"status": 200, "message": "Nexusstudio Redshift MCP Server Running!"}
