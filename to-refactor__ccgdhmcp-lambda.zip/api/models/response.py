"""Pydantic response models."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class QueryResponse(BaseModel):
    answer: str = Field(..., description="Natural language answer")
    execution_time: Optional[float] = Field(None, description="Wall-clock seconds")
    sql_query: Optional[str] = Field(None, description="Generated SQL (if any)")
    confidence: Optional[float] = Field(None, description="Agent confidence 0-1")
    rows: List[Dict[str, Any]] = Field(default_factory=list, description="Result rows")
    row_count: int = Field(0, description="Number of rows returned")
    columns: List[str] = Field(default_factory=list, description="Column names")
