"""FastAPI application factory — MCP Server mode.

``create_app()`` is the single entry point used by ``main.py`` and by
test fixtures.  The service acts as an MCP server exposing tool endpoints;
no internal agent loop is wired here.

Lambda / AgentCore Gateway note
--------------------------------
When deployed on AWS Lambda the FastAPI lifespan (startup/shutdown) is
bypassed because Mangum is configured with ``lifespan="off"``.  To keep
service initialisation working in both runtimes the heavy wiring lives
inside ``get_tool_service()``, a public module-level function that:

  1. Fetches Conjur secrets into ``os.environ``.
  2. Reloads ``core.config.settings`` so those env vars are visible.
  3. Builds and returns a ``RedshiftToolService`` instance.

The result is stored in the module-level ``_TOOL_SERVICE`` variable so
it is constructed **once per Lambda container** (cold-start) and reused
across all warm invocations.

EKS/gunicorn path: the lifespan calls ``get_tool_service()`` as before,
so behaviour is identical to the previous version.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core.config import settings
from core.logging_config import configure_logging
from api.routes import health, query, tools

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level service singleton
# ---------------------------------------------------------------------------
# Cached here so that Lambda warm invocations skip re-initialisation.
# None until the first call to get_tool_service().
# ---------------------------------------------------------------------------
_TOOL_SERVICE: Optional[object] = None  # type: RedshiftToolService
_CATALOG_CLIENT: Optional[object] = None  # type: module (infrastructure.business_catalog.catalog_client)


def _build_tool_service():
    """Build and wire all dependencies into a RedshiftToolService."""
    from infrastructure.redshift.gateway import RedshiftMCPGateway
    from infrastructure.vector_store.gateway import PgVectorGateway
    from infrastructure.graph_ontology import GraphOntologyEnricher
    from application.services.redshift_tool_service import RedshiftToolService

    redshift = RedshiftMCPGateway.create(settings.redshift)
    logger.info(
        "Redshift gateway ready → %s:%d/%s",
        settings.redshift.host, settings.redshift.port, settings.redshift.database,
    )

    vector_store = PgVectorGateway.create(
        region=settings.aws.region,
        verify_ssl=settings.aws.verify_ssl,
    )
    _count = vector_store.entry_count
    if _count is None:
        # entry_count already logged a WARNING with the exception detail —
        # this line intentionally omits a fake number instead of the old
        # "-1 entries" sentinel, which was indistinguishable from a real count.
        logger.warning("Vector store ready — count unavailable (see prior WARNING for cause)")
    else:
        logger.info("Vector store ready — %d entries", _count)

    graph_enricher = None
    if settings.graph_ontology and settings.graph_ontology.neptune_endpoint:
        logger.info(
            "Graph ontology configured — neptune_endpoint=%s port=%d region=%s iam_auth=%s",
            settings.graph_ontology.neptune_endpoint,
            settings.graph_ontology.neptune_port,
            settings.graph_ontology.neptune_region,
            settings.graph_ontology.neptune_iam_auth,
        )
        # GraphOntologyEnricher.from_settings() -> NeptuneClient.try_connect()
        # never raises: an unreachable Neptune cluster logs a warning and
        # yields a non-loaded (no-op) enricher, so the rest of the service
        # continues in vector-only mode rather than failing to start.
        graph_enricher = GraphOntologyEnricher.from_settings(settings.graph_ontology)
        if graph_enricher.is_loaded:
            logger.info("Graph ontology ready — Neptune reader connected")
        else:
            logger.warning("Neptune unavailable — running in vector-only mode")
    else:
        logger.info("Graph ontology not configured — vector-only mode")

    logger.info(
        "Enrichers initialized: vector_store=True, graph_enricher=%s",
        graph_enricher is not None and graph_enricher.is_loaded,
    )

    service = RedshiftToolService(
        redshift=redshift,
        vector_store=vector_store,
        graph_enricher=graph_enricher,
    )

    logger.info("RedshiftToolService (MCP mode) ready")
    return service


def _fetch_secrets() -> None:
    """Fetch Conjur secrets and inject them into ``os.environ``.

    Retries up to 3 times with exponential back-off so that a brief
    Conjur connectivity blip at Lambda cold-start does not abort initialisation.
    """
    import time as _time
    from creds.conjur_secrets import (
        inject_pgvector_credentials_from_conjur,
        inject_redshift_credentials_from_conjur,
    )
    last_exc: Exception = RuntimeError("unreachable")
    for attempt in range(3):
        try:
            inject_pgvector_credentials_from_conjur()
            inject_redshift_credentials_from_conjur()
            return
        except Exception as exc:
            last_exc = exc
            if attempt < 2:
                wait = 2 ** attempt  # 1s, 2s
                logger.warning(
                    "Conjur secret fetch attempt %d/3 failed (%s) — retrying in %ds",
                    attempt + 1, exc, wait,
                )
                _time.sleep(wait)
    raise last_exc


def _reload_settings() -> None:
    """Reload ``core.config.settings`` so Conjur-injected env vars are visible.

    Also updates the module-level ``settings`` binding in this file so that
    ``_build_tool_service()`` (which references the local ``settings`` name
    imported at the top via ``from core.config import settings``) picks up
    the freshly-built config object with Conjur-injected credentials.
    """
    global settings
    import importlib
    import core.config as _cfg_module
    importlib.reload(_cfg_module)
    import core.config
    core.config.settings = _cfg_module.AppConfig.from_raw(_cfg_module._RAW)
    settings = core.config.settings  # update local binding used by _build_tool_service()


def _validate_credentials() -> None:
    """Verify Conjur-injected credentials are present after _reload_settings().

    Logs an ERROR (not a warning) for each missing value so that a Conjur
    failure is immediately visible in CloudWatch rather than surfacing later
    as an opaque connection error.
    """
    import core.config
    s = core.config.settings
    missing = []
    if not s.redshift.user:
        missing.append("REDSHIFT_USER")
    if not s.redshift.password:
        missing.append("REDSHIFT_PASSWORD")
    if not s.vector_db.user:
        missing.append("VECTOR_POSTGRES_USER")
    if not s.vector_db.password:
        missing.append("VECTOR_POSTGRES_PASSWORD")
    if missing:
        logger.error(
            "Conjur credential injection incomplete — the following required "
            "secrets are still empty after Conjur fetch: %s.  "
            "Database connections will fail.",
            ", ".join(missing),
        )


def get_tool_service():
    """Return the module-level RedshiftToolService singleton.

    Initialises the service on the first call (Lambda cold-start or first
    EKS request before lifespan completes).  Subsequent calls return the
    cached instance without any I/O.

    Thread-safe for the single-threaded Lambda invocation model.  For EKS
    the lifespan is the primary initialisation path; this function acts as
    a defensive fallback.
    """
    global _TOOL_SERVICE
    if _TOOL_SERVICE is None:
        configure_logging(os.getenv("LOG_LEVEL", "INFO"))
        logger.info(
            "Initialising RedshiftToolService — runtime=%s",
            "lambda" if os.getenv("AWS_LAMBDA_FUNCTION_NAME") else "local",
        )
        _fetch_secrets()
        _reload_settings()
        _validate_credentials()
        _TOOL_SERVICE = _build_tool_service()
        logger.info("RedshiftToolService initialised and cached")
    return _TOOL_SERVICE


def _build_catalog_client():
    """Build the business catalog Neptune client module, or return None if not configured.

    Builds only when BUSINESS_CATALOG_NEPTUNE_ENDPOINT or GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT
    is available (either directly or via config.yaml).  Returns the module object so
    callers can call module.fetch_catalog_context(…) and module.check_connectivity().
    Never raises — a missing endpoint logs a warning and returns None so the rest of
    the service continues in catalog-unavailable mode.
    """
    try:
        import infrastructure.business_catalog.catalog_client as _catalog_mod
        endpoint = (
            os.getenv("BUSINESS_CATALOG_NEPTUNE_ENDPOINT", "")
            or os.getenv("GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT", "")
            or (settings.graph_ontology and settings.graph_ontology.neptune_endpoint or "")
        )
        if not endpoint:
            logger.info("Business catalog Neptune not configured — catalog tool disabled")
            return None
        logger.info(
            "Business catalog Neptune configured — endpoint resolved (BUSINESS_CATALOG_NEPTUNE_ENDPOINT or fallback)"
        )
        return _catalog_mod
    except Exception as exc:
        logger.warning("Business catalog client build failed — catalog tool disabled: %s", exc)
        return None


def get_catalog_client():
    """Return the module-level business catalog client singleton (may be None)."""
    global _CATALOG_CLIENT
    if _CATALOG_CLIENT is None:
        _CATALOG_CLIENT = _build_catalog_client()
    return _CATALOG_CLIENT


# ---------------------------------------------------------------------------
# Datasource-aware orchestration path (additive — does NOT replace
# get_tool_service()/_TOOL_SERVICE above). Existing Discovery-only callers
# keep using get_tool_service() unchanged. This is the only path that builds
# a DatasourceRouter and multiple RedshiftToolService instances (Discovery,
# GDH, Actuarial); it is opt-in for new callers only.
# ---------------------------------------------------------------------------
_QUERY_ORCHESTRATOR: Optional[object] = None  # type: QueryOrchestrator


def _ensure_datasource_credentials(name: str):
    """Fetch *name*'s Redshift credentials from Conjur if not already present.

    Self-sufficient regardless of call order: for "discovery" this calls the
    same injector ``get_tool_service()`` uses (idempotent — re-setting
    REDSHIFT_USER/PASSWORD to the same values is harmless if that path
    already ran), so ``get_query_orchestrator()`` never depends on
    ``get_tool_service()`` having run first. For other datasources it uses
    the generalized per-name injector. Returns a freshly-reloaded
    ``DatasourceConfig`` reflecting the injected credentials.

    Raises whatever the underlying injector raises (``ValueError`` on a
    missing/empty Conjur secret) — callers must catch this and exclude the
    datasource rather than aborting startup.
    """
    from creds.conjur_secrets import (
        inject_datasource_credentials_from_conjur,
        inject_redshift_credentials_from_conjur,
    )

    if name == "discovery":
        inject_redshift_credentials_from_conjur()
    else:
        inject_datasource_credentials_from_conjur(name)

    import importlib
    import core.config as _cfg_module
    importlib.reload(_cfg_module)
    return _cfg_module.AppConfig.from_raw(_cfg_module._RAW).datasources[name]


def _build_datasource_service(name: str, ds_cfg, vector_store, graph_enricher):
    """Build one RedshiftToolService for *name*, or return None if unavailable.

    Encapsulates the per-datasource skip conditions (missing host/database,
    missing/unfetchable credentials, gateway build failure) so
    ``_build_datasource_services()`` stays a simple loop over the registry.
    """
    from infrastructure.redshift.gateway import RedshiftMCPGateway
    from application.services.redshift_tool_service import RedshiftToolService

    if not ds_cfg.host or not ds_cfg.database:
        logger.warning("Datasource '%s' has no host/database configured — excluded from routing.", name)
        return None

    if not ds_cfg.user or not ds_cfg.password:
        try:
            ds_cfg = _ensure_datasource_credentials(name)
        except Exception as exc:
            logger.warning(
                "Datasource '%s' credentials unavailable from Conjur (%s) — excluded from routing.",
                name, exc,
            )
            return None

    try:
        gateway = RedshiftMCPGateway.create(ds_cfg)
    except Exception as exc:
        logger.warning("Datasource '%s' gateway build failed (%s) — excluded from routing.", name, exc)
        return None

    ds_graph_enricher = graph_enricher if ds_cfg.graph_enrichment_enabled else None
    service = RedshiftToolService(
        redshift=gateway,
        vector_store=vector_store,
        graph_enricher=ds_graph_enricher,
        schemas=ds_cfg.schemas,
    )
    logger.info(
        "Datasource '%s' ready → %s:%d/%s (graph_enrichment=%s, schemas=%s)",
        name, ds_cfg.host, ds_cfg.port, ds_cfg.database,
        ds_graph_enricher is not None, ds_cfg.schemas,
    )
    return service


def _build_datasource_services():
    """Build one RedshiftToolService per configured datasource, plus the router.

    Discovery is sourced from ``settings.datasources["discovery"]`` (not
    ``settings.redshift`` — see migration plan) but reads identical env vars,
    so its behavior is unchanged. GDH/Actuarial are built with
    ``graph_enricher=None`` unconditionally — Neptune enrichment is Discovery
    -only until a validated graph exists for the other domains (no
    cross-datasource Neptune lookups).

    A datasource whose Conjur credentials are not yet provisioned is logged
    and excluded from the returned ``services`` dict (and therefore from
    ``DatasourceRouter``'s routing map) rather than aborting startup.
    """
    from infrastructure.vector_store.gateway import PgVectorGateway
    from infrastructure.graph_ontology import GraphOntologyEnricher
    from application.services.datasource_router import DatasourceRouter
    from application.services.query_orchestrator import QueryOrchestrator

    vector_store = PgVectorGateway.create(
        region=settings.aws.region,
        verify_ssl=settings.aws.verify_ssl,
    )

    graph_enricher = None
    if settings.graph_ontology and settings.graph_ontology.neptune_endpoint:
        graph_enricher = GraphOntologyEnricher.from_settings(settings.graph_ontology)

    services: dict = {}
    for name, ds_cfg in settings.datasources.items():
        service = _build_datasource_service(name, ds_cfg, vector_store, graph_enricher)
        if service is not None:
            services[name] = service

    router = DatasourceRouter(settings.datasources)
    orchestrator = QueryOrchestrator(services=services, router=router, vector_store=vector_store)
    return orchestrator


def get_query_orchestrator():
    """Return the module-level QueryOrchestrator singleton (multi-datasource path).

    Separate from ``get_tool_service()`` by design — see module docstring
    above this function. Building this does not affect the Discovery-only
    singleton in any way.
    """
    global _QUERY_ORCHESTRATOR
    if _QUERY_ORCHESTRATOR is None:
        _QUERY_ORCHESTRATOR = _build_datasource_services()
        logger.info(
            "QueryOrchestrator initialised — datasources=%s",
            sorted(_QUERY_ORCHESTRATOR.services.keys()),
        )
    return _QUERY_ORCHESTRATOR


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage service lifecycle (startup / shutdown) for EKS/gunicorn.

    Delegates to ``get_tool_service()`` so both EKS and Lambda share the
    same initialisation path and the singleton is only built once.
    """
    configure_logging(os.getenv("LOG_LEVEL", "INFO"))
    logger.info("Starting GBS NexusStudio Redshift MCP Service …")

    try:
        app.state.tool_service = get_tool_service()
        app.state.catalog_client = get_catalog_client()
        logger.info("Service initialised and ready to serve requests")
        yield
    except Exception as exc:
        logger.exception("Startup failed: %s", exc)
        raise
    finally:
        logger.info("Shutting down …")
        app.state.tool_service = None
        app.state.catalog_client = None


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="GBS NexusStudio Redshift MCP Service",
        description="MCP server exposing Redshift tools for external agents",
        version="4.0.0",
        lifespan=lifespan,
    )

    # CORS — restricted by default.  Set CORS_ALLOWED_ORIGINS to a comma-
    # separated allow-list (e.g. "https://app.example.com") to enable browser
    # access on the EKS path.  When unset, no cross-origin requests are allowed.
    # (The Lambda/AgentCore path does not use CORS.)  Note: credentials cannot
    # be combined with a "*" wildcard, so credentials are enabled only when an
    # explicit origin list is provided.
    _origins_raw = os.getenv("CORS_ALLOWED_ORIGINS", "").strip()
    allowed_origins = [o.strip() for o in _origins_raw.split(",") if o.strip()]
    if allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=allowed_origins,
            allow_credentials=True,
            allow_methods=["GET", "POST"],
            allow_headers=["*"],
        )
    else:
        logger.info("CORS disabled (no CORS_ALLOWED_ORIGINS set).")

    app.include_router(health.router)
    app.include_router(query.router)
    app.include_router(tools.router)

    return app
