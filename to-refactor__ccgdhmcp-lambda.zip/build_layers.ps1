# =============================================================================
# build_layers.ps1 - Build two x86_64 Lambda Layers
#
# Usage:
#   $env:ARTIFACTORY_TOKEN = 'your_token'
#   .\build_layers.ps1
#
# The Artifactory token MUST be set in the environment variable
#   ARTIFACTORY_TOKEN before running this script.
#   It is never accepted as a script parameter and must never be hardcoded.
#
# Output:
#   dist\graph_broker_ai_layer.zip   - AI / LangChain dependencies
#   dist\graph_broker_core_layer.zip - Database, API, AWS SDK, infrastructure
#
# Requirements (on the build machine):
#   - Python 3.11  (x86_64)
#   - pip  >= 23
#   - PowerShell 5.1+
# =============================================================================
param(
    [string]$ArtifactoryUser = "t03vb2h"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Validate token - read exclusively from the environment; never hardcode
# ---------------------------------------------------------------------------
$ArtifactoryToken = $env:ARTIFACTORY_TOKEN

if ([string]::IsNullOrWhiteSpace($ArtifactoryToken)) {
    Write-Error @"
Artifactory token not found.
Set the environment variable before running this script:
  `$env:ARTIFACTORY_TOKEN = 'your_token'
  .\build_layers.ps1
"@
    exit 1
}

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
$PYTHON           = "python"
$DIST_DIR         = ".\dist"
$TEMP_REQS_DIR    = ".\dist\tmp_reqs"

$AI_LAYER_DIR     = "$DIST_DIR\ai_layer\python"
$AI_LAYER_ZIP     = "$DIST_DIR\graph_broker_ai_layer.zip"

$CORE_LAYER_DIR   = "$DIST_DIR\core_layer\python"
$CORE_LAYER_ZIP   = "$DIST_DIR\graph_broker_core_layer.zip"

$AI_REQS_FILE     = "$TEMP_REQS_DIR\ai-requirements.txt"
$CORE_REQS_FILE   = "$TEMP_REQS_DIR\core-requirements.txt"

# Build pip index URL from injected credentials (never stored in source)
$ARTIFACTORY_HOST = "nylartifactory.jfrog.io"
$PIP_INDEX        = "https://${ArtifactoryUser}:${ArtifactoryToken}@${ARTIFACTORY_HOST}/artifactory/api/pypi/pypi-python-org/simple"

# Common pip flags for Lambda-compatible x86_64 Linux wheels
$PIP_FLAGS = @(
    "--platform",         "manylinux2014_x86_64",
    "--python-version",   "3.11",
    "--implementation",   "cp",
    "--abi",              "cp311",
    "--only-binary",      ":all:",
    "--upgrade",
    "--no-cache-dir",
    "--index-url",        $PIP_INDEX,
    "--trusted-host",     $ARTIFACTORY_HOST
)

# ---------------------------------------------------------------------------
# Layer 1 - AI dependencies
#   LangChain, LangSmith, AI protocol, async / HTTP transport, serialisation
# ---------------------------------------------------------------------------
$AI_PACKAGES = @"
langchain-aws==1.5.0
langchain-core==1.4.0
langchain-protocol==0.0.16
langsmith==0.8.7
aiohttp==3.13.5
aiohappyeyeballs==2.6.2
aiosignal==1.4.0
async-timeout==4.0.3
anyio==4.13.0
httpx==0.28.1
httpx-sse==0.4.3
httpcore==1.0.9
nest-asyncio==1.6.0
jsonpatch==1.33
jsonpointer==3.1.1
tenacity==9.1.4
orjson==3.11.9
numpy==2.2.6
xxhash==3.7.0
multidict==6.7.1
propcache==0.5.2
yarl==1.24.2
frozenlist==1.8.0
"@

# ---------------------------------------------------------------------------
# Layer 2 - Core (database, API, AWS SDK, infrastructure)
#   FastAPI / Uvicorn, Pydantic, psycopg2, pgvector, SQLAlchemy, gremlin,
#   boto3/botocore, Mangum, Conjur crypto libs, misc utilities
# ---------------------------------------------------------------------------
$CORE_PACKAGES = @"
boto3==1.43.18
botocore==1.43.18
s3transfer==0.18.0
jmespath==1.1.0
ec2-metadata==2.13.0
fastapi==0.109.0
uvicorn==0.27.0
httptools==0.8.0
starlette==0.35.1
mangum==0.17.0
sse-starlette==3.0.3
pydantic==2.13.4
pydantic_core==2.46.4
annotated-types==0.7.0
typing_extensions==4.15.0
typing-inspection==0.4.2
psycopg2-binary==2.9.12
pgvector==0.4.2
SQLAlchemy==2.0.50
greenlet==3.2.5
gremlinpython==3.8.1
isodate==0.7.2
websockets==16.0
requests==2.34.2
requests-toolbelt==1.0.0
urllib3==2.5.0
certifi==2025.7.14
charset-normalizer==3.4.7
idna==3.17
h11==0.16.0
click==8.4.1
PyYAML==6.0.3
packaging==25.0
python-dateutil==2.9.0.post0
six==1.17.0
asn1crypto==1.5.1
oscrypto==1.3.0
aenum==3.1.17
attrs==25.3.0
uuid_utils==0.16.0
watchfiles==1.2.0
zstandard==0.25.0
"@

# ---------------------------------------------------------------------------
# Helper: prune a layer directory
# ---------------------------------------------------------------------------
function Invoke-Prune {
    param([string]$Dir)

    # Compiled bytecode caches
    Get-ChildItem -Path $Dir -Recurse -Include "__pycache__" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    Get-ChildItem -Path $Dir -Recurse -Include "*.pyc","*.pyo" -File -ErrorAction SilentlyContinue |
        Remove-Item -Force

    # Test directories
    Get-ChildItem -Path $Dir -Recurse -Include "tests","test" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    # Package metadata (not needed at runtime)
    Get-ChildItem -Path $Dir -Recurse -Include "*.dist-info","*.egg-info" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force

    # Type stub files (IDE / type-checker use only - never loaded at runtime)
    Get-ChildItem -Path $Dir -Recurse -Include "*.pyi" -File -ErrorAction SilentlyContinue |
        Remove-Item -Force

    # CLI entry-point scripts (never invoked inside Lambda)
    Get-ChildItem -Path $Dir -Recurse -Include "bin","Scripts" -Directory -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force
}

# ---------------------------------------------------------------------------
# Helper: report sizes and warn on Lambda limits
# ---------------------------------------------------------------------------
function Show-LayerSize {
    param(
        [string]$Label,
        [string]$UnzippedDir,
        [string]$ZipPath
    )

    $unzipped_mb = [math]::Round(
        (Get-ChildItem -Path $UnzippedDir -Recurse |
         Measure-Object -Property Length -Sum).Sum / 1MB, 1)

    $zipped_mb = [math]::Round((Get-Item $ZipPath).Length / 1MB, 1)

    Write-Host "`n==> $Label sizes:" -ForegroundColor Yellow
    Write-Host "    Unzipped : $unzipped_mb MB"
    Write-Host "    Zipped   : $zipped_mb MB"

    if ($unzipped_mb -gt 250) {
        Write-Warning "$Label unzipped size ($unzipped_mb MB) exceeds Lambda's 250 MB limit!"
    }
    if ($zipped_mb -gt 50) {
        Write-Warning "$Label zipped size ($zipped_mb MB) exceeds Lambda's 50 MB direct-upload limit - use S3!"
    }
}

# ---------------------------------------------------------------------------
# Helper: print top-N packages by installed size (call after Invoke-Prune)
# ---------------------------------------------------------------------------
function Show-TopPackageSizes {
    param(
        [string]$LayerDir,
        [string]$Label,
        [int]$Top = 20
    )
    Write-Host "`n==> $Label - Top $Top packages by installed size:" -ForegroundColor Yellow

    $results = Get-ChildItem -Path $LayerDir -Directory -ErrorAction SilentlyContinue |
        ForEach-Object {
            $bytes = (Get-ChildItem -Path $_.FullName -Recurse -File -ErrorAction SilentlyContinue |
                      Measure-Object -Property Length -Sum).Sum
            [PSCustomObject]@{
                Package = $_.Name
                SizeMB  = [math]::Round($bytes / 1MB, 2)
            }
        } |
        Sort-Object SizeMB -Descending |
        Select-Object -First $Top

    $results | Format-Table -AutoSize

    $total = ($results | Measure-Object -Property SizeMB -Sum).Sum
    Write-Host "    Shown total : $([math]::Round($total, 1)) MB" -ForegroundColor DarkGray
}

# ===========================================================================
# CLEAN PREVIOUS BUILD
# ===========================================================================
Write-Host "`n==> Cleaning previous build artifacts..." -ForegroundColor Cyan

foreach ($path in @($AI_LAYER_DIR, "$DIST_DIR\ai_layer",
                    $CORE_LAYER_DIR, "$DIST_DIR\core_layer",
                    $TEMP_REQS_DIR,
                    $AI_LAYER_ZIP, $CORE_LAYER_ZIP)) {
    if (Test-Path $path) { Remove-Item -Recurse -Force $path }
}

New-Item -ItemType Directory -Path $AI_LAYER_DIR    -Force | Out-Null
New-Item -ItemType Directory -Path $CORE_LAYER_DIR  -Force | Out-Null
New-Item -ItemType Directory -Path $TEMP_REQS_DIR   -Force | Out-Null

# Write temporary requirements files
$AI_PACKAGES   | Out-File -FilePath $AI_REQS_FILE   -Encoding utf8
$CORE_PACKAGES | Out-File -FilePath $CORE_REQS_FILE -Encoding utf8

Write-Host "  Temporary requirements files written to $TEMP_REQS_DIR"

# ===========================================================================
# LAYER 1 - AI LAYER
# ===========================================================================
Write-Host "`n==> [Layer 1] Installing AI / LangChain packages into $AI_LAYER_DIR ..." -ForegroundColor Cyan

& $PYTHON -m pip install `
    --requirement $AI_REQS_FILE `
    --target $AI_LAYER_DIR `
    @PIP_FLAGS

if ($LASTEXITCODE -ne 0) {
    Write-Error "pip install failed for AI layer. See output above."
    exit 1
}

Write-Host "`n==> [Layer 1] Pruning build artifacts..." -ForegroundColor Cyan
Invoke-Prune -Dir $AI_LAYER_DIR
Write-Host "  Pruning complete"
Show-TopPackageSizes -LayerDir $AI_LAYER_DIR -Label "AI layer"

Write-Host "`n==> [Layer 1] Creating $AI_LAYER_ZIP ..." -ForegroundColor Cyan
Compress-Archive -Path "$DIST_DIR\ai_layer\*" -DestinationPath $AI_LAYER_ZIP -Force

Show-LayerSize -Label "AI layer (graph-broker-ai-layer)" `
               -UnzippedDir $AI_LAYER_DIR `
               -ZipPath $AI_LAYER_ZIP

# ===========================================================================
# LAYER 2 - CORE LAYER
# ===========================================================================
Write-Host "`n==> [Layer 2] Installing Core / infrastructure packages into $CORE_LAYER_DIR ..." -ForegroundColor Cyan

& $PYTHON -m pip install `
    --requirement $CORE_REQS_FILE `
    --target $CORE_LAYER_DIR `
    @PIP_FLAGS

if ($LASTEXITCODE -ne 0) {
    Write-Error "pip install failed for Core layer. See output above."
    exit 1
}

Write-Host "`n==> [Layer 2] Pruning build artifacts..." -ForegroundColor Cyan
Invoke-Prune -Dir $CORE_LAYER_DIR

# Prune unused botocore service data - keep only services used by this application
$BOTOCORE_DATA = "$CORE_LAYER_DIR\botocore\data"
if (Test-Path $BOTOCORE_DATA) {
    $KEEP_SERVICES = @(
        'bedrock', 'bedrock-runtime', 'bedrock-agent', 'bedrock-agent-runtime',
        's3', 'iam', 'sts', 'secretsmanager', 'ec2',
        'redshift', 'redshift-data', 'neptune', 'neptunedata', 'rds'
    )
    Get-ChildItem -Path $BOTOCORE_DATA -Directory |
        Where-Object { $_.Name -notin $KEEP_SERVICES } |
        Remove-Item -Recurse -Force
    $kept = (Get-ChildItem -Path $BOTOCORE_DATA -Directory).Count
    Write-Host "  botocore/data pruned to $kept service directories"
}
Write-Host "  Pruning complete"
Show-TopPackageSizes -LayerDir $CORE_LAYER_DIR -Label "Core layer"

Write-Host "`n==> [Layer 2] Creating $CORE_LAYER_ZIP ..." -ForegroundColor Cyan
Compress-Archive -Path "$DIST_DIR\core_layer\*" -DestinationPath $CORE_LAYER_ZIP -Force

Show-LayerSize -Label "Core layer (graph-broker-core-layer)" `
               -UnzippedDir $CORE_LAYER_DIR `
               -ZipPath $CORE_LAYER_ZIP

# Combined unzipped size check
# AWS enforces 250 MB total across all layers attached to one function
$ai_unzipped   = [math]::Round((Get-ChildItem -Path $AI_LAYER_DIR   -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
$core_unzipped = [math]::Round((Get-ChildItem -Path $CORE_LAYER_DIR -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
$combined_mb   = $ai_unzipped + $core_unzipped
Write-Host "`n==> Combined unzipped size (both layers): $combined_mb MB" -ForegroundColor Yellow
Write-Host "    AI layer   : $ai_unzipped MB"
Write-Host "    Core layer : $core_unzipped MB"
if ($combined_mb -gt 200) {
    Write-Warning "Combined unzipped size ($combined_mb MB) is approaching Lambda's 250 MB total layer limit!"
}
if ($combined_mb -gt 250) {
    Write-Warning "Combined unzipped size ($combined_mb MB) EXCEEDS Lambda's 250 MB total layer limit - function will fail to initialize!"
}

# ===========================================================================
# CLEAN UP TEMPORARY REQUIREMENTS FILES
# ===========================================================================
Remove-Item -Recurse -Force $TEMP_REQS_DIR
Write-Host "`n==> Temporary requirements files removed."

# ===========================================================================
# SUMMARY
# ===========================================================================
Write-Host "`n==> Build complete!" -ForegroundColor Green
Write-Host "    AI layer  : $(Resolve-Path $AI_LAYER_ZIP)" -ForegroundColor Green
Write-Host "    Core layer: $(Resolve-Path $CORE_LAYER_ZIP)" -ForegroundColor Green

Write-Host @"

Lambda Layer deployment limits:
  Zipped  : 50 MB  (direct upload) - use S3 for larger layers
  Unzipped: 250 MB per layer (max 5 layers per function, 250 MB total unzipped)

Publish Layer 1 (AI):
  aws lambda publish-layer-version ``
      --layer-name graph-broker-ai-layer ``
      --zip-file fileb://dist/graph_broker_ai_layer.zip ``
      --compatible-runtimes python3.11 ``
      --compatible-architectures x86_64 ``
      --region us-east-1

Publish Layer 2 (Core):
  aws lambda publish-layer-version ``
      --layer-name graph-broker-core-layer ``
      --zip-file fileb://dist/graph_broker_core_layer.zip ``
      --compatible-runtimes python3.11 ``
      --compatible-architectures x86_64 ``
      --region us-east-1

After publishing, attach both layer ARNs to your Lambda function:
  aws lambda update-function-configuration ``
      --function-name <your-function-name> ``
      --layers <ai-layer-arn> <core-layer-arn> ``
      --region us-east-1
"@ -ForegroundColor DarkGray
