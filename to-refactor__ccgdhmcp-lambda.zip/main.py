"""Application entry point.

Delegates all wiring to api.app.create_app().

Production (EKS):
    gunicorn main:app -k uvicorn.workers.UvicornWorker -w 2 -b 0.0.0.0:8000

Lambda (AgentCore Gateway):
    Handler: main.handler
    Authentication is handled at the AgentCore Gateway (IAM) level.

Environment variables are injected from the agentregistry config YAML
rendered into the pod by the K8s deployment, or from Lambda environment
variables when running on AWS Lambda.
"""

import io
import os
import sys

# Force UTF-8 only on non-Lambda environments (local/EKS).
# On Lambda, wrapping sys.stdout in a TextIOWrapper causes
# "ValueError: I/O operation on closed file" because the Lambda
# runtime replaces stdout between the INIT and handler phases,
# leaving the old wrapper pointing to a closed buffer.
if not os.getenv("AWS_LAMBDA_FUNCTION_NAME"):
    if sys.stdout and hasattr(sys.stdout, 'buffer'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    if sys.stderr and hasattr(sys.stderr, 'buffer'):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

from api.app import create_app

app = create_app()

# ---------------------------------------------------------------------------
# Eager service initialisation — runs during Lambda INIT phase
# ---------------------------------------------------------------------------
# Lambda's configured timeout applies ONLY to handler execution (Duration),
# NOT to the INIT phase (Init Duration in the REPORT line).  By calling
# get_tool_service() here at module level, Conjur secret fetch + Redshift
# and pgvector connection setup happen during INIT — completely outside the
# timeout budget.  The handler then receives an already-warm service on both
# cold-start and warm invocations.
#
# Failure handling: if Conjur/network is unreachable during INIT, the
# exception is caught and logged.  The handler will attempt re-init on the
# first request and return a structured error if it still fails, rather than
# letting an unhandled module-level exception crash the Lambda container.
# ---------------------------------------------------------------------------
# Only pre-initialise on Lambda (where INIT time is free).  On local/EKS the
# FastAPI lifespan handles initialisation, and skipping this keeps the module
# importable without a live Conjur/DB (e.g. for unit tests).
if os.getenv("AWS_LAMBDA_FUNCTION_NAME"):
    try:
        from api.app import get_tool_service as _eager_init
        _eager_init()
    except Exception:  # noqa: BLE001
        import logging as _init_log
        _init_log.getLogger(__name__).exception(
            "Service pre-initialisation failed during Lambda INIT — "
            "will retry on first request.",
        )
    try:
        from api.app import get_query_orchestrator as _eager_orch_init
        _eager_orch_init()
    except Exception:  # noqa: BLE001
        import logging as _init_log
        _init_log.getLogger(__name__).exception(
            "Orchestrator pre-initialisation failed during Lambda INIT — "
            "will retry on first request.",
        )

# ---------------------------------------------------------------------------
# AWS Lambda handler — Bedrock AgentCore Gateway (direct MCP dispatcher)
# ---------------------------------------------------------------------------
# Bedrock AgentCore Gateway is NOT API Gateway.  It handles HTTP / TLS /
# SigV4 auth itself and invokes the Lambda with a raw MCP JSON-RPC 2.0
# payload as the event — for example:
#
#   {
#     "jsonrpc": "2.0",
#     "id": 1,
#     "method": "tools/call",
#     "params": { "name": "query_redshift", "arguments": {"sql": "..."} }
#   }
#
# Mangum (an ASGI ↔ API-Gateway-HTTP-event bridge) is therefore NOT needed
# here and will always raise "unable to infer a handler" because the event
# carries no HTTP envelope.  The FastAPI ``app`` object above is kept solely
# for the EKS / gunicorn runtime path.
#
# This handler implements the three MCP methods the AgentCore runtime calls:
#   initialize   — handshake / capability declaration
#   tools/list   — tool discovery
#   tools/call   — tool invocation (dispatched to RedshiftToolService)
#
# Service singleton: get_tool_service() is called once per cold-start and the
# result is cached inside api.app so all warm invocations reuse it.
# ---------------------------------------------------------------------------

import asyncio as _asyncio
import json as _json
import logging as _logging
import re as _re
import time as _time

_handler_log = _logging.getLogger(__name__)

# Log-formatting constants — defined once, referenced everywhere.
_SQL_INDENT = "\n│    "   # newline + box-drawing indent for multi-line SQL
_SQL_NONE   = "(none)"    # placeholder when no SQL is available


def _fmt_sql(sql: str | None) -> str:
    """Indent each SQL line for box-style log output."""
    return (sql or _SQL_NONE).replace("\n", _SQL_INDENT)


def _log_sql(label: str, sql: str | None) -> None:
    """Log a SQL statement (GENERATED or EXECUTING) with indented formatting."""
    _handler_log.info("│  %s SQL:%s%s", label, _SQL_INDENT, _fmt_sql(sql))


def _log_tool_start(tool: str, args: dict) -> float:
    """Log the start of a tool invocation and return a start timestamp."""
    safe_args = {k: (v[:200] if isinstance(v, str) else v) for k, v in args.items()}
    _handler_log.info(
        "┌─ TOOL INVOKED ─────────────────────────────\n"
        "│  tool    : %s\n"
        "│  args    : %s",
        tool, safe_args,
    )
    return _time.perf_counter()


def _log_tool_end(tool: str, t0: float, extra: str = "") -> None:
    """Log the end of a tool invocation with elapsed time."""
    elapsed = _time.perf_counter() - t0
    _handler_log.info(
        "└─ TOOL COMPLETE ────────────────────────────\n"
        "│  tool    : %s\n"
        "│  elapsed : %.3f s%s",
        tool, elapsed, f"\n│  {extra}" if extra else "",
    )


async def _dispatch_generation_tool(svc, tool_name: str, args: dict, t0: float):
    """Dispatch an LLM query generator and log its generated statement."""
    if tool_name == "generate_sql":
        generated = await svc.generate_sql(args["prompt"], args.get("schema_context"))
        _log_sql("GENERATED", generated)
    else:
        generated = await svc.generate_gremlin(args["prompt"], args.get("graph_context"))
        _handler_log.info("│  GENERATED GREMLIN:%s%s", _SQL_INDENT, _fmt_sql(generated))
    _log_tool_end(tool_name, t0)
    return generated


async def _dispatch_graph_or_generation_tool(svc, tool_name: str, args: dict, t0: float):
    """Dispatch LLM generators and graph-schema discovery tools."""
    if tool_name in {"generate_sql", "generate_gremlin"}:
        return await _dispatch_generation_tool(svc, tool_name, args, t0)

    if tool_name == "query_neptune":
        result = svc.query_neptune(args["gremlin"], args.get("max_results", 100))
        _log_tool_end(tool_name, t0, f"rows returned: {result.get('row_count', 0)}")
        return result

    result = svc.get_neptune_schema(**args)
    _log_tool_end(
        tool_name, t0,
        f"vertex labels: {len(result.get('vertex_labels', []))}  "
        f"edge labels: {len(result.get('edge_labels', []))}",
    )
    return result

# MCP tool manifest — single source of truth in core.mcp_tools.
from core.mcp_tools import (
    MCP_TOOLS as _MCP_TOOLS,
    PIPELINE_TOOL_NAMES as _PIPELINE_TOOL_NAMES,
    BOOK_OF_BUSINESS_TOOL_NAMES as _BOB_TOOL_NAMES,
    CLIENT_TOOL_METHODS as _CLIENT_TOOL_METHODS,
)


async def _dispatch_tool(svc, tool_name: str, args: dict):
    """Route a tools/call request to the matching RedshiftToolService method."""
    t0 = _log_tool_start(tool_name, args)

    if tool_name == "list_tables":
        result = svc.list_tables(args.get("schema_name"))
        row_count = len(result.get("rows", result)) if result else 0
        _log_tool_end(tool_name, t0, f"tables returned: {row_count}")
        return result

    if tool_name == "describe_table":
        result = svc.describe_table(args["table_name"], args.get("schema_name"))
        _log_tool_end(tool_name, t0, f"table: {args['table_name']}")
        return result

    if tool_name in {"generate_sql", "generate_gremlin", "get_neptune_schema", "query_neptune"}:
        return await _dispatch_graph_or_generation_tool(svc, tool_name, args, t0)

    if tool_name == "query_redshift":
        _log_sql("EXECUTING", args["sql"])
        result = svc.query_redshift(args["sql"])
        row_count = len(result.get("rows", result)) if result else 0
        _log_tool_end(tool_name, t0, f"rows returned: {row_count}")
        return result

    if tool_name == "vector_search":
        result = svc.vector_search(args["query"], args.get("top_k", 5))
        _log_tool_end(tool_name, t0, f"results: {len(result) if isinstance(result, list) else '?'}")
        return result

    if tool_name == "get_metadata_context":
        result = svc.get_metadata_context(args["query"])
        result.pop("_enricher", None)
        _log_tool_end(
            tool_name, t0,
            f"tables: {len(result.get('relevant_tables', []))}  "
            f"columns: {len(result.get('relevant_columns', []))}",
        )
        return result

    if tool_name == "get_business_catalog_context":
        from api.app import get_catalog_client
        catalog_client = get_catalog_client()
        if catalog_client is None:
            raise ValueError("Business catalog Neptune not configured")
        task = args.get("task") or args.get("query") or ""
        result = catalog_client.fetch_catalog_context(
            query_text=task,
            intent=args.get("intent"),
            hints=args.get("hints"),
            limits=args.get("limits"),
            agent=args.get("agent"),
            policy_key=args.get("policy_key"),
        )
        _log_tool_end(
            tool_name, t0,
            f"executed: {len(result.get('execution', {}).get('executed_query_ids', []))}  "
            f"rows: {sum(result.get('execution', {}).get('row_counts', {}).values())}",
        )
        return result

    raise ValueError(f"Unknown tool: {tool_name!r}")


def _serialize_qr(r) -> dict:
    """Serialise a QueryResult into the AgentCore response dict."""
    return {
        "answer":         r.answer,
        "sql_query":      r.sql_query,
        "execution_time": r.execution_time,
        "confidence":     r.confidence,
        "rows":           r.rows,
        "row_count":      r.row_count,
        "columns":        r.columns,
    }


async def _run_book_of_business(svc, query: str) -> dict:
    """Run the Book-of-Business pipeline and serialise the result."""
    _handler_log.info("📘 BOOK-OF-BUSINESS INVOKED — query: %s", query[:300])
    r = await svc.process_book_of_business_query(query)
    _log_sql("GENERATED", r.sql_query)
    return _serialize_qr(r)


async def _run_client_tool(svc, method_name: str, args: dict) -> dict:
    """Run a client-scoped domain tool (products/policies/demographics/segment).

    These are pipeline-style tools that return a QueryResult.  The whole ``args``
    dict is forwarded so per-tool optional hints (e.g. client_name / client_id)
    reach the service method; unknown keys are ignored by the method.
    """
    _handler_log.info("👤 CLIENT TOOL %s — args: %s", method_name, list(args.keys()))
    method = getattr(svc, method_name)
    r = await method(**args)
    _log_sql("GENERATED", r.sql_query)
    return _serialize_qr(r)


async def _run_pipeline(orchestrator, query: str) -> dict:
    """Route the NL query through QueryOrchestrator and serialise the result."""
    from application.services.datasource_router import AmbiguousDatasourceWarning
    _handler_log.info(
        "┌─ PIPELINE INVOKED (orchestrator.handle_query) ─────\n"
        "│  query: %s",
        query[:300],
    )
    t0 = _time.perf_counter()
    r = await orchestrator.handle_query(query)
    elapsed = _time.perf_counter() - t0
    if isinstance(r, AmbiguousDatasourceWarning):
        _handler_log.warning(
            "└─ PIPELINE — routing ambiguous: reason=%s  candidates=%s",
            r.reason, r.candidate_datasources,
        )
        return {
            "error": "Routing ambiguous — multiple datasources matched.",
            "code": "AMBIGUOUS_DATASOURCE",
            "candidates": list(r.candidate_datasources),
        }
    _log_sql("GENERATED", r.sql_query)
    _handler_log.info(
        "└─ PIPELINE COMPLETE ────────────────────────\n"
        "│  elapsed    : %.3f s\n"
        "│  rows       : %d\n"
        "│  confidence : %.4f\n"
        "│  answer     : %s",
        elapsed, r.row_count, r.confidence, r.answer[:300],
    )
    return _serialize_qr(r)


async def _dispatch_named(svc, orchestrator, tool_name: str, args: dict):
    """Dispatch by explicit tool name (AgentCore supplies it in client context).

    Preferred over key-inference: the tool identity is authoritative, so tools
    that share an argument shape (e.g. ``get_metadata_context`` and the pipeline
    both take only ``query``) are routed unambiguously.
    """
    # Defensive: normalize non-canonical argument keys (e.g. {"key1": "..."})
    # even when the tool name IS known, in case the Gateway's parameter
    # binding sends a generic key regardless of tool identity.
    args = _normalize_direct_event(args)
    if tool_name in _CLIENT_TOOL_METHODS:
        return await _run_client_tool(svc, _CLIENT_TOOL_METHODS[tool_name], args)
    if tool_name in _BOB_TOOL_NAMES:
        return await _run_book_of_business(svc, args["query"])
    if tool_name in _PIPELINE_TOOL_NAMES:
        return await _run_pipeline(orchestrator, args["query"])
    return await _dispatch_tool(svc, tool_name, args)


# Canonical MCP argument names.  Any event carrying one of these is already in
# the shape the dispatcher understands and is left untouched by normalization.
_KNOWN_ARG_KEYS = {
    "query", "task", "sql", "prompt", "table_name", "schema_name", "schema_context",
    "graph_context", "gremlin", "max_results", "top_k", "client_name", "client_id", "vertex_labels",
    "include_properties", "include_edge_properties", "max_labels",
    "max_properties_per_label", "sample_size", "max_connections",
}

_NEPTUNE_SCHEMA_ARG_KEYS = {
    "vertex_labels", "include_properties", "include_edge_properties", "max_labels",
    "max_properties_per_label", "sample_size", "max_connections",
}


def _normalize_direct_event(event: dict) -> dict:
    """Normalize a non-canonical AgentCore direct-call payload to ``{"query": ...}``.

    Root cause of the mis-routing bug: depending on how the Gateway target's
    inline tool schema binds its parameters, AgentCore sometimes does not send
    the canonical argument name (``query``) but a generic positional key such
    as ``key1`` — e.g. ``{"key1": "give me 5 records of AE book of business"}``.
    None of the key-based branches recognised ``key1``, so every such request
    fell through to the unconditional ``list_tables`` default at the bottom of
    the old dispatch chain — regardless of what the user actually asked.

    If the event contains no canonical key but exactly one non-empty string
    value, treat that value as the user's query text.
    """
    if any(k in event for k in _KNOWN_ARG_KEYS):
        return event  # already canonical — nothing to normalize

    string_values = [(k, v) for k, v in event.items() if isinstance(v, str) and v.strip()]
    if len(string_values) == 1:
        key, value = string_values[0]
        _handler_log.info(
            "AgentCore payload key %r is not a canonical MCP argument — "
            "normalizing %r -> 'query'.", key, key,
        )
        return {"query": value}

    return event


# --------------------------------------------------------------------------- #
# Deterministic infer-mode tool selection                                     #
# --------------------------------------------------------------------------- #
# Used ONLY when the explicit tool name is unavailable (AgentCore direct-call
# path without client-context tool identity).  Order matters: most specific
# intent first.  process_query is ALWAYS the default — list_tables is a narrow,
# explicit intent match, never a fallback for unrecognised input.

_BOB_INTENT_RE = _re.compile(
    r'\bbooks?\s+of\s+business\b|\bmy\s+book\b',
    _re.IGNORECASE,
)
_DESCRIBE_INTENT_RE = _re.compile(
    r'\bdescribe\b|\bstructure\s+of\b|\bcolumns?\s+of\b|\bschema\s+of\b',
    _re.IGNORECASE,
)
_LIST_TABLES_INTENT_RE = _re.compile(
    r'\b(show|list)\b[^.]*\btables\b|\bwhat\s+tables\b',
    _re.IGNORECASE,
)
# DAR metadata / schema intent — matches questions about physical DAR tables,
# columns, relationships, and graph ontology enrichment.  Does NOT match
# questions about business meaning, rules, or semantics — those go to catalog.
_DAR_METADATA_INTENT_RE = _re.compile(
    r'\bdar\b.*\b(table|column|schema|relation|metadata|structure|field|pk|fk|key)\b'
    r'|\b(dar\s+table|dar\s+column|dar\s+schema|dar\s+metadata)\b'
    r'|\bphysical\s+(table|column|schema|model)\b'
    r'|\b(table|column)\s+(metadata|definition|structure|relation)\b'
    r'|\bgraph\s+ontology\b|\bontology\s+(metadata|schema)\b'
    r'|\bneptune\s+(schema|metadata)\b',
    _re.IGNORECASE,
)
# Business semantic context intent — matches questions about business meaning,
# rules, signals, outcomes, domains, personas, and the catalog ontology.
# Must NOT match DAR physical schema questions (those are handled above first).
_SEMANTIC_CONTEXT_INTENT_RE = _re.compile(
    r'\bbusiness\s+(definition|meaning|domain|rule|concept|context|semantic|ontology|catalog)\b'
    r'|\b(business\s+domain|semantic\s+layer|semantic\s+catalog|business\s+catalog)\b'
    r'|\b(business\s+rule|business\s+signal|business\s+outcome|business\s+insight)\b'
    r'|\b(situation\s+type|plan\s+pattern|playbook|persona\s+definition)\b'
    r'|\bwhat\s+does\s+.{1,60}\s+mean\s+in\s+(business|insurance|nyl|gbs)\b'
    r'|\bdefin(e|ition)\s+of\b.{1,60}\b(business|insurance|concept|term)\b',
    _re.IGNORECASE,
)
_DESCRIBE_TABLE_NAME_RE = _re.compile(
    r'(?:describe|structure\s+of|columns?\s+of|schema\s+of)\s+(?:the\s+)?(?:table\s+)?'
    r'([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)?)',
    _re.IGNORECASE,
)


def infer_tool(query: str) -> str:
    """Deterministically select an MCP tool name from raw query text.

    Routing (first match wins):
      1. Book-of-Business intent   -> "book_of_business"
      2. DAR metadata/schema       -> "get_metadata_context"
         (physical DAR tables/columns/ontology — Neptune graph_ontology)
      3. Business semantic context -> "get_business_catalog_context"
         (business definitions, rules, signals, outcomes, catalog ontology)
      4. Describe-table intent     -> "describe_table"
      5. List-tables intent        -> "list_tables"
      6. Anything else             -> "process_query"  (the default)

    CRITICAL: process_query is the default for unmatched input.  list_tables
    is returned ONLY on an explicit "show/list ... tables" style match — it
    must never be used as a fallback for unrecognised text.  Similarly,
    describe_table requires one of the specific phrases in
    ``_DESCRIBE_INTENT_RE`` (e.g. "describe", "schema of", "columns of") —
    merely mentioning the word "table" in passing does not trigger it, so a
    question like "what is in the account table for John Smith" still falls
    through to process_query.

    DAR metadata check runs before semantic context so that questions about
    the physical DAR schema never accidentally hit the business catalog.
    """
    q = (query or "").strip()
    if not q:
        return "process_query"
    if _BOB_INTENT_RE.search(q):
        return "book_of_business"
    if _DAR_METADATA_INTENT_RE.search(q):
        return "get_metadata_context"
    if _SEMANTIC_CONTEXT_INTENT_RE.search(q):
        return "get_business_catalog_context"
    if _DESCRIBE_INTENT_RE.search(q):
        return "describe_table"
    if _LIST_TABLES_INTENT_RE.search(q):
        return "list_tables"
    return "process_query"


def _extract_table_name(query: str) -> str | None:
    """Best-effort extraction of a table name from a describe-table request."""
    m = _DESCRIBE_TABLE_NAME_RE.search(query or "")
    return m.group(1) if m else None


async def _dispatch_direct(svc, orchestrator, event: dict):
    """Dispatch a direct-arguments event.

    Used when the invoked tool name is NOT available from the Lambda client
    context (the common AgentCore direct-call shape observed in production —
    see ``_tool_name_from_context``).  On invocations where the tool name IS
    present, ``_dispatch_named`` is used instead and this function is bypassed.

    Canonical-key routing (payload already uses MCP argument names)
    -----------------------------------------------------------------
    ``sql``                                   -> query_redshift
    ``prompt``                                -> generate_sql
    ``table_name``                            -> describe_table
    ``query`` + ``top_k``                     -> vector_search
    ``query`` (bare)                          -> infer_tool(query) — see below

    Infer-mode routing (no canonical key present — e.g. AgentCore sent
    ``{"key1": "..."}``): the payload is normalized to ``{"query": ...}`` and
    then routed deterministically via ``infer_tool()``.  process_query is
    always the default; list_tables is returned only for an explicit
    "show/list tables" style match.
    """
    event = _normalize_direct_event(event)

    if "sql" in event:
        t0 = _log_tool_start("query_redshift", event)
        _log_sql("EXECUTING", event["sql"])
        result = svc.query_redshift(event["sql"])
        row_count = len(result.get("rows", result)) if result else 0
        _log_tool_end("query_redshift", t0, f"rows returned: {row_count}")
        return result

    if _NEPTUNE_SCHEMA_ARG_KEYS.intersection(event):
        return await _dispatch_tool(svc, "get_neptune_schema", event)

    if "prompt" in event:
        generator = "generate_gremlin" if "graph_context" in event else "generate_sql"
        return await _dispatch_tool(svc, generator, event)

    if "task" in event:
        return await _dispatch_tool(svc, "get_business_catalog_context", event)

    if "table_name" in event:
        t0 = _log_tool_start("describe_table", event)
        result = svc.describe_table(event["table_name"], event.get("schema_name"))
        _log_tool_end("describe_table", t0, f"table: {event['table_name']}")
        return result

    if "query" in event and "top_k" in event:
        t0 = _log_tool_start("vector_search", event)
        result = svc.vector_search(event["query"], event.get("top_k", 5))
        _log_tool_end("vector_search", t0, f"results: {len(result) if isinstance(result, list) else '?'}")
        return result

    if "query" in event:
        query = event["query"]
        tool = infer_tool(query)
        _handler_log.info(
            "AgentCore infer query=%r selected_tool=%r", query[:200], tool,
        )

        if tool == "book_of_business":
            return await _run_book_of_business(svc, query)

        if tool == "get_metadata_context":
            t0 = _log_tool_start("get_metadata_context", {"query": query})
            result = svc.get_metadata_context(query)
            result.pop("_enricher", None)
            _log_tool_end(
                "get_metadata_context", t0,
                f"tables: {len(result.get('relevant_tables', []))}  "
                f"columns: {len(result.get('relevant_columns', []))}",
            )
            return result

        if tool == "get_business_catalog_context":
            from api.app import get_catalog_client
            catalog_client = get_catalog_client()
            if catalog_client is None:
                _handler_log.warning(
                    "get_business_catalog_context inferred but catalog not configured "
                    "— falling back to process_query"
                )
                return await _run_pipeline(orchestrator, query)
            t0 = _log_tool_start("get_business_catalog_context", {"query": query})
            result = catalog_client.fetch_catalog_context(query_text=query)
            _log_tool_end(
                "get_business_catalog_context", t0,
                f"executed: {len(result.get('execution', {}).get('executed_query_ids', []))}  "
                f"rows: {sum(result.get('execution', {}).get('row_counts', {}).values())}",
            )
            return result

        if tool == "describe_table":
            table_name = _extract_table_name(query)
            if table_name:
                t0 = _log_tool_start("describe_table", {"table_name": table_name})
                result = svc.describe_table(table_name, event.get("schema_name"))
                _log_tool_end("describe_table", t0, f"table: {table_name}")
                return result
            # Intent detected but no table name could be extracted — fall
            # back to the pipeline rather than guessing a table.
            _handler_log.info(
                "describe_table intent matched but no table name extracted "
                "from query=%r — falling back to process_query.", query[:200],
            )
            return await _run_pipeline(orchestrator, query)

        if tool == "list_tables":
            t0 = _log_tool_start("list_tables", event)
            result = svc.list_tables(event.get("schema_name"))
            row_count = len(result.get("rows", result)) if result else 0
            _log_tool_end("list_tables", t0, f"tables returned: {row_count}")
            return result

        # Default: process_query.
        return await _run_pipeline(orchestrator, query)

    # No query text and no other canonical key at all (e.g. a bare
    # {"schema_name": "..."} schema-discovery probe with no question text).
    # This is the ONLY remaining path to list_tables, and it requires the
    # complete absence of any query text — it is never used as a fallback
    # for unrecognised natural-language input.
    t0 = _log_tool_start("list_tables", event)
    result = svc.list_tables(event.get("schema_name"))
    row_count = len(result.get("rows", result)) if result else 0
    _log_tool_end("list_tables", t0, f"tables returned: {row_count}")
    return result


def _tool_name_from_context(context) -> str | None:
    """Extract the invoked MCP tool name from the Lambda client context.

    AgentCore Gateway passes the tool name in
    ``context.client_context.custom['bedrockAgentCoreToolName']`` (some
    runtimes use ``toolName``), typically prefixed with ``<targetName>___``.
    Returns the bare tool name, or ``None`` when unavailable (local testing).
    """
    cc = getattr(context, "client_context", None)
    custom = getattr(cc, "custom", None) or {}
    raw = custom.get("bedrockAgentCoreToolName") or custom.get("toolName")
    if not raw:
        return None
    # Strip the AgentCore "<target>___<tool>" prefix if present.
    return raw.split("___", 1)[1] if "___" in raw else raw


def _handle_direct_tool_call(event: dict, explicit_tool: str | None = None) -> dict:
    """Handle a direct-arguments invocation from the AgentCore Gateway.

    AgentCore handles ``initialize`` and ``tools/list`` at the gateway layer.
    For ``tools/call`` it invokes the Lambda with *only* the tool arguments
    as the event payload — no JSON-RPC wrapper — and the tool name in the
    Lambda client context.

    When *explicit_tool* is known, dispatch by name (unambiguous).  Otherwise
    fall back to inferring the tool from the argument keys.

    Returns a plain dict; the gateway serialises it into the MCP
    ``content[0].text`` field automatically.
    """
    _handler_log.info(
        "AgentCore direct call — tool=%s  argument keys: %s",
        explicit_tool or "(infer)", list(event.keys()),
    )
    try:
        from api.app import get_tool_service, get_query_orchestrator
        orchestrator = get_query_orchestrator()
        # Non-pipeline tools (list_tables, describe_table, etc.) still need a
        # single-datasource service handle.  Prefer the discovery service that
        # the orchestrator already built to avoid an extra connection; fall
        # back to the legacy singleton only when it is absent.
        svc = orchestrator.services.get("discovery") or get_tool_service()
        if explicit_tool:
            result = _asyncio.run(_dispatch_named(svc, orchestrator, explicit_tool, event))
        else:
            result = _asyncio.run(_dispatch_direct(svc, orchestrator, event))
        # Ensure all values are JSON-serialisable (e.g. Decimal, datetime)
        return _json.loads(_json.dumps(result, default=str))
    except PermissionError as exc:
        _handler_log.warning("Direct call blocked (read-only): %s", exc)
        return {"error": str(exc), "code": "PERMISSION_DENIED"}
    except (KeyError, ValueError) as exc:
        _handler_log.warning("Direct call bad arguments: %s", exc)
        return {"error": str(exc), "code": "INVALID_ARGUMENTS"}
    except Exception as exc:
        _handler_log.exception("Direct call internal error: %s", exc)
        return {"error": str(exc), "code": "INTERNAL_ERROR"}


def handler(event, context):
    """AWS Lambda entry point — invoked by Bedrock AgentCore Gateway.

    Two dispatch paths:

    1. **AgentCore direct path** (no ``method`` key):
       AgentCore Gateway handles ``initialize`` / ``tools/list`` itself and
       invokes Lambda with *only* the tool arguments dict for ``tools/call``.
       Routed by key presence to the appropriate service method.

    2. **JSON-RPC fallback** (has ``method`` key):
       For direct Lambda test invocations and local development.
       Handles ``initialize``, ``tools/list``, ``tools/call``.
    """
    _handler_log.debug("Lambda event keys: %s", list(event.keys()))

    # ------------------------------------------------------------------ #
    # Path 1 — AgentCore direct arguments call                           #
    # ------------------------------------------------------------------ #
    if "method" not in event:
        return _handle_direct_tool_call(event, explicit_tool=_tool_name_from_context(context))

    # ------------------------------------------------------------------ #
    # Path 2 — JSON-RPC 2.0 (local / direct Lambda testing)              #
    # ------------------------------------------------------------------ #
    method = event.get("method", "")
    req_id = event.get("id", 1)
    params = event.get("params") or {}

    def _ok(result):
        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    def _err(code: int, message: str):
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}

    if method == "initialize":
        from core.mcp_tools import SYSTEM_PROMPT
        return _ok({
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {
                "name": "GBS NexusStudio Redshift MCP Service",
                "version": "4.0.0",
            },
            "instructions": SYSTEM_PROMPT,
        })

    if method == "tools/list":
        return _ok({"tools": _MCP_TOOLS})

    if method == "tools/call":
        tool_name = params.get("name", "")
        arguments = params.get("arguments") or {}
        _handler_log.info("tools/call  tool=%s  args=%s", tool_name, list(arguments.keys()))
        try:
            from api.app import get_tool_service
            svc = get_tool_service()
            result = _asyncio.run(_dispatch_tool(svc, tool_name, arguments))
            return _ok({
                "content": [{"type": "text", "text": _json.dumps(result, default=str)}],
            })
        except PermissionError as exc:
            _handler_log.warning("tools/call blocked (read-only): %s", exc)
            return _err(-32600, str(exc))
        except (KeyError, ValueError) as exc:
            _handler_log.warning("tools/call bad request: %s", exc)
            return _err(-32602, str(exc))
        except Exception as exc:
            _handler_log.exception("tools/call internal error: %s", exc)
            return _err(-32603, str(exc))

    _handler_log.warning("Unhandled MCP method: %r  event keys: %s", method, list(event.keys()))
    return _err(-32601, f"Method not found: {method!r}")
