"""Domain entities for query results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class QueryResult:
    """Represents the outcome of a natural-language query against Redshift."""

    answer: str
    sql_query: Optional[str] = None
    execution_time: float = 0.0
    confidence: float = 0.0
    intent: str = "unknown"
    rows: List[Dict[str, Any]] = field(default_factory=list)
    columns: List[str] = field(default_factory=list)

    @property
    def row_count(self) -> int:
        return len(self.rows)

    @property
    def is_empty(self) -> bool:
        return self.row_count == 0
