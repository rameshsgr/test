"""Domain entity definitions."""

from domain.entities.query_result import QueryResult

__all__ = ["QueryResult"]
