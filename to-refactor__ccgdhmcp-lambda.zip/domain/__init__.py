"Domain layer: pure business interfaces and entities — no infrastructure dependencies."
