"""Domain interface definitions — implemented by the infrastructure layer."""

from domain.interfaces.redshift_gateway import RedshiftGateway
from domain.interfaces.vector_store_gateway import VectorStoreGateway

__all__ = [
    "RedshiftGateway",
    "VectorStoreGateway",
]
