"""Abstract gateway for the vector metadata store."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class VectorStoreGateway(ABC):
    """Port for semantic/similarity search over table & column metadata."""

    @abstractmethod
    def search_tables_and_columns(
        self,
        query: str,
        table_count: int = 10,
        column_count: int = 30,
    ) -> Dict[str, List[Any]]:
        """Return {'tables': [...], 'columns': [...]} ranked by relevance."""

    @abstractmethod
    def search(self, query: str, top_k: int = 5) -> List[Any]:
        """Generic similarity search returning ranked results."""

    @abstractmethod
    def search_grouped_by_table(
        self,
        query: str,
        top_k: int = 50,
    ) -> List[Dict[str, Any]]:
        """Single semantic search; group results by table.

        Returns ``[{catalog_name, schema_name, table_name, columns:[{...}, ...]}, ...]``.
        """
