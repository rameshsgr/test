"""Abstract gateway for Redshift data access."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Tuple


class RedshiftGateway(ABC):
    """Port that infrastructure must implement to execute queries."""

    @abstractmethod
    def execute_query(self, sql: str) -> Dict[str, Any]:
        """Execute SQL and return {'rows': [...], 'columns': [...], 'total_rows': N}."""

    @abstractmethod
    async def generate_sql(
        self,
        prompt: str,
        schema_context: str | None = None,
    ) -> str:
        """Generate Redshift SQL with an LLM; does not execute the SQL."""

    @abstractmethod
    async def generate_gremlin(
        self,
        prompt: str,
        graph_context: str | None = None,
    ) -> str:
        """Generate Gremlin with an LLM; does not access or execute against Neptune."""

    @abstractmethod
    def list_tables(self, schema: str) -> Dict[str, Any]:
        """Return tables in *schema*."""

    @abstractmethod
    def describe_table(self, table_name: str, schema: str) -> Dict[str, Any]:
        """Return column metadata for *table_name*."""
