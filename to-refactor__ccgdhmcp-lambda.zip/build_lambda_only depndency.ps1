# =============================================================================
# build_lambda.ps1 - Build an x86_64 Lambda deployment package
#
# Usage:
#   .\build_lambda.ps1
#   .\build_lambda.ps1 -ArtifactoryToken "YOUR_TOKEN_HERE"
#
# The Artifactory token can also be supplied via the environment variable
#   ARTIFACTORY_TOKEN
# so it never has to be written in this file.
#
# Output:
#   dist\lambda_package.zip  - ready to upload to AWS Lambda (or S3 - Lambda)
#
# Requirements (on the build machine):
#   - Python 3.11  (x86_64)
#   - pip  >= 23
#   - PowerShell 5.1+
# =============================================================================
param(
    [string]$ArtifactoryUser  = "",
    [string]$ArtifactoryToken = ""   # never hardcode - pass via env or -ArtifactoryToken
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Validate token
# ---------------------------------------------------------------------------
if (-not $ArtifactoryToken) {
    Write-Error @"
Artifactory token not provided.
Supply it via:
  - Environment variable : `$env:ARTIFACTORY_TOKEN = 'your_token'
  - Script parameter     : .\build_lambda.ps1 -ArtifactoryToken 'your_token'
"@
    exit 1
}

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
$PACKAGE_DIR = ".\dist\lambda_package_graph_broker"
$OUTPUT_ZIP  = ".\dist\lambda_package_graph_broker.zip"
$PYTHON      = "python"          # change to full path if needed

# Build the pip index URL from the injected credentials (never stored in source)
$ARTIFACTORY_HOST = "nylartifactory.jfrog.io"
$PIP_INDEX        = "https://${ArtifactoryUser}:${ArtifactoryToken}@${ARTIFACTORY_HOST}/artifactory/api/pypi/pypi-python-org/simple"

$env:PIP_TRUSTED_HOST = $ARTIFACTORY_HOST
$env:PIP_INDEX_URL    = $PIP_INDEX

# ---------------------------------------------------------------------------
# Clean previous build
# ---------------------------------------------------------------------------
Write-Host "`n==> Cleaning previous build..." -ForegroundColor Cyan
if (Test-Path $PACKAGE_DIR) { Remove-Item -Recurse -Force $PACKAGE_DIR }
if (Test-Path $OUTPUT_ZIP)  { Remove-Item -Force $OUTPUT_ZIP }
New-Item -ItemType Directory -Path $PACKAGE_DIR | Out-Null
New-Item -ItemType Directory -Path ".\dist"     -Force | Out-Null

# ---------------------------------------------------------------------------
# Install dependencies - x86_64 Linux wheels only
# Lambda runtime is linux/amd64; force platform tags to avoid pulling
# ARM or Windows wheels on a non-Linux build machine.
# ---------------------------------------------------------------------------
Write-Host "`n==> Installing dependencies into $PACKAGE_DIR ..." -ForegroundColor Cyan

& $PYTHON -m pip install `
    --requirement requirements.txt `
    --target $PACKAGE_DIR `
    --platform manylinux2014_x86_64 `
    --python-version 3.11 `
    --implementation cp `
    --abi cp311 `
    --only-binary :all: `
    --upgrade `
    --no-cache-dir `
    --index-url $PIP_INDEX `
    --trusted-host $ARTIFACTORY_HOST

if ($LASTEXITCODE -ne 0) {
    Write-Error "pip install failed. See output above."
    exit 1
}

# ---------------------------------------------------------------------------
# Copy application source code
# Copies every package directory and top-level Python files.
# Excludes: .git, __pycache__, *.pyc, tests, dist, build artefacts.
# ---------------------------------------------------------------------------
# Write-Host "`n==> Copying application source..." -ForegroundColor Cyan

# $SOURCE_DIRS = @(
#     "api",
#     "application",
#     "components",
#     "core",
#     "creds",
#     "domain",
#     "infrastructure",
#     "prompts"
# )

# foreach ($dir in $SOURCE_DIRS) {
#     if (Test-Path ".\$dir") {
#         Copy-Item -Recurse -Force ".\$dir" "$PACKAGE_DIR\$dir"
#         Write-Host "  Copied $dir"
#     } else {
#         Write-Warning "  Directory '$dir' not found - skipping"
#     }
# }

# # Top-level files
# foreach ($file in @("main.py", "config.yaml")) {
#     if (Test-Path ".\$file") {
#         Copy-Item -Force ".\$file" "$PACKAGE_DIR\$file"
#         Write-Host "  Copied $file"
#     }
# }

# ---------------------------------------------------------------------------
# Remove unnecessary bloat from the package
# ---------------------------------------------------------------------------
Write-Host "`n==> Pruning build artefacts..." -ForegroundColor Cyan

# __pycache__ and .pyc files
Get-ChildItem -Path $PACKAGE_DIR -Recurse -Include "__pycache__" -Directory |
    Remove-Item -Recurse -Force
Get-ChildItem -Path $PACKAGE_DIR -Recurse -Include "*.pyc","*.pyo" |
    Remove-Item -Force

# Test directories inside installed packages
Get-ChildItem -Path $PACKAGE_DIR -Recurse -Include "tests","test" -Directory |
    Remove-Item -Recurse -Force

# Dist-info / egg-info (not needed at runtime)
Get-ChildItem -Path $PACKAGE_DIR -Recurse -Include "*.dist-info","*.egg-info" -Directory |
    Remove-Item -Recurse -Force

# Unnecessary boto3/botocore data (Lambda already has boto3 in the runtime,
# but we bundle our own pinned version - remove the large vendored certs/data
# that duplicate what botocore ships internally)
$BOTO_DATA = "$PACKAGE_DIR\botocore\data"
if (Test-Path $BOTO_DATA) {
    Write-Host "  Keeping botocore/data (required for service endpoints)"
}

Write-Host "  Pruning complete"

# ---------------------------------------------------------------------------
# Report package size before zipping
# ---------------------------------------------------------------------------
$size_mb = [math]::Round((Get-ChildItem -Path $PACKAGE_DIR -Recurse |
    Measure-Object -Property Length -Sum).Sum / 1MB, 1)
Write-Host "`n==> Unzipped package size: $size_mb MB" -ForegroundColor Yellow
if ($size_mb -gt 250) {
    Write-Warning "Package exceeds Lambda's 250 MB unzipped limit!"
}

# ---------------------------------------------------------------------------
# Zip the package
# ---------------------------------------------------------------------------
Write-Host "`n==> Creating $OUTPUT_ZIP ..." -ForegroundColor Cyan

# Compress-Archive needs the *contents* of the directory, not the directory
# itself, so we use the wildcard form.
Compress-Archive -Path "$PACKAGE_DIR\*" -DestinationPath $OUTPUT_ZIP -Force

$zip_mb = [math]::Round((Get-Item $OUTPUT_ZIP).Length / 1MB, 1)
Write-Host "`n==> Done!  ZIP size: $zip_mb MB" -ForegroundColor Green
Write-Host "    Output: $(Resolve-Path $OUTPUT_ZIP)" -ForegroundColor Green

# ---------------------------------------------------------------------------
# Lambda limits reminder
# ---------------------------------------------------------------------------
Write-Host @"

Lambda deployment limits:
  Zipped  : 50 MB  (direct upload) - use S3 if larger
  Unzipped: 250 MB
  Handler : main.handler

Upload command (example):
  aws lambda update-function-code ``
      --function-name <your-function-name> ``
      --zip-file fileb://dist/lambda_package.zip ``
      --region us-east-1

IMPORTANT — set timeout and memory after first deploy (or on every deploy):
  aws lambda update-function-configuration ``
      --function-name <your-function-name> ``
      --timeout 300 ``
      --memory-size 512 ``
      --region us-east-1

  Timeout rationale  : cold-start INIT is outside the timeout budget; 300 s
                       covers Conjur (already in INIT) + vector search +
                       Bedrock SQL generation + Redshift query execution.
  Memory rationale   : 512 MB minimum for psycopg2 + pgvector + boto3;
                       increase to 1024 MB if Bedrock latency is a concern
                       (Lambda CPU scales linearly with memory).
"@ -ForegroundColor DarkGray