"""Conjur secret fetcher for GDH Redshift MCP Service.

Retrieves database credentials from Conjur using IAM authentication.
Called once at service startup; results are injected into ``os.environ``
so all downstream config (``core.config.settings``) picks them up
transparently.

All Conjur connection parameters and secret variable paths are read
exclusively from environment variables — nothing is hardcoded here.

Required environment variables
-------------------------------
  CONJUR_APPLIANCE_URL            Conjur appliance base URL
  CONJUR_ACCOUNT                  Conjur account name
  CONJUR_SERVICE_ID               Conjur authn-iam service ID
  CONJUR_HOST_ID                  Conjur host identity (IAM role path)
  CONJUR_ROLE_ARN                 AWS IAM role ARN assumed by the pod

  CONJUR_SECRET_PGVECTOR_USER     Conjur variable path → pgvector username
  CONJUR_SECRET_PGVECTOR_PASSWORD Conjur variable path → pgvector password

  CONJUR_SECRET_REDSHIFT_USER     Conjur variable path → Redshift username
  CONJUR_SECRET_REDSHIFT_PASSWORD Conjur variable path → Redshift password

Optional
--------
  CONJUR_CERT_FILE                Path to CA cert file
  CONJUR_CA_CERT_CONTENT          Inline CA cert PEM content

Note: REDSHIFT_USER, REDSHIFT_PASSWORD, VECTOR_POSTGRES_USER, and
VECTOR_POSTGRES_PASSWORD must NOT be set directly as environment variables.
Their values are fetched exclusively from Conjur at startup and injected
into os.environ by the functions below.
"""

from __future__ import annotations

import json
import logging
import os

from components.conjur_iam_auth import conjur_iam_auth

logger = logging.getLogger(__name__)


def _assert_not_conjur_error(value: str, path: str) -> None:
    """Raise ValueError if Conjur returned an error JSON instead of a secret value.

    When a Conjur variable path does not exist or the host lacks permission,
    the Conjur API returns a JSON body like:
        {"error": {"code": "not_found", "message": "CONJ00076E Variable ..."}}
    conjur_iam_auth.getVariableId() returns this body as-is, so without this
    check the raw JSON string gets injected as the credential value, causing
    a confusing "password authentication failed" error at the database level.
    """
    stripped = value.strip()
    if stripped.startswith("{"):
        try:
            parsed = json.loads(stripped)
            if "error" in parsed:
                err = parsed["error"]
                raise ValueError(
                    f"Conjur returned an error for path '{path}': "
                    f"[{err.get('code', 'unknown')}] {err.get('message', stripped)}"
                )
        except (json.JSONDecodeError, AttributeError):
            pass  # not JSON — value is fine


def _build_conjur_client() -> conjur_iam_auth:
    """Build a ``conjur_iam_auth`` client using pod IAM role (IRSA).

    The three non-secret infrastructure values (appliance_url, account,
    service_id) are read first from environment variables, then from
    config.yaml defaults (via ``core.config.settings.conjur``).
    ``CONJUR_HOST_ID`` and ``CONJUR_ROLE_ARN`` remain strictly required env
    vars — they are IAM-role-specific and differ per deployment.
    Raises ``KeyError`` at startup if a required value is missing from both
    sources.
    """
    # Lazy import avoids circular dependency at module load time.
    try:
        from core.config import settings as _settings
        _cjr = _settings.conjur
    except Exception:  # noqa: BLE001
        _cjr = None

    def _req(env_key: str, cfg_val: str = "") -> str:
        """Return env var value, falling back to config.yaml; raise KeyError if empty."""
        val = os.environ.get(env_key, "").strip() or (cfg_val or "").strip()
        if not val:
            raise KeyError(env_key)
        return val

    iam_auth_variables: dict = {
        "appliance_url":  _req("CONJUR_APPLIANCE_URL",  _cjr.appliance_url  if _cjr else ""),
        "service_id":     _req("CONJUR_SERVICE_ID",     _cjr.service_id     if _cjr else ""),
        "username":       os.environ["CONJUR_HOST_ID"],
        "conjur_account": _req("CONJUR_ACCOUNT",        _cjr.account        if _cjr else ""),
        "role_arn":       os.environ["CONJUR_ROLE_ARN"],
    }

    ca_cert_content = os.getenv("CONJUR_CA_CERT_CONTENT", "")
    ca_cert_path    = os.getenv("CONJUR_CERT_FILE", "")

    if ca_cert_content:
        iam_auth_variables["ca_cert_content"] = ca_cert_content
    elif ca_cert_path:
        iam_auth_variables["cert_file"] = ca_cert_path
    else:
        iam_auth_variables["cert_file"] = ""

    return conjur_iam_auth(iam_auth_variables)


# ---------------------------------------------------------------------------
# pgvector credentials
# ---------------------------------------------------------------------------

def inject_pgvector_credentials_from_conjur() -> None:
    """Fetch pgvector credentials from Conjur and inject into ``os.environ``.

    Reads the Conjur variable paths from ``CONJUR_SECRET_PGVECTOR_USER``
    and ``CONJUR_SECRET_PGVECTOR_PASSWORD``, fetches the actual credential
    values from Conjur, and sets ``VECTOR_POSTGRES_USER`` and
    ``VECTOR_POSTGRES_PASSWORD`` so that ``core.config.settings.vector_db``
    picks them up automatically.

    Both Conjur path env vars are required — raises ``ValueError`` if either
    is missing or if Conjur returns an empty value.
    """
    user_path     = os.environ.get("CONJUR_SECRET_PGVECTOR_USER", "").strip()
    password_path = os.environ.get("CONJUR_SECRET_PGVECTOR_PASSWORD", "").strip()

    if not user_path:
        raise ValueError(
            "CONJUR_SECRET_PGVECTOR_USER is required but not set. "
            "Set it to the Conjur variable path for the pgvector username."
        )
    if not password_path:
        raise ValueError(
            "CONJUR_SECRET_PGVECTOR_PASSWORD is required but not set. "
            "Set it to the Conjur variable path for the pgvector password."
        )

    logger.info("Fetching pgvector credentials from Conjur …")
    client  = _build_conjur_client()
    secrets = client.getVariableId(user_path, password_path)

    user     = secrets.get(user_path, "").strip()
    password = secrets.get(password_path, "").strip()

    if not user:
        raise ValueError(f"Conjur returned empty pgvector username — path='{user_path}'")
    if not password:
        raise ValueError(f"Conjur returned empty pgvector password — path='{password_path}'")
    _assert_not_conjur_error(user, user_path)
    _assert_not_conjur_error(password, password_path)

    os.environ["VECTOR_POSTGRES_USER"]     = user
    os.environ["VECTOR_POSTGRES_PASSWORD"] = password
    logger.info("✅ pgvector credentials injected into environment from Conjur")


# ---------------------------------------------------------------------------
# Redshift credentials
# ---------------------------------------------------------------------------

def inject_redshift_credentials_from_conjur() -> None:
    """Fetch Redshift credentials from Conjur and inject into ``os.environ``.

    Reads the Conjur variable paths from ``CONJUR_SECRET_REDSHIFT_USER``
    and ``CONJUR_SECRET_REDSHIFT_PASSWORD``, fetches the actual credential
    values from Conjur, and sets ``REDSHIFT_USER`` and ``REDSHIFT_PASSWORD``
    so that ``core.config.settings.redshift`` picks them up automatically.

    Both Conjur path env vars are required — raises ``ValueError`` if either
    is missing or if Conjur returns an empty value.
    """
    user_path     = os.environ.get("CONJUR_SECRET_REDSHIFT_USER", "").strip()
    password_path = os.environ.get("CONJUR_SECRET_REDSHIFT_PASSWORD", "").strip()

    if not user_path:
        raise ValueError(
            "CONJUR_SECRET_REDSHIFT_USER is required but not set. "
            "Set it to the Conjur variable path for the Redshift username."
        )
    if not password_path:
        raise ValueError(
            "CONJUR_SECRET_REDSHIFT_PASSWORD is required but not set. "
            "Set it to the Conjur variable path for the Redshift password."
        )

    logger.info("Fetching Redshift user + password from Conjur …")
    client  = _build_conjur_client()
    secrets = client.getVariableId(user_path, password_path)

    user     = secrets.get(user_path, "").strip()
    password = secrets.get(password_path, "").strip()

    if not user:
        raise ValueError(f"Conjur returned empty Redshift username — path='{user_path}'")
    if not password:
        raise ValueError(f"Conjur returned empty Redshift password — path='{password_path}'")
    _assert_not_conjur_error(user, user_path)
    _assert_not_conjur_error(password, password_path)

    os.environ["REDSHIFT_USER"]     = user
    os.environ["REDSHIFT_PASSWORD"] = password
    logger.info("✅ Redshift user + password injected into environment from Conjur")


# ---------------------------------------------------------------------------
# Generalized per-datasource credentials (multi-datasource orchestration path)
# ---------------------------------------------------------------------------
# NOT called by _fetch_secrets()/get_tool_service() — that Discovery-only path
# is unchanged (see inject_redshift_credentials_from_conjur above). This is
# used exclusively by the new datasource-aware orchestration layer for
# non-Discovery datasources (e.g. "gdh", "actuarial"), whose Conjur variable
# paths (CONJUR_SECRET_<NAME>_USER / CONJUR_SECRET_<NAME>_PASSWORD) may not
# be provisioned yet in every environment — callers must treat a raised
# ValueError as "this datasource is unavailable", not a fatal startup error.

def inject_datasource_credentials_from_conjur(name: str) -> None:
    """Fetch a named datasource's Redshift credentials from Conjur.

    Reads ``CONJUR_SECRET_<NAME>_USER`` / ``CONJUR_SECRET_<NAME>_PASSWORD``
    (``name`` upper-cased), fetches the values from Conjur, and injects them
    as ``REDSHIFT_<NAME>_USER`` / ``REDSHIFT_<NAME>_PASSWORD`` so that
    ``core.config.settings.datasources[name]`` picks them up on reload —
    mirroring ``DatasourceConfig.from_dict``'s env var naming exactly.

    Raises ``ValueError`` if the Conjur variable paths are not configured or
    Conjur returns an empty/error value — callers should treat this as
    "datasource unavailable", not abort the whole service.
    """
    upper = name.upper()
    user_path_var     = f"CONJUR_SECRET_{upper}_USER"
    password_path_var = f"CONJUR_SECRET_{upper}_PASSWORD"
    user_path     = os.environ.get(user_path_var, "").strip()
    password_path = os.environ.get(password_path_var, "").strip()

    if not user_path:
        raise ValueError(f"{user_path_var} is required but not set for datasource '{name}'.")
    if not password_path:
        raise ValueError(f"{password_path_var} is required but not set for datasource '{name}'.")

    logger.info("Fetching '%s' Redshift credentials from Conjur …", name)
    client  = _build_conjur_client()
    secrets = client.getVariableId(user_path, password_path)

    user     = secrets.get(user_path, "").strip()
    password = secrets.get(password_path, "").strip()

    if not user:
        raise ValueError(f"Conjur returned empty username for '{name}' — path='{user_path}'")
    if not password:
        raise ValueError(f"Conjur returned empty password for '{name}' — path='{password_path}'")
    _assert_not_conjur_error(user, user_path)
    _assert_not_conjur_error(password, password_path)

    os.environ[f"REDSHIFT_{upper}_USER"]     = user
    os.environ[f"REDSHIFT_{upper}_PASSWORD"] = password
    logger.info("✅ '%s' Redshift credentials injected into environment from Conjur", name)
