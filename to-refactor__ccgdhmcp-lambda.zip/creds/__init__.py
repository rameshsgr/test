"""Credentials package — fetches secrets from Conjur at startup."""
