from atexit import register
import base64
import random
from socket import IP_ADD_MEMBERSHIP
import string
import sys
import datetime
import hashlib
import hmac
import json
import os
import tempfile
import requests  # pip install requests
from datetime import timedelta
import urllib.parse
import boto3
from ec2_metadata import ec2_metadata
from datetime import datetime as dt


# ************* REQUEST VALUES *************
AWS_METADATA_URL_IMDSv2 = 'http://169.254.169.254/latest'
METHOD = 'GET'
SERVICE = 'sts'
HOST = 'sts.amazonaws.com'
ENDPOINT = 'https://sts.amazonaws.com'
REQUEST_PARAMETERS = 'Action=GetCallerIdentity&Version=2011-06-15'
IMDSv2Token = ''
session_key = ''
session_id = ''


class conjur_iam_auth:

    # default constructor
    def __init__(self, iam_auth_variables):

        if 'role_arn' in iam_auth_variables:
            self.role_arn = iam_auth_variables['role_arn']
        else:
            self.role_arn = ""

        if 'ca_cert_content' in iam_auth_variables:
            self.ca_cert_content = iam_auth_variables['ca_cert_content']
            self.cert_file =""
        else:
            self.cert_file = iam_auth_variables['cert_file']
            self.ca_cert_content=""

        self.appliance_url = iam_auth_variables['appliance_url']
        self.service_id = iam_auth_variables['service_id']
        self.username = iam_auth_variables['username']
        self.host_id = iam_auth_variables['username']
        self.account = iam_auth_variables['conjur_account']        
        # self.ca_cert_content = iam_auth_variables['ca_cert_content']

    class ConjurIAMAuthnException(Exception):
        def __init__(self):
            Exception.__init__(
                self, "Conjur IAM authentication failed with 401 - Unauthorized. Check conjur logs for more information")

    class IAMRoleNotAvailableException(Exception):
        def __init__(self):
            Exception.__init__(
                self, "Most likely the ec2 instance is configured with no or an incorrect iam role")

    class InvalidAwsAccountIdException(Exception):
        def __init__(self):
            Exception.__init__(
                self, "The AWS Account ID specified in the CONJUR_AUTHN_LOGIN is invalid and must be a 12 digit number")

    def valid_aws_account_number(host_id):
        parts = host_id.split("/")
        account_id = parts[len(parts)-2]
        if len(account_id) == 12:
            return True
        return False

    def sign(key, msg):
        return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

    def get_signature_key(key, dateStamp, regionName, serviceName):
        kDate = conjur_iam_auth.sign(('AWS4' + key).encode('utf-8'), dateStamp)
        kRegion = conjur_iam_auth.sign(kDate, regionName)
        kService = conjur_iam_auth.sign(kRegion, serviceName)
        kSigning = conjur_iam_auth.sign(kService, 'aws4_request')
        return kSigning

    def getIMDSv2Token(self):
        r = requests.put(AWS_METADATA_URL_IMDSv2 + '/api/token', data={}, headers={
            'X-aws-ec2-metadata-token-ttl-seconds': '900',
        })
        conjur_iam_auth.IMDSv2Token = r.text

        return conjur_iam_auth.IMDSv2Token

    def get_aws_region(self):
        if self.role_arn != "":
            region  = os.getenv('aws_region','us-east-1')
            return region
        else:
            conjur_iam_auth.getIMDSv2Token(self)
            region = requests.get(AWS_METADATA_URL_IMDSv2+'/meta-data/placement/region',
                                  headers={'X-aws-ec2-metadata-token': conjur_iam_auth.IMDSv2Token})
            return region.text

    def get_iam_role_name(self):
        conjur_iam_auth.getIMDSv2Token(self)
        iam_role = requests.get(AWS_METADATA_URL_IMDSv2+'/meta-data/iam/security-credentials',
                                headers={'X-aws-ec2-metadata-token': conjur_iam_auth.IMDSv2Token})
        return iam_role.text

    def get_cred_assume_role(self):
        # print('inside cred assume role')
        sts_client = boto3.client('sts')
        # print(sts_client)
        timestamp = 1625309472.357246
        date_time = dt.fromtimestamp(timestamp)
        str_date_time = date_time.strftime("%d_%m_%Y_%H_%M_%S")
        random_string = ''.join(random.choices(string.ascii_lowercase, k=15))
        role_session_name = 'Conjur_integration_' + str_date_time+'_'+random_string
        
        try:
            # print("self.role_arn:",self.role_arn)
            # print("role_session_name:",role_session_name)
            assumed_role_object = sts_client.assume_role(
                RoleArn=self.role_arn,
                RoleSessionName=role_session_name)
            # print(assumed_role_object)
        except Exception as e:
            raise RuntimeError(f"STS assume_role failed for {self.role_arn}: {e}") from e
        credentials = assumed_role_object['Credentials']
        # print(credentials)
        return credentials

    def get_iam_role_metadata(self, role_name):
        # print('inside iam role metadata')
        if self.role_arn != "":
            # print('test1')
            r = conjur_iam_auth.get_cred_assume_role(self)
            access_key_id = r["AccessKeyId"]
            secret_access_key = r["SecretAccessKey"]
            token = r["SessionToken"]
            conjur_iam_auth.session_key = secret_access_key
            conjur_iam_auth.session_id = access_key_id
            # print('metadata good')
        else:
            r = requests.get(AWS_METADATA_URL_IMDSv2 +
                             '/meta-data/iam/security-credentials/' + role_name,
                             headers={'X-aws-ec2-metadata-token': conjur_iam_auth.IMDSv2Token})
            if r.status_code == 404:
                raise conjur_iam_auth.IAMRoleNotAvailableException()

            json_dict = json.loads(r.text)

            access_key_id = json_dict["AccessKeyId"]
            secret_access_key = json_dict["SecretAccessKey"]
            token = json_dict["Token"]

        return access_key_id, secret_access_key, token

    def create_canonical_request(amzdate, token, signed_headers, payload_hash):
        # ************* TASK 1: CREATE A CANONICAL REQUEST *************
        # http://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html

        # Step 1 is to define the verb (GET, POST, etc.)--already done.

        # Step 2: Create canonical URI--the part of the URI from domain to query
        # string (use '/' if no path)
        canonical_uri = '/'

        # Step 3: Create the canonical query string. In this example (a GET request),
        # request parameters are in the query string. Query string values must
        # be URL-encoded (space=%20). The parameters must be sorted by name.
        # For this example, the query string is pre-formatted in the request_parameters variable.
        canonical_querystring = REQUEST_PARAMETERS

        # Step 4: Create payload hash (hash of the request body content). For GET
        # requests, the payload is an empty string ("").
        # payload_hash = hashlib.sha256(('').encode('utf-8')).hexdigest()

        # Step 5: Create the canonical headers and signed headers. Header names
        # must be trimmed and lowercase, and sorted in code point order from
        # low to high. Note that there is a trailing \n.
        canonical_headers = 'host:' + HOST + '\n' + 'x-amz-content-sha256:' + payload_hash + \
            '\n' + 'x-amz-date:' + amzdate + '\n' + 'x-amz-security-token:' + token + '\n'

        # Step 6: Create the list of signed headers. This lists the headers
        # in the canonical_headers list, delimited with ";" and in alpha order.
        # Note: The request can include any headers; canonical_headers and
        # signed_headers lists those that you want to be included in the
        # hash of the request. "Host" and "x-amz-date" are always required.
        # signed_headers = 'host;x-amz-content-sha256;x-amz-date;x-amz-security-token'

        # Step 7: Combine elements to create canonical request
        canonical_request = METHOD + '\n' + canonical_uri + '\n' + canonical_querystring + \
            '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash

        return canonical_request

    def create_conjur_iam_api_key(self, iam_role_name=None, access_key=None, secret_key=None, token=None):
        # print("Inside conur IAM API key")
        if self.role_arn == "":
            if iam_role_name is None:
                iam_role_name = conjur_iam_auth.get_iam_role_name(self)
        # print("tet")
        if access_key is None and secret_key is None and token is None:
            access_key, secret_key, token = conjur_iam_auth.get_iam_role_metadata(self,
                                                                        iam_role_name)
        # print('test')
        try:
            region = conjur_iam_auth.get_aws_region(self)
            import logging as _log; _log.getLogger(__name__).debug("Region: %s", region)
        except Exception as e:
            raise RuntimeError(f"Failed to determine AWS region: {e}") from e
        if access_key is None or secret_key is None:
            import logging as _log; _log.getLogger(__name__).error("No access key is available.")
            sys.exit()

        # Create a date for headers and the credential string
        t = datetime.datetime.utcnow()
        amzdate = t.strftime('%Y%m%dT%H%M%SZ')
        # Date w/o time, used in credential scope
        datestamp = t.strftime('%Y%m%d')

        # ************* TASK 1: CREATE A CANONICAL REQUEST *************
        signed_headers = 'host;x-amz-content-sha256;x-amz-date;x-amz-security-token'
        payload_hash = hashlib.sha256(('').encode('utf-8')).hexdigest()
        canonical_request = conjur_iam_auth.create_canonical_request(
            amzdate, token, signed_headers, payload_hash)

        # ************* TASK 2: CREATE THE STRING TO SIGN*************
        # Match the algorithm to the hashing algorithm you use, either SHA-1 or
        # SHA-256 (recommended)
        algorithm = 'AWS4-HMAC-SHA256'
        credential_scope = datestamp + '/' + region + \
            '/' + SERVICE + '/' + 'aws4_request'
        string_to_sign = algorithm + '\n' + amzdate + '\n' + credential_scope + \
            '\n' + \
            hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()

        # ************* TASK 3: CALCULATE THE SIGNATURE *************
        # Create the signing key using the function defined above.
        signing_key = conjur_iam_auth.get_signature_key(
            secret_key, datestamp, region, SERVICE)

        # Sign the string_to_sign using the signing_key
        signature = hmac.new(signing_key, string_to_sign.encode(
            'utf-8'), hashlib.sha256).hexdigest()

        # ************* TASK 4: ADD SIGNING INFORMATION TO THE REQUEST *************
        # The signing information can be either in a query string value or in
        # a header named Authorization. This code shows how to use a header.
        # Create authorization header and add to request headers
        authorization_header = algorithm + ' ' + 'Credential=' + access_key + '/' + \
            credential_scope + ', ' + 'SignedHeaders=' + \
            signed_headers + ', ' + 'Signature=' + signature

        # The request can include any headers, but MUST include "host", "x-amz-date",
        # and (for this scenario) "Authorization". "host" and "x-amz-date" must
        # be included in the canonical_headers and signed_headers, as noted
        # earlier. Order here is not significant.
        # Python note: The 'host' header is added automatically by the Python 'requests' library.

        headers = {
            'host': HOST,
            'x-amz-date': amzdate,
            'x-amz-security-token': token,
            'x-amz-content-sha256': payload_hash,
            'authorization': authorization_header
        }

        # ************* SEND THE REQUEST *************
        return '{}'.format(headers).replace("'", '"')

    def get_conjur_iam_session_token(self, appliance_url, account, service_id, host_id, cert_file,ca_cert_content, iam_role_name=None, access_key=None, secret_key=None, token=None, ssl_verify=True):
        # print('inside iam session token')
        if not conjur_iam_auth.valid_aws_account_number(host_id):
            raise conjur_iam_auth.InvalidAwsAccountIdException()

        appliance_url = appliance_url.rstrip("/")
        url = "{}/authn-iam/{}/{}/{}/authenticate".format(
            appliance_url, service_id, account, urllib.parse.quote(host_id, safe=''))
        # print("url:",url)
        try:
            iam_api_key = conjur_iam_auth.create_conjur_iam_api_key(self,
                                                                iam_role_name, access_key, secret_key, token)
        except Exception as e:
            raise RuntimeError(f"Failed to create Conjur IAM API key: {e}") from e
        # print("iam_api_key",iam_api_key)
        # If cert file is not provided then assume conjur is using valid certificate
        if cert_file == None:
            cert_file = True        

        # If ssl_verify is explicitly false then ignore ssl certificate even if cert_file is set
        if not ssl_verify:
            cert_file = False
        if ca_cert_content:
            with tempfile.NamedTemporaryFile(delete=False) as temp_cert_file:
                temp_cert_file.write(ca_cert_content.encode('utf-8'))
                cert_file = temp_cert_file.name

        try:
            r = requests.post(url=url, data=iam_api_key, verify=False)
            # print(f'r_value:{r}')
        except Exception as e:
            raise RuntimeError(f"Conjur authenticate HTTP request failed: {e}") from e

        if r.status_code == 401:
            raise conjur_iam_auth.ConjurIAMAuthnException()
        
        return r.text

    def getVariableId(self, *variableIds):
        # print("Inside Get variable id")

        session_token = conjur_iam_auth.get_conjur_iam_session_token(self,
                                                                     self.appliance_url, self.account, self.service_id, self.host_id, self.cert_file,self.ca_cert_content, iam_role_name=None, access_key=None, secret_key=None, token=None, ssl_verify=True)

        # print("session_token:",session_token)

        api_token = base64.b64encode(session_token.encode()).decode('utf-8')
        # print("api_token", api_token)
        myDict = {}
        for variable_id in variableIds:

            variableUrl = self.appliance_url + "/secrets/" + \
                self.account + "/variable/" + variable_id
            # print("variableUrl", variableUrl)

            header = {
                'Authorization': 'Token token="'+api_token+'"',
            }
            if self.ca_cert_content:
                with tempfile.NamedTemporaryFile(delete=False) as temp_cert_file:
                    temp_cert_file.write(self.ca_cert_content.encode('utf-8'))
                    self.cert_file = temp_cert_file.name

            r = requests.get(url=variableUrl, headers=header,
                             verify=False)
            # print("Response:",r)
            myDict[variable_id] = r.content.decode('utf-8')
        # print("myDict", myDict)
        return myDict