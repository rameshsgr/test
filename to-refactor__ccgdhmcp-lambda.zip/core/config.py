"""Centralised configuration — load once, inject everywhere.

Resolution order (highest → lowest priority)
---------------------------------------------
1. Environment variable  (EKS ConfigMap / Secret)
2. config.yaml value     (non-sensitive schema/defaults bundled in image)

Rule: **secrets must never live in config.yaml or source code**.
      They must always come from env vars injected by the K8s ConfigMap / Secret.

EKS deployment
--------------
All values come from the agentregistry config YAML rendered into the pod as
environment variables.  config.yaml is bundled in the image for
schema/defaults reference but every value is overridden by the injected env vars.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import yaml

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _env(key: str, yaml_val: Optional[str] = None, required: bool = False) -> str:
    """
    Return env-var value, falling back to *yaml_val*.

    If *required* is True and neither source provides a value, a WARNING
    is logged (not a crash).  The service will start and fail gracefully
    at request-time rather than refusing to boot entirely.
    """
    # os.getenv always wins over YAML
    value = os.getenv(key)
    if not value and yaml_val not in (None, "", "null", "NULL"):
        value = str(yaml_val).strip()
    if not value:
        if required:
            _log.warning(
                "Required config '%s' is not set. "
                "Set it as an environment variable. "
                "Related functionality will fail at runtime.",
                key,
            )
        return ""
    return value


def _env_int(key: str, yaml_val=None, default: int = 0) -> int:
    raw = os.getenv(key)
    if not raw and yaml_val is not None:
        raw = str(yaml_val)
    try:
        return int(raw) if raw else default
    except (ValueError, TypeError):
        _log.warning("Config '%s' value '%s' is not an integer; using %d", key, raw, default)
        return default


def _env_bool(key: str, yaml_val=None, default: bool = False) -> bool:
    raw = os.getenv(key)
    if not raw and yaml_val is not None:
        raw = str(yaml_val)
    if raw is None:
        return default
    return raw.strip().lower() in ("true", "1", "yes")


def _env_float(key: str, yaml_val=None, default: float = 0.0) -> float:
    raw = os.getenv(key)
    if not raw and yaml_val is not None:
        raw = str(yaml_val)
    try:
        return float(raw) if raw else default
    except (ValueError, TypeError):
        _log.warning("Config '%s' value '%s' is not a float; using %f", key, raw, default)
        return default


# ---------------------------------------------------------------------------
# Raw YAML loader — provides local-dev defaults only
# ---------------------------------------------------------------------------

def _load_yaml(path: str | Path = "config.yaml") -> dict:
    try:
        with open(path, "r") as fh:
            return yaml.safe_load(fh) or {}
    except FileNotFoundError:
        _log.debug("config.yaml not found at '%s' — using env vars only.", path)
        return {}
    except Exception as exc:  # noqa: BLE001
        _log.warning("Could not read config.yaml: %s — using env vars only.", exc)
        return {}


_RAW: dict = _load_yaml(
    os.getenv("CONFIG_PATH", str(Path(__file__).parent.parent / "config.yaml"))
)


# ---------------------------------------------------------------------------
# Typed config dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RedshiftConfig:
    """Redshift connection.

    ``user`` and ``password`` are injected at startup by
    ``creds.conjur_secrets.inject_redshift_credentials_from_conjur()``
    via ``CONJUR_SECRET_REDSHIFT_USER`` / ``CONJUR_SECRET_REDSHIFT_PASSWORD``.
    Do NOT set REDSHIFT_USER or REDSHIFT_PASSWORD directly.
    """

    host: str
    database: str
    user: str
    password: str
    port: int = 5439
    schema: str = "public"
    schemas: tuple = ()          # all accessible schemas — parsed from REDSHIFT_SCHEMAS
    ssl: bool = True
    ssl_insecure: bool = False
    timeout: int = 300

    @classmethod
    def from_dict(cls, d: dict) -> "RedshiftConfig":
        # ``SCHEMA``/``REDSHIFT_SCHEMA`` is intended to be a SINGLE schema, but
        # deployments have historically set it to a comma-joined list (e.g.
        # "ARD_CLIENT_POLICY,ARD_SALES_OPPORTUNITY").  Guard against that so
        # ``schema`` (used as the single connection/default schema) is never a
        # comma-joined string — take the first entry as the primary schema.
        _primary_raw = _env("REDSHIFT_SCHEMA", d.get("SCHEMA"), required=False) or "public"
        # REDSHIFT_SCHEMAS — comma-separated list of all accessible schemas.
        # Falls back to the (possibly comma-joined) REDSHIFT_SCHEMA value.
        _schemas_raw = (
            _env("REDSHIFT_SCHEMAS", d.get("SCHEMAS"), required=False)
            or _primary_raw
        )
        schemas_tuple = tuple(s.strip() for s in _schemas_raw.split(",") if s.strip())
        # Primary schema is always a single value — never a comma-joined list.
        primary_schema = _primary_raw.split(",")[0].strip() or "public"
        return cls(
            host=_env("REDSHIFT_HOST", d.get("HOST"), required=True),
            database=_env("REDSHIFT_DATABASE", d.get("DATABASE"), required=True),
            # Injected by Conjur at startup — NOT a direct env var.
            # Do NOT set REDSHIFT_USER / REDSHIFT_PASSWORD as plain env vars.
            # required=False here because Conjur hasn't run yet at import time;
            # validation happens in api.app._validate_credentials() post-injection.
            user=_env("REDSHIFT_USER", required=False),
            password=_env("REDSHIFT_PASSWORD", required=False),
            port=_env_int("REDSHIFT_PORT", d.get("PORT"), default=5439),
            schema=primary_schema,
            schemas=schemas_tuple,
            ssl=_env_bool("REDSHIFT_SSL", d.get("SSL"), default=True),
            ssl_insecure=_env_bool("REDSHIFT_SSL_INSECURE", d.get("SSL_INSECURE"), default=False),
            timeout=_env_int("REDSHIFT_TIMEOUT", d.get("TIMEOUT"), default=300),
        )


@dataclass(frozen=True)
class DatasourceConfig:
    """A single named Redshift datasource (cluster + database + schema group).

    ``discovery`` is always built in "legacy" mode: it reads the exact same
    env vars as the original ``RedshiftConfig`` (``REDSHIFT_HOST``,
    ``REDSHIFT_SCHEMA(S)``, etc.) so existing Discovery Zone deployments are
    byte-for-byte unaffected by the introduction of this class.

    Other datasources (``gdh``, ``actuarial``, ...) read prefixed env vars
    (``REDSHIFT_<NAME>_HOST``, ``REDSHIFT_<NAME>_SCHEMAS``, ...) and are not
    required to be fully configured yet — they exist so ``DatasourceRouter``
    can build its schema→datasource map from ``schemas`` without a separate
    routing table in config.yaml.

    ``graph_enrichment_enabled`` gates Neptune enrichment per datasource.
    Only ``discovery`` defaults to enabled — the current graph reflects the
    validated DAR model for Discovery Zone only, so GDH/Actuarial must
    explicitly opt in once (and if) a matching graph is available for them.
    """

    name: str
    host: str
    database: str
    user: str
    password: str
    schemas: tuple = ()
    port: int = 5439
    ssl: bool = True
    ssl_insecure: bool = False
    timeout: int = 300
    graph_enrichment_enabled: bool = False

    @property
    def schema(self) -> str:
        """Primary (first) schema — mirrors ``RedshiftConfig.schema`` so this
        class is drop-in compatible with ``infrastructure.redshift.mcp_server
        ._build_client_config()``, which expects a single ``schema`` value."""
        return self.schemas[0] if self.schemas else "public"

    @classmethod
    def from_dict(cls, name: str, d: dict, *, legacy: bool = False) -> "DatasourceConfig":
        prefix = "REDSHIFT" if legacy else f"REDSHIFT_{name.upper()}"

        _schemas_yaml = d.get("schemas") or d.get("SCHEMA") or d.get("SCHEMAS")
        if isinstance(_schemas_yaml, (list, tuple)):
            _schemas_yaml = ",".join(str(s) for s in _schemas_yaml)

        _primary_raw = _env(f"{prefix}_SCHEMA", _schemas_yaml, required=False) or "public"
        _schemas_raw = _env(f"{prefix}_SCHEMAS", _schemas_yaml, required=False) or _primary_raw
        schemas_tuple = tuple(s.strip() for s in _schemas_raw.split(",") if s.strip())

        default_graph_enabled = legacy or (name.lower() == "discovery")
        graph_enrichment_enabled = _env_bool(
            f"{prefix}_GRAPH_ENRICHMENT_ENABLED",
            d.get("graph_enrichment_enabled"),
            default=default_graph_enabled,
        )

        return cls(
            name=name,
            host=_env(f"{prefix}_HOST", d.get("host", d.get("HOST")), required=legacy),
            database=_env(f"{prefix}_DATABASE", d.get("database", d.get("DATABASE")), required=legacy),
            user=_env(f"{prefix}_USER" if not legacy else "REDSHIFT_USER", required=False),
            password=_env(f"{prefix}_PASSWORD" if not legacy else "REDSHIFT_PASSWORD", required=False),
            port=(
                _env_int(f"{prefix}_PORT", d.get("port", d.get("PORT")), default=0)
                or _env_int("REDSHIFT_PORT", None, default=0)
                or 5455
            ),
            schemas=schemas_tuple,
            ssl=_env_bool(f"{prefix}_SSL", d.get("ssl", d.get("SSL")), default=True),
            ssl_insecure=_env_bool(f"{prefix}_SSL_INSECURE", d.get("ssl_insecure", d.get("SSL_INSECURE")), default=False),
            timeout=_env_int(f"{prefix}_TIMEOUT", d.get("timeout", d.get("TIMEOUT")), default=300),
            graph_enrichment_enabled=graph_enrichment_enabled,
        )


@dataclass(frozen=True)
class AwsConfig:
    """AWS credentials — on Lambda/EKS the execution role is used automatically by boto3."""

    region: str = "us-east-1"
    verify_ssl: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "AwsConfig":
        return cls(
            region=_env("AWS_REGION", d.get("AWS_REGION"), required=False)
                   or _env("AWS_DEFAULT_REGION", d.get("AWS_DEFAULT_REGION"), required=False)
                   or "us-east-1",
            verify_ssl=_env_bool("AWS_VERIFY_SSL", d.get("AWS_VERIFY_SSL"), default=False),
        )


@dataclass(frozen=True)
class ChatModelConfig:
    """Bedrock LLM parameters."""

    model_id: str
    max_tokens: int = 4096
    temperature: float = 0.7

    @classmethod
    def from_dict(cls, d: dict) -> "ChatModelConfig":
        return cls(
            model_id=_env("BEDROCK_MODEL_ID", d.get("BEDROCK_MODEL_ID"), required=True),
            max_tokens=_env_int("BEDROCK_MAX_TOKENS", d.get("BEDROCK_MAX_TOKENS"), default=4096),
            temperature=_env_float("BEDROCK_TEMPERATURE", d.get("BEDROCK_TEMPERATURE"), default=0.7),
        )


@dataclass(frozen=True)
class VectorDbConfig:
    """pgvector Aurora PostgreSQL connection.

    ``user`` and ``password`` are injected at startup by
    ``creds.conjur_secrets.inject_pgvector_credentials_from_conjur()``
    via ``CONJUR_SECRET_PGVECTOR_USER`` / ``CONJUR_SECRET_PGVECTOR_PASSWORD``.
    Do NOT set VECTOR_POSTGRES_USER or VECTOR_POSTGRES_PASSWORD directly.

    auto_provision
    --------------
    Runtime is READ-ONLY by default (``auto_provision=False``): the store
    only ever validates that the schema/table already exist and never issues
    ``CREATE SCHEMA`` / ``CREATE TABLE`` / ``CREATE INDEX`` / ``CREATE
    EXTENSION``. Infrastructure/DBA tooling — or the offline
    ``infrastructure/vector_store/provision_pgvector.py`` script in non-prod —
    is responsible for provisioning. Set ``VECTOR_AUTO_PROVISION=true`` only
    for that offline/dev provisioning path; the running service should never
    set it.
    """

    host: str
    port: int
    database: str
    user: str
    password: str
    ssl: bool
    schema: str
    table: str
    embedding_dimension: int
    embedding_model: str
    auto_provision: bool = False

    @classmethod
    def from_dict(cls, d: dict, embed_d: dict | None = None) -> "VectorDbConfig":
        ed = embed_d or {}
        return cls(
            host=_env("VECTOR_POSTGRES_HOST", d.get("VECTOR_POSTGRES_HOST"), required=True),
            port=_env_int("VECTOR_POSTGRES_PORT", d.get("VECTOR_POSTGRES_PORT"), default=5432),
            database=_env("VECTOR_POSTGRES_DB", d.get("VECTOR_POSTGRES_DB"), required=True),
            # Injected by Conjur at startup — NOT a direct env var.
            # Do NOT set VECTOR_POSTGRES_USER / VECTOR_POSTGRES_PASSWORD as plain env vars.
            # required=False here because Conjur hasn't run yet at import time;
            # validation happens in api.app._validate_credentials() post-injection.
            user=_env("VECTOR_POSTGRES_USER", required=False),
            password=_env("VECTOR_POSTGRES_PASSWORD", required=False),
            ssl=_env_bool("VECTOR_POSTGRES_SSL", d.get("VECTOR_POSTGRES_SSL"), default=True),
            schema=_env("VECTOR_SCHEMA", d.get("VECTOR_SCHEMA")) or "public",
            table=_env("VECTOR_TABLE", d.get("VECTOR_TABLE")) or "discovery_clientreporting",
            # Default False = read-only runtime. Must be explicitly opted into
            # for offline/dev provisioning — never set true in prod/EKS/Lambda.
            auto_provision=_env_bool(
                "VECTOR_AUTO_PROVISION", d.get("VECTOR_AUTO_PROVISION"), default=False,
            ),
            embedding_dimension=_env_int(
                "EMBEDDING_DIMENSION",
                ed.get("EMBEDDING_DIMENSION"),
                default=1024,
            ),
            embedding_model=_env(
                "TITAN_MODEL_ID",
                ed.get("TITAN_MODEL_ID"),
            ) or "amazon.titan-embed-text-v2:0",
        )


@dataclass(frozen=True)
class SearchConfig:
    """Similarity search tuning."""

    top_k: int = 10
    column_multiplier: int = 3

    @classmethod
    def from_dict(cls, d: dict) -> "SearchConfig":
        return cls(
            top_k=_env_int("SEARCH_TOP_K", d.get("TOP_K"), default=10),
            column_multiplier=_env_int("SEARCH_COLUMN_MULTIPLIER", d.get("COLUMN_MULTIPLIER"), default=3),
        )


@dataclass(frozen=True)
class GraphOntologyConfig:
    """Business ontology graph — enriched live from Neptune (no S3 dependency).

    PGVector remains responsible for semantic table/column retrieval; for
    each table PGVector returns, ``NeptuneGraphOntologyEnricher`` issues
    bounded Gremlin queries against the Neptune **reader** endpoint to pull
    PK/FK, join-path, and logical-name metadata. Nothing is
    downloaded/cached from S3 and no offline compaction step is required —
    see ``infrastructure/graph_ontology/neptune_enricher.py``.

    Vertex/edge label and property names are NOT hardcoded — they live in
    ``schema_mapping`` (see ``infrastructure.graph_ontology.schema_mapping
    .GraphSchemaMapping``), sourced from config.yaml /
    ``GRAPH_ONTOLOGY_MAPPING_*`` env vars, and default to the validated DAR
    graph model (``DarTable``/``DarColumn`` with flat ``schemaName``/
    ``tableName`` properties — see that module's docstring for why no edge
    traversal is required).

    allowed_schemas
    ---------------
    Comma-separated schema names. Graph keyword-expansion will only surface
    tables whose schema matches at least one entry. Leave empty to allow all.
    Set via ``GRAPH_ONTOLOGY_ALLOWED_SCHEMAS`` or config.yaml.
    """

    neptune_endpoint: str = ""       # GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT — reader endpoint hostname
    neptune_port: int = 8182         # GRAPH_ONTOLOGY_NEPTUNE_PORT
    neptune_region: str = "us-east-1"  # GRAPH_ONTOLOGY_NEPTUNE_REGION
    neptune_iam_auth: bool = True    # GRAPH_ONTOLOGY_NEPTUNE_IAM_AUTH — SigV4-sign the handshake
    allowed_schemas: tuple = ()
    schema_mapping: "GraphSchemaMapping" = None  # type: ignore[assignment]

    @classmethod
    def from_dict(cls, d: dict) -> "GraphOntologyConfig":
        from infrastructure.graph_ontology.schema_mapping import GraphSchemaMapping

        neptune_endpoint = _env(
            "GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT", d.get("neptune_endpoint", ""),
        )
        neptune_port = _env_int(
            "GRAPH_ONTOLOGY_NEPTUNE_PORT", d.get("neptune_port"), default=8182,
        )
        neptune_region = _env(
            "GRAPH_ONTOLOGY_NEPTUNE_REGION", d.get("neptune_region", "")
        ) or "us-east-1"
        neptune_iam_auth = _env_bool(
            "GRAPH_ONTOLOGY_NEPTUNE_IAM_AUTH", d.get("neptune_iam_auth"), default=True,
        )

        raw_schemas = _env(
            "GRAPH_ONTOLOGY_ALLOWED_SCHEMAS",
            d.get("allowed_schemas", ""),
        )
        allowed: tuple = ()
        if raw_schemas:
            allowed = tuple(s.strip() for s in raw_schemas.split(",") if s.strip())

        mapping = GraphSchemaMapping.from_dict(d.get("schema_mapping", {}) or {}, _env)

        return cls(
            neptune_endpoint=neptune_endpoint,
            neptune_port=neptune_port,
            neptune_region=neptune_region,
            neptune_iam_auth=neptune_iam_auth,
            allowed_schemas=allowed,
            schema_mapping=mapping,
        )


@dataclass(frozen=True)
class BusinessCatalogConfig:
    """Business catalog Neptune connection — semantic layer graph access.

    Uses boto3 neptunedata REST data-plane (not gremlinpython websocket).
    Endpoint resolution order (in fetch_catalog_context):
    1. BUSINESS_CATALOG_NEPTUNE_ENDPOINT env var
    2. GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT env var (same cluster, different vertex family)
    3. graph_ontology.neptune_endpoint from config.yaml

    No credentials needed — IAM SigV4 via Lambda execution role.
    """

    neptune_endpoint: str = ""      # BUSINESS_CATALOG_NEPTUNE_ENDPOINT
    neptune_region: str = "us-east-1"  # BUSINESS_CATALOG_NEPTUNE_REGION
    neptune_iam_auth: bool = True    # BUSINESS_CATALOG_NEPTUNE_IAM_AUTH

    @classmethod
    def from_dict(cls, d: dict) -> "BusinessCatalogConfig":
        neptune_endpoint = _env(
            "BUSINESS_CATALOG_NEPTUNE_ENDPOINT", d.get("neptune_endpoint", ""),
        )
        neptune_region = (
            _env("BUSINESS_CATALOG_NEPTUNE_REGION", d.get("neptune_region", ""))
            or _env("AWS_REGION", None)
            or _env("AWS_DEFAULT_REGION", None)
            or "us-east-1"
        )
        neptune_iam_auth = _env_bool(
            "BUSINESS_CATALOG_NEPTUNE_IAM_AUTH", d.get("neptune_iam_auth"), default=True,
        )
        return cls(
            neptune_endpoint=neptune_endpoint,
            neptune_region=neptune_region,
            neptune_iam_auth=neptune_iam_auth,
        )


@dataclass(frozen=True)
class ConjurConfig:
    """Conjur IAM auth configuration.

    All values are injected at runtime via env vars set in the per-env
    agentregistry config YAML.  Nothing is hardcoded here.
    """

    appliance_url: str    = ""
    account: str          = ""
    service_id: str       = ""
    host_id: str          = ""
    role_arn: str         = ""
    cert_file: str        = ""
    ca_cert_content: str  = ""
    # Conjur variable paths — set per-env in agentregistry config YAML
    secret_redshift_user: str     = ""
    secret_redshift_password: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "ConjurConfig":
        return cls(
            appliance_url=_env("CONJUR_APPLIANCE_URL", d.get("appliance_url"), required=False),
            account=_env("CONJUR_ACCOUNT", d.get("account"), required=False),
            service_id=_env("CONJUR_SERVICE_ID", d.get("service_id"), required=False),
            host_id=_env("CONJUR_HOST_ID", d.get("host_id"), required=False),
            role_arn=_env("CONJUR_ROLE_ARN", d.get("role_arn"), required=False),
            cert_file=_env("CONJUR_CERT_FILE", d.get("cert_file"), required=False),
            ca_cert_content=_env("CONJUR_CA_CERT_CONTENT", d.get("ca_cert_content"), required=False),
            secret_redshift_user=_env(
                "CONJUR_SECRET_REDSHIFT_USER", d.get("secret_redshift_user"), required=False
            ),
            secret_redshift_password=_env(
                "CONJUR_SECRET_REDSHIFT_PASSWORD", d.get("secret_redshift_password"), required=False
            ),
        )


@dataclass(frozen=True)
class AppConfig:
    """Root application configuration assembled from env vars + YAML defaults."""

    redshift: RedshiftConfig
    aws: AwsConfig
    chat_model: ChatModelConfig
    vector_db: VectorDbConfig
    search: SearchConfig
    graph_ontology: Optional[GraphOntologyConfig] = None
    business_catalog: Optional[BusinessCatalogConfig] = None
    conjur: Optional[ConjurConfig] = None
    datasources: Optional[dict] = None  # dict[str, DatasourceConfig]

    @classmethod
    def from_raw(cls, raw: dict) -> "AppConfig":
        graph_ontology_cfg: Optional[GraphOntologyConfig] = None
        if (
            "graph_ontology" in raw
            or os.getenv("GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT")
        ):
            try:
                graph_ontology_cfg = GraphOntologyConfig.from_dict(raw.get("graph_ontology", {}))
            except Exception as exc:
                _log.warning("Graph ontology disabled — config error: %s", exc)

        business_catalog_cfg: Optional[BusinessCatalogConfig] = None
        if (
            "business_catalog" in raw
            or os.getenv("BUSINESS_CATALOG_NEPTUNE_ENDPOINT")
            or os.getenv("GRAPH_ONTOLOGY_NEPTUNE_ENDPOINT")
        ):
            try:
                business_catalog_cfg = BusinessCatalogConfig.from_dict(raw.get("business_catalog", {}))
            except Exception as exc:
                _log.warning("Business catalog config disabled — config error: %s", exc)

        conjur_cfg: Optional[ConjurConfig] = None
        try:
            conjur_cfg = ConjurConfig.from_dict(raw.get("conjur", {}))
        except Exception as exc:
            _log.warning("Conjur config disabled — config error: %s", exc)

        # Datasource registry: "discovery" is always built in legacy mode so it
        # reads the exact same REDSHIFT_* env vars as the original RedshiftConfig
        # above — Discovery Zone behavior is unchanged by this addition. Any
        # other datasources declared under `datasources:` in config.yaml are
        # added alongside it (non-legacy, prefixed env vars).
        raw_datasources = raw.get("datasources", {}) or {}
        datasources_cfg: dict = {
            "discovery": DatasourceConfig.from_dict(
                "discovery", raw_datasources.get("discovery", {}) or {}, legacy=True
            )
        }
        for ds_name, ds_raw in raw_datasources.items():
            if ds_name.lower() == "discovery":
                continue
            try:
                datasources_cfg[ds_name] = DatasourceConfig.from_dict(ds_name, ds_raw or {}, legacy=False)
            except Exception as exc:
                _log.warning("Datasource '%s' config error, skipping: %s", ds_name, exc)

        return cls(
            redshift=RedshiftConfig.from_dict(raw.get("redshift", {})),
            aws=AwsConfig.from_dict(raw.get("AWS_SSO", {})),
            chat_model=ChatModelConfig.from_dict(raw.get("chat_model", {})),
            vector_db=VectorDbConfig.from_dict(raw.get("vector_db", {}), raw.get("Embed_model", {})),
            search=SearchConfig.from_dict(raw.get("search", {})),
            graph_ontology=graph_ontology_cfg,
            business_catalog=business_catalog_cfg,
            conjur=conjur_cfg,
            datasources=datasources_cfg,
        )


# ---------------------------------------------------------------------------
# Singleton — built once at import time
# ---------------------------------------------------------------------------

settings: AppConfig = AppConfig.from_raw(_RAW)
