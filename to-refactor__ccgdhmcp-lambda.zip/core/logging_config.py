"""Centralised logging setup — call configure_logging() once at startup."""

from __future__ import annotations

import io
import logging
import sys


def configure_logging(level: str = "INFO") -> None:
    """Configure root logger with a consistent format.

    Forces UTF-8 on the stdout stream so emoji/Unicode log messages work on
    Windows consoles that default to cp1252.
    """
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # Wrap stdout in a UTF-8 TextIOWrapper so emoji characters don't crash
    # on Windows terminals that use cp1252 (or similar narrow encodings).
    # On AWS Lambda the underlying buffer may be closed when this is called
    # during the handler phase (after INIT-phase wrapping in main.py), so
    # catch ValueError ("I/O operation on closed file") and fall back to
    # sys.stdout as-is.
    try:
        utf8_stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )
    except (AttributeError, ValueError):
        # AttributeError: sys.stdout has no .buffer (e.g. pytest capture)
        # ValueError:     buffer is closed (Lambda handler phase after INIT)
        utf8_stdout = sys.stdout

    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
        stream=utf8_stdout,
        force=True,
    )
    # Silence noisy third-party loggers
    for noisy in ("urllib3", "boto3", "botocore", "httpcore", "httpx"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
