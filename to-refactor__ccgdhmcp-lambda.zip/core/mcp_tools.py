"""Single source of truth for the MCP tool manifest and LLM-facing prompts.

Previously the tool definitions were duplicated across three places
(``lambda_handler._MCP_TOOLS``, ``infrastructure.redshift.mcp_server._TOOLS``
and ``api.routes.tools.TOOL_MANIFEST``) which disagreed on tool count and
parameter names.  Define them ONCE here and derive every other view from it:

  * ``MCP_TOOLS``            — canonical MCP wire format (name/description/inputSchema)
  * ``rest_manifest()``      — simplified view for the REST ``GET /tools`` endpoint
  * ``SYSTEM_PROMPT``        — MCP server system prompt (retrieval-first behaviour)
  * ``BOOK_OF_BUSINESS_INSTRUCTIONS`` — domain reasoning pack injected as schema
                               context for Book-of-Business questions

Tool descriptions are written as *prompts*: they tell the calling LLM when to
use (and not use) each tool, what to pass, and how to preserve user intent.
"""

from __future__ import annotations

from typing import Any, Dict, List

# ---------------------------------------------------------------------------
# Shared prompt fragments (kept DRY across tool descriptions)
# ---------------------------------------------------------------------------

_PRESERVE = (
    "Preserve the user's wording, business entities, account/customer names, "
    "territories, opportunities, dates, filters and metrics EXACTLY — never drop, "
    "rename, simplify or relax them."
)

# ---------------------------------------------------------------------------
# Canonical MCP tool manifest
# ---------------------------------------------------------------------------

MCP_TOOLS: List[Dict[str, Any]] = [
    {
        "name": "get_metadata_context",
        "description": (
            "[HYBRID METADATA: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE GRAPH ONTOLOGY] PRIMARY retrieval "
            "tool for Redshift SQL grounding. Run this FIRST for any business or data question. "
            "PGVector is the source of DAR table/column metadata. The tool searches that data "
            "dictionary first and may enrich the results with relationships from the configured "
            "Neptune graph ontology when graph enrichment is enabled and triggered. "
            "It returns relevant Redshift tables, columns, graph-assisted inferred "
            "JOIN paths (column-name matches, not verified graph relationships), and "
            "business-term→physical-name mappings. "
            "This is NOT raw vector-only search, Neptune graph-schema discovery, business-catalog "
            "retrieval, or data-query execution. "
            "Use it to ground table/column/JOIN choices before generating SQL. "
            "Always use it when the question names an account, customer, book of business, "
            "territory, business unit, opportunity, hierarchy or any relationship. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The user's question, passed through verbatim (required).",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "process_query",
        "description": (
            "[END-TO-END: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE ONTOLOGY + BEDROCK + REDSHIFT] "
            "Natural-language analytics pipeline: metadata retrieval → SQL generation → execution → "
            "answer. Use this when the user asks a data question in natural language and you "
            "want Redshift data and a complete answer in one call. Do NOT use it merely to inspect "
            "the vector store or Neptune schema. Do NOT pre-summarise or rewrite the question — "
            "pass it exactly as the user asked. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's natural-language question, verbatim (required)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "book_of_business",
        "description": (
            "[DOMAIN PIPELINE: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE ONTOLOGY + BEDROCK + REDSHIFT] "
            "Use for Book-of-Business data questions: 'show my book of business', 'what accounts "
            "belong to a book of business', book/territory revenue, trends, performance by "
            "account, growth opportunities, risks and account concentration, relationship or "
            "hierarchy analysis, revenue attribution, and pipeline/opportunity analysis. "
            "Treats Book of Business as a business domain concept (the set of accounts and "
            "opportunities attributed to an owner / territory / business unit) — it resolves "
            "ownership and hierarchy via retrieval and graph enrichment rather than assuming "
            "column names. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's Book-of-Business question, verbatim (required)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "getClientProducts",
        "description": (
            "[DOMAIN PIPELINE: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE ONTOLOGY + BEDROCK + REDSHIFT] "
            "Use for a client's PRODUCT holdings and product analysis: products owned by a "
            "client, product ownership, product penetration, product mix, and product "
            "recommendation scenarios. Supports name-based and ID-based lookup. "
            "Example: 'Show products owned by client John Smith'. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's question, verbatim (required)."},
                "client_name": {"type": "string", "description": "Client full name, if the user named one (optional hint)."},
                "client_id": {"type": "string", "description": "Client identifier, if provided (optional hint)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "getClientPolicies",
        "description": (
            "[DOMAIN PIPELINE: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE ONTOLOGY + BEDROCK + REDSHIFT] "
            "Use for a client's POLICIES and policy analysis: policy lookup, coverage review, "
            "policy relationships, status review (active / inactive / expired / historical), and "
            "policy portfolio analysis. Supports name-based and ID-based lookup and graph "
            "traversal for policy ownership/associations. "
            "Example: 'Show policies for client John Smith'. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's question, verbatim (required)."},
                "client_name": {"type": "string", "description": "Client full name, if the user named one (optional hint)."},
                "client_id": {"type": "string", "description": "Client identifier, if provided (optional hint)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "getClientByDemographics",
        "description": (
            "[DOMAIN PIPELINE: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE ONTOLOGY + BEDROCK + REDSHIFT] "
            "Use to find/analyse clients by DEMOGRAPHIC attributes: age or age ranges, income, "
            "geography/region, household, lifecycle stage, and population analysis. "
            "Example: 'Show clients between 45 and 60 with income above 250K'. "
            "Demographic attributes are resolved dynamically from the retrieved metadata — do "
            "not assume column names. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's demographic question, verbatim (required)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "getClientBySegment",
        "description": (
            "[DOMAIN PIPELINE: PGVECTOR DAR METADATA + OPTIONAL NEPTUNE ONTOLOGY + BEDROCK + REDSHIFT] "
            "Use for customer SEGMENTATION queries: segment-based client retrieval, affluent / "
            "wealth / business segment analysis, segment membership lookups, segment hierarchy "
            "analysis, and segmentation reporting. "
            "Example: 'Show affluent clients in California'. Segment terminology and hierarchy "
            "are resolved via retrieval + graph — do not assume column names. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's segmentation question, verbatim (required)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "generate_sql",
        "description": (
            "[BEDROCK GENERATOR: REDSHIFT SQL; DOES NOT QUERY DATA] Generate a read-only "
            "Redshift SELECT from a natural-language prompt. This tool calls Bedrock only; it "
            "does not search PGVector or Neptune and does not execute SQL. "
            "Call ONLY after get_metadata_context, and pass its schema context as "
            "'schema_context'. Do not invent tables, columns or joins — use only what the "
            "retrieved context provides. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Natural-language question, verbatim (required)."},
                "schema_context": {"type": "string", "description": "Retrieved table/column/JOIN context (optional but strongly recommended)."},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "generate_gremlin",
        "description": (
            "[BEDROCK GENERATOR: NEPTUNE GREMLIN; DOES NOT ACCESS NEPTUNE] Generate a "
            "read-only, bounded Amazon Neptune Gremlin traversal from a "
            "natural-language prompt. Call get_neptune_schema first and pass its relevant "
            "vertex labels, edge labels, properties and connections as a JSON-serialized "
            "'graph_context' string. "
            "This tool generates the traversal only; it does not execute "
            "it. Never invent graph labels, edge labels or properties, and never generate "
            "addV, addE, property, drop, mergeV, mergeE or other mutation steps. " + _PRESERVE
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Natural-language graph question, verbatim (required)."},
                "graph_context": {
                    "type": "string",
                    "description": "JSON-serialized Neptune labels, properties and directed connections from get_neptune_schema (optional but strongly recommended).",
                },
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "get_neptune_schema",
        "description": (
            "[NEPTUNE GRAPH ONTOLOGY ONLY: SCHEMA INSPECTION] Inspect the observed Neptune "
            "graph-ontology shape using fixed, bounded, "
            "read-only traversals. Returns vertex labels, edge labels, properties by "
            "label, and observed directed edge connections without returning vertex IDs "
            "or property values. Call this BEFORE generate_gremlin and pass the relevant "
            "result as graph_context. This tool does NOT search PGVector, query Redshift data, "
            "or retrieve the business semantic catalog. Neptune is schemaless, so results are "
            "sampled and may not represent every label or property."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "vertex_labels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional vertex labels to inspect; omit to discover observed labels.",
                },
                "include_properties": {
                    "type": "boolean",
                    "description": "Include observed vertex property names (default true).",
                },
                "include_edge_properties": {
                    "type": "boolean",
                    "description": "Include observed edge property names (default true).",
                },
                "max_labels": {
                    "type": "integer",
                    "description": "Maximum labels returned (default 25, server cap 100).",
                },
                "max_properties_per_label": {
                    "type": "integer",
                    "description": "Maximum properties per label (default 50, server cap 200).",
                },
                "sample_size": {
                    "type": "integer",
                    "description": "Maximum vertices/edges sampled per traversal (default 100, server cap 1000).",
                },
                "max_connections": {
                    "type": "integer",
                    "description": "Maximum observed directed label connections (default 100, server cap 500).",
                },
            },
            "required": [],
        },
    },
    {
        "name": "query_neptune",
        "description": (
            "[NEPTUNE GRAPH ONTOLOGY ONLY: READ-ONLY GREMLIN EXECUTION] Execute one "
            "read-only, bounded Gremlin traversal against the same Neptune graph ontology "
            "inspected by get_neptune_schema. Use only after get_neptune_schema and "
            "generate_gremlin. The traversal must begin with g.V() or g.E(); mutation steps "
            "and multiple statements are rejected. Results are capped and converted to "
            "JSON-safe values. This tool does NOT access the separate business-catalog "
            "graph, PGVector, or Redshift."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "gremlin": {
                    "type": "string",
                    "description": "Read-only Gremlin traversal to execute (required).",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum results returned (default 100, server cap 500).",
                },
            },
            "required": ["gremlin"],
        },
    },
    {
        "name": "query_redshift",
        "description": (
            "[REDSHIFT DATA ONLY: SQL EXECUTION] Execute a read-only SQL statement "
            "(SELECT / WITH only) against Redshift and "
            "return rows. Use to run SQL produced by generate_sql or hand-verified SQL. "
            "This tool does NOT search PGVector or access either Neptune graph. "
            "Never modify the user's requested filters when constructing the SQL."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "sql": {"type": "string", "description": "SQL statement to execute (required). Must be SELECT or WITH."},
            },
            "required": ["sql"],
        },
    },
    {
        "name": "vector_search",
        "description": (
            "[PGVECTOR ONLY: LOW-LEVEL METADATA SEARCH] Semantic search over the Redshift "
            "data-dictionary vector store, returning raw "
            "column-level matches. Prefer get_metadata_context for question answering; use "
            "this only when you need raw ranked matches (e.g. mapping a single business term "
            "to physical columns). This tool does NOT access Neptune or query Redshift data."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural-language search text (required)."},
                "top_k": {"type": "integer", "description": "Number of results to return (default 5)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "list_tables",
        "description": (
            "[REDSHIFT ONLY: SCHEMA DISCOVERY] List tables from Redshift system metadata in a "
            "schema (or all configured "
            "schemas when omitted). Use to discover table names; do NOT use to answer data "
            "questions. This tool does NOT access PGVector or Neptune."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Schema name (optional)."},
            },
        },
    },
    {
        "name": "describe_table",
        "description": (
            "[REDSHIFT ONLY: SCHEMA DISCOVERY] Return column names, data types and PK/FK "
            "information from Redshift system metadata for a table. Use to inspect a specific "
            "table before writing SQL. This tool does NOT access PGVector or Neptune."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "table_name": {"type": "string", "description": "Table name (required)."},
                "schema_name": {"type": "string", "description": "Schema name (optional)."},
            },
            "required": ["table_name"],
        },
    },
]

# Tool names that trigger the full NL->SQL pipeline rather than a single tool call.
PIPELINE_TOOL_NAMES = {"process_query", "query", "query_pipeline"}
BOOK_OF_BUSINESS_TOOL_NAMES = {"book_of_business"}

# Client-scoped domain tools → RedshiftToolService coroutine method names.
# These are pipeline-style tools (retrieval + graph + SQL + execution) that
# inject a domain instruction pack into the schema context.  The handler
# forwards the whole arguments dict, so optional hints (client_name/client_id)
# reach the service method.
CLIENT_TOOL_METHODS = {
    "getClientProducts":       "get_client_products",
    "getClientPolicies":       "get_client_policies",
    "getClientByDemographics": "get_client_by_demographics",
    "getClientBySegment":      "get_client_by_segment",
}

# ---------------------------------------------------------------------------
# Business catalog tool — appended to MCP_TOOLS (additive, no existing tool changed)
# ---------------------------------------------------------------------------

MCP_TOOLS.append(
    {
        "name": "get_business_catalog_context",
        "description": (
            "[NEPTUNE BUSINESS CATALOG ONLY: ALLOWLISTED SEMANTIC RETRIEVAL] Retrieve business "
            "semantic-layer context from the enterprise catalog graph in Neptune. This business "
            "catalog is separate from the Neptune graph ontology inspected by "
            "get_neptune_schema and used for relationship enrichment by get_metadata_context. "
            "Returns definitions, rules, signals, insights, outcomes, capabilities, "
            "personas, and situation types grounded in the GBS business ontology. "
            "Use this BEFORE reasoning about business terminology, domain governance, "
            "renewal rules, eligibility constraints, opportunity signals, or insight derivation. "
            "Callers should supply an explicit registered intent and agent policy when available; "
            "otherwise intent is inferred from the task text. "
            "Pass the user's refined task verbatim as task. All queries are allowlisted — "
            "this tool never generates free-form Gremlin, searches PGVector, or queries "
            "Redshift data."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "Refined business task or question, verbatim. "
                        "Used for automatic intent inference."
                    ),
                },
                "intent": {
                    "type": "string",
                    "description": "Optional registered semantic intent; preferred over keyword inference.",
                },
                "agent": {
                    "type": "string",
                    "description": "Optional caller agent name used to derive and audit catalog policy routing.",
                },
                "policy_key": {
                    "type": "string",
                    "description": "Optional registered catalog policy key, for example business-planner-v1.",
                },
                "hints": {
                    "type": "object",
                    "description": "Optional identifier hints used for routing only; values are never interpolated into Gremlin.",
                },
                "limits": {
                    "type": "object",
                    "properties": {
                        "max_templates": {"type": "integer"},
                        "max_rows": {"type": "integer"},
                        "template_timeout_ms": {"type": "integer"},
                        "total_timeout_ms": {"type": "integer"},
                    },
                    "description": "Optional lower execution budgets; server and policy caps always apply.",
                },
            },
            "required": ["task"],
        },
    }
)


def rest_manifest() -> List[Dict[str, Any]]:
    """Simplified manifest for the REST ``GET /tools`` discovery endpoint."""
    out: List[Dict[str, Any]] = []
    for t in MCP_TOOLS:
        props = t["inputSchema"].get("properties", {})
        required = set(t["inputSchema"].get("required", []))
        out.append({
            "name": t["name"],
            "description": t["description"],
            "endpoint": f"POST /tools/{t['name']}",
            "input_schema": {
                k: f"{v.get('type', 'string')}"
                   f"{' (required)' if k in required else ' (optional)'}"
                for k, v in props.items()
            },
        })
    return out


# ---------------------------------------------------------------------------
# MCP server system prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are the GDH Redshift MCP analytics server for New York Life. You turn business
questions into safe, read-only Redshift SELECT statements, grounded in retrieved metadata.

NON-NEGOTIABLE RULES
1. Accept the user's question exactly as written. Never drop, rewrite, simplify or
   "relax" account names, customer names, books of business, territories, business
   units, opportunities, industries, regions, dates, filters or metrics.
2. Retrieve before you reason. Always call get_metadata_context first and base every
   table/column/JOIN choice ONLY on what it returns (vector + graph context).
3. Use the graph context: prefer its suggested_joins and business-term->physical
   mappings; never invent joins, tables or columns.
4. Choose retrieval by query type:
   - Simple fact: vector retrieval; add graph only if a relationship is named.
   - Business-concept / relationship / analytical / any query naming an account,
     customer, book of business, territory, owner, hierarchy or opportunity:
     ALWAYS use BOTH vector retrieval AND graph enrichment, then merge.
5. Treat "book of business" as a first-class concept: the set of accounts and
   opportunities attributed to an owner / territory / business unit. Resolve
   ownership and hierarchy via the graph before aggregating revenue / pipeline /
   concentration. Use the book_of_business tool for these questions.
6. Read-only: only SELECT / WITH. Prefer materialized views over external tables.
7. Produce an explainable plan (tables, joins, filters, metrics) before SQL, and
   generate SQL that traces back to the retrieved context.
8. Answer concisely in business terms, but always cite the SQL and the tables used.
"""


# ---------------------------------------------------------------------------
# Book-of-Business domain reasoning pack (injected as schema-context guidance)
# ---------------------------------------------------------------------------

BOOK_OF_BUSINESS_INSTRUCTIONS = """\
-- BUSINESS DOMAIN: BOOK OF BUSINESS --
A "book of business" is the set of ACCOUNTS, POLICIES, PRODUCTS and
OPPORTUNITIES attributed to an owner, territory, or business unit. It spans
MULTIPLE related tables (e.g. client/golden-record, policy, product) — it is
a business concept, not a single table. When answering, use ONLY
tables/columns from the SCHEMA CONTEXT above and:
  * USE EVERY TABLE RETRIEVED IN SCHEMA CONTEXT that is relevant to the
    question — do not answer from a single table (e.g. the client table
    alone) when policy, product, or opportunity tables were also retrieved
    and the question implies that broader scope. A Book-of-Business question
    almost always requires JOINING across client + policy + product
    (or opportunity) tables, not just selecting from the most obviously
    named one.
  * Identify the ownership / territory / business-unit dimension from the retrieved
    columns (look for logical names such as owner, advisor, agent, territory,
    region, business unit) and the account/opportunity fact tables.
  * Use the graph-assisted inferred JOIN paths above if present (these are
    column-name matches, not verified graph relationships — still prefer
    them over inventing your own). If none are listed, use the "Shared
    columns across retrieved tables" hint (if present)
    to join tables on their common key column(s) — e.g. a client id or policy id
    column that appears in more than one retrieved table. Do not invent join
    keys that appear in neither list.
  * PRESERVE any owner, territory, account, customer or date the user named — filter
    to exactly that scope; never widen it.
Sub-intent guidance (apply whichever the user asked for; do not add others):
  * "show my book / accounts in a book"      -> list distinct accounts for the owner/territory scope.
  * "revenue / revenue attribution"           -> SUM revenue grouped by account (and owner/territory).
  * "trends"                                   -> aggregate the metric by time period (month/quarter/year).
  * "performance by account"                   -> per-account metrics, ordered by the requested measure.
  * "growth opportunities / pipeline"          -> OPEN opportunities by stage/amount for the scope.
  * "risks / account concentration"            -> top-N accounts' share of the scope total (concentration).
  * "relationship / hierarchy / customer hierarchy" -> roll up parent/child accounts using the
                                                  graph-provided relationships.
"""


# ---------------------------------------------------------------------------
# Client-scoped domain reasoning packs (injected as schema-context guidance)
# ---------------------------------------------------------------------------
# All packs share the same rules: resolve concepts from the retrieved metadata
# and graph (never assume column names), preserve the user's scope exactly, and
# respect PII/PHI flags surfaced by the graph enricher.

_CLIENT_COMMON = """\
  * Resolve client / customer / household identity from the retrieved metadata
    (look for logical names such as client, customer, party, member, household)
    and filter to EXACTLY the client the user named — never widen the scope.
  * Use the graph-assisted inferred JOIN paths above to connect entities
    (column-name matches, not verified graph relationships); do not invent joins.
  * Respect PII/PHI: do not select sensitive columns unless the user asked for them.
"""

CLIENT_PRODUCTS_INSTRUCTIONS = """\
-- BUSINESS DOMAIN: CLIENT PRODUCTS --
Retrieve the PRODUCTS associated with the client (holdings / ownership).
""" + _CLIENT_COMMON + """\
  * Support name-based and ID-based client lookup (use whichever the user gave).
  * Return product details, product category/type, and ownership information.
  * For penetration / mix analysis, aggregate product counts per client/category.
"""

CLIENT_POLICIES_INSTRUCTIONS = """\
-- BUSINESS DOMAIN: CLIENT POLICIES --
Retrieve the POLICIES associated with the client.
""" + _CLIENT_COMMON + """\
  * Support active, inactive, expired and historical policies; if the user did
    not specify a status, do not filter by status.
  * Use graph relationships when policy ownership/associations require traversal.
  * Return policy metadata (identifiers, type, status, coverage, key dates).
"""

CLIENT_DEMOGRAPHICS_INSTRUCTIONS = """\
-- BUSINESS DOMAIN: CLIENT DEMOGRAPHICS --
Find/analyse clients by DEMOGRAPHIC attributes.
""" + _CLIENT_COMMON + """\
  * Map demographic terms (age, age range, income, geography/region, household,
    lifecycle stage) to physical columns using the business-term mapping above.
  * Preserve every numeric bound and range EXACTLY (e.g. age 45-60, income > 250K).
  * If an attribute is not present in the retrieved metadata, state that clearly
    rather than substituting a different column.
"""

CLIENT_SEGMENT_INSTRUCTIONS = """\
-- BUSINESS DOMAIN: CLIENT SEGMENT --
Retrieve/analyse clients by customer SEGMENT.
""" + _CLIENT_COMMON + """\
  * Identify the segment dimension from the retrieved metadata (look for logical
    names such as segment, tier, affluent, wealth, band) and filter to the exact
    segment(s) the user named (e.g. affluent, wealth, business).
  * Use graph relationships when a segment hierarchy exists (roll up sub-segments).
  * Combine segment with any other scope the user gave (e.g. geography) — keep both.
"""
