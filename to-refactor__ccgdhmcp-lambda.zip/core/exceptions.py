"""Application-wide custom exceptions."""

from __future__ import annotations


class AppError(Exception):
    """Base for all application errors."""


class ConfigurationError(AppError):
    """Raised when required configuration is missing or invalid."""


class RedshiftConnectionError(AppError):
    """Raised when a connection to Redshift cannot be established."""


class RedshiftQueryError(AppError):
    """Raised when a Redshift query fails at runtime."""


class VectorStoreError(AppError):
    """Raised when the vector store is unavailable or returns bad data."""


class LLMError(AppError):
    """Raised when the LLM (Bedrock) call fails."""


class SQLGenerationError(AppError):
    """Raised when the LLM is unable to produce valid SQL."""


class AuthenticationError(AppError):
    """Raised when a token cannot be validated."""
    status_code: int = 401


class ChatbotNotInitializedError(AppError):
    """Raised when a query is received before the chatbot is ready."""
    status_code: int = 503
