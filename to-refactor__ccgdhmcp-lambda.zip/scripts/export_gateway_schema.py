"""Export the AgentCore Gateway inline tool schema from the single source of truth.

The Bedrock AgentCore Gateway target for this Lambda uses an *inline* tool
schema (see the Gateway console → Target → "Target schema: Inline").  That
schema must stay in sync with ``core.mcp_tools.MCP_TOOLS`` — this script
generates it so the two never drift.

The inline payload is a JSON array of tool specs, each::

    { "name": ..., "description": ..., "inputSchema": { JSON Schema } }

which is exactly the shape of ``MCP_TOOLS``.

Usage
-----
    # print to stdout
    python -m scripts.export_gateway_schema

    # write to a file
    python -m scripts.export_gateway_schema -o gateway/tool_schema.json

Paste the output into the Gateway target's inline schema, or feed the file to
``aws bedrock-agentcore ... update-gateway-target`` in your IaC pipeline.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

# Make the repo root importable when run as a plain script (not -m).
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from core.mcp_tools import MCP_TOOLS  # noqa: E402


def build_inline_schema() -> list[dict]:
    """Return the Gateway inline tool-schema payload derived from MCP_TOOLS."""
    schema: list[dict] = []
    for tool in MCP_TOOLS:
        input_schema = tool["inputSchema"]
        # Normalise: ensure every inputSchema is a well-formed object schema.
        if input_schema.get("type") != "object":
            raise ValueError(f"Tool {tool['name']!r} inputSchema must be type=object")
        schema.append({
            "name": tool["name"],
            "description": tool["description"],
            "inputSchema": {
                "type": "object",
                "properties": input_schema.get("properties", {}),
                "required": input_schema.get("required", []),
            },
        })
    return schema


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "-o", "--output",
        help="Write the schema to this file instead of stdout.",
    )
    parser.add_argument(
        "--indent", type=int, default=2,
        help="JSON indentation (default 2; use 0 for compact).",
    )
    args = parser.parse_args(argv)

    schema = build_inline_schema()
    text = json.dumps(schema, indent=args.indent or None, ensure_ascii=False)

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        print(f"Wrote {len(schema)} tool definitions to {args.output}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
