"""One-off Neptune graph-shape discovery — NOT imported by the running service.

``infrastructure/graph_ontology/neptune_enricher.py`` assumes specific
vertex labels (``Table``, ``View``), edge labels (``HAS_OBJECT``,
``HAS_COLUMN``, ``DERIVED_FROM``), and property names (``schema_name``,
``table_name``, ``primary_key_flag``, ``foreign_key_flag``,
``phi_pii_indicator``, ...) carried over from the previous offline
compaction tool's assumptions about this same graph.

Run this script wherever Neptune connectivity is actually available (inside
the VPC / from Lambda) to confirm those assumptions against the live
cluster before depending on them in production. It only *reads* label and
sample-property counts — bounded, capped queries, never a full export.

Usage
-----
::

    python -m scripts.discover_neptune_schema \\
        --endpoint gbs-dev-nexusstudio-gdhmetadata-db-neptune.cluster-ro-cx43s6svxdp2.us-east-1.neptune.amazonaws.com \\
        --region us-east-1
"""

from __future__ import annotations

import argparse
import logging
import sys

from infrastructure.graph_ontology.neptune_client import NeptuneClient

logger = logging.getLogger(__name__)


def discover(client: NeptuneClient) -> None:
    vertex_labels = client.submit("g.V().label().dedup().limit(50)")
    print(f"Vertex labels (up to 50): {vertex_labels}")

    edge_labels = client.submit("g.E().label().dedup().limit(50)")
    print(f"Edge labels (up to 50): {edge_labels}")

    for label in vertex_labels:
        sample = client.submit(f"g.V().hasLabel('{label}').limit(1).valueMap()")
        print(f"\nSample properties for vertex label '{label}':")
        print(sample)

    for label in edge_labels:
        endpoints = client.submit(
            f"g.E().hasLabel('{label}').limit(1)"
            f".project('from_label','to_label').by(outV().label()).by(inV().label())"
        )
        print(f"\nSample endpoints for edge label '{label}': {endpoints}")


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", required=True, help="Neptune reader endpoint hostname")
    parser.add_argument("--port", type=int, default=8182)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--no-iam-auth", action="store_true", help="Disable SigV4 signing")
    args = parser.parse_args(argv)

    client = NeptuneClient(
        endpoint=args.endpoint,
        port=args.port,
        region=args.region,
        iam_auth=not args.no_iam_auth,
    )
    try:
        discover(client)
    finally:
        client.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
